    _   __                ______           ______ 
   / | / /___ _____ ___  / ____/________ _/ __/ /_
  /  |/ / __ `/ __ `__ \/ /   / ___/ __ `/ /_/ __/
 / /|  / /_/ / / / / / / /___/ /  / /_/ / __/ /_  
/_/ |_/\__,_/_/ /_/ /_/\____/_/   \__,_/_/  \__/  
                                                  

Version: NamCraft Beta 1.0.6
For Minecraft Version: Beta 1.7.3
Created By: bracomadar

This document is Copyright �2011 and is the intellectual property of the author, bracomadar. 
It may be not be reproduced under any circumstances except for personal, private use as long as it remains in its 
unaltered, unedited form. It may not be placed on any web site or otherwise distributed publicly without advance written 
permission. Use, or distribution of this Minecraft mod on any other website or as a part of any public display is 
strictly prohibited, and a violation of copyright.

_____________________________________________________________

Installation:

1. Download AudioMod here...

http://www.minecraftforum.net/topic/75440-v173-risugamis-mods-updates/

2. Locate your Minecraft directory.  It should be in...
   C:\Users\(username)\AppData\Roaming\.minecraft, or you can hit Start and then in the search bar, type %appdata% and
   you should be able to find it easily that way. 
3. Make a backup copy of your bin folder and your saves folder. This is so you can easily go back to the way you had the game and
   you won't mess up your current saved games.  
4. Extract the "resources" folder in NamCraft.zip to your .minecraft directory.  You should have a folder named "resources" already 
   there. This is the sound files for NamCraft, so if your sounds don't seem to be working, you probably don't have this installed 
   to the right location.  You'll want to merge this to your existing folder.
5. Open the folder named "Bin" and using WinRar or an equally capable ZIP program, open minecraft.jar.
6. Delete the META-INF folder in that .jar file. (IF YOU DON'T DO THIS, YOU GET A BLACK SCREEN WHEN YOU START!!!)
7. If you haven't done it already, extract all the files from your AudioMod.zip into your minecraft.jar
8. Open up the folder in NamCraft.zip named "MinecraftJar".  Copy ALL the ".class" files, folders, and the .png files and drag them
   to minecraft.jar, being sure to overwrite/replace the existing files.  DO NOT JUST MOVE "MinecraftJar" DIRECTLY INTO minecraft.jar!!!
9. Close minecraft.jar
10.That should be it.  Run Minecraft and try not to get killed :)

_____________________________________________________________

For crafting recipes go to http://namcraft.wikispaces.com/

For more info, to give feedback, or get updates go to http://namcraft.blogspot.com/