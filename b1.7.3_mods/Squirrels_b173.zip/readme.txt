Installation:
(This is written on the premise you know how to get to your minecraft.jar)

1. Backup your minecraft.jar.
2. Delete META-INF.
3. Install ModLoader and Audiomod.
4. Drag the files in the "minecraft" folder into your minecraft.jar
5. Drag the folders in the "resources" folder into /.minecraft/resources/
6. Start up minecraft and play.