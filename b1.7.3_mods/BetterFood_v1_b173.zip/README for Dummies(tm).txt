
--------- README ---------

If there is a folder named 'Source Code' in this archive then the contents of that folder will be the source code for the mod. If you dont know what source code is THEN YOU DONT NEED IT.  Move along grasshopper.

If there is a folder named 'resources' in this archive then THE ENTIRE CONTENTS of that folder need placed inside your .minecraft/resources folder. If you dont know where this is DONT ASK ME.  Use google.

The folder named 'minecraft jar' needs its ENTIRE CONTENTS drug directly inside your minecraft.jar.  This means open it, highlight EVERYTHING THERE INCLUDING ALL FOLDERS, and drag them where you were told.  its that simple.  Dont ask for help if you cant understand this as I will laugh at you.



-------- Lisence ---------

If you are a Modder who updates this mod to a new version of the Minecraft client BEFORE I am able to update it myself, you have the right to redistribute this mod for that ONE client version ONLY. 

If you are a Modder who has made SIGNIFICANT CHANGES to this mod by using the included source code you can redistribute your CHANGED COPY only as long as you also include the source code. You may not distribute a modified copy if it does not include source code for the entire mod. You may not distribute an unmodified version of this mod.

If you want an exception to these limits just ask me. I'll probably say no but you might catch me in a good mood and get lucky. Dont bother PMing me on any forums, I almost never check those.  Use one of these:

email:  Seronis_MC_Mods.uyf@gishpuppy.com
aim:    Seronis
yim:    Seronis

48 hours after a new version of minecraft is released by Mojang, permission is automatically granted to anyone who wants to package or distribute the outdated version of this mod.  This automatic permission NEVER applies to the version of the mod compatible with the most up to date release of Minecraft.

Any situation above that gives you automatic permission to distribute DOES NOT give you permission to profit from that distribution. This means no advertising links that pay per click (like adfly) or any other method. You still MUST get written permission for that. 