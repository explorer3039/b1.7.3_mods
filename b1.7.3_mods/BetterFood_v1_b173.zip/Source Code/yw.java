// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SourceFile


public class yw extends gm
{

    public yw(int i, int j, boolean flag)
    {
        super(i);
        a = j;
        bk = flag;
        bg = 64;
    }

    public iz a(iz iz1, fd fd, gs gs1)
    {
		bg = 64;
		if( (iz1.a > 4 && !(this instanceof qk)) || gs1.Y >= 20 ) {
			return iz1;
		}

        iz1.a--;
        gs1.c(a);
        return iz1;
    }

    public int l()
    {
        return a;
    }

    public boolean m()
    {
        return bk;
    }

    private int a;
    private boolean bk;
}
