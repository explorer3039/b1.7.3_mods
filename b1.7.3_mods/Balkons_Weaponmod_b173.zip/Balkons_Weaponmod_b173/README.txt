Balkon's WeaponMod v5.2.1

How to install:
- Backup your minecraft.jar
- Requires Risagumi's ModLoader, so first install that one.
- Then drag and drop all files into the root of minecraft.jar with a file browser like 7-Zip or WinRar.
- If you're using Xie's Hunger mod, install the file in the Xie's Hungermod patch-folder.
- Delete META-INF if you did not do that already.
- Move the properties file to the .minecraft folder. Edit it for disabling weapons and custom item/entity id's.
- (Optional) Install the HD textures to put them in your texture pack in the right folders or add them to minecraft.jar.
- Enjoy!

If you want Painterly textures, Quandary textures or HD textures in the style of the Faithful32 texture pack,
go to the forum page on http://www.minecraftforum.net/index.php?showtopic=211517 for the downloads.

---------------------------------------------------------------------------------------

Mod and textures made by BalkondeurAlpha!
Crossbow textures made by sismk!
Dynamite texture made by CrazyErik!
HD Halberd textures made by milly_rainbow!

---------------------------------------------------------------------------------------

Changelog v5.2.1
- Minecraft 1.7.3 compatibility.
- Possibly fixed weapons not reloading for some people.

Changelog v5.2
- Minecraft 1.7.2 compatibility.
- Tweaked the flail again.
- Reduced the knockback of the heavy weapons.
- Code improvements.

Changelog v5.1
- Added entity ID's to the properties file, the entities (bullet, javelin, dynamite, etc) are now saved when you quit the game.
- Fixed some flail bugs.
- Fixed the reload time being different on every computer. Reload time is the same as it ever was now.
- Fixed dispensers don't shoot entities.
- Fixed weapons don't get damage when destroying a block.

Changelog v5.0
- Added a new weapon: the flail.
- Fixed some words in the tooltips not beginning with an upper case letter.
- Fixed game crash when shooting a weapon with incompatibility of the EntityPlayer class.
- Due to that, the reload time is slightly longer.

More info about the mod at the forum post on http://www.minecraftforum.net/index.php?showtopic=211517

--------------------------------------------------------------------------------------

TERMS AND CONDITIONS
0. USED TERMS
MOD - modification, plugin, a piece of software that interfaces with the Minecraft client to extend, add, change or remove original capabilities.
MOJANG - Mojang AB
OWNER - Arjen Kremers, Balkondeur, BalkondeurAlpha on minecraftforum.net, Original author of the MOD. Under the copyright terms accepted when purchasing Minecraft (http://www.minecraft.net/copyright.jsp) the OWNER has full rights over their MOD despite use of MOJANG code.
USER - End user of the mod, person installing the mod.

1. LIABILITY
THIS MOD IS PROVIDED 'AS IS' WITH NO WARRANTIES, IMPLIED OR OTHERWISE. THE OWNER OF THIS MOD TAKES NO RESPONSIBILITY FOR ANY DAMAGES INCURRED FROM THE USE OF THIS MOD. THIS MOD ALTERS FUNDAMENTAL PARTS OF THE MINECRAFT GAME, PARTS OF MINECRAFT MAY NOT WORK WITH THIS MOD INSTALLED. ALL DAMAGES CAUSED FROM THE USE OR MISUSE OF THIS MOD FALL ON THE USER.

2. USE
Use of this MOD to be installed, manually or automatically, is given to the USER without restriction.

3. REDISTRIBUTION
This MOD may only be distributed where uploaded, mirrored, or otherwise linked to by the OWNER solely. All mirrors of this mod must have advance written permission from the OWNER. ANY attempts to make money off of this MOD (selling, selling modified versions, adfly, sharecash, etc.) by others than the OWNER are STRICTLY FORBIDDEN, and the OWNER may claim damages or take other action to rectify the situation.

4. DERIVATIVE WORKS/MODIFICATION
This mod is provided freely and may be decompiled and modified for private use, either with a decompiler or a bytecode editor. Public distribution of modified versions of this MOD require advance written permission of the OWNER and may be subject to certain terms.

5. CONTACT
To contact the OWNER about any of the terms mentioned above, send your question to this e-mail adress: arjen.kremers@casema.nl
Or send the OWNER a PM on minecraftforum.net.