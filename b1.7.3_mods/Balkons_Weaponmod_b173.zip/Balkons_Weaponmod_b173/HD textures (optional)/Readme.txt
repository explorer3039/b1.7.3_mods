Place the textures in the right folders of your texture pack or put them in the minecraft.jar file.
The textures are 32x32.
If you want to make some new textures for me, please contact me!

HD textures made by Balkondeur using parts of Gerudoku texture pack and JohnSmith texture pack.
HD halberds made by milly_rainbow.
HD dynamite, blowgun and dart made by legomaniack.