Villager mod for minecraft b1.7.3
by mankini_man

[About]
 Adds new villager NPC.
 They all spawn with randomized name, textures and they do not despawn.

 You can give items by right clicking with it.
 Right click with empty hand to take item back.
 They will drop whatever item they were holding when they die.

 To open rename GUI, sneak + right click. Name can be up to 30 characters.

[Installation]
 Requires Risugami's ModLoader so get and install that first.

 copy .zip archive in /.minecraft/mods/
 copy content of "config" folder into /.minecraft/config/

[Recipe]
 They do not spawn naturally to prevent them filling up mob cap because they never despawn.
 To spawn them, you have to craft spawn egg with three blocks of dirt like this:

 *Temporary placeholder recipe!*

 [#][#][ ]
 [#][ ][ ]
 [ ][ ][ ]

 # = dirt

 You get 8 eggs per crafting.

[Configuration]
 In /.minecraft/config/villagers/ you will find two text files called "male.txt" and "female.txt".
 You can edit these to add your own custom names or modify existing ones.
 Change only applies to newly spawned villagers, so existing dudes will still keep their old names.

[Compatibility]
 Shouldn't conflict with most of the mods.
 It uses item ID 600 for spawn egg by default. (changable by editing .cfg file found in /config/)
 It does not use any of the block IDs or sprite IDs.

[Plan for future]
 More villager variations.
 Proper recipe for spawn egg.
 Village generation.
 Ability to Give Armor.
 Better AI.

[Known issues]
 If you try to give/take usable item (food, egg, snowball etc.), 
 sometimes you might accidentaly use them immediately after doing so. 

 When killed while holding damaged item, they will drop fully repaired one(ignores damage value).

 Sometimes your will be stuck at sneak mode after exiting from GUI menu.
 Hitting sneak key again will fix this.

[History]
 2014/10/04 : v1.2
  +Added nice GUI for renaming and other stuff.
  +Added new function to the AI. If villager is holding item and is set to wander, they will attack zombies on sight and any other mobs who accidentally caused damage.
  +Changed NBT format. No longer compatible with older versions of the mod. Villagers spawned in older versions will simply despawn when you load them.

 2014/09/29 : v1.1
  +Fixed villagers giving back corrupted items.
  +Added config file support.
  +Added waiting function.
  +Added 200 new names which you can edit.

 2014/09/28 : v1.0 Released for minecraft b1.7.3