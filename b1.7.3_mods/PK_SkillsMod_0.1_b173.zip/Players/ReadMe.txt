Installation:

- Download and install ModLoader if you haven't already.
- Drag everything in "To jar" into your minecraft jar (%appdata%/.minecraft/bin/mincraft.jar or your OS's equivalent).
- Copy the contents of "To .minecraft" to your .minecraft folder (used for changing key bindings).
- Delete the META-INF Folder.
- Install a skill pack.
- Enjoy!

Know Conflicts:

- Any mod that edits EntityPlayer (gs.class) or GuiIngame (uq.class).


The main thread is here: http://www.minecraftforum.net/topic/364710-/