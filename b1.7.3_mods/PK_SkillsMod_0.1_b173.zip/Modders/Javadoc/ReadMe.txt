This won't really be of much use since I barely commented on anything.
It would make more sense to just look at the methods to see what they do.

~Paraknight