package net.minecraft.src;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.Properties;
import java.util.Random;
import net.minecraft.src.skillsMod.*;
import net.minecraft.src.skillsMod.Skill.SkillType;
import net.minecraft.src.skillsMod.GuiSkillIngame.GuiSkillGet;
import net.minecraft.client.Minecraft;

public class mod_Skills extends BaseMod {
	public static final int skillInvLimit = 80;
	public static final int skillBarLimit = 5;
	private Minecraft game = ModLoader.getMinecraftInstance();
	public KeyBinding skillGuiKeyBinding, skillKeyBindings[] = new KeyBinding[skillBarLimit];
	public boolean showSkillGet = false;
	public ItemStack skillGetSkill;
	public InventorySkills skillInvBackup;
	public GuiSkillIngame guiSkillIngame = new GuiSkillIngame(game);
	public GuiSkillGet guiSkillGet = guiSkillIngame.new GuiSkillGet(game);
	public SpellList spellList = new SpellList();
	private World currentWorld;
	
	public mod_Skills() {
		loadSkillKeyBindings();
		ModLoader.SetInGUIHook(this, true, false);
		ModLoader.SetInGameHook(this, true, false);
	}
	
	@Override
	public String Version() {
		return "beta for 1.7.3";
	}
	
	@Override
	public boolean OnTickInGame(Minecraft game) {
		game.thePlayer.skillInv.decrementAnimations();
		updateAllSpells();
		for (int i = 0; i < skillBarLimit; i++) {
			ItemStack skill = game.thePlayer.skillInv.getStackInSlot(
					(skillInvLimit - skillBarLimit) + i);
			if(skill!=null)
				((Skill) skill.getItem()).beingUsed = false;
		}
		return true;
	}
	
	@Override
	public void KeyboardEvent(KeyBinding keybinding) {
		ItemStack skillStack = null;
		for (int i = 0; i < skillBarLimit; i++) {
			skillStack = game.thePlayer.skillInv.getStackInSlot(
					(skillInvLimit - skillBarLimit) + i);
			if (keybinding == skillKeyBindings[i]) {
				Skill skill=null;
				if (skillStack != null
						&& game.thePlayer.energy >= (skill=((Skill) (skillStack.getItem()))).getEnergyExpenditure()
						&& skill.cooldownTimer==8
						&& !game.theWorld.multiplayerWorld) {
					if(guiSkillIngame.getChargeupFrame()<100) {
						cancelCurrentSkill(guiSkillIngame.getChargeupSkill());
						skill.beingUsed = false;
					} else {
						skill.beingUsed = true;
						triggerSkillUse(i,skill);
					}
				} else if(skill!=null&&skill.skillType==SkillType.ACTIVE){
				} else
					game.theWorld.playSoundAtEntity(game.thePlayer, "note.bass", 1.0F, 0F);
			}
		}
		if(keybinding == skillGuiKeyBinding)
			if(game.currentScreen == null)
				ModLoader.OpenGUI(game.thePlayer, new GuiSkillInv(game.thePlayer.skillSlots));
			else
				game.thePlayer.closeScreen();
		// game.thePlayer.respawnPlayer();
	}
	
	
	//Loading and updating bound keys.
	private int getProp(String property, String defValue) {
		int value=Integer.parseInt(defValue);
		FileInputStream propFile = null;
		Properties skillProps = new Properties();
		try {
			propFile = new FileInputStream(Minecraft.getMinecraftDir().toString()+"/SkillsMod.properties");
			skillProps.load(propFile);
			value=Integer.parseInt(skillProps.getProperty(property, defValue));
		} catch (Exception e){
		} finally {
			if(propFile!=null)
				try {propFile.close();} catch (IOException e){}
		}
		return value;
	}

	public void loadSkillKeyBindings() {
		skillGuiKeyBinding = new KeyBinding("key.skillGui", getProp("SkillGUI", "37"));
		ModLoader.RegisterKey(this, skillGuiKeyBinding, false);
		for (int i = 0; i < skillBarLimit; i++)
			skillKeyBindings[i] = new KeyBinding("key.skill" + (i + 1), getProp("Skill"+(i+1), Integer.toString(44+i)));
		updateKeyBindingTypes();
	}
	
	public void updateKeyBindingTypes() {
		for (int i = 0; i < skillBarLimit; i++) {
			if(game.thePlayer==null || game.thePlayer.skillInv==null)
				return;
			ItemStack skillStack;
			if((skillStack = game.thePlayer.skillInv.getStackInSlot(skillInvLimit-skillBarLimit+i))==null)
				continue;
			Skill skill = (Skill) skillStack.getItem();
			if(skill != null && skill.skillType == SkillType.ACTIVE)
				ModLoader.RegisterKey(this, skillKeyBindings[i], true);
			else
				ModLoader.RegisterKey(this, skillKeyBindings[i], false);
		}
	}

	
	public static mod_Skills getSkillsModInstance() {
		Object mod = null;
		Iterator itr = ModLoader.getLoadedMods().iterator();
		while (itr.hasNext()) {
			mod = itr.next();
			if (mod instanceof mod_Skills) {
				return (mod_Skills) mod;
			}
		}
		return null;
	}

	/**
	 * Spawns a skill entity at the position of any entity.
	 * This is most likely used in an entity's onDeath() method.
	 * @param skill
	 * @param entity
	 */
	public static void spawnSkill(Skill skill, Entity entity) {
		mod_Skills.spawnSkill(skill, entity.posX, entity.posY, entity.posZ);
	}

	/**
	 * Spawns a skill entity at a given position.
	 * This method can be called from anywhere at any event.
	 * @param skill
	 * @param posX
	 * @param posY
	 * @param posZ
	 */
	public static void spawnSkill(Skill skill, double posX, double posY, double posZ) {
		World world = ModLoader.getMinecraftInstance().theWorld;
		EntitySkill entitySkill = new EntitySkill(
				world,posX,posY,posZ,new ItemStack(skill.shiftedIndex, 1, 0));
		entitySkill.delayBeforeCanPickup = 0;
		world.entityJoinedWorld(entitySkill);
	}
	
	/**
	 * Teaches the player a new skill.
	 * This method can be called from anywhere at any event.
	 * @param skill
	 * @return
	 */
	public static boolean learnSkill(Skill skill) {
		return mod_Skills.getSkillsModInstance().learn(skill);
	}
	
	public boolean learn(Skill skill) {
		ItemStack skillStack = new ItemStack(skill);
		if (game.thePlayer.skillInv.getInventorySlotContainItem(skill.shiftedIndex) != -1
				|| game.theWorld.multiplayerWorld) {
			return false;
		}
		if (game.thePlayer.skillInv.addItemStackToInventory(skillStack)) {
			Random rand = new Random();
			ModLoader.OnItemPickup(game.thePlayer, skillStack);
			game.theWorld.playSoundAtEntity(game.thePlayer,"note.snare",0.2F,((rand.nextFloat() - rand.nextFloat()) * 0.7F + 1.0F) * 2.0F);
			displaySkillGet(skillStack);
			return true;
		}
		return false;
	}
	
	public void displaySkillGet(ItemStack skill) {
		skillGetSkill = skill;
		showSkillGet = true;
	}
	
	/**
	 * Triggers a given skill if the player knows it.
	 * The use of this method is rare.
	 * @param skill
	 */
	public static void triggerSkill(Skill skill) {
		mod_Skills.getSkillsModInstance().trigger(skill);
	}
	
	public void trigger(Skill skill)
    {
		if(skill==null || game.thePlayer.skillInv.getInventorySlotContainItem(skill.shiftedIndex) == -1
				|| game.theWorld.multiplayerWorld)
            return;
		int slot=game.thePlayer.skillInv.getInventorySlotContainItem(skill.shiftedIndex)-(skillInvLimit-skillBarLimit);
		if (game.thePlayer.energy >= skill.getEnergyExpenditure()
				&& skill.cooldownTimer==8) {
			if(guiSkillIngame.getChargeupFrame()<100) {
				cancelCurrentSkill(guiSkillIngame.getChargeupSkill());
				skill.beingUsed = false;
			}
			else {
				skill.beingUsed = true;
				triggerSkillUse(slot,skill);
			}
		} else
			game.theWorld.playSoundAtEntity(game.thePlayer, "note.bass", 1.0F, 0F);
	}
	
	private void triggerSkillUse(int slot, Skill skill) {
		if((skill.skillType==SkillType.ENCHANTMENT)
				&&(game.thePlayer.inventory.getCurrentItem()==null
				||game.thePlayer.inventory.getCurrentItem().getItem()!=skill.boundItem)) {
			game.theWorld.playSoundAtEntity(game.thePlayer, "note.bass", 1.0F, 0F);
			return;
		}
		if((skill.skillType==SkillType.CHANNELING||skill.skillType==SkillType.ENCHANTMENT)) {
			int itemCount=0;
			for (int i=0;i<game.thePlayer.inventory.mainInventory.length;i++) {
				if(game.thePlayer.inventory.mainInventory[i]!=null
						&&game.thePlayer.inventory.mainInventory[i].itemID==skill.boundConsumable.shiftedIndex)
					itemCount+=game.thePlayer.inventory.mainInventory[i].stackSize;
			}
			if(itemCount>=skill.consumableAmount) {
				for (int i=0;i<skill.consumableAmount;i++)
					game.thePlayer.inventory.consumeInventoryItem(skill.boundConsumable.shiftedIndex);
				skill.chargeup(game, slot);
				return;
			} else {
				game.theWorld.playSoundAtEntity(game.thePlayer, "note.bass", 1.0F, 0F);
				return;
			}
		}
		skill.chargeup(game, slot);
	}
	
	private void cancelCurrentSkill(Skill skill) {
		game.theWorld.playSoundAtEntity(game.thePlayer, "note.bass", 1.0F, 0F);
		skill.cancelCharge();
		if(game.thePlayer!=null&&skill.boundConsumable!=null)
			game.thePlayer.inventory.addItemStackToInventory(new ItemStack(skill.boundConsumable,skill.consumableAmount));
	}
	
	private void updateAllSpells() {
		if(spellList.isEmpty())
			return;
		Iterator itr = spellList.activeSpells.iterator();
		Spell spell;
		while (itr.hasNext()) {
			spell = (Spell) itr.next();
			spell.beingUsed = true;
			spell.onTick(game);
		}
	}
	
	public void updateCooldownGUI() {
		ItemStack skillStack;
		for(int slot=0;slot<skillBarLimit;slot++) {
			skillStack=game.thePlayer.skillInv.getStackInSlot(slot+(skillInvLimit-skillBarLimit));
			if(skillStack!=null)
				guiSkillIngame.updateCooldownGUI(((Skill)skillStack.getItem()).cooldownTimer, slot);
			else
				guiSkillIngame.updateCooldownGUI(8, slot);
		}
	}

	public void setCurrentWorld(World world) {
		if(world != currentWorld)
			skillInvBackup=null;
		currentWorld = world;
	}
}