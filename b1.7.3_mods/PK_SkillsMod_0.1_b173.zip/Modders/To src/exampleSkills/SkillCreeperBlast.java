package net.minecraft.src.exampleSkills;

import net.minecraft.src.*;
import net.minecraft.src.skillsMod.Skill;
import net.minecraft.client.Minecraft;

public class SkillCreeperBlast extends Skill {

    public SkillCreeperBlast(int id, int expendAmount, float chargeup, float cooldown, boolean pressAndHold) {
        super(id, expendAmount, chargeup, cooldown);
    }
    
	public boolean useSkill(Minecraft theGame) {
		EntityPlayer entityplayer = theGame.thePlayer;
    	World world = theGame.theWorld;
    	
    	world.createExplosion(entityplayer, entityplayer.posX, entityplayer.posY, entityplayer.posZ, 3F);
    	
    	return skillUsed;
    }
	
}
