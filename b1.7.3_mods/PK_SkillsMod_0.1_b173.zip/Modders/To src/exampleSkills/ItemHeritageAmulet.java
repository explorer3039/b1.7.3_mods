package net.minecraft.src.exampleSkills;

import net.minecraft.src.*;

public class ItemHeritageAmulet extends Item {

	public ItemHeritageAmulet(int i) {
		super(i);
		maxStackSize = 1;
	}

	public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer entityplayer) {
		mod_Skills.triggerSkill(mod_ExampleSkills.bindingSignet);
		return itemstack;
	}

}