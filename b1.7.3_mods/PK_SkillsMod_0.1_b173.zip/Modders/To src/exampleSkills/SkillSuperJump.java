package net.minecraft.src.exampleSkills;

import net.minecraft.src.*;
import net.minecraft.src.skillsMod.Skill;
import net.minecraft.client.Minecraft;

public class SkillSuperJump extends Skill {

    public SkillSuperJump(int id, int expendAmount, float chargeup, float cooldown, boolean pressAndHold) {
        super(id, expendAmount, chargeup, cooldown);
    }

	public boolean useSkill(Minecraft theGame) {
		superJump(theGame.thePlayer);
		return skillUsed;
	}

	private void superJump(EntityPlayer player) {
		boolean flag = player.handleWaterMovement();
		boolean flag1 = player.handleLavaMovement();
		if (flag)
			player.motionY += 0.41999998688697815D;
		else if (flag1)
			player.motionY = 0.41999998688697815D;
		else if (player.onGround)
			player.motionY = 0.41999998688697815D * 2;
	}

}