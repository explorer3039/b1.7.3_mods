package net.minecraft.src.exampleSkills;

import net.minecraft.src.EntityPlayer;
import net.minecraft.src.Item;
import net.minecraft.src.ItemStack;
import net.minecraft.src.World;

public class ItemManaPotion extends Item {
	
	private int restAmount;
	
	public ItemManaPotion(int id, int restAmount) {
        super(id);
        maxStackSize = 1;
		this.restAmount = restAmount;
    }

	public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer entityplayer) {
		if (entityplayer.energy < 20 && !world.multiplayerWorld) {
			entityplayer.rest(restAmount);
			itemstack.stackSize--; //Keep this if you want the item to be consumed.

			/*
			 * Add whatever else this item does. If it's a tool, you might as
			 * well just add this stuff to something that extends ItemTool etc.
			 */
		}
		return itemstack;
	}
}