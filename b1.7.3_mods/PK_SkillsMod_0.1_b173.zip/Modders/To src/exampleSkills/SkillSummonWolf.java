package net.minecraft.src.exampleSkills;

import net.minecraft.src.*;
import net.minecraft.src.skillsMod.Skill;
import net.minecraft.client.Minecraft;

public class SkillSummonWolf extends Skill {

    public SkillSummonWolf(int id, int expendAmount, float chargeup, float cooldown, boolean pressAndHold) {
        super(id, expendAmount, chargeup, cooldown);
    }
    
	public boolean useSkill(Minecraft theGame) {
    	EntityPlayer entityplayer = theGame.thePlayer;
    	World world = theGame.theWorld;
    	world.playSoundAtEntity(entityplayer, "mob.ghast.fireball", 1.0F, 1.0F / (itemRand.nextFloat() * 0.4F + 0.8F));
    	EntityWolf entitywolf = new EntityWolf(world);
    	entitywolf.setLocationAndAngles(entityplayer.posX, entityplayer.posY, entityplayer.posZ, entityplayer.rotationYaw, entityplayer.rotationPitch);
    	entitywolf.spawnExplosionParticle();
    	entitywolf.setWolfTamed(true);
    	entitywolf.setPathToEntity(null);
    	entitywolf.health = 20;
    	entitywolf.setWolfOwner(entityplayer.username);
    	world.func_9425_a(entitywolf, (byte)7);
    	world.entityJoinedWorld(entitywolf);
    	return skillUsed;
    }
}