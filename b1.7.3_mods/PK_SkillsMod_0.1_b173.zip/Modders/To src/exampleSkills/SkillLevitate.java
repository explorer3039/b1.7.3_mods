package net.minecraft.src.exampleSkills;

import net.minecraft.src.*;
import net.minecraft.src.skillsMod.Skill;
import net.minecraft.client.Minecraft;


public class SkillLevitate extends Skill {

    public SkillLevitate(int id, int expendAmount, float chargeup, float cooldown, boolean pressAndHold) {
        super(id, expendAmount, chargeup, cooldown);
    }
    
	public boolean useSkill(Minecraft theGame) {
    	EntityPlayer entityplayer = theGame.thePlayer;
    	entityplayer.addVelocity(0.0D, 0.1D, 0.0D);
    	return skillUsed;
    }
}