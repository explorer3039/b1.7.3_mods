package net.minecraft.src.exampleSkills;

import net.minecraft.src.*;
import net.minecraft.src.skillsMod.Skill;
import net.minecraft.client.Minecraft;

public class SkillBindingSignet extends Skill {

	public SkillBindingSignet(int id, int expendAmount, float chargeup, float cooldown) {
        super(id, expendAmount, chargeup, cooldown);
    }

	public boolean useSkill(Minecraft game) {
		EntityPlayer player = game.thePlayer;
		World world = game.theWorld;
    	if(!world.multiplayerWorld && !world.worldProvider.canRespawnHere())
    		game.usePortal();
    	ChunkCoordinates chunkcoordinates = world.getSpawnPoint();
    	int x=chunkcoordinates.x;
    	int y=chunkcoordinates.y;
    	int z=chunkcoordinates.z;
    	while(!world.isAirBlock(x, y, z))y++; //So you don't spawn in the floor.
    	player.setPosition((float)x, (float)y+2.0F, (float)z);
    	world.playSoundAtEntity(player, "mob.ghast.fireball", 1.0F, 1.0F / (itemRand.nextFloat() * 0.4F + 0.8F));
    	return skillUsed;
    }
}