package net.minecraft.src.exampleSkills;

import java.util.LinkedList;
import net.minecraft.src.*;
import net.minecraft.src.skillsMod.*;

public class ItemSkillBook extends Item {
	
	private LinkedList<Skill> skills = new LinkedList<Skill>();

	public ItemSkillBook(int i) {
		super(i);
		maxStackSize = 1;
	}

	public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer entityplayer) {
		int learnt=0;
		if (!world.multiplayerWorld) {
			//mod_Skills.spawnSkill(mod_ExampleSkills.creeperBlast, entityplayer);
			for (Skill skill : skills)
				learnt += mod_Skills.learnSkill(skill)?1:0;
			if(learnt>0)
				itemstack.stackSize--;
		}
		return itemstack;
	}
	
	public ItemSkillBook addSkill(Skill skill) {
		skills.add(skill);
		return this;
	}

}