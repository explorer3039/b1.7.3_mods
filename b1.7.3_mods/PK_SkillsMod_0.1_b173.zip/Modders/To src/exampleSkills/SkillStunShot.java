package net.minecraft.src.exampleSkills;

import net.minecraft.src.*;
import net.minecraft.src.skillsMod.Skill;
import net.minecraft.client.Minecraft;


public class SkillStunShot extends Skill {
	
    public SkillStunShot(int id, int expendAmount, float chargeup, float cooldown, boolean pressAndHold) {
        super(id, expendAmount, chargeup, cooldown);
    }
    
	public boolean useSkill(Minecraft theGame) {
		EntityPlayer entityplayer = theGame.thePlayer;
    	World world = theGame.theWorld;
    	world.playSoundAtEntity(entityplayer, "random.bow", 1.0F, 1.0F / (itemRand.nextFloat() * 0.4F + 0.8F));
    	world.entityJoinedWorld(new EntityStunArrow(world, entityplayer));
    	return skillUsed;
    }
}