package net.minecraft.src.exampleSkills;

import java.util.Random;
import net.minecraft.src.*;
import net.minecraft.src.skillsMod.Spell;
import net.minecraft.client.Minecraft;

public class SpellHealingBreeze extends Spell {
	
	private Random rand = new Random();
	
    public SpellHealingBreeze(int id, int expendAmount, float chargeup, float cooldown, float duration) {
		super(id, expendAmount, chargeup, cooldown, duration);
	}

	public boolean useSkill(Minecraft theGame)
    {
		//You can still use this.
    	return skillUsed;
    }
	
	protected boolean onSpellStart(Minecraft theGame) {
		if(theGame.thePlayer.health<4)
			theGame.thePlayer.heal(4);
		return spellActivated;
	}

	protected void onSpellEnd(Minecraft theGame) {
	}
	
	public void onTick(Minecraft theGame){
		EntityPlayer player = theGame.thePlayer;
		if(player.health<20 && rand.nextFloat()>0.9 && rand.nextFloat()>0.5)
			theGame.thePlayer.heal(1);
	}
}
