package net.minecraft.src.skillsMod;

import java.util.Iterator;
import org.lwjgl.opengl.GL11;
import net.minecraft.src.*;
import net.minecraft.client.Minecraft;

public class GuiSkillIngame {

	private int texX;
	private int texY;
	private int sizeX;
	private int sizeY;
	private int posX;
	private int posY;
	private int width;
	private int height;
	private int chargeupFrame;
	private int cooldownFrames[];
	private Skill chargeupSkill;
	private Minecraft game;
	private static RenderItem itemRenderer = new RenderItem();

	public GuiSkillIngame(Minecraft game) {
		this.game = game;
		ScaledResolution scaledresolution = new ScaledResolution(
				game.gameSettings, game.displayWidth, game.displayHeight);
		width = scaledresolution.getScaledWidth();
		height = scaledresolution.getScaledHeight();
		texX = 104;
		texY = 0;
		sizeX = 22;
		sizeY = 102;
		posX = width - sizeX;
		posY = (height-sizeY)/2;
		cooldownFrames = new int[mod_Skills.skillBarLimit];
		chargeupFrame = 100;
		chargeupSkill = null;
		for (int i = 0; i < cooldownFrames.length; i++)
			cooldownFrames[i] = 8;
	}
	
	public void renderSkillHUD(float f) {
		//game.ingameGUI.addChatMessage("Still rendering " + o++);
		//GL11.glBlendFunc(775, 769); Inverts everything.
		//if(!game.skipRenderWorld && !game.gameSettings.hideGUI) {
			//game.entityRenderer.func_905_b();
		ScaledResolution scaledresolution = new ScaledResolution(
				game.gameSettings, game.displayWidth, game.displayHeight);
		width = scaledresolution.getScaledWidth();
		height = scaledresolution.getScaledHeight();
		posX = width - sizeX;
		posY = (height-sizeY)/2;
		renderSkillBar();
		renderSkillsInBar(f);
		renderCooldownGUI();
		renderChargeupGUI();
		renderSpellGUI();
		//}
		//if (game.currentScreen != null) {
		//game.ingameGUI.drawGradientRect(0, 0, width, height, 0xc0101010, 0xd0101010);
		//}
	}

	private void renderSkillBar() {
		GL11.glEnable(3042 /*GL_BLEND*/);
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		GL11.glBindTexture(3553, game.renderEngine.getTexture("/net/minecraft/src/skillsMod/textures/skillgui.png"));
		game.ingameGUI.drawTexturedModalRect(posX, posY, texX, texY, sizeX, sizeY);
		GL11.glDisable(3042 /*GL_BLEND*/);
	}

	private void renderSkillsInBar(float f) {
		GL11.glEnable(32826 /*GL_RESCALE_NORMAL_EXT*/);
        GL11.glPushMatrix();
        GL11.glRotatef(120F, 1.0F, 0.0F, 0.0F);
        RenderHelper.enableStandardItemLighting();
        GL11.glPopMatrix();
        for (int i = 0; i < mod_Skills.skillBarLimit; i++)
        	renderSkillSlot(mod_Skills.skillInvLimit
		        			- mod_Skills.skillBarLimit + i, posX
		        			+ ((sizeX - 16) / 2), posY + sizeY - 22
		        			+ ((22 - 16) / 2) - (i * 20),f);
        RenderHelper.disableStandardItemLighting();
        GL11.glDisable(32826 /*GL_RESCALE_NORMAL_EXT*/);
	}

	private void renderSkillSlot(int i, int j, int k, float f) {
		ItemStack itemstack = game.thePlayer.skillInv.getStackInSlot(i);
		if (itemstack == null)
			return;
		float f1 = itemstack.animationsToGo - f;
		if (f1 > 0.0F) {
			GL11.glPushMatrix();
            float f2 = 1.0F + f1 / 5F;
            GL11.glTranslatef(j + 8, k + 12, 0.0F);
            GL11.glScalef(1.0F / f2, (f2 + 1.0F) / 2.0F, 1.0F);
            GL11.glTranslatef(-(j + 8), -(k + 12), 0.0F);
		}
		itemRenderer.renderItemIntoGUI(game.fontRenderer, game.renderEngine,
				itemstack, j, k);
		if (f1 > 0.0F)
			GL11.glPopMatrix();
	}

	public void updateCooldownGUI(int cooldownFrame, int slot) {
		cooldownFrames[slot] = cooldownFrame;
	}
	
	public void updateChargeupGUI(int chargeupFrame, Skill skill) {
		this.chargeupFrame = chargeupFrame;
		this.chargeupSkill = skill;
	}
	
	private void renderCooldownGUI() {
		for (int i = 0; i < cooldownFrames.length; i++) {
			if(cooldownFrames[i]>7)
				continue;
			GL11.glEnable(3042 /*GL_BLEND*/);
            GL11.glDisable(2929 /*GL_DEPTH_TEST*/);
            RenderHelper.enableStandardItemLighting();
			GL11.glBindTexture(3553, game.renderEngine.getTexture("/net/minecraft/src/skillsMod/textures/skillgui.png"));
			game.ingameGUI.drawTexturedModalRect(posX+3, posY+83-(i*20), 126, cooldownFrames[i]*16, 16, 16);
			GL11.glDisable(3042 /*GL_BLEND*/);
			GL11.glEnable(2929 /*GL_DEPTH_TEST*/);
			RenderHelper.disableStandardItemLighting();
		}
	}
	
	private void renderChargeupGUI() {
		if(chargeupFrame>99)
			return;
		GL11.glEnable(3042 /*GL_BLEND*/);
		//RenderHelper.enableStandardItemLighting();
		GL11.glBindTexture(3553, game.renderEngine.getTexture("/net/minecraft/src/skillsMod/textures/skillgui.png"));
		game.ingameGUI.drawTexturedModalRect((width-104)/2, height-(height/5)-(10/2), 0, 130, 104, 10);
		game.ingameGUI.drawTexturedModalRect((width-100)/2, height-(height/5)-(8/2), 0, 140, chargeupFrame+1, 8);
		drawSkillName();
		GL11.glDisable(3042 /*GL_BLEND*/);
		//RenderHelper.disableStandardItemLighting();
	}

	private void renderSpellGUI() {
		SpellList spellList = mod_Skills.getSkillsModInstance().spellList;
		if(spellList.isEmpty())
			return;
		
		Iterator itr = spellList.activeSpells.iterator();
		Spell spell;
		for(int i=0;itr.hasNext();i++) {
			int x = ((width-22-((spellList.size()-1)*22))/2)+(22*i);
			spell = (Spell) itr.next();
			GL11.glBindTexture(3553, game.renderEngine.getTexture("/net/minecraft/src/skillsMod/textures/skillgui.png"));
			renderSpellBox(x);
			RenderHelper.enableStandardItemLighting();
			renderSpells(spell, x, spellList.size());
			GL11.glDisable(2896 /*GL_LIGHTING*/);
            GL11.glDisable(2929 /*GL_DEPTH_TEST*/);
            game.fontRenderer.drawStringWithShadow((new StringBuilder()).append("").append(String.valueOf(spell.timeLeft)).toString(), x + 17 - game.fontRenderer.getStringWidth(String.valueOf(spell.timeLeft)), 9, 0xffffff);
            GL11.glEnable(2896 /*GL_LIGHTING*/);
            GL11.glEnable(2929 /*GL_DEPTH_TEST*/);
            RenderHelper.disableStandardItemLighting();
		}
	}

	private void renderSpellBox(int x) {
		GL11.glEnable(3042 /*GL_BLEND*/);
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		game.ingameGUI.drawTexturedModalRect(x, 0, 103, 102, 22, 20);
		// TODO Fix texture.
		GL11.glDisable(3042 /*GL_BLEND*/);
	}
	
	private void renderSpells(Spell spell, int x, int i) {
		GL11.glEnable(32826 /*GL_RESCALE_NORMAL_EXT*/);
		GL11.glPushMatrix();
		GL11.glRotatef(120F, 1.0F, 0.0F, 0.0F);
		RenderHelper.enableStandardItemLighting();
		GL11.glPopMatrix();
		itemRenderer.renderItemIntoGUI(game.fontRenderer, game.renderEngine, new ItemStack(spell), x+3, 2);
		RenderHelper.disableStandardItemLighting();
		GL11.glDisable(32826 /*GL_RESCALE_NORMAL_EXT*/);
	}

	private void drawSkillName() {
		String skillName = StringTranslate.getInstance()
		.translateNamedKey(chargeupSkill.getItemName());
		game.fontRenderer.drawStringWithShadow(skillName, (width-((skillName.length()+1)*5))/2,
				height-(height/5)-(8/2), 0xFFFFFF);
	}

	public int getCooldownFrame(int i) {
		return cooldownFrames[i];
	}
	
	public int getChargeupFrame() {
		return chargeupFrame;
	}
	
	public void resetChargeupFrame() {
		chargeupFrame=100;
	}

	public Skill getChargeupSkill() {
		return chargeupSkill;
	}
	
	public class GuiSkillGet {
		private int texX;
		private int texY;
		private int sizeX;
		private int sizeY;
		private int posX;
		private int posY;
		private int offset;
		private int timer;
		private int showGetDuration;
		private Minecraft game;
		private StringTranslate st;
		private RenderItem itemRenderer = new RenderItem();

		public GuiSkillGet(Minecraft game) {
			super();
			this.game = game;
			st = StringTranslate.getInstance();
			ScaledResolution scaledresolution = new ScaledResolution(
					game.gameSettings, game.displayWidth, game.displayHeight);
			int width = scaledresolution.getScaledWidth();
			int height = scaledresolution.getScaledHeight();
			texX = 0;
			texY = 98;
			sizeX = 104;
			sizeY = 32;
			posX = (width*3/4)-(sizeX/2);
			posY = (height-sizeY)/2;
			offset = 0;
			showGetDuration = 50;
			timer = showGetDuration;
		}

		public void updateSkillGet(ItemStack skill) {
			ScaledResolution scaledresolution = new ScaledResolution(
					game.gameSettings, game.displayWidth, game.displayHeight);
			int width = scaledresolution.getScaledWidth();
			int height = scaledresolution.getScaledHeight();
			posX = (width*3/4)-(sizeX/2);
			posY = (height-sizeY)/2;
			if(timer>=0) {
				if(timer%5==0)
					offset++;
				game.entityRenderer.func_905_b();
				GL11.glEnable(3042 /*GL_BLEND*/);
				GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
				GL11.glBindTexture(3553, game.renderEngine.getTexture("/net/minecraft/src/skillsMod/textures/skillgui.png"));
				game.ingameGUI.drawTexturedModalRect(posX, posY - offset, texX, texY, sizeX, sizeY);
				game.fontRenderer.drawStringWithShadow("Skill Learnt:", posX + 30, posY + 7 - offset, -256);
				game.fontRenderer.drawStringWithShadow(st.translateNamedKey(skill.getItemName()), posX + 30, posY + 18 - offset, -1);
				GL11.glDisable(3042 /*GL_BLEND*/);
				GL11.glEnable(32826 /*GL_RESCALE_NORMAL_EXT*/);
		        GL11.glPushMatrix();
		        GL11.glRotatef(120F, 1.0F, 0.0F, 0.0F);
		        RenderHelper.enableStandardItemLighting();
		        GL11.glPopMatrix();
		        itemRenderer.renderItemIntoGUI(game.fontRenderer, game.renderEngine,
		        		skill, posX+(sizeX/8), posY+(sizeY/2)-8 - offset);
				RenderHelper.disableStandardItemLighting();
		        GL11.glDisable(32826 /*GL_RESCALE_NORMAL_EXT*/);
				timer--;
			}
			if(timer<0) {
				offset = 0;
				timer=showGetDuration;
				mod_Skills.getSkillsModInstance().showSkillGet = false;
			}
		}

	}
}
