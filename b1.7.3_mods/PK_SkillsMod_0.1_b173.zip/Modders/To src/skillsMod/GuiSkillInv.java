package net.minecraft.src.skillsMod;

import net.minecraft.client.Minecraft;
import net.minecraft.src.*;
import net.minecraft.src.skillsMod.Skill.SkillType;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

public class GuiSkillInv extends GuiContainer {

	private int texX;
	private int texY;
	private int posX;
	private int posY;
	private GuiSkillTooltip toolTip;
	private int currentPage = 0;
	private int maxPages = 5;
	private GuiSkillTab tabs[] = new GuiSkillTab[maxPages];
	private static RenderItem itemRenderer = new RenderItem();

	public GuiSkillInv(Container skillSlots) {
		super(skillSlots);
		Minecraft game = ModLoader.getMinecraftInstance();
		ScaledResolution scaledResolution = new ScaledResolution(
				game.gameSettings, game.displayWidth, game.displayHeight);
		toolTip = new GuiSkillTooltip(game);
		texX = 0;
		texY = 0;
		xSize = 104;
		ySize = 98;
		posX = (scaledResolution.getScaledWidth() - xSize) / 2;
		posY = (scaledResolution.getScaledHeight() - ySize) / 2;
		field_948_f = true;
	}
	
	@Override
	public void initGui() {
		controlList.clear();
		for (int i=0;i<tabs.length;i++)
			tabs[i]=new GuiSkillTab(posX+41+(i*11), posY+4, String.valueOf(i+1));
		tabs[0].toggle(tabs);
	}
	
	@Override
	public void drawScreen(int i, int j, float f)
    {
		drawDefaultBackground();
        int k = (width - xSize) / 2;
        int l = (height - ySize) / 2;
        drawGuiContainerBackgroundLayer(f);
        GL11.glPushMatrix();
        GL11.glRotatef(120F, 1.0F, 0.0F, 0.0F);
        RenderHelper.enableStandardItemLighting();
        GL11.glPopMatrix();
        GL11.glPushMatrix();
        GL11.glTranslatef(k, l, 0.0F);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        GL11.glEnable(32826 /*GL_RESCALE_NORMAL_EXT*/);
        Slot slot = null;
        for(int i1 = 0; i1 < ((inventorySlots.slots.size()-mod_Skills.skillBarLimit)/maxPages); i1++)
        {
            Slot slot1 = (Slot)inventorySlots.slots.get(i1+(currentPage*15));
            drawSlotInventory(slot1);
            if(getIsMouseOverSlot(slot1, i, j))
            {
                slot = slot1;
                GL11.glDisable(2896 /*GL_LIGHTING*/);
                GL11.glDisable(2929 /*GL_DEPTH_TEST*/);
                int j1 = slot1.xDisplayPosition;
                int l1 = slot1.yDisplayPosition;
                drawGradientRect(j1, l1, j1 + 16, l1 + 16, 0x80ffffff, 0x80ffffff);
                GL11.glEnable(2896 /*GL_LIGHTING*/);
                GL11.glEnable(2929 /*GL_DEPTH_TEST*/);
            }
        }
        for(int i1 = 0; i1 < mod_Skills.skillBarLimit; i1++)
        {
            Slot slot1 = (Slot)inventorySlots.slots.get(i1+(mod_Skills.skillInvLimit-mod_Skills.skillBarLimit));
            drawSlotInventory(slot1);
            if(getIsMouseOverSlot(slot1, i, j))
            {
                slot = slot1;
                GL11.glDisable(2896 /*GL_LIGHTING*/);
                GL11.glDisable(2929 /*GL_DEPTH_TEST*/);
                int j1 = slot1.xDisplayPosition;
                int l1 = slot1.yDisplayPosition;
                drawGradientRect(j1, l1, j1 + 16, l1 + 16, 0x80ffffff, 0x80ffffff);
                GL11.glEnable(2896 /*GL_LIGHTING*/);
                GL11.glEnable(2929 /*GL_DEPTH_TEST*/);
            }
        }

        InventoryPlayer inventoryplayer = mc.thePlayer.inventory;
        if(inventoryplayer.getItemStack() != null)
        {
            GL11.glTranslatef(0.0F, 0.0F, 32F);
            itemRenderer.renderItemIntoGUI(fontRenderer, mc.renderEngine, inventoryplayer.getItemStack(), i - k - 8, j - l - 8);
            itemRenderer.renderItemOverlayIntoGUI(fontRenderer, mc.renderEngine, inventoryplayer.getItemStack(), i - k - 8, j - l - 8);
        }
        GL11.glDisable(32826 /*GL_RESCALE_NORMAL_EXT*/);
        RenderHelper.disableStandardItemLighting();
        GL11.glDisable(2896 /*GL_LIGHTING*/);
        GL11.glDisable(2929 /*GL_DEPTH_TEST*/);
        drawGuiContainerForegroundLayer();
        if(inventoryplayer.getItemStack() == null && slot != null && slot.getHasStack())
        {
            String s = (new StringBuilder()).append("").append(StringTranslate.getInstance().translateNamedKey(slot.getStack().getItemName())).toString().trim();
            if(s.length() > 0)
            {
                int k1 = (i - k) + 12;
                int i2 = j - l - 12;
                int j2 = fontRenderer.getStringWidth(s);
                drawGradientRect(k1 - 3, i2 - 3, k1 + j2 + 3, i2 + 8 + 3, 0xc0000000, 0xc0000000);
                fontRenderer.drawStringWithShadow(s, k1, i2, -1);
            }
        }
        GL11.glPopMatrix();
        for(int k1 = 0; k1 < controlList.size(); k1++)
        {
            GuiButton guibutton = (GuiButton)controlList.get(k1);
            guibutton.drawButton(mc, i, j);
        }
        GL11.glEnable(2896 /*GL_LIGHTING*/);
        GL11.glEnable(2929 /*GL_DEPTH_TEST*/);
        for(int k1 = 0; k1 < inventorySlots.slots.size(); k1++)
        {
            Slot slot1 = (Slot)inventorySlots.slots.get(k1);
            if(isSlotOnCurrentPage(k1)&&getIsMouseOverSlot(slot1, i, j) && mc.thePlayer.skillInv.getStackInSlot(k1)!=null)
            	toolTip.draw((Skill)mc.thePlayer.skillInv.getStackInSlot(k1).getItem(), i, j);
        }
    }
	
	private boolean isSlotOnCurrentPage(int i){
		return (i>=(currentPage*((mod_Skills.skillInvLimit-mod_Skills.skillBarLimit)/5))
			&& i<((currentPage+1)*((mod_Skills.skillInvLimit-mod_Skills.skillBarLimit)/5)))
			|| i>=(mod_Skills.skillInvLimit-mod_Skills.skillBarLimit);
	}

	@Override
	protected void drawGuiContainerForegroundLayer() {
		fontRenderer.drawStringWithShadow("Skills", 8, 5, 0xFFFFFF);
		fontRenderer.drawString("Z", 13, 100, 0x9999FF);
		fontRenderer.drawString("X", 31, 100, 0x6666FF);
		fontRenderer.drawString("C", 49, 100, 0x6666FF);
		fontRenderer.drawString("V", 67, 100, 0x6666FF);
		fontRenderer.drawString("B", 85, 100, 0x6666FF);
	}

	@Override
	protected void drawGuiContainerBackgroundLayer(float f) {
		ScaledResolution scaledResolution = new ScaledResolution(
				mc.gameSettings, mc.displayWidth, mc.displayHeight);
		posX = (scaledResolution.getScaledWidth() - xSize) / 2;
		posY = (scaledResolution.getScaledHeight() - ySize) / 2;
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		mc.renderEngine.bindTexture(mc.renderEngine
				.getTexture("/net/minecraft/src/skillsMod/textures/skillgui.png"));
		drawTexturedModalRect(posX, posY, texX, texY, xSize, ySize);
		drawTabButtons(scaledResolution);
	}
	
	private void drawTabButtons(ScaledResolution scaledResolution){
        int mouseX = (Mouse.getX()*scaledResolution.getScaledWidth())/mc.displayWidth;
        int mouseY = scaledResolution.getScaledHeight()-(Mouse.getY()*scaledResolution.getScaledHeight())/mc.displayHeight-1;
        for (int i=0;i<tabs.length;i++)
			tabs[i].drawButton(mc, posX+41+(i*11), posY+4, mouseX, mouseY);
	}

	@Override
	public void onGuiClosed() {
		if (mc.thePlayer == null) {
			return;
		} else {
			InventoryPlayer inventoryplayer = mc.thePlayer.inventory;
			if(inventoryplayer.getItemStack() != null)
			{
				mc.thePlayer.skillSlots.tossSkill(mc.thePlayer, inventoryplayer.getItemStack());
				inventoryplayer.setItemStack(null);
			}
			return;
		}
	}

	@Override
	protected void mouseClicked(int i, int j, int k) {
		if (k == 0 || k == 1) {
			Slot slot = getSlotAtPosition(i, j);
			int l = (width - xSize) / 2;
			int i1 = (height - ySize) / 2;
			boolean flag = i < l || j < i1 || i >= l + xSize || j >= i1 + ySize;
			int j1 = -1;
			if (slot != null) {
				j1 = slot.slotNumber;
			}
			if (flag) {
				j1 = -999;
			}
			if(j1 != -1) {
				boolean flag1 = j1 != -999
				&& (Keyboard.isKeyDown(42) || Keyboard.isKeyDown(54));

				mc.thePlayer.skillSlots.func_27280_a(j1, k,
						flag1, mc.thePlayer);
			}
		}
		for (int m = 0; m < tabs.length; m++)
			if(tabs[m].mousePressed(mc, i, j))
				currentPage=tabs[m].toggle(tabs);
	}

	private Slot getSlotAtPosition(int i, int j) {
		for (int k = 0; k < inventorySlots.slots.size(); k++) {
			Slot slot = (Slot) inventorySlots.slots.get(k);
			if (getIsMouseOverSlot(slot, i, j)&&isSlotOnCurrentPage(k)) {
				return slot;
			}
		}

		return null;
	}

	private boolean getIsMouseOverSlot(Slot slot, int i, int j) {
		int k = (width - xSize) / 2;
		int l = (height - ySize) / 2;
		i -= k;
		j -= l;
		return i >= slot.xDisplayPosition - 1
				&& i < slot.xDisplayPosition + 16 + 1
				&& j >= slot.yDisplayPosition - 1
				&& j < slot.yDisplayPosition + 16 + 1;
	}
	
	private void drawSlotInventory(Slot slot)
    {
        int i = slot.xDisplayPosition;
        int j = slot.yDisplayPosition;
        ItemStack itemstack = slot.getStack();
        if(itemstack == null)
        {
            int k = slot.getBackgroundIconIndex();
            if(k >= 0)
            {
                GL11.glDisable(2896 /*GL_LIGHTING*/);
                mc.renderEngine.bindTexture(mc.renderEngine.getTexture("/gui/items.png"));
                drawTexturedModalRect(i, j, (k % 16) * 16, (k / 16) * 16, 16, 16);
                GL11.glEnable(2896 /*GL_LIGHTING*/);
                return;
            }
        }
        itemRenderer.renderItemIntoGUI(fontRenderer, mc.renderEngine, itemstack, i, j);
        itemRenderer.renderItemOverlayIntoGUI(fontRenderer, mc.renderEngine, itemstack, i, j);
    }
	
	@Override
	protected void keyTyped(char c, int i) {
		if (i == 1 || i == mc.gameSettings.keyBindInventory.keyCode)
			mc.thePlayer.closeScreen();
	}
	
	public class GuiSkillTab extends GuiButton{
		
		private boolean selected=false;

		public GuiSkillTab(int posX, int posY, String text) {
			super(8, posX, posY, 12, 10, text);
		}
		
		public void drawButton(Minecraft game, int posX, int posY, int mouseX, int mouseY)
	    {
			xPosition=posX;
			yPosition=posY;
	        if(!enabled2)
	            return;
	        FontRenderer fontrenderer = game.fontRenderer;
	        GL11.glBindTexture(3553 /*GL_TEXTURE_2D*/, game.renderEngine.getTexture("/net/minecraft/src/skillsMod/textures/skillgui.png"));
	        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
	        int k = selected?2:isMouseOverBin(mouseX, mouseY);
	        drawTexturedModalRect(xPosition, yPosition, 142+(k*12), 69, width, height);
			if (k==1)
				drawCenteredString(fontrenderer, displayString, xPosition + width/2, yPosition+(height-8)/2, 0xffffa0);
			else
				drawCenteredString(fontrenderer, displayString, xPosition + width/2, yPosition+(height-8)/2, 0xe0e0e0);
	    }
		
		protected int isMouseOverBin(int i, int j) {
			return (i>=xPosition&&j>=yPosition&&i<xPosition+width&&j<yPosition+height)?1:0;
		}
		
		public int toggle(GuiSkillTab tabs[]) {
			int r=0;
			if(!selected)
				selected=true;
			for (int i=0;i<tabs.length;i++) {
				if(tabs[i]!=this)
					tabs[i].selected=false;
				else
					r=i;
			}
			return r;
		}
	}
	
	public class GuiSkillTooltip {

		private int texX;
		private int texYBox;
		private int texYIco;
		private int sizeXBox;
		private int sizeYBox;
		private int sizeIco;
		private Minecraft game;

		public GuiSkillTooltip(Minecraft game) {
			super();
			this.game = game;
			texX = 142;
			texYBox = 0;
			texYIco = 60;
			sizeXBox = 80;
			sizeYBox = 60;
			sizeIco = 9;
		}

		public void draw(Skill skill, int posX, int posY) {
			//game.entityRenderer.func_905_b();
			posX += 9;
			RenderHelper.enableStandardItemLighting();
			GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
			GL11.glEnable(3042 /*GL_BLEND*/);
			GL11.glDisable(2896 /*GL_LIGHTING*/);
			GL11.glDisable(2929 /*GL_DEPTH_TEST*/);
			GL11.glBindTexture(3553, game.renderEngine.getTexture("/net/minecraft/src/skillsMod/textures/skillgui.png"));
			game.ingameGUI.drawTexturedModalRect(posX, posY, texX, texYBox, sizeXBox, sizeYBox);
			int yOffset = drawIcons(skill, posX, posY)*10;
			game.fontRenderer.drawStringWithShadow(skill.skillType.skillTypeString, posX+3, posY+15+yOffset, -256);
			game.fontRenderer.drawStringWithShadow(skill.getSkillDescrL1(), posX+4, posY+27+yOffset, -1);
			game.fontRenderer.drawStringWithShadow(skill.getSkillDescrL2(), posX+4, posY+37+yOffset, -1);
			//game.fontRenderer.getStringWidth(String.valueOf(14));
			RenderHelper.disableStandardItemLighting();
			GL11.glDisable(3042 /*GL_BLEND*/);
			GL11.glEnable(2896 /*GL_LIGHTING*/);
			GL11.glEnable(2929 /*GL_DEPTH_TEST*/);
			
		}

		private int drawIcons(Skill skill, int posX, int posY) {
			boolean newrow=false;
			if(skill.expendAmount>0) {
				game.ingameGUI.drawTexturedModalRect(posX+3, posY+2, texX + (0*sizeIco), texYIco, sizeIco, sizeIco);
				String s = skill.skillType!=SkillType.ACTIVE ? String.valueOf(skill.expendAmount) : String.valueOf(skill.expendAmount*20)+" per s";
				game.fontRenderer.drawString(s, posX+3+10, posY+3, 0xB3D9FF);
				newrow=true;
			}
			int k=0;
			if(newrow)
				k=1;
			if(skill.skillType.canHaveDuration && skill instanceof Spell && ((Spell)skill).duration>0) {
				GL11.glBindTexture(3553, game.renderEngine.getTexture("/net/minecraft/src/skillsMod/textures/skillgui.png"));
				game.ingameGUI.drawTexturedModalRect(posX+(35*k)+3, posY+2, texX + (3*sizeIco), texYIco, sizeIco, sizeIco);
				game.fontRenderer.drawString(String.valueOf(((Spell)skill).duration)+"s", posX+(35*k)+3+10, posY+3, 0xB3D9FF);
				newrow=true;
			}
			int j=0;
			if(skill.chargeup>0) {
				if(newrow)
					k=1;
				GL11.glBindTexture(3553, game.renderEngine.getTexture("/net/minecraft/src/skillsMod/textures/skillgui.png"));
				game.ingameGUI.drawTexturedModalRect(posX+3, posY+(10*k)+2, texX + (1*sizeIco), texYIco, sizeIco, sizeIco);
				game.fontRenderer.drawString(String.valueOf(skill.chargeup)+"s", posX+3+10, posY+3+(10*k), 0xB3D9FF);
				j++;
			}
			if(skill.cooldown>0) {
				GL11.glBindTexture(3553, game.renderEngine.getTexture("/net/minecraft/src/skillsMod/textures/skillgui.png"));
				game.ingameGUI.drawTexturedModalRect(posX+(35*j)+3, posY+(10*k)+2, texX + (2*sizeIco), texYIco, sizeIco, sizeIco);
				game.fontRenderer.drawString(String.valueOf(skill.cooldown)+"s", posX+(35*j)+3+10, posY+3+(10*k), 0xB3D9FF);
			}
			int r = ((skill.chargeup>0||skill.cooldown>0)&&newrow)?1:0;
			return r;
		}
	}
}