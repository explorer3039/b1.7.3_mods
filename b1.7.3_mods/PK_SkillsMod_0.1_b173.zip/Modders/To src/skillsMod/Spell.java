package net.minecraft.src.skillsMod;

import java.util.Timer;
import java.util.TimerTask;
import net.minecraft.client.Minecraft;
import net.minecraft.src.mod_Skills;

public class Spell extends Skill{

	protected static final boolean spellActivated = true;
	protected static final boolean skillNotActivated = false;
	public int timeLeft;
	protected float duration;

	private Timer spellTimer;
	
	public Spell(int id, int expendAmount, float chargeup, float cooldown, float duration) {
		super(id, expendAmount, chargeup, cooldown);
		this.duration = duration;
		skillType = SkillType.SPELL;
	}
	
	protected boolean onSpellStart(Minecraft theGame) {
		return false;
	}

	protected void onSpellEnd(Minecraft theGame) {
	}
	
	public void onTick(Minecraft theGame){
	}
	
	public void remove(Minecraft game, Spell spell, int slot) {
		spellTimer.cancel();
		spell.beingUsed = false;
		spell.onSpellEnd(game);
		int i=0;
		SpellList spellList = mod_Skills.getSkillsModInstance().spellList;
		for (Spell spellSlot : spellList.activeSpells) {
			if(spellSlot==spell)
				spellList.deleteSlot(i);
			i++;
		}
	}
	
	@Override
	public void activate(Minecraft game) {
		SpellList spellList = mod_Skills.getSkillsModInstance().spellList;
		if(onSpellStart(game)) {
			if(spellList.activeSpells.contains(this)) {
				timeLeft = (int)duration;
				return;
			}
			scheduleEnd(game, spellList.add(this));
		}
	}

	private void scheduleEnd(Minecraft game, int slot) {
		if(duration==0)
			return;
		spellTimer = new java.util.Timer();
		spellTimer.scheduleAtFixedRate(new SpellDeactivate(game, this, slot), 0, 1000);
	}

	class SpellDeactivate extends TimerTask {
		// Yeah I know this is stupid but just for now.
		private Minecraft game;
		private Spell spell;
		private int slot;
		public SpellDeactivate(Minecraft game, Spell spell, int slot){
			this.game=game;
			this.spell=spell;
			this.slot=slot;
			spell.timeLeft = (int)spell.duration+1;
		}
		@Override
		public void run() {
			//skillsMod.guiSkillBar.updateSpellGUI(spell, slot);
			if(!game.isGamePaused)
				spell.timeLeft--;
			if(spell.timeLeft<1||game.thePlayer.isDead) {
				spell.remove(game, spell, slot);
			}
		}
	}

}
