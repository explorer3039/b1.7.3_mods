package net.minecraft.src.skillsMod;

import java.util.Random;
import net.minecraft.src.*;

public class ContainerSkills extends Container {

	public boolean isSinglePlayer;
	private Random rand;

	public ContainerSkills(InventorySkills inventorySkills) {
		this(inventorySkills, true);
	}

	public ContainerSkills(InventorySkills skillInv, boolean flag) {
		isSinglePlayer = flag;
		rand = new Random();

		for (int i = 0; i < 5; i++)
			for (int j = 0; j < (mod_Skills.skillInvLimit/mod_Skills.skillBarLimit)/5; j++)
				for (int k = 0; k < mod_Skills.skillBarLimit; k++)
					addSlot(new SlotSkill(skillInv,k+(j*5)+(i*15),8+k*18,16+j*18));
		for (int l = 0; l < mod_Skills.skillBarLimit; l++)
			addSlot(new SlotSkill(skillInv, l+(5*15), 8+l*18, 16+(3*18)+4));

	}

	@Override
	public boolean isUsableByPlayer(EntityPlayer entityplayer) {
		return true;
	}

	@Override
	public ItemStack getStackInSlot(int i) {
		ItemStack itemstack = null;
		Slot slot = (Slot) slots.get(i);
		if (slot != null && slot.getHasStack()) {
			ItemStack itemstack1 = slot.getStack();
			itemstack = itemstack1.copy();
			if (i >= 5 && i < 15) {
				func_28125_a(itemstack1, 15, 15, false);
			} else {
				func_28125_a(itemstack1, 5, 15, false);
			}
			if (itemstack1.stackSize == 0) {
				slot.putStack(null);
			} else {
				slot.onSlotChanged();
			}
			if (itemstack1.stackSize != itemstack.stackSize) {
				slot.onPickupFromSlot(itemstack1);
			} else {
				return null;
			}
		}
		return itemstack;
	}

	@Override
	public ItemStack func_27280_a(int i, int j, boolean flag, EntityPlayer entityplayer)
    {
        ItemStack itemstack = null;
        if(j == 0 || j == 1)
        {
        	//Weird.
            InventoryPlayer skillInv = entityplayer.inventory;//mod_Skills.getSkillsModInstance().skillInv;
            if(i == -999) // Click out of bounds.
            {
                if(skillInv.getItemStack() != null && i == -999)
                {
                    if(j == 0)
                    {
                    	tossSkill(entityplayer, skillInv.getItemStack());
                        skillInv.setItemStack(null);
                    }
                    if(j == 1)
                    {
                    	tossSkill(entityplayer, skillInv.getItemStack());
                        if(skillInv.getItemStack().stackSize == 0)
                        {
                            skillInv.setItemStack(null);
                        }
                    }
                }
            } else
            if(flag) // Shift-click
            {
                ItemStack itemstack1 = getStackInSlot(i);
                if(itemstack1 != null)
                {
                    int k = itemstack1.stackSize;
                    itemstack = itemstack1.copy();
                    Slot slot1 = (Slot)slots.get(i);
                    if(slot1 != null && slot1.getStack() != null)
                    {
                        int l = slot1.getStack().stackSize;
                        if(l < k)
                        {
                            func_27280_a(i, j, flag, entityplayer);
                        }
                    }
                }
            } else
            {
                Slot slot = (Slot)slots.get(i);
                if(slot != null)
                {
                    slot.onSlotChanged();
                    ItemStack itemstack2 = slot.getStack();
                    ItemStack itemstack3 = skillInv.getItemStack();
                    if(itemstack2 != null)
                    {
                        itemstack = itemstack2.copy();
                    }
                    if(itemstack2 == null)
                    {
                        if(itemstack3 != null && slot.isItemValid(itemstack3))
                        {
                            int i1 = j != 0 ? 1 : itemstack3.stackSize;
                            if(i1 > slot.getSlotStackLimit())
                            {
                                i1 = slot.getSlotStackLimit();
                            }
                            slot.putStack(itemstack3.splitStack(i1));
                            if(itemstack3.stackSize == 0)
                            {
                                skillInv.setItemStack(null);
                            }
                        }
                    } else
                    if(itemstack3 == null)
                    {
                        int j1 = j != 0 ? (itemstack2.stackSize + 1) / 2 : itemstack2.stackSize;
                        ItemStack itemstack5 = slot.decrStackSize(j1);
                        skillInv.setItemStack(itemstack5);
                        if(itemstack2.stackSize == 0)
                        {
                            slot.putStack(null);
                        }
                        slot.onPickupFromSlot(skillInv.getItemStack());
                    } else
                    if(slot.isItemValid(itemstack3))
                    {
                        if(itemstack2.itemID != itemstack3.itemID || itemstack2.getHasSubtypes() && itemstack2.getItemDamage() != itemstack3.getItemDamage())
                        {
                            if(itemstack3.stackSize <= slot.getSlotStackLimit())
                            {
                                ItemStack itemstack4 = itemstack2;
                                slot.putStack(itemstack3);
                                skillInv.setItemStack(itemstack4);
                            }
                        } else
                        {
                            int k1 = j != 0 ? 1 : itemstack3.stackSize;
                            if(k1 > slot.getSlotStackLimit() - itemstack2.stackSize)
                            {
                                k1 = slot.getSlotStackLimit() - itemstack2.stackSize;
                            }
                            if(k1 > itemstack3.getMaxStackSize() - itemstack2.stackSize)
                            {
                                k1 = itemstack3.getMaxStackSize() - itemstack2.stackSize;
                            }
                            itemstack3.splitStack(k1);
                            if(itemstack3.stackSize == 0)
                            {
                                skillInv.setItemStack(null);
                            }
                            itemstack2.stackSize += k1;
                        }
                    } else
                    if(itemstack2.itemID == itemstack3.itemID && itemstack3.getMaxStackSize() > 1 && (!itemstack2.getHasSubtypes() || itemstack2.getItemDamage() == itemstack3.getItemDamage()))
                    {
                        int l1 = itemstack2.stackSize;
                        if(l1 > 0 && l1 + itemstack3.stackSize <= itemstack3.getMaxStackSize())
                        {
                            itemstack3.stackSize += l1;
                            itemstack2.splitStack(l1);
                            if(itemstack2.stackSize == 0)
                            {
                                slot.putStack(null);
                            }
                            slot.onPickupFromSlot(skillInv.getItemStack());
                        }
                    }
                }
            }
        }
        return itemstack;
    }

	public void tossSkill(EntityPlayer player, ItemStack skillStack) {
		World world = ModLoader.getMinecraftInstance().theWorld;
		
		if (skillStack == null) {
			return;
		}
		EntitySkill entitySkill = new EntitySkill(world, player.posX,
				(player.posY - 0.30000001192092896D)
						+ player.getEyeHeight(), player.posZ,
				new ItemStack(skillStack.getItem().shiftedIndex, 1, 0));
		entitySkill.delayBeforeCanPickup = 40;
		float f1 = 0.3F;
		entitySkill.motionX = -MathHelper
				.sin((player.rotationYaw / 180F) * 3.141593F)
				* MathHelper.cos((player.rotationPitch / 180F) * 3.141593F)
				* f1;
		entitySkill.motionZ = MathHelper
				.cos((player.rotationYaw / 180F) * 3.141593F)
				* MathHelper.cos((player.rotationPitch / 180F) * 3.141593F)
				* f1;
		entitySkill.motionY = -MathHelper
				.sin((player.rotationPitch / 180F) * 3.141593F) * f1 + 0.1F;
		f1 = 0.02F;
		float f3 = rand.nextFloat() * 3.141593F * 2.0F;
		f1 *= rand.nextFloat();
		entitySkill.motionX += Math.cos(f3) * f1;
		entitySkill.motionY += (rand.nextFloat() - rand.nextFloat()) * 0.1F;
		entitySkill.motionZ += Math.sin(f3) * f1;
		world.entityJoinedWorld(entitySkill);
	}
	
}
