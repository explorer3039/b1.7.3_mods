package net.minecraft.src.skillsMod;

import net.minecraft.src.*;
import net.minecraft.src.skillsMod.Skill.SkillType;

class SlotSkill extends Slot {

	private int slotIndex;
	
	SlotSkill(IInventory iinventory, int slotIndex, int posX, int posY) {
		super(iinventory, slotIndex, posX, posY);
		this.slotIndex = slotIndex;
	}

	@Override
	public int getSlotStackLimit() {
		return 1;
	}

	@Override
	public boolean isItemValid(ItemStack itemstack) {
		if (itemstack.getItem() instanceof Skill) {
			if(slotIndex==75)
				if(((Skill) itemstack.getItem()).skillType == SkillType.ELITE)
					return true;
				else
					return false;
			else
				return true;
		}
		return false;
	}

	/* final int skillType; *//* synthetic field */
}