package net.minecraft.src.skillsMod;

import java.util.LinkedList;

public class SpellList {
	
	public LinkedList<Spell> activeSpells;
	
	public SpellList() {
		activeSpells = new LinkedList<Spell>();
	}
	
	public int add(Spell s) {
		activeSpells.add(s);
		return size()-1;
	}
	
	public boolean isEmpty() {
		if(activeSpells.isEmpty())
			return true;
		return false;
	}

	public int size() {
		return activeSpells.size();
	}

	public Spell get(int i) {
		return activeSpells.get(i);
	}
	
	public void deleteSlot(int i) {
		activeSpells.remove(i);
	}

	public void clearAll() {
		activeSpells.clear();
	}
	
}