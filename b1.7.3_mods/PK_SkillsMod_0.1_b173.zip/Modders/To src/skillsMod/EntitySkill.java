package net.minecraft.src.skillsMod;

import net.minecraft.src.*;
import net.minecraft.src.skillsMod.GuiSkillIngame.GuiSkillGet;

public class EntitySkill extends EntityItem {

	private int skillGetTimer;
	private ItemStack skill;
	private GuiSkillGet skillGetGui;

	public EntitySkill(World world, double d, double d1, double d2, ItemStack itemstack) {
		super(world, d, d1, d2, itemstack);
		skill = itemstack;
		skillGetTimer = 0;
	}

	@Override
	public void onUpdate() {
		super.onUpdate();
		if(skillGetTimer>0) {
			skillGetGui.updateSkillGet(skill);
			skillGetTimer--;
		}
	}
	
	@Override
	public void onCollideWithPlayer(EntityPlayer entityplayer)
    {
		mod_Skills skillsMod = mod_Skills.getSkillsModInstance();
		
		if(entityplayer.skillInv.getInventorySlotContainItem(skill.itemID) != -1 || skillsMod==null ||  worldObj.multiplayerWorld)
        {
            return;
        }
        if(delayBeforeCanPickup == 0 && entityplayer.skillInv.addItemStackToInventory(skill))
        {
            ModLoader.OnItemPickup(entityplayer, item);
            worldObj.playSoundAtEntity(this, "note.snare", 0.2F, ((rand.nextFloat() - rand.nextFloat()) * 0.7F + 1.0F) * 2.0F);
            entityplayer.onItemPickup(this, item.stackSize);
            if(item.stackSize <= 0)
            {
                setEntityDead();
            }
            skillsMod.displaySkillGet(skill);
        }
	}
}
