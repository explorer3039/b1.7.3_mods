package net.minecraft.src.skillsMod;

import java.util.TimerTask;
import net.minecraft.client.Minecraft;
import net.minecraft.src.Item;
import net.minecraft.src.mod_Skills;

public class Skill extends Item {
	
	protected static final boolean skillUsed = true;
	protected static final boolean skillNotUsed = false;
	public SkillType skillType = SkillType.STANDARD;
	protected final int expendAmount;
	protected final float cooldown;
	protected final float chargeup;
	private java.util.Timer coolTimer;
	private java.util.Timer chargeTimer;
	public boolean beingUsed = false;
	public String skillDescrL1;
	public String skillDescrL2;
	public Item boundItem;
	public Item boundConsumable;
	public int consumableAmount;
	public int cooldownTimer=8;

	public Skill(int id, int expendAmount, float chargeup, float cooldown) {
		super(id);
		this.expendAmount = expendAmount;
		this.chargeup = chargeup;
		this.cooldown = cooldown;
		if(chargeup==0&&cooldown==0)
			skillType = SkillType.ACTIVE;
		maxStackSize = 1;
	}
	
	public enum SkillType {
		STANDARD("Standard",false),
		ELITE("Elite",true),
		ACTIVE("Active",false),
		SPELL("Spell",true),
		PASSIVE("Passive",false),
		CHANNELING("Channeling",true),
		ENCHANTMENT("Enchantment",true);

		public String skillTypeString;
		public boolean canHaveDuration;

		SkillType(String s, boolean b){
			skillTypeString = s;
			canHaveDuration = b;
		}
	}

	/**
	 * A method run once a skill is used.
	 * @param theGame
	 * @return
	 */
	protected boolean useSkill(Minecraft theGame) {
		return skillUsed;
	}
	
	public boolean isBeingUsed() {
		return beingUsed;
	}
	
	public int getEnergyExpenditure() {
		return expendAmount;
	}
	
	public Skill setSkillName(String s) {
		super.setItemName(s);
		return this;
	}
	
	/**
	 * Binds an item for an enchantment skill.
	 * @param item
	 * @return
	 */
	public Skill bindItem(Item item) {
		boundItem=item;
		skillType=SkillType.ENCHANTMENT;
		return this;
	}
	
	/**
	 * Binds a consumable item to any skill.
	 * @param item
	 * @param amount
	 * @return
	 */
	public Skill bindConsumable(Item item, int amount) {
		boundConsumable=item;
		consumableAmount=amount;
		if(skillType!=SkillType.ENCHANTMENT)
			skillType=SkillType.CHANNELING;
		return this;
	}
	
	public Skill setSkillDescr(String s) {
		if(s.length()<13)
			skillDescrL1 = s;
		else {
			StringBuilder sb = new StringBuilder(s);
			int space = -1;
			space = new StringBuilder(sb.substring(0, 12)).lastIndexOf(" ");
			if(space>-1) {
				skillDescrL1 = sb.substring(0,space);
				skillDescrL2 = (sb.length()-skillDescrL1.length()-1)<13?sb.substring(space+1):sb.substring(space+1,12+(13-(12-skillDescrL1.length())));
			} else {
				skillDescrL1 = sb.substring(0,12);
				skillDescrL2 = sb.length()<25?sb.substring(12):sb.substring(12,24);
			}
		}
		return this;
	}
	
	public String getSkillDescrL1() {
		return skillDescrL1;
	}
	
	public String getSkillDescrL2() {
		return skillDescrL2;
	}
	
	public void cancelCharge() {
		chargeTimer.cancel();
		mod_Skills.getSkillsModInstance().guiSkillIngame.resetChargeupFrame();
	}
	
	public void chargeup(Minecraft game, int slot) {
		if(chargeup==0 || skillType == SkillType.ACTIVE) {
			if(this.useSkill(game)) {
				game.thePlayer.expendEntity(expendAmount);
				if(skillType.canHaveDuration && this instanceof Spell && ((Spell)this).duration>0)
					this.activate(game);
				this.cooldown(game, slot);
			}
			else
				game.theWorld.playSoundAtEntity(game.thePlayer, "note.bass", 1.0F, 0F);
		}
		else {
			chargeTimer = new java.util.Timer();
			chargeTimer.scheduleAtFixedRate(new SkillChargeup(game, this, slot), 0, (long)(chargeup*10));
		}
	}
	
	class SkillChargeup extends TimerTask {
		// Yeah I know this is stupid but just for now.
		private Minecraft game;
		private int chargeupFrame;
		private int slot;
		private Skill skill;
		public SkillChargeup(Minecraft game, Skill skill, int slot){
			this.game=game;
			this.skill=skill;
			this.slot=slot;
			chargeupFrame = 0;
		}
		@Override
		public void run() {
			mod_Skills.getSkillsModInstance().guiSkillIngame.updateChargeupGUI(chargeupFrame, skill);
			if(!game.isGamePaused)
				chargeupFrame++;
			if(chargeupFrame>100) {
				chargeTimer.cancel();
				if(useSkill(game)) {
					game.thePlayer.expendEntity(expendAmount);
					if(skillType.canHaveDuration && skill instanceof Spell && ((Spell)skill).duration>0)
						activate(game);
					cooldown(game, slot);
				} else
					game.theWorld.playSoundAtEntity(game.thePlayer, "note.bass", 1.0F, 0F);
			}
		}
	}
	
	private void cooldown(Minecraft game, int slot) {
		if(cooldown==0 || skillType == SkillType.ACTIVE)
			return;
		coolTimer = new java.util.Timer();
		coolTimer.scheduleAtFixedRate(new SkillCooldown(game, slot), 0, (long)((cooldown/8)*1000));
	}

	class SkillCooldown extends TimerTask {
		// Yeah I know this is stupid but just for now.
		private Minecraft game;
		private int cooldownFrame;
		private Skill skill;
		private int slot;
		public SkillCooldown(Minecraft game, int slot){
			this.game=game;
			this.slot=slot;
			cooldownFrame = 0;
		}
		@Override
		public void run() {
			slot=game.thePlayer.skillInv.getInventorySlotContainItem(shiftedIndex)-(mod_Skills.skillInvLimit-mod_Skills.skillBarLimit);
			if(slot>0)
				mod_Skills.getSkillsModInstance().guiSkillIngame.updateCooldownGUI(cooldownFrame, slot);
			cooldownTimer=cooldownFrame;
			if(!game.isGamePaused)
				cooldownFrame++;
			if(cooldownFrame>8) {
				coolTimer.cancel();
			}
		}
	}
	
	public void activate(Minecraft game) {
	}
	
}
