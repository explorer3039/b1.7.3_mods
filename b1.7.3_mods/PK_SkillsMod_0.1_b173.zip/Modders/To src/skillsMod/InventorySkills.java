package net.minecraft.src.skillsMod;

import net.minecraft.src.*;

public class InventorySkills implements IInventory {

	public ItemStack skillInventory[] = new ItemStack[mod_Skills.skillInvLimit];
	public EntityPlayer player;
	private ItemStack itemStack;
	public boolean inventoryChanged = false;

	public InventorySkills(EntityPlayer entityplayer) {
		player = entityplayer;
	}

	public int getInventorySlotContainItem(int i) {
		for (int j = 0; j < skillInventory.length; j++)
			if (skillInventory[j] != null && skillInventory[j].itemID == i)
				return j;
		return -1;
	}

	private int storeItemStack(ItemStack itemstack) {
		for (int i = 0; i < skillInventory.length; i++)
			if (skillInventory[i] != null
					&& skillInventory[i].itemID == itemstack.itemID
					&& skillInventory[i].isStackable()
					&& skillInventory[i].stackSize < skillInventory[i]
							.getMaxStackSize()
					&& skillInventory[i].stackSize < getInventoryStackLimit()
					&& (!skillInventory[i].getHasSubtypes() || skillInventory[i]
							.getItemDamage() == itemstack.getItemDamage()))
				return i;
		return -1;
	}

	private int getFirstEmptyStack() {
		for (int i = 0; i < skillInventory.length; i++)
			if (skillInventory[i] == null)
				return i;
		return -1;
	}

	private int storePartialItemStack(ItemStack itemstack) {
		int i = itemstack.itemID;
		int j = itemstack.stackSize;
		int k = storeItemStack(itemstack);
		if (k < 0)
			k = getFirstEmptyStack();
		if (k < 0)
			return j;
		if (skillInventory[k] == null)
			skillInventory[k] = new ItemStack(i, 0, itemstack.getItemDamage());
		int l = j;
		if (l > skillInventory[k].getMaxStackSize() - skillInventory[k].stackSize)
			l = skillInventory[k].getMaxStackSize() - skillInventory[k].stackSize;
		if (l > getInventoryStackLimit() - skillInventory[k].stackSize)
			l = getInventoryStackLimit() - skillInventory[k].stackSize;
		if (l == 0)
			return j;
		else {
			j -= l;
			skillInventory[k].stackSize += l;
			skillInventory[k].animationsToGo = 5;
			return j;
		}
	}

	public void decrementAnimations() {
		for (int i = 0; i < skillInventory.length; i++)
			if (skillInventory[i] != null)
				skillInventory[i].updateAnimation(player.worldObj, player, i, false);// currentItem boolean
	}

	public boolean addItemStackToInventory(ItemStack itemstack) {
		if (!itemstack.isItemDamaged()) {
			int i;
			do {
				i = itemstack.stackSize;
				itemstack.stackSize = storePartialItemStack(itemstack);
			} while (itemstack.stackSize > 0 && itemstack.stackSize < i);
			return itemstack.stackSize < i;
		}
		int j = getFirstEmptyStack();
		if (j >= 0) {
			skillInventory[j] = ItemStack.copyItemStack(itemstack);
			skillInventory[j].animationsToGo = 5;
			itemstack.stackSize = 0;
			return true;
		}
		else
			return false;
	}

	public NBTTagList writeToNBT(NBTTagList nbttaglist) {
		for (int i = 0; i < skillInventory.length; i++)
			if (skillInventory[i] != null) {
				NBTTagCompound nbttagcompound = new NBTTagCompound();
				nbttagcompound.setByte("Skill Slot", (byte) i);
				skillInventory[i].writeToNBT(nbttagcompound);
				nbttaglist.setTag(nbttagcompound);
			}
		return nbttaglist;
	}

	public void readFromNBT(NBTTagList nbttaglist) {
		skillInventory = new ItemStack[80];
		for (int i = 0; i < nbttaglist.tagCount(); i++) {
			NBTTagCompound nbttagcompound = (NBTTagCompound) nbttaglist
					.tagAt(i);
			int j = nbttagcompound.getByte("Skill Slot") & 0xff;
			ItemStack itemstack = new ItemStack(nbttagcompound);
			if (itemstack.getItem() == null)
				continue;
			if (j >= 0 && j < skillInventory.length)
				skillInventory[j] = itemstack;
		}
	}

	@Override
	public ItemStack decrStackSize(int i, int j) {
		ItemStack aitemstack[] = skillInventory;
		if (aitemstack[i] != null) {
			if (aitemstack[i].stackSize <= j) {
				ItemStack itemstack = aitemstack[i];
				aitemstack[i] = null;
				return itemstack;
			}
			ItemStack itemstack1 = aitemstack[i].splitStack(j);
			if (aitemstack[i].stackSize == 0)
				aitemstack[i] = null;
			return itemstack1;
		}
		else
			return null;
	}

	@Override
	public void setInventorySlotContents(int i, ItemStack itemstack) {
		skillInventory[i] = itemstack;
	}

	@Override
	public int getSizeInventory() {
		return skillInventory.length;
	}

	@Override
	public ItemStack getStackInSlot(int i) {
		return skillInventory[i];
	}

	@Override
	public String getInvName() {
		return "Skills";
	}

	@Override
	public int getInventoryStackLimit() {
		return 1;
	}

	@Override
	public void onInventoryChanged() {
		inventoryChanged = true;
		mod_Skills skillsMod = mod_Skills.getSkillsModInstance();
		skillsMod.updateKeyBindingTypes();
		skillsMod.updateCooldownGUI();
		skillsMod.skillInvBackup = this;
	}

	public void setItemStack(ItemStack itemstack) {
		itemStack = itemstack;
		player.onItemStackChanged(itemstack);
	}

	public ItemStack getItemStack() {
		return itemStack;
	}

	@Override
	public boolean canInteractWith(EntityPlayer entityplayer) {
		if (entityplayer.isDead)
			return false;
		return true;/* entityplayer.getDistanceSqToEntity(player) <= 64D; */
	}
}