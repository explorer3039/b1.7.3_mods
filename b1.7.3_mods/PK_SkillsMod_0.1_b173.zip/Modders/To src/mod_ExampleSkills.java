package net.minecraft.src;

import java.util.Map;
import net.minecraft.src.exampleSkills.*;
import net.minecraft.src.skillsMod.*;

public class mod_ExampleSkills extends BaseMod{

	public static final Item heritageAmulet = new ItemHeritageAmulet(31601).setItemName("heritageAmulet");
	public static final Item manaPotion = (new ItemManaPotion(31602, 5)).setItemName("manaPotion");

	public static final Skill creeperBlast = (new SkillCreeperBlast(31500, 20, 3, 30, false))
		.setSkillName("creeperBlast")
		.setSkillDescr("Creature Mimic");
    public static final Skill stunShot = (new SkillStunShot(31501, 10, 0.5F, 10, false))
    	.setSkillName("stunShot")
    	.setSkillDescr("Ranged Attack")
    	.bindItem(Item.bow)
    	.bindConsumable(Item.arrow, 1);
    public static final Skill superJump = (new SkillSuperJump(31502, 10, 0.5F, 2.5F, false))
    	.setSkillName("superJump")
    	.setSkillDescr("Physical Augmentation");
    public static final Skill summonWolf = (new SkillSummonWolf(31503, 10, 5, 60, false))
    	.setSkillName("summonWolf")
    	.setSkillDescr("Binding Ritual")
    	.bindConsumable(Item.bone, 5);
    public static final Skill levitate = (new SkillLevitate(31505, 1, 0, 0, true))
    	.setSkillName("levitate")
    	.setSkillDescr("Mental Augmentation");
    public static final Spell healingBreeze = (Spell) (new SpellHealingBreeze(31506, 5, 4, 4, 10))
		.setSkillName("healingBreeze")
		.setSkillDescr("Healing Blessing");
    public static final Skill bindingSignet = (new SkillBindingSignet(31507, 0, 10, 90))
		.setSkillName("bindingSignet")
		.setSkillDescr("Warp Skill")//"Teleportation" is too long by one letter.
		.bindConsumable(heritageAmulet, 1);
	
    public static final Item genSkillBook = new ItemSkillBook(31600)
    											.addSkill(creeperBlast)
    											.addSkill(levitate)
    											.addSkill(stunShot)
    											.addSkill(summonWolf)
    											.addSkill(superJump)
    											.addSkill(healingBreeze)
    											.addSkill(bindingSignet)
    											.setItemName("genSkillBook");
    
    public mod_ExampleSkills()
	{
    	creeperBlast.iconIndex = ModLoader.addOverride("/gui/items.png", "/net/minecraft/src/exampleSkills/textures/creeperblast.png");
    	ModLoader.AddName(creeperBlast, "Creeper Blast");
    	
    	stunShot.iconIndex = ModLoader.addOverride("/gui/items.png", "/net/minecraft/src/exampleSkills/textures/stunshot.png");
    	ModLoader.AddName(stunShot, "Stunshot");
    	
    	superJump.iconIndex = ModLoader.addOverride("/gui/items.png", "/net/minecraft/src/exampleSkills/textures/superjump.png");
    	ModLoader.AddName(superJump, "Super Jump");
    	
    	summonWolf.iconIndex = ModLoader.addOverride("/gui/items.png", "/net/minecraft/src/exampleSkills/textures/summonwolf.png");
    	ModLoader.AddName(summonWolf, "Summon Wolf");
    	
    	levitate.iconIndex = ModLoader.addOverride("/gui/items.png", "/net/minecraft/src/exampleSkills/textures/levitate.png");
    	ModLoader.AddName(levitate, "Levitate");
    	
    	healingBreeze.iconIndex = ModLoader.addOverride("/gui/items.png","/net/minecraft/src/exampleSkills/textures/healingbreeze.png");
    	ModLoader.AddName(healingBreeze, "Healing Breeze");
    	
    	bindingSignet.iconIndex = ModLoader.addOverride("/gui/items.png","/net/minecraft/src/exampleSkills/textures/bindingsignet.png");
    	ModLoader.AddName(bindingSignet, "Binding Signet");
    	
    	genSkillBook.iconIndex = ModLoader.addOverride("/gui/items.png", "/net/minecraft/src/exampleSkills/textures/genskillbook.png");
    	ModLoader.AddName(genSkillBook, "Generic Skill Book");
		ModLoader.AddRecipe(new ItemStack(genSkillBook, 1), new Object[] {
				"#", "X", Character.valueOf('#'), Item.ingotGold,
				Character.valueOf('X'), Item.book });
		
		heritageAmulet.iconIndex = ModLoader.addOverride("/gui/items.png", "/net/minecraft/src/exampleSkills/textures/heritageAmulet.png");
    	ModLoader.AddName(heritageAmulet, "Heritage Amulet");
		ModLoader.AddRecipe(new ItemStack(heritageAmulet, 1), new Object[] {
				" S ", "S S", "GDG" , Character.valueOf('S'), Item.silk,
				Character.valueOf('G'), Item.ingotGold, Character.valueOf('D'), Item.diamond });
		
		manaPotion.iconIndex = ModLoader.addOverride("/gui/items.png", "/net/minecraft/src/exampleSkills/textures/manapotion.png");
		ModLoader.AddName(manaPotion, "Mana Potion");
		ModLoader.AddRecipe(new ItemStack(manaPotion, 1), new Object[] {
            " # ", "XLX", " X ", Character.valueOf('#'), Block.planks, Character.valueOf('X'), Block.glass, Character.valueOf('L'),  new ItemStack(Item.dyePowder, 9, 4)
        });
		
		ModLoader.RegisterEntityID(EntityStunArrow.class, "StunArrow",ModLoader.getUniqueEntityId());
	}

	public void AddRenderer(Map map) {
		map.put(EntityStunArrow.class, new RenderStunArrow());
	}
	
	public String Version(){return "for 1.7.3";}
}
