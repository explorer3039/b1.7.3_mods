All of the code is completely open source; use whatever you want and never worry about copyright or such.

To develop skills using the API, open your workspace and drag "mod_Skills", "EntityPlayer", "GuiIngame" and the folder "skillsMod" from "To src" to "net.minecraft.src". If you want you can also drag "mod_ExampleSkills" and "exampleSkills" or else just check out the code in any text editor.

Do *NOT* try to decompile a minecraft jar with the skills mod installed because it will give you errors you can only solve by changing the mcp mappings. At the same time, my few comments and documentation in the code won't be there if you do. (I would have simply made it into a jar but mcp wouldn't let you compile if I did, although eclipse does)

The main thread is here: http://www.minecraftforum.net/topic/364710-/

Have fun!

~Paraknight