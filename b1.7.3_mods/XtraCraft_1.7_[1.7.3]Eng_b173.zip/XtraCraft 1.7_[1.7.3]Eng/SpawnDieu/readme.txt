To make the god spawn you have to go in the divine sanctuairy, 
then go back to the normal world and log out, and then install the file "SpawnDieu.class", 
and then re log in and he will be spawned in the sanctuary, he oftenly spawns far so if you can't see him, redo this.