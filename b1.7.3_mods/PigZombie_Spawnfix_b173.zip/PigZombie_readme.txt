Digital Cougar : 09/10/2011

This mod makes pig zombies ONLY spawn on Netherrack / Bloodstone. So if you build a base in the nether, use some other material for the floor and they won't spawn inside your base! Similarly, put railway track on anything other than native Netherrack / Bloodstone to keep them off your rail lines. :)

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
Use this mod at your own risk! Although I have extensively playtested it, I cannot and will not guarantee that it won't cause your computer to spontaneously erupt into flames, your plants, pets and/or family members to wither and die, your power to go off, sunspots and solar eruptions, plagues, oceans of blood, demonic possessions, or monkeys to fly out of your butt. The author is not responsible for any damages, direct or consequential, that may result from its use.
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=