INSTALLATION:
	- install modloader v4 (http://www.minecraftforum.net/viewtopic.php?f=25&t=80246)
	- add all the files into minecraft.jar

CONFIGURATION:
By default the detector will be displayed.
The searched materials are Diamond and Iron.
To change the zoom level, you can use the B key.
To switch between materials, you can use the N key.
To filter the distance, you can use the V key.

In order to change this configuration, you can create in the folder %appdata%\.minecraft a file named EllianDetector.settings.
It can contains the following properties:
ZoomKey: equals to the key that you want to map with the zoom level switch
MaterialKey: equals to the key that you want to map with the material switch
DistanceKey: equals to the key that you want to map with the filter on the distance
Distance: equals to the value of  distance filter that you want to apply

Followed by the list of materials that you want to display in the form
<Material Name>=<Material code>

The material code can be found here: http://www.minecraftwiki.net/wiki/Data_Values 
 

 
sample of configuration file:
ZoomKey=B
MaterialKey=N
Diamond=56
Iron=15

