BDB_ModV1.0(1.7.3) - Boats Don't Break Mod

=== Description ===
The BDB_mod makes boats in minecraft un-crashable while you are riding them.
This means that if you crash into land while going fast, your boat will NOT break.
Also if you break the boat with your hands it gives you 5 planks which is exactly enough to make another boat

=== Installation ===
1.) Delete META-INF
2.) Drag-and-drop fz.class into minecraft.jar

Have fun with your un-crashable boats

=== In future updates ===
1.) when you break the boat with your hands it will give you the boat item in return instead of planks
2.) I will add a motor feature to the boat which makes you go super speed
3.) I will add a gun to the boat