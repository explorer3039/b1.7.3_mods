==========================================
Single Player Commands for PlayerAPI patch
==========================================

Version 1.0 for Single Player Commands 2.11.1

by Divisor



Description
===========

The Single Player Commands for PlayerAPI patch provides full SPC functionality without simply replacing the file "dc.class".

Instead ModLoader combined with the PlayerAPI mod will be used to hook into all methods necessary.



Required Mods
=============

Requires

    * ModLoader
    * Single Player Commands version 2.11.1
    * Flan's PlayerAPI version 1.7 or higher

to be installed in the listed order.



Installation
============

If you are allready using Single Player Commands:

* Update to the latest PlayerAPI version by copying the files inside the corresponding downloaded ZIP file to their corresponding locations in your "Minecraft.jar" in your "/.minecraft/bin/" - this will destroy SPC functionality.
* Update to the latest ModLoader version by copying the files inside the corresponding downloaded ZIP file to the same location - this might cause problem with other not-modloader mods.
* Copy all class files inside the "SPC-PlayerAPI Patch" ZIP file to the same location - this will restore SPC functionality.


If you are allready using PlayerAPI:

* Copy all files inside the your downloaded Single Player Commands ZIP file to their corresponding locations in your "Minecraft.jar" in your "/.minecraft/bin/" - this will add SPC but destroy PlayerAPI functionality.
* Update to the latest PlayerAPI version by copying the files inside the corresponding downloaded ZIP file to the same location - this will restore PlayerAPI but destroy SPC functionality.
* Update to the latest ModLoader version by copying the files inside the corresponding downloaded ZIP file to the same location - this might cause problem with other not-modloader mods.
* Copy all class files inside the "SPC-PlayerAPI Patch" ZIP file to the same location - this will restore SPC functionality.


If you use none of them:

* Copy all files inside the your downloaded Single Player Commands ZIP file to their corresponding locations in your "Minecraft.jar" in your "/.minecraft/bin/" - this will add SPC functionality.
* Update to the latest PlayerAPI version by copying the files inside the corresponding downloaded ZIP file to the same location - this will add PlayerAPI but destroy SPC functionality.
* Update to the latest ModLoader version by copying the files inside the corresponding downloaded ZIP file to the same location - this might cause problem with other not-modloader mods.
* Copy all class files inside the "SPC-PlayerAPI Patch" ZIP file to the same location - this will restore SPC functionality.
* Do not forget to delete the "META-INF" directory if you have not allready done it.


In any case, NEVER forget: ALWAYS back up your stuff!
