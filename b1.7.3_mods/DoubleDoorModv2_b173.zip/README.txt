Double Door Mod created by kirsybuu

DESCRIPTION:
Allows double doors to be opened and closed in unison.
New feature - Double Trap Doors! All the convenience of synchronized double doors, but horizontally!

Double doors and trap doors will work on unmodded clients playing on a modded server.
If installed on a client, they will not function on unmodded servers.


HOW TO INSTALL: 
1. Pick the correct version of the mod to use - IMPORTANT!
2. Drag 'n' drop the desired mod files into your bin/minecraft.jar or minecraft_server.jar
3. Delete the folder META-INF


VERSIONS:
Client mods for 1.7.3 -> "client version" folder
    le.class -> double door mod
    oq.class -> double trapdoor mod

Server mods for 1.7.3 -> "server version" folder
    hc.class -> double door mod
    jd.class -> double trapdoor mod

Should be compatible with all mods that do not directly modify the door or trap door class.
These mods can be used together or individually.
Mod loader not required.


CREDITS:
Created using Minecraft Coder Pack
Made possible by Mojang
Double trap doors suggested by gamalipi of the Minecraft forums.

This mod is Copyright ©2011 kirsybuu. No website is able to host any of my material without my(kirsybuu) consent. It may not be placed on any web site or otherwise distributed publicly without advance written permission. I(kirsybuu) am not responsible for any damage due to mod incompatabilties or otherwise.
