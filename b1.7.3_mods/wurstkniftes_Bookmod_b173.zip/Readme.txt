[======================================]
|---------wurstkniftes Bookmod---------|
|--------------V. 1.7------------------|
|---------for Minecraft 1.7.3----------|
[======================================]


[========About the mod=========]
So, this is wurstkniftes Bookmod. Thank for downloading it. This mod allows you
to write in books and store them in bookshelves. It doesn't replace the normal bookshelves
and books, so you can use them for decoration.
Since verison 1.5 you can make copies of your books with the writing table.
And the best thing: Fullscreen should work finally.   
I made a fully remake of the mod, because much of the code was very bad.
Now you can write the title for your book in the first line of the book and it is
shown in you inventory if you point at it.
This mod was my own idea, but then i recognized that an other talented modder already
created a mod like this one, but because it's outdated, i finished my own mod.
I thank Bhaumat for his idea where i got much of my inspiration from. 
[==============================]


[=========Installation=========]
Note: You need Risugami's Modloader for this mod.Download it here:
http://www.minecraftforum.net/viewtopic.php?t=80246

1->Extract all files from the archive.
2->Open Explorer, type in %appdata%, press enter and open the /.minecraft/bin/ folder
3->Open the minecraft.jar with a zip program like 7-Zip(www.7-zip.org)
4->Put the *.class-files and the "wk"-folder from the archive into the minecraft.jar
5->DELETE THE "META-INF"-FOLDER IF YOU HAVN'T DONE YET! 
   IF YOU DON'T DO THAT YOU WILL JUST GET A BLACK SCREEN!
6->Close your zip program
[==============================]


[===========Crafting===========]
The books are available in four colors, crafted from a simple book with a feather and the
dye you want for the book. You can use:
-Ink sac for black books
-Lapis lazuli for blue books
-Cactus green for green books
-Rose red for red books
For the ones who can't read so long texts:

 X
 ~
 #

X = Ink sac/Lapis lazuli/Cactus green/Rose red
~ = Feather
# = Book

The bookshelves are crafted like this:

###
\O\
###

# = Wooden planks
O = Chest
\ = Sticks

Recipe for the writing table:

 ~
 -
###

# = Wooden planks
- = Paper
~ = Feather
[==============================]


[==========Known bugs==========]
---If you write into a book that was copied on the writing desk, the writing will
   appear in the source book too.

If you find another bugs, post them in the forum thread, maybe I or someone
else can help you or I can fix the bug in a newer version.
[==============================]


[========Saving system=========]
The book texts are saved in files in a subfolder in the save directory of your world
(/.minecraft/saves/"Your save name"/books/). The files are called "bookX.txt", where X
ist the ID of the book. In the files, every line is a page in the book, and every 
paragraph("�") is a new line.
[==============================]


[========Compatibility=========]
Every mod which changes the "iw.class"isn't compatible with
this mod.

The IDs of the new contents are:

Red book->520
Blue book->521
Green book->522
Black book->523

Bookshelf->109
Copy Table->110

If you want to change the IDs, check the "wkBookmod.props"-file in your minecraft folder.

The mod is fully compatible with HD textures. 
[==============================]


[========Version history=======]
1.0--->Initial release
1.1--->Added ModLoader v5 support.
1.2--->1.4 support, changeable IDs 
1.3--->Book titles, fixed the "empty-book-bug"
1.4--->1.4_01 support
1.5--->1.5_01 support, Copy table, fullscreen support
1.6--->1.6.6 support, book colors, better titles, new saving system
1.7--->1.7.2/1.7.3 support
[==============================]


[===========Credits============]
wursknifte--->Coder
Korthek------>Designer(Gui, Icons)
Lyror-------->Co-artist(interface ideas and something like this)

And of course: Special thanks to Bhaumat, who created the
outdated Version of this mod, of which I knew nothing, when the half of
the mod was already finished. I took a lot of inspiration from his
mod(which can be found here: http://www.minecraftforum.net/viewtopic.php?t=90494&f=25)
The mod was made with the MCP. Thanks to everyone who done that great pack.
[==============================]

 
    