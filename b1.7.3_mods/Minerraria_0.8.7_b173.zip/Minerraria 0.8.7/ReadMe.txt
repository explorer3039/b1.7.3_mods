How to install:

1. Download ModLoader.
2. Drag all files inside "Jar" file to your minecraft.jar
3. Enjoy


What to test:
1. Try to Find the Corruption Biome
2. Find 5 new Ores
3. Find Demon eyes (not aggresive currently...)
4. Test all Crafting Recipes


More Items/Mobs going to be added..Enjoy!