Got from:
http://www.minecraftforum.net/forums/mapping-and-modding/minecraft-mods/1273917-1-7-3-tmims-mods
