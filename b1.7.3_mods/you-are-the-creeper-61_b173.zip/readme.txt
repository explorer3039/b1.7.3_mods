You Are the Creeper, a mod by Rotten194

Credits:
--------------
Rotten194, me: The mod! 
sismk: Nest block textures
Mr_okushama: HumanBehaviourAI.class, great guy, etc.
Risugami: ModLoader
_303: Spawnlist
#Risucraft: Helpful guys

Notes:
--------------
Feel free to decompile this for your own mods - the source is rather messy though! If you need help with a 
specific topic you can bug me over IRC.

Don't redistribute this without permission. Full liscense @ http://www.minecraftforum.net/viewtopic.php?f=1032&t=160365