INSTRUCTIONS:

Thank you for installing Obsidian Emeralds!

INSTRUCTIONS FOR INSTALLING OBSIDIAN EMERALDS 1.0
***
I expect you to have already installed ModLoader 1.8.1.
***
There will be two files:
1. Armor
2. Jar

PC:
AFTER INSTALLING MODLOADER:
Click on the 'Start' menu, and click run.  In run, type in, "%appdata%". From there, locate the .minecraft folder, and open up bin.  Using WinZip (or some other unarchiver), open up the minecraft.jar file and place all the files in 'Jar' into it.  Then, in minecraft.jar, find the "armor" folder and place all the files in 'Armor' into it.
You can close out of all these windows now.  Run the game and you should be good to go!
***
Mac:
AFTER INSTALLING MODLOADER:
In finder, on the top toolbar, click on the 'Go' drop-down menu and then click 'Go to Folder.'  In that text box, type in "/Users/<username>/Library/Application Support".  Please note to type in your computer's user in the place where I said '<username>'.  From there, locate your 'minecraft' folder, and after opening it click 'bin'.  Locate the file "minecraft.jar", and rename it "minecraft.jar.zip".  Double click the renamed file and then you should see a new file called "minecraft.jar".  Throw away the .zip file and open up the new 'minecraft.jar' file.  Drag all the files in "Jar" into this folder.  After this, locate the 'armor' folder located in 'minecraft.jar'.  Open it, and then drag all the contents of "Armor" into it.  Yay, you're finished!  Close out of all these windows now, and run minecraft.  You should be good to go!

NOTE:
Be sure to not place the mod's entire folders into the specified minecraft ones, only place the included files. 
***
THIS GAME WORKS WITH TOOMANYITEMS.  I am not sure about other mods.

If it doesn't work, please contact me at aidancbrady@yahoo.com.

Thank you for installing!

Forum link:
http://www.minecraftforum.net/topic/812232-181-obsidian-emeralds-10/


