Freerunner's Mod v2.0.0

How to install:
- Backup your minecraft.jar.
- Requires Risugami's ModLoader, so first install that one by following the instructions on ModLoader's forum post.
- Then drag and drop all files into the root of minecraft.jar with a file browser like 7-Zip or WinRar.
- If you don't want the animations, just don't install the ds.class and fh.class file.
- Delete META-INF if you did not do that already.
- Move the properties file to the .minecraft/mods/freerun/ folder. Edit it for custom block ID's and other settings.
- Enjoy!

---------------------------------------------------------------------------------------

Mod and textures made by BalkondeurAlpha!

---------------------------------------------------------------------------------------

Changelog v2.0.0
- IMPORTANT: Changed location of the properties file to the .minecraft/mods/freerun/ folder.
- Added some animations for climbing and wallrunning.
- Added ability to swim faster while freerunning.
- Added a new property to the properties file to set the speed multiplier.
- Added a new item, the climbing glove. Use it to reach even higher places.
- Improved falling and rolling again.
- Landing on mobs while freerunning prevent falling damage.
- Made climbing even more realistic.
- Made it possible to eject left and right, besides backwards, from a hanging position.
- Made wooden bars easier to select.
- More small tweaks and fixes.

More info about the mod at the forum post on www.minecraftforum.net/topic/411018-/

--------------------------------------------------------------------------------------

TERMS AND CONDITIONS
0. USED TERMS
MOD - modification, plugin, a piece of software that interfaces with the Minecraft client to extend, add, change or remove original capabilities.
MOJANG - Mojang AB
OWNER - Arjen Kremers, Original author of the MOD. Under the copyright terms accepted when purchasing Minecraft (http://www.minecraft.net/copyright.jsp) the OWNER has full rights over their MOD despite use of MOJANG code.
USER - End user of the mod, person installing the mod.

1. LIABILITY
THIS MOD IS PROVIDED 'AS IS' WITH NO WARRANTIES, IMPLIED OR OTHERWISE. THE OWNER OF THIS MOD TAKES NO RESPONSIBILITY FOR ANY DAMAGES INCURRED FROM THE USE OF THIS MOD. THIS MOD ALTERS FUNDAMENTAL PARTS OF THE MINECRAFT GAME, PARTS OF MINECRAFT MAY NOT WORK WITH THIS MOD INSTALLED. ALL DAMAGES CAUSED FROM THE USE OR MISUSE OF THIS MOD FALL ON THE USER.

2. USE
Use of this MOD to be installed, manually or automatically, is given to the USER without restriction.

3. REDISTRIBUTION
This MOD may only be distributed where uploaded, mirrored, or otherwise linked to by the OWNER solely. All mirrors of this mod must have advance written permission from the OWNER. ANY attempts to make money off of this MOD (selling, selling modified versions, adfly, sharecash, etc.) by others than the OWNER are STRICTLY FORBIDDEN, and the OWNER may claim damages or take other action to rectify the situation.

4. DERIVATIVE WORKS/MODIFICATION
This mod is provided freely and may be decompiled and modified for private use, either with a decompiler or a bytecode editor. Public distribution of modified versions of this MOD require advance written permission of the OWNER and may be subject to certain terms.

5. CONTACT
To contact the OWNER about any of the terms mentioned above, send your question to this e-mail adress: balkondeur@casema.nl
Or send the OWNER a PM on minecraftforum.net. Accountname: BalkondeurAlpha.