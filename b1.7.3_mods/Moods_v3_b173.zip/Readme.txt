Flan's Moods Mod for Minecraft 1.7.3

Version 3

------------
Installation
------------

1. Open the .zip archive (already done)
2. Open your .minecraft directory (appdata/.minecraft)
3. Go to .minecraft/bin and open your minecraft.jar in winRAR, winZIP, 7zip or any other suitiable program
4. Drag the files from "jar files" into the minecraft.jar
5. Install Risugami's ModLoader (similar instructions to above, included in ModLoader download)
6. Install SDK's ModLoaderMp (similar instructions to above)
7. Install PlayerAPI
8. DELETE THE META-INF FOLDER
9. Play!
