 ###########################
#   Mod: Lost Soul v1.1.2   #
#   For Minecraft v1.7.3    #
#   By Snaxt                #
 ###########################

Procedure:

Works with modloader

Step 1: Install modloader
Step 2: Copy all files from the folder "minecraft jar" of the archive into your minecraft.jar (Delete META-INF)
Step 3: Play Lost Soul


Installation:

Ce mode fonctionne avec le modloader.

Etape 1: Installer le modloader
Etape 2: Copier tous les fichiers du dossier "minecraft jar" de l'archive du mod dans minecraft.jar (Supprimer META-INF)
Etape 3: Jouez avec le mod Lost Soul



!! THANK YOU TO DOWNLOAD MY MOD !!