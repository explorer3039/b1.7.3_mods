package net.minecraft.src.radioBlock;

import java.io.File;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Random;
import paulscode.sound.SoundSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.src.*;

public class BlockRadio extends Block {
	
	private int x,y,z;
	public String currentSong;
	private Minecraft game = ModLoader.getMinecraftInstance();
	public int backTextureIndex, faceTextureIndex, sideTextureIndex, topTextureIndex;
	public boolean isMusicPlaying = false;
	private GuiRadio radioGui = new GuiRadio(this);
	private ArrayList<String> songs = new ArrayList<String>();
	private SoundSystem sndSystem;
	
	public BlockRadio(int id) {
		super(id, Material.wood);
		loadSongs();
	}

	private void loadSongs() {
		File files[] = null;
		try {
			files = new File(Minecraft.getMinecraftDir()+"/resources/mod/streaming/radio/").listFiles();
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(files!=null){
			for (int i = 0; i < files.length; i++) {
				StringBuilder sb = new StringBuilder(files[i].toString());
				sb.delete(0, sb.lastIndexOf("\\")+1);
				sb.delete(sb.indexOf("."), sb.length());
				songs.add(sb.toString());
			}
		}
	}

	@Override
	public void onBlockAdded(World world, int x, int y, int z) {
		setRadioDefaultDirection(world, x, y, z);
		updateVolume(world, x,y,z);
	}

	private void setRadioDefaultDirection(World world, int x, int y, int z) {
    	// TODO: Code for SMP.
        if(world.multiplayerWorld)
            return;
        int i = world.getBlockId(x,y,z-1);
        int j = world.getBlockId(x,y,z+1);
        int k = world.getBlockId(x-1,y,z);
        int l = world.getBlockId(x+1,y,z);
        byte bt0 = 3;
        if(Block.opaqueCubeLookup[i] && !Block.opaqueCubeLookup[j])
            bt0 = 3;
        if(Block.opaqueCubeLookup[j] && !Block.opaqueCubeLookup[i])
            bt0 = 2;
        if(Block.opaqueCubeLookup[k] && !Block.opaqueCubeLookup[l])
            bt0 = 5;
        if(Block.opaqueCubeLookup[l] && !Block.opaqueCubeLookup[k])
            bt0 = 4;
        world.setBlockMetadataWithNotify(x, y, z, bt0);
    }

	@Override
	public int getBlockTexture(IBlockAccess iblockaccess, int x, int y, int z, int side) {
		if(/*side==0||*/side==1)
			return topTextureIndex;
		if(side == 5-iblockaccess.getBlockMetadata(x, y, z)&&side!=1&&side!=0)
			return backTextureIndex;
        if(side == iblockaccess.getBlockMetadata(x, y, z))
        	return faceTextureIndex;
        return sideTextureIndex;
    }
	
	@Override
	public int getBlockTextureFromSide(int side) {
		/* 0 = bottom
		 * 1 = top
		 * 2 = front
		 * 3 = back
		 * 4,5 = sides
		 * ^that is wrong
		 * */
		if(side==0||side==1)
			return topTextureIndex;
		if(side==3)
			return backTextureIndex;
		return sideTextureIndex;
	}

	@Override
	public boolean blockActivated(World world, int x, int y, int z, EntityPlayer entityplayer) {
		//TODO Optimise this.
		this.x=x;
		this.y=y;
		this.z=z;
		ModLoader.OpenGUI(game.thePlayer, radioGui);
		//toggleMusic(world, x, y, z);
		return true;
	}
	
	@Override
	public void onBlockRemoval(World world, int x, int y, int z) {
		world.playRecord(null, x, y, z);
		isMusicPlaying = false;
		radioGui.updateIcons(isMusicPlaying);
		super.onBlockRemoval(world, x, y, z);
	}
	
	public void onPlayClicked() {
		toggleMusic(game.theWorld,x,y,z);
	}
	
	public void onBackwardClicked() {
		loadPrevSong();
	}
	
	public void onForwardClicked() {
		loadNextSong();
	}

	public void toggleMusic(World world, int x, int y, int z) {
		if(world.isAirBlock(x, y, z))
			return;
		if(songs.size()<1) {
			world.playSoundEffect((double)x, (double)y, (double)z, "random.click", 0.3F, 0.7F);
			return;
		}
		if(currentSong==null)
			currentSong=songs.get(0);
		if (!isMusicPlaying) {
			world.playSoundEffect((double)x, (double)y, (double)z, "random.click", 0.3F, 0.7F);
			world.spawnParticle("note", (double)x+0.5D, (double)y+1.2D, (double)z+0.5D, (double)new Random().nextFloat(), 0.0D, 0.0D);
            playMusic(currentSong, x, y, z);
            isMusicPlaying=true;
            radioGui.updateIcons(isMusicPlaying);
        } else {
        	world.playSoundEffect((double)x, (double)y, (double)z, "random.click", 0.3F, 0.2F);
            world.playRecord(null, x, y, z);
            isMusicPlaying=false;
            radioGui.updateIcons(isMusicPlaying);
        }
    	return;
    }
    
	private int tracker=1;
	private void loadNextSong() {
    	if(songs.size()<1)
    		return;
    	tracker++;
    	if(tracker>songs.size()-1)
    		tracker=0;
    	World world = game.theWorld;
    	String song=songs.get(tracker);
    	world.playSoundEffect((double)x, (double)y, (double)z, "random.click", 0.3F, 0.7F);
    	world.playRecord(null, x, y, z);
   		currentSong=song;
   		if(isMusicPlaying)
   			playMusic(currentSong, x, y, z);
	}
	
	private void loadPrevSong() {
    	if(songs.size()<1)
    		return;
    	tracker--;
    	if(tracker<0)
    		tracker=songs.size()-1;
    	World world = game.theWorld;
    	String song=songs.get(tracker);
    	world.playSoundEffect((double)x, (double)y, (double)z, "random.click", 0.3F, 0.7F);
    	world.playRecord(null, x, y, z);
   		currentSong=song;
   		if(isMusicPlaying)
   			playMusic(currentSong, x, y, z);
	}
	
    private String randomSong() {
    	if(songs.size()<1)
    		return null;
		return songs.get(new Random().nextInt(songs.size()));
	}

	public void playMusic(String name, int x, int y, int z) {
    	if(name != null)
            game.ingameGUI.setRecordPlayingMessage(name);
    	game.sndManager.playStreaming("radio."+name, x, y, z, 1.0F, 1.0F);
		updateVolume(game.theWorld, x,y,z);
    }

	public void onNeighborBlockChange(World world, int x, int y, int z, int side) {
		updateVolume(world, x,y,z);
	}
	
	private void updateVolume(World world, int x, int y, int z) {
		setVolume(speakersConnected(world,x,y,z));
	}

	private void setVolume(int amount) {
		if(sndSystem==null)
			try {
				sndSystem = getSoundSystemInstance();
			} catch (Exception e) {
				return;
			}
		amount = amount>2?2:amount;
		amount = amount==1?0:amount;
		sndSystem.setVolume("streaming", (1+amount)*0.5F*game.gameSettings.soundVolume);
		//game.ingameGUI.addChatMessage("Volume set to "+(1+amount));
	}

	private SoundSystem getSoundSystemInstance() throws IllegalArgumentException, IllegalAccessException {
		SoundManager sndManager = game.sndManager;
		Field fields[] = sndManager.getClass().getDeclaredFields();
	    for (int i = 0; i < fields.length; i++){ 
	    	if(fields[i].getName().equals("a")) {
	    		fields[i].setAccessible(true); 
	    		return (SoundSystem) fields[i].get(sndManager);
	    	}
	    }
		return null;
	}

	private int speakersConnected(World world, int x, int y, int z) {
		int amount=0;
		for(int i=-1;i<2;i++)
			for(int j=-1;j<2;j++)
				if(world.getBlockId(x+j, y, z+i)==mod_RadioBlock.speaker.blockID)
					amount++;
		//game.ingameGUI.addChatMessage(amount+" speakers connected.");
		return amount;
	}

	
}