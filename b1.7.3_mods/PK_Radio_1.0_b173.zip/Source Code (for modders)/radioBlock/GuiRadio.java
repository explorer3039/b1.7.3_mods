package net.minecraft.src.radioBlock;

import org.lwjgl.opengl.GL11;
import net.minecraft.client.Minecraft;
import net.minecraft.src.*;

public class GuiRadio extends GuiScreen {

	Minecraft game = ModLoader.getMinecraftInstance();
	private int guiTexX=0, guiTexY=0;
	private int guiSizeX=176, guiSizeY=76;
	private int guiPosX, guiPosY;
	private boolean isMusicPlaying = false;
	public boolean guiVisible = false;
	private BlockRadio radioBlock;
	
	public GuiRadio(BlockRadio radioBlock) {
		super();
		this.radioBlock=radioBlock;
		ScaledResolution scaledResolution
		= new ScaledResolution(game.gameSettings, game.displayWidth, game.displayHeight);
		guiPosX = (scaledResolution.getScaledWidth()-guiSizeX)/2;
		guiPosY = (scaledResolution.getScaledHeight()-guiSizeY)/2;
		//field_948_f = true;
	}
	
	private enum RadioButtonType{
		PLAYBUTTON(0,76,32,32,72,38),
		BACKWARDBUTTON(32,87,32,22,39,43),
		FORWARDBUTTON(64,87,32,22,105,43),
		PLAYICON(32,76,11,11,83,48),
		STOPICON(43,76,10,11,83,48),
		BACKICON(53,76,14,11,46,48),
		FORWARDICON(67,76,14,11,116,48);

		public int texX, texY, defaultTexY;
		public int sizeX, sizeY;
		public int posX, posY;
		public int buttonState=0;

		private RadioButtonType(int texX, int texY, int sizeX, int sizeY, int posX, int posY){
			this.texX=texX;
			this.texY=texY+(this.buttonState*sizeY);
			this.defaultTexY=this.texY;
			this.sizeX=sizeX;
			this.sizeY=sizeY;
			this.posX=posX;
			this.posY=posY;
		}
		public void updateButtonState(int state){
			if(this==RadioButtonType.PLAYBUTTON||this==RadioButtonType.BACKWARDBUTTON||this==RadioButtonType.FORWARDBUTTON){
				buttonState=state;
				texY=defaultTexY+(buttonState*sizeY);
			}
		}
	}
	
	private class RadioButton{
		private RadioButtonType rbt;
		public RadioButton(RadioButtonType rbt){
			this.rbt=rbt;
		}
		public void drawButton(int mouseX, int mouseY) {
			updateState(mouseX, mouseY);
			drawTexturedModalRect(guiPosX+rbt.posX, guiPosY+rbt.posY, rbt.texX, rbt.texY, rbt.sizeX, rbt.sizeY);
		}
		public void onClick(RadioButtonType rbt) {
			if(rbt==RadioButtonType.PLAYBUTTON)
				radioBlock.onPlayClicked();
			else if(rbt==RadioButtonType.BACKWARDBUTTON)
				radioBlock.onBackwardClicked();
			else if(rbt==RadioButtonType.FORWARDBUTTON)
				radioBlock.onForwardClicked();
		}
		private void updateState(int mouseX, int mouseY) {
			if(rbt.buttonState==2)
				return;
//			int mouseX = (Mouse.getX()*res.getScaledWidth())/mc.displayWidth;
//			int mouseY = res.getScaledHeight()-(Mouse.getY()*res.getScaledHeight())/mc.displayHeight-1;
			mouseX -= (width - guiSizeX) / 2;
			mouseY -= (height - guiSizeY) / 2;
			if (mouseX >= rbt.posX - 1
					&& mouseX < rbt.posX+rbt.sizeX+1
					&& mouseY >= rbt.posY-1
					&& mouseY < rbt.posY+rbt.sizeY+1)
				rbt.updateButtonState(1);
			else
				rbt.updateButtonState(0);
		}
	}
	
	public void updateIcons(boolean isMusicPlaying) {
		this.isMusicPlaying=isMusicPlaying;
	}
	
	@Override
	public void initGui() {
		controlList.clear();
		controlList.add(new RadioButton(RadioButtonType.PLAYBUTTON));
		controlList.add(new RadioButton(RadioButtonType.BACKWARDBUTTON));
		controlList.add(new RadioButton(RadioButtonType.FORWARDBUTTON));
		controlList.add(new RadioButton(RadioButtonType.PLAYICON));
		controlList.add(new RadioButton(RadioButtonType.STOPICON));
		controlList.add(new RadioButton(RadioButtonType.BACKICON));
		controlList.add(new RadioButton(RadioButtonType.FORWARDICON));
	}
	
	@Override
	public void drawScreen(int mouseX, int mouseY, float tickerThing)
    {
		ScaledResolution res = new ScaledResolution(game.gameSettings, game.displayWidth, game.displayHeight);
		guiPosX = (res.getScaledWidth() - guiSizeX) / 2;
		guiPosY = (res.getScaledHeight() - guiSizeY) / 2;
		drawDefaultBackground();
		drawGuiBG();
		drawGuiFGAndButtons(mouseX,mouseY);
	}
	
	private void drawGuiBG() {
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		mc.renderEngine.bindTexture(mc.renderEngine.getTexture("/radioBlock/textures/radiogui.png"));
		drawTexturedModalRect(guiPosX, guiPosY, guiTexX, guiTexY, guiSizeX, guiSizeY);
	}

	private void drawGuiFGAndButtons(int mouseX, int mouseY) {
		GL11.glDisable(32826 /*GL_RESCALE_NORMAL_EXT*/);
        RenderHelper.disableStandardItemLighting();
		GL11.glDisable(2896 /* GL_LIGHTING */);
		GL11.glDisable(2929 /* GL_DEPTH_TEST */);
		fontRenderer.drawStringWithShadow("(( Radio ))", guiPosX+(guiSizeX/2)-25, guiPosY+6, 0x660000);
		String song;
		if (radioBlock.currentSong!=null) {
			song = radioBlock.currentSong.length() <= 26 ? radioBlock.currentSong
					: new StringBuilder(radioBlock.currentSong)
							.delete(25, radioBlock.currentSong.length() + 1)
							.append("...").toString();
		} else
			song="-No Signal-";
		fontRenderer.drawString(song, guiPosX + 10, guiPosY + 22, 0x99FF00);
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		mc.renderEngine.bindTexture(mc.renderEngine.getTexture("/radioBlock/textures/radiogui.png"));
		for (int i = 0; i < controlList.size(); i++) {
			RadioButton radioButton = (RadioButton) controlList.get(i);
			if(radioButton.rbt==RadioButtonType.PLAYICON && isMusicPlaying)
				continue;
			if(radioButton.rbt==RadioButtonType.STOPICON && !isMusicPlaying)
				continue;
			radioButton.drawButton(mouseX, mouseY);
		}
		GL11.glEnable(32826 /*GL_RESCALE_NORMAL_EXT*/);
		RenderHelper.enableStandardItemLighting();
		GL11.glEnable(2896 /* GL_LIGHTING */);
		GL11.glEnable(2929 /* GL_DEPTH_TEST */);
	}
	
	@Override
	public boolean doesGuiPauseGame() {
		return false;
	}

	@Override
	public void onGuiClosed() {
		guiVisible = false;
	}

	@Override
	public void updateScreen() {
        super.updateScreen();
        if(!mc.thePlayer.isEntityAlive() || mc.thePlayer.isDead)
            mc.thePlayer.closeScreen();
    }

	@Override
	protected void mouseClicked(int x, int y, int button) {
		if (button == 0 || button == 1)
			for (int i = 0; i < controlList.size(); i++) {
				RadioButton radioButton = (RadioButton) controlList.get(i);
				if (radioButton.rbt.buttonState == 1) {
					radioButton.rbt.updateButtonState(2);
					radioButton.onClick(radioButton.rbt);
				}
			}
	}
	
	@Override
	protected void mouseMovedOrUp(int x, int y, int button) {
		for (int i = 0; i < controlList.size(); i++)
			((RadioButton) controlList.get(i)).rbt.updateButtonState(0);
	}

	@Override
	protected void keyTyped(char c, int i)
    {
        if(i == 1 || i == mc.gameSettings.keyBindInventory.keyCode)
            mc.thePlayer.closeScreen();
    }

}