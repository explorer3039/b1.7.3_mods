package net.minecraft.src.radioBlock;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;
import javax.imageio.ImageIO;
import net.minecraft.src.*;

public class TextureRadioFX extends TextureFX {

	private int tickCounter=0;
	private byte EQBG[] = new byte[1024];
	//16*16*4 (a byte is a 4-bit pixel colour and there are 255 pixels).
	private byte EQ[] = new byte[48];
	//2*6*4.
	private int barHeight = 0;
	
	public TextureRadioFX() {
		super(mod_RadioBlock.radio.faceTextureIndex);
		
		//Manipulating individual pixels, LIKE A BOSS.
		try {
			loadBG(ImageIO.read(this.getClass().getResource("textures/radio_face.png")));
			loadEQbar(ImageIO.read(this.getClass().getResource("textures/EQbar.png")));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void loadBG(BufferedImage bg) {
		for (int row=0;row<16;row++)
			for (int col=0;col<16;col++) {
				int pixel = bg.getRGB(col, row);
				EQBG[((col+(row*16))*4)+0] = (byte)((pixel>>16)&0xFF); //Red
				EQBG[((col+(row*16))*4)+1] = (byte)((pixel>>8)&0xFF); //Green
				EQBG[((col+(row*16))*4)+2] = (byte)((pixel)&0xFF); //Blue
				EQBG[((col+(row*16))*4)+3] = (byte)((pixel>>24)&0xFF); //Alpha
			}
	}
	
	private void loadEQbar(BufferedImage eq) {
		for (int row=0;row<6;row++)
			for (int col=0;col<2;col++) {
				int pixel = eq.getRGB(col, row);
				//ARGB Layers.
				EQ[((col+(row*2))*4)+0] = (byte)((pixel>>16)&0xFF); //Red
				EQ[((col+(row*2))*4)+1] = (byte)((pixel>>8)&0xFF); //Green
				EQ[((col+(row*2))*4)+2] = (byte)((pixel)&0xFF); //Blue
				EQ[((col+(row*2))*4)+3] = (byte)((pixel>>24)&0xFF); //Alpha
			}
	}

	public void onTick() {
		//BG to bottom layer.
		if(tickCounter%2==0) {
			imageData = EQBG.clone();

			//EQ bars.
			for (int bar=0;bar<5;bar++) {
				if(mod_RadioBlock.radio.isMusicPlaying) {
					barHeight += (new Random().nextInt(3)-1);
					barHeight = barHeight>6?6:barHeight;
					barHeight = barHeight<0?0:barHeight;
				} else
					barHeight = 0;
						
				for (int row=2+6-barHeight,eqy=0;row<8;row++,eqy++)
					for (int col=1,eqx=0;col<3;col++,eqx++) {
						if (anaglyphEnabled); //3D thing, cba

						//ARBG Layers.
						imageData[(((col+(bar*3))+(row*16))*4)+0] = EQ[((eqx+((eqy+6-barHeight)*2))*4)+0]; //Red
						imageData[(((col+(bar*3))+(row*16))*4)+1] = EQ[((eqx+((eqy+6-barHeight)*2))*4)+1]; //Green
						imageData[(((col+(bar*3))+(row*16))*4)+2] = EQ[((eqx+((eqy+6-barHeight)*2))*4)+2]; //Blue
						imageData[(((col+(bar*3))+(row*16))*4)+3] = EQ[((eqx+((eqy+6-barHeight)*2))*4)+3]; //Alpha
					}
			}
		}
		tickCounter++;
		if(tickCounter>100)
			tickCounter=0;
	}
}