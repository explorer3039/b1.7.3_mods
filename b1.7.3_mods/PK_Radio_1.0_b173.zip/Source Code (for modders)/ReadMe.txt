This folder contains the full deobfuscated code I wrote. Use what ever you want, it's completely open source.

I must warn you though, my code is slightly minimalistic and under-commented (in fact I barely comment on anything) and my style is sort of unconventional, being self-taught. So if you want me to explain the OpenGL methods I use for example or something, hit me up. ;)

If you have ModLoader related questions, I suggest you check out the ModLoader JavaDocs if you want to know what the methods I call do. When I'm modding chances are I'll be on #risucraft too.

~Paraknight