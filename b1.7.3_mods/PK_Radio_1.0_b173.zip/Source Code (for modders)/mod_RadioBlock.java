package net.minecraft.src;

import net.minecraft.src.radioBlock.*;
import net.minecraft.client.Minecraft;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class mod_RadioBlock extends BaseMod {

	public static BlockRadio radio = (BlockRadio) new BlockRadio(getRadioBlockID()).setHardness(2.0F).setResistance(10F).setStepSound(new StepSound("stone", 1.0F, 1.0F)).setBlockName("radio");
	public static Block speaker = new Block(getSpeakerBlockID(), Material.wood).setHardness(2.0F).setResistance(10F).setStepSound(new StepSound("stone", 1.0F, 1.0F)).setBlockName("speaker");
	
	public mod_RadioBlock() {
		loadBlockData();
		ModLoader.SetInGUIHook(this, true, false);
	}

	private static int getRadioBlockID() {
		int id=100;
		FileInputStream propFile = null;
		Properties radioProps = new Properties();
		try {
			propFile = new FileInputStream(Minecraft.getMinecraftDir().toString()+"/RadioMod.properties");
			radioProps.load(propFile);
			id=Integer.parseInt(radioProps.getProperty("RadioBlockID", "100"));
		} catch (Exception e){
		} finally {
			if(propFile!=null)
				try {propFile.close();} catch (IOException e){}
		}
		return id;
	}
	
	private static int getSpeakerBlockID() {
		int id=101;
		FileInputStream propFile = null;
		Properties radioProps = new Properties();
		try {
			propFile = new FileInputStream(Minecraft.getMinecraftDir().toString()+"/RadioMod.properties");
			radioProps.load(propFile);
			id=Integer.parseInt(radioProps.getProperty("SpeakerBlockID", "101"));
		} catch (Exception e){
		} finally {
			if(propFile!=null)
				try {propFile.close();} catch (IOException e){}
		}
		return id;
	}

	private void loadBlockData() {
		radio.faceTextureIndex = ModLoader.getUniqueSpriteIndex("/terrain.png");
		radio.backTextureIndex = ModLoader.addOverride("/terrain.png", "/radioBlock/textures/radio_back.png");
		radio.sideTextureIndex = ModLoader.addOverride("/terrain.png", "/radioBlock/textures/radio_side.png");
		radio.topTextureIndex = ModLoader.addOverride("/terrain.png", "/radioBlock/textures/radio_top.png");
		ModLoader.RegisterBlock(radio);
		ModLoader.AddName(radio, "Radio");
		ModLoader.AddRecipe(new ItemStack(radio, 1), new Object[] {
			"IPI", "PNP", "IPI", Character.valueOf('P'), Block.planks, Character.valueOf('I'), Item.ingotIron, Character.valueOf('N'), Block.musicBlock});
			//"#", Character.valueOf('#'), Block.sand});
		speaker.blockIndexInTexture = radio.sideTextureIndex;
		ModLoader.RegisterBlock(speaker);
		ModLoader.AddName(speaker, "Speaker");
		ModLoader.AddRecipe(new ItemStack(speaker, 1), new Object[] {
			"IPI", "PRP", "IPI", Character.valueOf('P'), Block.planks, Character.valueOf('I'), Item.ingotIron, Character.valueOf('R'), Item.redstone});
			//"#", Character.valueOf('#'), Block.dirt});
	}
	
	public void RegisterAnimation(net.minecraft.client.Minecraft game) {
		ModLoader.addAnimation(new TextureRadioFX());
	}
	
	public String Version(){return "for Minecraft Beta 1.7.3";}
}
