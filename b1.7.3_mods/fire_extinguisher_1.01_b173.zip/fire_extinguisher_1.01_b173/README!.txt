####################################################
#extinguisher V.1.01 2011 By Burnner               #
#                                                  #
#Dont be scare of fire!                            #
####################################################
---------------
How to Install
---------------
!!REQUIRES MODLOADER!!

1. Move the files from the intominecraft.jar folder into minecraft.jar (obviously)

2. Open Minecraft



If you like it, plz donate :)


Have Fun!

Burnner


24.08.2011
