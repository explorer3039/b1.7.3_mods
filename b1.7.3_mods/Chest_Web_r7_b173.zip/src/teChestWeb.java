public class teChestWeb extends ow implements lw {
	private static iz[] webItems = new iz[27];
	
	private iz[] items = new iz[27];
	private boolean updated = false;
	
	@Override
	public int a() {return items.length;}
	@Override
	public iz f_(int slot) {return items[slot];}
	@Override
	public String c() {return "ChestWeb";}
	@Override
	public int d() {return 64;}
	
	@Override
	public iz a(int slot, int amount) {
		if (items[slot] != null) {
			if (items[slot].a <= amount) {
				iz item = items[slot];
				items[slot] = null;
				y_();
				
				return item;
			}
			
			iz item = items[slot].a(amount);
			if (items[slot].a == 0) items[slot] = null;
			y_();
			
			return item;
		}
		return null;
	}
	
	@Override
	public void a(int slot, iz item) {
		items[slot] = item;
		if (item != null && item.a > d()) item.a = d();
		y_();
	}
	
	@Override
	public void n_() {
		if (!updated) {
			webGet();
			updated = true;
		}
	}
	
	public static void load(nu nbtCompound) {
		sp list = nbtCompound.l("Items");
		for (int i = 0; i < list.c(); i++) {
			nu cmp1 = (nu)list.a(i);
			int slot = cmp1.c("Slot") & 0xFF;
			webItems[slot] = new iz(cmp1);
		}
	}

	public static void save(nu nbtCompound) {
		sp list = new sp();
		for (int i = 0; i < webItems.length; i++) {
			if (webItems[i] != null) {
				nu cmp1 = new nu();
				cmp1.a("Slot",(byte)i);
				webItems[i].a(cmp1);
				list.a(cmp1);
			}
		}
		nbtCompound.a("Items",list);
	}
	
	@Override
	public void y_() {
		super.y_();
		d.i(e, f, g);
	}
	
	@Override
	public boolean a_(gs player) {
		if (d.b(e,f,g) != this) return false;
		return player.f(e+0.5D,f+0.5D,g+0.5D) <= 64D;
	}
	
	public void update() {
		webSet();
		for (Object obj : d.c) {
			if (obj instanceof teChestWeb) {
				teChestWeb chestWeb = (teChestWeb)obj;
				chestWeb.updated = false;
			}
		}
		updated = true;
	}
	
	public void webSet() {
		for (int i = 0; i < items.length; i++) {
			if (items[i] == null) {webItems[i] = null; continue;}
			webItems[i] = new iz(items[i].c,items[i].a,items[i].i());
		}
	}
	public void webGet() {
		for (int i = 0; i < items.length; i++) {
			if (webItems[i] == null) {items[i] = null; continue;}
			items[i] = new iz(webItems[i].c,webItems[i].a,webItems[i].i());
		}
	}
}