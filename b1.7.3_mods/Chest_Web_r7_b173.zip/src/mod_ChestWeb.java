import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import net.minecraft.client.Minecraft;

public class mod_ChestWeb extends BaseMod {
	static final int itemOff = 256;
	static final String dir = "/Shockah/ChestWeb/";
	private static fd worldObj;
	
	static final uu
		bOBSIDIAN = uu.aq,
		bCHEST = uu.av;
	
	static final gm
		iREDDUST = gm.aA;
	
	static uu bCHESTW;
	
	@MLProp public static int idMobileChest = 199;
	
	static {
		bCHESTW = new bChestWeb(idMobileChest);
		
		ToolBase.Pickaxe.mineBlocks.add(new BlockHarvestPower(bCHESTW.bn,80));
		
		ModLoader.RegisterTileEntity(teChestWeb.class,"ChestWeb");
	}
	
	public mod_ChestWeb() {
		ModLoader.RegisterBlock(bCHESTW);
		ModLoader.AddName(bCHESTW,"Mobile Chest");
		((bChestWeb)bCHESTW).loadSprites();
		
		ModLoader.AddRecipe(new iz(bCHESTW),"DOD","OCO","DOD",'C',bCHEST,'D',iREDDUST,'O',bOBSIDIAN);
		ModLoader.SetInGameHook(this,true,true);
		
		try {
			Class.forName("EnumRarity");
			EnumRarity.setRarity(EnumRarity.Rare,bCHESTW);
		} catch (Exception e) {}
	}
	
	public boolean OnTickInGame(Minecraft game) {
		if (!game.f.B) {
			if (game.f != worldObj) {
				if (worldObj != null) saveNBT(worldObj);
				if (game.f != null) loadNBT(game.f);
				worldObj = game.f;
			}
			if ((worldObj != null) && (worldObj.x.f() % worldObj.p == 0L)) saveNBT(worldObj);
		}
		return true;
	}
	
	public void saveNBT(fd world) {
		try {
			File f1 = GetWorldSaveLocation(world);
			File f2 = new File(f1,"ChestWeb.dat");
			if (!f2.exists()) as.a(new nu(),new FileOutputStream(f2));
			nu nbtCompound = as.a(new FileInputStream(f2));
			
			teChestWeb.save(nbtCompound);
			
			as.a(nbtCompound,new FileOutputStream(f2));
		} catch (Exception e) {e.printStackTrace();}
	}
	public void loadNBT(fd world) {
		try {
			File f1 = GetWorldSaveLocation(world);
			File f2 = new File(f1,"ChestWeb.dat");
			if (!f2.exists()) as.a(new nu(),new FileOutputStream(f2));
			nu nbtCompound = as.a(new FileInputStream(f2));
			
			teChestWeb.load(nbtCompound);
		} catch (Exception e) {e.printStackTrace();}
	}
	
	public String Version() {return "r7";}
	
	public static File GetWorldSaveLocation(fd world) {
		return world.w instanceof fm ? ((fm)world.w).a() : null;
	}
}