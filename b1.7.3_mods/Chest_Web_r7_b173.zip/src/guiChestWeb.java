import org.lwjgl.opengl.GL11;

public class guiChestWeb extends id {
	private lw inventory;
	private int m = 0;

	public guiChestWeb(teChestWeb chestWeb, lw paramij2) {
		super(new guiServerChestWeb(paramij2,chestWeb));
		inventory = paramij2;
		f = false;

		int i2 = 222;
		int j = i2-108;
		m = 3;

		i = j+m*18;
	}

	protected void k() {
		g.b("Chest Web",8,6,4210752);
		g.b(inventory.c(),8,i-96+2,4210752);
	}

	protected void a(float paramFloat) {
		int i2 = b.p.b("/gui/container.png");
		GL11.glColor4f(1F,1F,1F,1F);
		b.p.b(i2);
		int j = (c - a) / 2;
		int n = (d - i) / 2;
		b(j,n,0,0,a,m*18+17);
		b(j,n+m*18+17,0,126,a,96);
	}
}