import java.util.Random;

public class bChestWeb extends rw {
	public static int[] sprites = new int[2];
	
	public bChestWeb(int bID) {
		super(bID,sprites[0],ln.d); a(uu.h);
		a(getClass().getName());
		
		c(10F); b(2000F);
	}

	public int a(Random rand) {
		return 0;
	}
	
	public int a(xp blockAc, int px, int py, int pz, int side) {
		if (side == 0 || side == 1) return 37;

		int meta = new Loc(px,py,pz).getMeta(blockAc);
		if (side != meta) return sprites[0];
		
		return sprites[1];
	}
	public int a(int side) {
		if (side == 0 || side == 1) return 37;
		if (side == 3) return sprites[1];
		return sprites[0];
	}
	
	public boolean a(fd world, int px, int py, int pz, gs player) {
		ow tileEntity = new Loc(px,py,pz).getTileEntity(world);
		if (tileEntity != null) ModLoader.OpenGUI(player,new guiChestWeb((teChestWeb)tileEntity,player.c));
		return true;
	}
	
	public void d(fd world, int px, int py, int pz) {
		super.d(world,px,py,pz);
		h(world,px,py,pz);
	}
	public void a(fd world, int px, int py, int pz, ls living) {
		int i = in.b(living.aS*4F/360F+0.5D)&0x3;

		int meta = 0;
		if (i == 0) meta = 2;
		if (i == 1) meta = 5;
		if (i == 2) meta = 3;
		if (i == 3) meta = 4;
		new Loc(px,py,pz).setMetaNotify(world,meta);
	}
	private void h(fd world, int px, int py, int pz) {
		int i = world.a(px,py,pz-1);
		int j = world.a(px,py,pz+1);
		int k = world.a(px-1,py,pz);
		int m = world.a(px+1,py,pz);

		int meta = 3;
		if (uu.o[i] && !uu.o[j]) meta = 3;
		if (uu.o[j] && !uu.o[i]) meta = 2;
		if (uu.o[k] && !uu.o[m]) meta = 5;
		if (uu.o[m] && !uu.o[k]) meta = 4;
		new Loc(px,py,pz).setMetaNotify(world,meta);
	}
	
	public void loadSprites() {
		for (int i = 0; i < 2; i++) {
			sprites[i] = ModLoader.getUniqueSpriteIndex("/terrain.png");
			sprites[i] = ModLoader.addOverride("/terrain.png",mod_ChestWeb.dir+(getClass().getName())+i+".png");
		}
		bm = sprites[1];
	}

	protected ow a_() {return new teChestWeb();}
}