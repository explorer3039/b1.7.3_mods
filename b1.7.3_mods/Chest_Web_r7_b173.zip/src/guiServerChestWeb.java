public class guiServerChestWeb extends dw {
	private teChestWeb chestWeb;

	public guiServerChestWeb(lw paramij1, teChestWeb paramij2) {
		chestWeb = paramij2;
		int i = 3;

		int j = (i - 4) * 18;
		int m;
		for (int k = 0; k < i; k++) {
			for (m = 0; m < 9; m++) {
				a(new gp(paramij2, m + k * 9, 8 + m * 18, 18 + k * 18));
			}
		}

		for (int k = 0; k < 3; k++) {
			for (m = 0; m < 9; m++) {
				a(new gp(paramij1, m + k * 9 + 9, 8 + m * 18, 103 + k * 18 + j));
			}
		}
		for (int k = 0; k < 9; k++) a(new gp(paramij1, k, 8 + k * 18, 161 + j));
	}

	public boolean b(gs parameu) {
		chestWeb.update();
		return chestWeb.a_(parameu);
	}
}