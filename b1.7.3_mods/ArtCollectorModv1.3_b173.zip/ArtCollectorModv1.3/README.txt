V1.3

for 1.73

Installation

open minecraft.jar with 7zip etc.
add files to Jar 
Delete meta-Inf



the names of the files are as follows

white       - kz
green       - kgreen
blue        - kblu
lightblue   - klb
lime green  - klgreen
grey        - kgrey
brown       - kbr
light grey  - klgrey
black       - kbla
pink        - kpi
purple      - kpu
yellow      - ky
cyan        - kc
orange      - ko
red         - kr
magenta     - km


texture packs will work with this mod, just you'll only be able to see white wool paintings


Art Collector Mod by Redaxe