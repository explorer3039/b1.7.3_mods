trainjo's erosion mod version 2.2
---------------------------------

Installation
------------
  1) Make sure you have installed modloader correctly
  2) Place mod_erosion.zip in the folder mods inside the minecraft directory
  3) Start Minecraft and have fun!

Description
-----------
This mod allows flowing water to erode some kinds of blocks in minecraft.
If water touches such a block it will have a chance to change in another block.
Stone will change into cobblestone.
Cobblestone will change into gravel.
Gravel will change into sand.
Sand will dissapear when eroded.

Configuration
-------------
In the Erosion.cfg file in the config folder you can set the following options:

erosion_time:
	use: Determines the time it takes for a block to erode.
	values: Anywhere between 1 and 50000. The default is 20.
erosion_mode:
	use: Determines the mode the erosion mod runs in.
	values: 1, 2 or 3. 1 is the least lag, 3 is the most realistic, 2 is default.
erosion:
	use: Turn the mod on and off.
	values: true when on, false when off.


Version history
---------------
v2.3 Added grass dissapearing underneath water and different erosion times for every material.
v2.2 Fixed a bug in version 2.1 and the water will now take on a more river like shape (less lakes).
v2.1 Erosion is now mainly happening in the direction the water is flowing in. Also made erosion downwards less common.
v2.0 Updated to 1.7.3 and made an option to reduce lag.
v1.3 some changes to make the system work better. A block touching two flowing water will now erode twice as fast.
	The erosion time has increased significantly. A single water block now takes at least 50 seconds to erode a block.
	You might want to check your erosion time since 50 in 1.2 is a lot quicker than 50 in 1.3. The default has changed from 50 to 5 (which is already slower!)
v1.2 a minor change to stop the code from being triggered in multiplayer. (will add multiplayer support later, but has to be server side)
v1.1 added a config file in the config directory. Edit the value erosion_time to make erosion slower or quicker
v1.0 expanded the area for erosion a lot. It now takes longer for a block to erode.
v0.1 initial release