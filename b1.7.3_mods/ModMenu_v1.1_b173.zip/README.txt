ModMenu v1.1 for beta 1.7.3

Requires:

- ModLoader

- OverrideAPI v0.1_02 or higher

Compatibility:

- Should be compatible with anything

Installation:

- Use this .zip as mod for minecraft.jar

�hangeLog:

- Added modinfo for each mod. It can be found in ".minecraft/config/Mod Menu/" and edited.

TODO list:

1) Add functionality for buttons (so you can turn on and off mods, but this will be applied only after a restart)

2) Add more info (like authors, multiplayer support, bigger description, etc)

Credit:

- mine_diver

Feel free to use it :D