package net.minecraft.src;

import java.util.Map;

import net.mine_diver.modmenu.Core;
import net.mine_diver.modmenu.info;

public class mod_ModMenu extends BaseMod {
	public mod_ModMenu() {
		Core.INSTANCE.init();
	}
	
	@Override
	public void AddRenderer(@SuppressWarnings("rawtypes") Map map) {
		Core.INSTANCE.postInit();
	}
	
	public String Name() {
		return info.NAME;
	}
	
	public String Description() {
		return info.DESCRIPTION;
	}
	
	@Override
	public String Version() {
		return info.VERSION;
	}
	
}
