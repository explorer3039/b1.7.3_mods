package net.mine_diver.modmenu.util;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Properties;

import javax.imageio.ImageIO;

import org.lwjgl.opengl.GL11;

import net.mine_diver.modmenu.Core;
import net.minecraft.client.Minecraft;
import net.minecraft.src.BaseMod;

public class Mod {
	public Mod(BaseMod mod) {
		baseMod = mod;
		Properties config = Core.INSTANCE.config.load(this);
		name = config.getProperty("name", getName());
		description = config.getProperty("description", getDescription());
		config.setProperty("name", name);
		config.setProperty("description", description);
		Core.INSTANCE.config.save(this, config);
		version = baseMod.Version();
		modTextureId = -1;
		try
        {
            modThumbnail = ImageIO.read(getClass().getResource(getThumbnailPath()));
        }
        catch(IOException ioexception)
        {
            ioexception.printStackTrace();
        }
		catch(IllegalArgumentException e) {};
	}
	
	private String getName() {
		String name = baseMod.getClass().getSimpleName().startsWith("mod_") ? baseMod.getClass().getSimpleName().substring(4) : baseMod.getClass().getSimpleName();
		try {
			name = (String)baseMod.getClass().getDeclaredMethod("Name", new Class<?>[]{}).invoke(baseMod, new Object[]{});
		} catch (Exception e) {}
		return name;
	}
	
	private String getDescription() {
		String description = defaultDescription;
		try {
			description = (String)baseMod.getClass().getDeclaredMethod("Description", new Class<?>[]{}).invoke(baseMod, new Object[]{});
		} catch (Exception e) {}
		return description;
	}
	
	private String getThumbnailPath() {
		String thumbnailPath = "/gui/mods/" + (baseMod.getClass().getSimpleName().startsWith("mod_") ? baseMod.getClass().getSimpleName().substring(4) : baseMod.getClass().getSimpleName()) + ".png";
		try {
			thumbnailPath = (String)baseMod.getClass().getDeclaredMethod("Icon", new Class<?>[]{}).invoke(baseMod, new Object[]{});
		} catch (Exception e) {}
		return thumbnailPath;
	}
	
	public void bindThumbnailTexture(Minecraft minecraft) {
		if(modThumbnail != null && modTextureId < 0)
        {
            modTextureId = minecraft.renderEngine.allocateAndSetupTexture(modThumbnail);
        }
        if(modThumbnail != null)
        {
            minecraft.renderEngine.bindTexture(modTextureId);
        } else
        {
            GL11.glBindTexture(3553, minecraft.renderEngine.getTexture(defaultIcon));
        }
	}
	
	@Override
	public String toString() {
		return name + ":" + description + ":" + version;
	}
	
	public final BaseMod baseMod;
	public final String name;
	public final String description;
	public final String version;
	private BufferedImage modThumbnail;
	private int modTextureId;
	
	public static String defaultDescription = "A ModLoader mod";
	public static String defaultIcon = "/gui/background.png";
}
