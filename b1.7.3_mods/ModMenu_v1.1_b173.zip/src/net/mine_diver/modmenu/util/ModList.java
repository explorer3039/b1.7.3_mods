package net.mine_diver.modmenu.util;

import java.util.*;
import net.minecraft.src.BaseMod;
import net.minecraft.src.ModLoader;

public class ModList
{

    public ModList()
    {
        loadedMods = new ArrayList<Mod>();
        field_6538_d = new HashMap<String, Mod>();
        updateLoadedMods();
    }

    @SuppressWarnings("unchecked")
	public void updateLoadedMods()
    {
    	loadedMods.clear();
        for (BaseMod baseMod : (List<BaseMod>)ModLoader.getLoadedMods()) {
        	Mod mod = new Mod(baseMod);
        	if (!field_6538_d.containsKey(mod.toString())) {
        		field_6538_d.put(mod.toString(), mod);
        	}
        	loadedMods.add(field_6538_d.get(mod.toString()));
        }
    }

    public List<Mod> loadedMods()
    {
        return new ArrayList<Mod>(loadedMods);
    }

    private List<Mod> loadedMods;
    private Map<String, Mod> field_6538_d;
}
