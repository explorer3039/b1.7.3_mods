package net.mine_diver.modmenu;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

import net.mine_diver.modmenu.util.Mod;
import net.minecraft.client.Minecraft;

public class Config {
	public void init() {
		if (!configDir.exists()) {
			configDir.mkdirs();
		}
	}
	
	public Properties load(Mod mod) {
		Properties config = new Properties();
		FileInputStream file;
		try {
			file = new FileInputStream(configDir + "/"
		+ (mod.baseMod.getClass().getSimpleName().startsWith("mod_") ? mod.baseMod.getClass().getSimpleName().substring(4) : mod.baseMod.getClass().getSimpleName())
		+ ".modinfo");
			config.load(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return config;
	}
	
	public void save(Mod mod, Properties config) {
		try {
			FileOutputStream file = new FileOutputStream(configDir + "/"
		+ (mod.baseMod.getClass().getSimpleName().startsWith("mod_") ? mod.baseMod.getClass().getSimpleName().substring(4) : mod.baseMod.getClass().getSimpleName())
		+ ".modinfo");
			config.store(file, "Mod info for " + mod.baseMod.getClass().getSimpleName());
			file.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	private final File configDir = new File(Minecraft.getMinecraftDir() + "/config/Mod Menu/");
}
