package net.mine_diver.modmenu;

import net.mine_diver.modmenu.gui.GuiEventsHandler;
import net.mine_diver.modmenu.util.ModList;
import net.minecraft.src.overrideapi.OverrideAPI;

public class Core {
	
	private Core() {}
	
	public static final Core INSTANCE = new Core();
	
	public void init() {
		OverrideAPI.registerButtonHandler(new GuiEventsHandler());
		config.init();
	}
	
	public void postInit() {
		modList = new ModList();
	}
	
	public final Config config = new Config();
	public ModList modList;
}
