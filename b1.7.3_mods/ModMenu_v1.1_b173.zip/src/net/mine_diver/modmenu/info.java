package net.mine_diver.modmenu;

public class info {
	public static final String NAME = "Mod Menu";
	public static final String DESCRIPTION = "Adds the Mod Menu you're looking at!";
	public static final String VERSION = "v1.0";
}
