This is Right Click Harvest for Minecraft Beta 1.7.3 Client

DESCRIPTION
This is a small mod that lets you harvest wheat from fully grown crops by right clicking with an empty fist

INSTALL
1. Install Modloader
2. Delete META-INF from the minecraft.jar
3. Insert this zip into the .minecraft/mods folder
4. ???
5. Success!