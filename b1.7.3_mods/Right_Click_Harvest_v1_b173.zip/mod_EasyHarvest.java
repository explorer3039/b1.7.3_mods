package net.minecraft.src;

import org.lwjgl.input.Mouse;

import net.minecraft.client.Minecraft;

public class mod_EasyHarvest extends BaseMod {
	
	private Minecraft mc = ModLoader.getMinecraftInstance();
	private boolean btwInstalled = false;

	public String Version() {
		return "v1";
	}
	
	public mod_EasyHarvest() {
		ModLoader.SetInGameHook(this, true, false);
	}
	
	public void ModsLoaded()
    {
		btwInstalled = ModLoader.isModLoaded("mod_FCBetterThanWolves");
    }
	
	public boolean OnTickInGame(Minecraft minecraft)
    {
		if(Mouse.isButtonDown(1) && mc.objectMouseOver != null && mc.objectMouseOver.typeOfHit == EnumMovingObjectType.TILE)
        {
            int x = mc.objectMouseOver.blockX;
            int y = mc.objectMouseOver.blockY;
            int z = mc.objectMouseOver.blockZ;
            int id = mc.theWorld.getBlockId(x, y, z);
        	int metadata = mc.theWorld.getBlockMetadata(x, y, z);
            if((id == Block.crops.blockID && Block.blocksList[id].idDropped(metadata, mc.theWorld.rand) == Item.wheat.shiftedIndex)
            		|| (btwInstalled && id == mod_FCBetterThanWolves.fcHempCrop.blockID && Block.blocksList[id].idDropped(metadata, mc.theWorld.rand) == mod_FCBetterThanWolves.fcHemp.shiftedIndex)) {
            	if(mc.thePlayer.inventory.getCurrentItem() == null)
                {
                    mc.playerController.clickBlock(x, y, z, mc.objectMouseOver.sideHit);
                    mc.thePlayer.swingItem();
                }
            }
        }
        return true;
    }

}
