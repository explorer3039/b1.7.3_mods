// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

// Referenced classes of package net.minecraft.src:
//            BaseMod, ItemRecipeBook, Item, ModLoader, 
//            ItemStack

public class mod_URB extends BaseMod
{

	public String Version()
    {
        return "v2.0";
    }
	
	public mod_URB()
    {
		Item book = new ItemURB(recipeBookID);
		ModLoader.AddShapelessRecipe(new ItemStack(book), 
        	new Object[] { Block.workbench, Item.book, new ItemStack(Item.dyePowder, 1, 0) }
        );
        ModLoader.AddName(book, "Recipe Book");
        
        //Check if ModLoaderMP is installed
        try {
        	Class.forName("ModLoaderMp");
			modloaderMPinstalled = true;
			
			//Try to load URB's BaseModMp file
			try {
				ClassLoader classloader = (net.minecraft.src.ModLoader.class).getClassLoader();
				Method addmodMethod = ModLoader.class.getDeclaredMethod("addMod", ClassLoader.class, String.class);
				addmodMethod.setAccessible(true);
				addmodMethod.invoke(null, new Object[] { classloader, "URB_MP.class" });
			} 
			catch (IllegalAccessException e) { e.printStackTrace(); } 
			catch (InvocationTargetException e) { e.printStackTrace(); }
			catch (NoSuchMethodException e) { e.printStackTrace(); } 
		} 
        catch (ClassNotFoundException e) { modloaderMPinstalled = false; }
    }
	
	public static List getRecipes() {
		if (recipes == null) {
			recipes = CraftingManager.getInstance().getRecipeList();
			for (int i = 0; i < recipes.size(); i++) {
				//Removes recipes that are too big and ruin everything @flans mod
				if(((IRecipe)recipes.get(i)).getRecipeSize() > 9)
                {
					recipes.remove(i);
					i-=1;
                }
        	}
		}
        return recipes;
	}
	
    @MLProp(name="RecipeBookID", info="The item ID for the recipe book", min=256, max=31999)
    public static int recipeBookID = 398;
    
    @MLProp(name="GuiID", info="The gui ID used in ModLoaderMP: must be the same as the one in the server file", min=0, max=127)
    public static int guiID = 15;
    private static List recipes;
    public static boolean modloaderMPinstalled;
}
