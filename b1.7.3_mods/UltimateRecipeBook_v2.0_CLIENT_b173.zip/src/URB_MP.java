package net.minecraft.src;

public class URB_MP extends BaseModMp {

	public String Version() {
		return "v2.0";
	}

	URB_MP() {
		//TODO option to change gui id
		//TODO TEST ITEM & GUI ID LIMITS
		 ModLoaderMp.RegisterGUI(this, mod_URB.guiID);
	}
	
	public GuiScreen HandleGUI(int inventoryType)
	{
			if(inventoryType == mod_URB.guiID) {
				InventoryPlayer inv = ModLoader.getMinecraftInstance().thePlayer.inventory;
				return new GuiURB(inv, inv.getCurrentItem());
			}
			else return null;
	}
	 
	public static void sendBookDamageToServer(int newDamageValue) {
			int[] dataInt = new int[1];
	    	dataInt[0] = newDamageValue;
	    	Packet230ModLoader packet = new Packet230ModLoader();
	    	packet.dataInt = dataInt;
	    	ModLoaderMp.SendPacket(ModLoaderMp.GetModInstance(URB_MP.class), packet);
	}
}
