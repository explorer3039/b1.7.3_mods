// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Logger;

// Referenced classes of package net.minecraft.src:
//            IInventory, CraftingManager, ModLoader, ItemStack, 
//            IRecipe, ShapedRecipes, ShapelessRecipes, EntityPlayer

public class InventoryURB
    implements IInventory
{

    public InventoryURB(ItemStack itemstack)
    {
    	index = -1;
    	recipesComplete = mod_URB.getRecipes();
    	recipes = recipesComplete;
        items = new ItemStack[6][];
        book = itemstack;
        index = setIndex(book.getItemDamage()*6);
    }

    public void decIndex()
    {
        index = setIndex(index - 6);
    }

    public void incIndex()
    {
        index = setIndex(index + 6);
    }
    
    public int getPage() {
    	return index/6;
    }

    public int setIndex(int i)
    {
        if(index == i && !newList)
        {
            return i;
        }
        newList = false;
        if(i < 0)
        {
        	i = recipes.size() - 1;
        	if (i == -1)
        		i = 0;
        } else
        if(i >= recipes.size())
        {
            i = 0;
        }
        items = new ItemStack[6][];
        for(int j = 0; j < 6; j++)
        {
            items[j] = new ItemStack[10];
            int k = i + j;
            if(k < recipes.size())
            {
                IRecipe irecipe = (IRecipe)recipes.get(k);
                try
                {
                    if(irecipe instanceof ShapedRecipes)
                    {
                        int l = ((Integer)ModLoader.getPrivateValue(net.minecraft.src.ShapedRecipes.class, (ShapedRecipes)irecipe, 0)).intValue();
                        ItemStack aitemstack[] = (ItemStack[])ModLoader.getPrivateValue(net.minecraft.src.ShapedRecipes.class, (ShapedRecipes)irecipe, 2);
                        items[j][0] = irecipe.getRecipeOutput();
                        for(int k1 = 0; k1 < aitemstack.length; k1++)
                        {
                        	if (aitemstack[k1] != null && aitemstack[k1].stackSize > 1) aitemstack[k1].stackSize = 1;
                            int l1 = k1 % l;
                            int i2 = k1 / l;
                            items[j][l1 + i2 * 3 + 1] = aitemstack[k1];
                        }

                    } else
                    if(irecipe instanceof ShapelessRecipes)
                    {
                        List list = (List)ModLoader.getPrivateValue(net.minecraft.src.ShapelessRecipes.class, (ShapelessRecipes)irecipe, 1);
                        items[j][0] = irecipe.getRecipeOutput();
                        for(int j1 = 0; j1 < list.size(); j1++)
                        {
                            items[j][j1 + 1] = (ItemStack)list.get(j1);
                        }

                    }
                }
                catch(Throwable throwable)
                {
                    ModLoader.getLogger().throwing("RecipeInventory", "setIndex", throwable);
                    ModLoader.ThrowException("Exception in RecipeInventory", throwable);
                }
            }
        }

        
        return i;
    }

    public int getSizeInventory()
    {
        return 60;
    }

    public ItemStack decrStackSize(int i, int j)
    {
    	if(i == 9)
        {
            if(filter.stackSize <= j)
            {
                ItemStack itemstack = filter;
                filter = null;
                newList = true;
                
                return itemstack;
            }
            ItemStack itemstack1 = filter.splitStack(j);
            if(filter.stackSize == 0)
            {
                filter = null;
                newList = true;
            }
            return itemstack1;
        }
        return null;
        
    }

    public void setInventorySlotContents(int i, ItemStack itemstack)
    {
    	if (i == 9) {
    		if (filter != itemstack) {
    			newList = true;
    		}
    		filter = itemstack;
    	}
        //items[i / 10][i % 10] = itemstack;
    }

    public boolean canInteractWith(EntityPlayer entityplayer)
    {
        return true;
    }

    public String getInvName()
    {
        return String.format("%d / %d", new Object[] {
            getPage() + 1, Integer.valueOf((recipes.size() - 1) / 6) + 1
        });
    }

    public ItemStack getStackInSlot(int i)
    {
    	if (i == 9) {
    		return filter;
    	}
    	i -= 10;
    	if (items[i / 10] != null) {
    		return items[i / 10][i % 10];
    	}
    	
    	return null;
    }

    public int getInventoryStackLimit()
    {
        return 64;
    }

    public void onInventoryChanged()
    {
    	if (newList) {
    		recipes = getMatchingRecipes(filter);
        	index = setIndex(0);
        	newList = false;
    	}
    }
    
    public List getMatchingRecipes(ItemStack itemstack)
    {
    	List arraylist = new ArrayList();
    	if (itemstack == null) {
    		return recipesComplete;
    	}
    	for(Iterator iterator = recipesComplete.iterator(); iterator.hasNext();)
        {
            IRecipe irecipe = (IRecipe)iterator.next();
           if(itemstack.itemID == irecipe.getRecipeOutput().itemID && (irecipe.getRecipeOutput().getItemDamage() == itemstack.getItemDamage() || irecipe.getRecipeOutput().getItemDamage() < 0))
            //if(itemstack.itemID == irecipe.getRecipeOutput().itemID && ( (irecipe.getRecipeOutput().getItemDamage() == itemstack.getItemDamage() || !irecipe.getRecipeOutput().getHasSubtypes()) )|| irecipe.getRecipeOutput().getItemDamage() < 0)
            {
                arraylist.add(irecipe);
            } else
            if(irecipe instanceof ShapedRecipes)
            {
                ShapedRecipes shapedrecipes = (ShapedRecipes)irecipe;
                try
                {
                    ItemStack aitemstack[] = (ItemStack[])ModLoader.getPrivateValue(net.minecraft.src.ShapedRecipes.class, (ShapedRecipes)irecipe, 2);
                    ItemStack aitemstack1[];
                    int j = (aitemstack1 = aitemstack).length;
                    for(int i = 0; i < j; i++)
                    {
                        ItemStack itemstack1 = aitemstack1[i];
                        if(itemstack1 == null || itemstack.itemID != itemstack1.itemID || itemstack1.getItemDamage() != itemstack.getItemDamage() && itemstack1.getItemDamage() >= 0)
                        {
                            continue;
                        }
                        arraylist.add(irecipe);
                        break;
                    }

                }
                catch(Exception exception)
                {
                   exception.printStackTrace();
                }
            } 
            else if(irecipe instanceof ShapelessRecipes)
            {
                ShapelessRecipes shapelessrecipes = (ShapelessRecipes)irecipe;
                try
                {
                    List list = (List)ModLoader.getPrivateValue(net.minecraft.src.ShapelessRecipes.class, (ShapelessRecipes)irecipe, 1);
                    for(Iterator iterator1 = list.iterator(); iterator1.hasNext();)
                    {
                        Object obj = iterator1.next();
                        ItemStack itemstack2 = (ItemStack)obj;
                        if(itemstack.itemID == itemstack2.itemID && (itemstack2.getItemDamage() == itemstack.getItemDamage() || itemstack2.getItemDamage() < 0))
                        {
                            arraylist.add(irecipe);
                            break;
                        }
                    }

                }
                catch(Exception exception)
                    {
                        exception.printStackTrace();
                    }
                
            }
        }
        return arraylist;
    }
    
    public void savePageToDamage(int i) {
    	book.setItemDamage(i);
    	if (mod_URB.modloaderMPinstalled) {
    		URB_MP.sendBookDamageToServer(i);
    	}
    }
    
    
    private Boolean newList = false;
    private static List recipesComplete;
    private List recipes;
    private final ItemStack book;
    protected ItemStack filter;
    private int index;
    public ItemStack items[][];
	

}
