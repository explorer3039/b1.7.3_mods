// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;


// Referenced classes of package net.minecraft.src:
//            Item, ModLoader, GuiRecipesCraft, EntityPlayer, 
//            ItemStack, World

public class ItemURB extends Item
{

    protected ItemURB(int i)
    {
        super(i - 256);
        setItemName("recipeBook");
        setIconCoord(11, 3);
        maxStackSize = 1;
    }

    public int getColorFromDamage(int i)
    {
    	return 0xffa0a0;
    }

    public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer entityplayer)
    {
    	ModLoader.OpenGUI(entityplayer, new GuiURB(entityplayer.inventory, itemstack));
    	return itemstack;
    }

	
}
