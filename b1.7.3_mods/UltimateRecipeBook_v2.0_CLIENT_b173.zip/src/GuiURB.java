// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

// Referenced classes of package net.minecraft.src:
//            GuiContainer, CraftingInventoryRecipeBookCB, InventoryRecipeBook, FontRenderer, 
//            RenderEngine

public class GuiURB extends GuiContainer
{

    protected int ySize2;
	public GuiURB(IInventory iinventory, ItemStack itemstack)
    {
		super(new ContainerURB(iinventory, inv = new InventoryURB(itemstack)));
        xSize = 242;
        ySize = 173 + 48;
        ySize2 = 173;
    }
	
	//Change page with scroll wheel
    public void handleMouseInput()
    {
        int i = Mouse.getEventDWheel();
        if(i > 0) inv.incIndex();
        if(i < 0) inv.decIndex();
        super.handleMouseInput();
    }

    //Change page with LMB or RMB
    protected void mouseClicked(int i, int j, int k)
    {
    	if ((i > width - xSize >> 1) && (i - xSize < width - xSize >> 1)
        		&& (j > height - ySize2 >> 1) && (j - ySize2 < height - ySize2 >> 1)) {
        	if(k == 0) inv.incIndex();
        	if(k == 1) inv.decIndex();
        }
        else {
        	super.mouseClicked(i, j, k);
        }
    }
    
    //Change page with arrow keys
    protected void keyTyped(char c, int i)
    {
    	if (i == 205) inv.incIndex();
        if (i == 203) inv.decIndex();
        super.keyTyped(c, i);
    }
    
    protected void drawGuiContainerForegroundLayer()
    {
    	String s = inv.getInvName();
        fontRenderer.drawString(s, xSize - 4 - s.length() * 6, 34, 0x404040);
    }
    
    protected void drawGuiContainerBackgroundLayer(float f)
    {
    	drawDefaultBackground();
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        mc.renderEngine.bindTexture(mc.renderEngine.getTexture("/gui/crafting.png"));
        int j = width - xSize >> 1;
        int k = height - ySize2 >> 1;
        int l = (xSize - 8) / 2;
        for(int i1 = 0; i1 < 2; i1++)
        {
        	drawTexturedModalRect(j + 4 + i1 * l, k+3, 4, 0, l, 4); //top border
            drawTexturedModalRect(j + 4 + i1 * l, (k + ySize2) - 4+3, 4, 162, l, 4); //bottom border
        	
        }

        int j1 = (ySize2 - 8) / 3;
        for(int k1 = 0; k1 < 3; k1++)
        {
            drawTexturedModalRect(j, k + 4 + k1 * j1+3, 0, 4, 4, j1); //left border
            drawTexturedModalRect((j + xSize) - 4, k + 4 + k1 * j1+3, 172, 4, 4, j1); //right border
        }

        //four corners
        drawTexturedModalRect(j, k+3, 0, 0, 4, 4);
        drawTexturedModalRect(j + 238, k+3, 172, 0, 4, 4);
        drawTexturedModalRect(j, (k + ySize2) - 4+3, 0, 162, 4, 4);
        drawTexturedModalRect((j + xSize) - 4, (k + ySize2) - 4+3, 172, 162, 4, 4);
        
        
        for(int l1 = 0; l1 < 2; l1++)
        {
            for(int i2 = 0; i2 < 3; i2++)
            {
                drawTexturedModalRect(j + 4 + l1 * 117, k + 4 + i2 * 55+3, 29, 15, 117, 55); //crafting tables
            }

        }
        drawTexturedModalRect(j + xSize/2 - 176/2, k + ySize2, 0, 166 - 28, xSize, 32); //hotbar
        //drawTexturedModalRect(j + 4, (k + ySize) - 4+3, 4, 162, xSize/2 - 172/2 - 5, 4); //new bottom border left
        drawTexturedModalRect(j + xSize/2 + 172/2 + 1, (k + ySize2) - 4+3, 4, 162, xSize/2 - 172/2 - 5, 4); //new bottom border right
        
        drawTexturedModalRect(j, k + ySize2, 0, 166 - 28, 16, 32); //filter left
        drawTexturedModalRect(j + 16, k + ySize2, 172 - 12, 166 - 28, 16, 32); //filter right
        
        drawTexturedModalRect(j + 28, k + ySize2, 3, 166 - 28, 9, 3);
        drawTexturedModalRect(j + 31, (k + ySize2) - 4+3 + 3, 4, 162, 3, 4); //new new bottom border left
    }

    public void onGuiClosed()
    {
        super.onGuiClosed();
        if (inv.filter != null) {
    		inv.savePageToDamage(0);
    		if (!mc.theWorld.multiplayerWorld) {
    			mc.thePlayer.dropPlayerItem(inv.filter);
    		}
    	}
        else {
        	inv.savePageToDamage(inv.getPage());
        }
    }

    private static InventoryURB inv;
}
