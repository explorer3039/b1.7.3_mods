This is UltimateRecipeBook v2.0 for Minecraft Beta 1.7.3 Client
Compatible with servers that have v2.0 installed

DESCRIPTION
This mod combines Risugami's Recipe Book and Shockah's Crafting Book into 1 item.
It can be crafted with an ink sack, crafting table and book.
You can change the item id and gui id (for modded multiplayer) in the config file in .minecraft/config.

INSTALL
1. Install Modloader
2. Install ModLoaderMP Unofficial v2 (OPTIONAL: Required to function on servers with URB installed)
3. Delete META-INF from the minecraft.jar
4. Insert this zip into the .minecraft/mods folder
5. ???
6. Success!

CREDIT
Original recipe book mods which I have shamelessly stolen - Risugami & Shockah
Coding mastermind - me, rek

CHANGELOG for v2.0
- Sloppy code -> legit code
- UI overhaul: instead of there being a seperate gui for each book, there is 1 combining the best of both
- Flan's plane crash when scrolling back is fixed
- ModLoaderMp is no longer required for those playing on single player
- Item & Gui IDs are now configurable