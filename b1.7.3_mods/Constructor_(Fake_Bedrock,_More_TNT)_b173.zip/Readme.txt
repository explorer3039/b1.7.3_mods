Constructor
version: 1.01
Copyright to Jantomedes

INSTALATION:
+Make sure that you have instaled ModLoader 1.7.3 and deleted META-INF foler.
+Put everything from Code folder into your minecraft.jar

ChangeLog:
1.00
+Added faster destroying obsidian and bedrock (<- ya, reeeeally faster! ;)
+Added Super TNT
+NOW YOU ARE THINKING WITH SUPER TNT!
1.01
+Added Hyper TNT
+NOW YOU ARE THINKING WITH HYPER TNT!

WARNING:
NEVER detonate more than 10 hyper tnt! It's like 1200 normal TNT.

Thank for downloading! ;)
-Jantomedes