=======================
Smart Moving Server Mod
=======================

Version 3.5 for Minecraft 1.7.3

by Divisor



Description
===========

The Smart Moving Server mod provides smart moving specific communication between different SMP clients.

Additionally using a SMP server with this mod avoids bugs that can happen when using Smart Moving clients with standard SMP servers.



Installation
============

Installation varies depending on the minecraft server you are using.
So choose your package and install it - do NOT install more than one package.

In any case, NEVER forget: ALWAYS back up your stuff!


ModLoaderMp Server
------------------
* Your are running a standard minecraft server
* Your server allready has SDK's ModLoaderMp installed.

Copy all files inside the included "Server ModLoaderMp" zip package to their corresponding locations in your "minecraft_server.jar".

This package additionally overwrites the file dl.class on the server, it should not be combined with other mods that overwrite this file too.

Don't forget to:
* ensure you have the latest version of SDK's ModLoaderMp server installed.
* ensure the minecraft clients that connect to your server have the package "Smart Moving Client for ModLoaderMp" installed correctly.


Bukkit Server
-------------
* You are running a Bukkit minecraft server.
* You have ItemCraft 1.6.6 installed on your Bukkit server.

When you don't allready have ItemCraft 1.6.6 installed on your Bukkit Server install it. (http://syrome.sy.funpic.de/wbblite/).
You will need the ItemCraft release 1.6.6 not lower not higher. This specific ItemCraft release has been build against a the Bukkit server build 1060, so make sure you use exactly this build to get Itemcraft running.

After you successfully installed ItemCraft 1.6.6 on the Bukkit server build 1060 (http://syrome.sy.funpic.de/wbblite/?page=Board&boardID=6):
* Extract the contents of the Smart Moving installation package "SmartMoving Server for Bukkit-ItemCraft.zip"
* Copy the extracted file "ICSmartMoving.jar" into the folder "<bukkit>\ItemCraft\ICPlugins"
* Edit the file "<bukkit>\ItemCraft\ICScript\plugins.ic" and add the line '"ICSmartMoving.jar" plugin' (without the single apostrophes) at the end of the file.
* Move the contents of the extracted file "craftbukkit-0.0.1-SNAPSHOT.patch.zip" to their corresponding locations of your "craftbukkit-0.0.1-SNAPSHOT.jar"
  (optional - used for crawling into small holes without taking damage)

Don't forget to:
* ensure you have the build 1060 of the Bukkit server.
* ensure you have the version 1.6.6 of ItemCraft.
* ensure ItemCraft is correctly embedded into the Bukkit server.
* ensure the minecraft clients that connect to your server have the package "Smart Moving Client for ModLoaderMp" installed correctly.
