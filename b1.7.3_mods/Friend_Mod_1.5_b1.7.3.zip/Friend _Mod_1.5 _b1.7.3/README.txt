=============================
#   Minecraft Friend Mod    #
=============================

#       Version:  1.5       #
#     MCVersion: 1.7.3      #
#        Release:  r3       #
# Release Date:  09/08/2011 #


Prequisits:
----------

- Valid Minecraft Alpha/Beta Account.
- Minecraft 1.7.3 Client.
- Risugami's ModLoader.
- Risugami's AudioMod.
- An Archiver that can handle a RAR.
- Notepad++ or some other text file editing program.

Changelog:
---------

- Updated for compatibility with 1.7.3.

- HelpMod removed (mass overhaul on the way).

- Numerous bugs fixed.

- MOTDs and special friend phrases added (pulls from a HTML).

- Opted in for NaughtyList Mod Protector.

- Changed Friend config format to .fmc (you can still edit with Notepad++).



Installation Instructions:
-------------------------

(This is written on the premise you know how to get to your .minecraft folder, minecraft.jar and insert classes using an archiver).

1. Add files from "Add to jar" To the minecraft.jar.
2. Add files from "Add to .minecraft" to folder ".minecraft" (the one /bin is in!).
3. Add the contents of "Add to Resources" to Resources in your /.minecraft/
4. Open folder "mod_Friend" (the one in .minecraft) and then edit "Choose_Config_Here.txt" to the name of the config you wish to load.
5. Be sure to add the texture to the minecraft.jar(best putting it in the /mobs folder inside minecraft.jar).
6. Start Minecraft and have fun!


Features:
--------

- Changeable name and texture (EVEN NAME COLOUR* :O)

- Fully Customizable Phrases.

- Choose between a Male and Female Friend.

- Unique GUI Experience (Inventory & Information).

- Better Pathfinding.

- Hardcore Fighting.

- Health bar.

- Friendship.


In-Game Instructions:
--------------------

When your friend spawns they will greet you and begin following you, there are several ways you can 
interact with your friend, they are:

- Dismiss and Recall your friend with the '[' and ']' keys (note: dismissal is basically death, all items are lost).

- Pass Items, Press 'Q' (minecraft default) to pass an item to your friend, they have the same inventory space as you.

- Food, as well as being able to eat from their hotbar, you can right click friends to give them food on the fly.

- FriendInv, Press 'U' (my default) to open your friend's GUI, but only if you are < 50 blocks away.
= Features of FriendInv:
 = Dynamic Information Panel with the following information:
  - Friend Name
  - Friend follow status, Following/Waiting/Attacking/Hurt/Dieing
  - Friend strength (will show higher if sword equipped).
  - Friend Distance, exact distance between you both.
  - 'Armed' will say either Yes or No to whether your friend will attack enemies. (give them a sword!)
  - Time, the amount of time your friend has been connected.
 = Weapon Slot, the Red slot will be the actively held item, depending on what's in there your friend either 'Will fight' or will not, there are several objects that can be used as weapons.
 = Food slots, Your friend will have a better chance of eating food if it's in the bottom purple bar.
 = Green Slot, Place a feather here to have your friend stand still (immune whilst standing still).
 = Armour Slots, yes that's right, you can equip your friend with some armour in the same way you do, it will hold the same protective qualities as it does when you wear it.
 = Friend Panel, a visual representation of your friend to play with, the green circle on the corner will change colours depending on the amount of health he/she has.

You can not damage your friend by hitting them, so don't worry about that, also whilst they have a feather
in their hand they will not take damage from anybody.

Your friend will only target mobs if they target you (if they can see them), they won't attack peaceful mobs.

If your friend dies they will essentially ragequit, you can be sure that they will come back soon (in 1 minute from when they leave).


Credits:
-------

Mr_okushama - Mod Creator

Other Worthy Individuals:
_303 - Original Config code.
Corosus, Kodaichi, HarryPitFall, Risugami, Seronis,
Club559, ZeuX, and Ayutashi - Supporting Mr_okushama and teaching him java.
MCP Team - Creating modders out of block heads since 2010.


==================
=  Terms of Use  =
==================

By Downloading/Installing this Minecraft Modification you are agreeing to the following:
- You will actively seek methods of help other than the forum thread or PMs to Mr_okushama.
- You are responsible for any damaged/corrupted worlds.
- You will NEVER rush the Mr_okushama for updates, we will delay release 1 hour for each request.
- You agree to not compain about the adf.ly links we use to earn a tiny amount of money for all of our hard work.
- You will not re-package and/or re-distrubute this modification or any of the included files.


Breaking any one of the terms listed above will result in your name being added to the NaughtyList database, 
causing my mods to no longer work for you.

Friend Mod concept, code and distribution is all to be handled solely by okushama_inc (Mr_okushama).

Minecraft � Mojang Specifications AB 2010-2011, All Rights Reserved.
Friend Mod � okushama_inc 2010-2011, All Rights Reserved.
