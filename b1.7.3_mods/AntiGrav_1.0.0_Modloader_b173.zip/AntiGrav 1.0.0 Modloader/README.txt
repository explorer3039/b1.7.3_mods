0) If you haven't already, install modloader
1) Pull everything in this folder except this file in your minecraft.jar
2) Remember to delete META-INF, if not done already
3) Start minecraft. A config file will be created in .minecraft/mods/AntiGrav
4) Close minecraft and edit the config file to your liking. It should be explained through comments, if not, ask in the thread

To avoid world corruption, everytime you start Minecraft again, you will need to replace the control blocks / redstone torches / trigger a new redstone pulse (from off to on)

REMEMBER: BACK UP YOUR FILES. I AM NOT RESPONSIBLE FOR ANY KIND OF DAMAGE DONE TO YOUR SAVES OR THE JAR

http://www.minecraftforum.net/forums/mapping-and-modding/minecraft-mods/1275446-1-7-3-antigrav-let-your-houses-fly
