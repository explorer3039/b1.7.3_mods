// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;

import java.util.List;
import java.util.Random;

import net.minecraft.client.Minecraft;

// Referenced classes of package net.minecraft.src:
//            EntityAnimal, DataWatcher, ItemStack, Block, 
//            EntityPlayer, InventoryPlayer, Item, ItemShears, 
//            World, EntityItem, NBTTagCompound, Entity

public class EntitySheep extends EntityAnimal
{

    public EntitySheep(World world)
    {
        super(world);
        texture = "/mob/sheep.png";
        setSize(0.9F, 1.3F);
        reFleece = getFTime();
        //
        tamed = false;
        //
    }

    protected void entityInit()
    {
        super.entityInit();
        dataWatcher.addObject(16, new Byte((byte)0));
    }

    public boolean attackEntityFrom(Entity entity, int i)
    {
        return super.attackEntityFrom(entity, i);
    }

    protected void dropFewItems()
    {
        if(!getSheared())
        {
            entityDropItem(new ItemStack(Block.cloth.blockID, 1, getFleeceColor()), 0.0F);
        }
    }

    protected int getDropItemId()
    {
        return Block.cloth.blockID;
    }

    public boolean interact(EntityPlayer entityplayer)
    {
    	if(mc.thePlayer.ridingEntity != null && mc.thePlayer.ridingEntity == this){
    		entityplayer.mountEntity(null);
    		return true;
    	}
    	ItemStack itemstack = entityplayer.getCurrentEquippedItem();
    	if(tamed && itemstack != null && itemstack.itemID == mod_AnimalFarming.mounter.shiftedIndex){
    		itemstack.damageItem(1, entityplayer);
    		entityplayer.mountEntity(this);
    		return true;
    	}
        if(itemstack != null && itemstack.itemID == Item.shears.shiftedIndex && !getSheared())
        {
            if(!worldObj.multiplayerWorld)
            {
                setSheared(true);
                int i = 2 + rand.nextInt(3);
                for(int j = 0; j < i; j++)
                {
                    EntityItem entityitem = entityDropItem(new ItemStack(Block.cloth.blockID, 1, getFleeceColor()), 1.0F);
                    entityitem.motionY += rand.nextFloat() * 0.05F;
                    entityitem.motionX += (rand.nextFloat() - rand.nextFloat()) * 0.1F;
                    entityitem.motionZ += (rand.nextFloat() - rand.nextFloat()) * 0.1F;
                }

            }
            itemstack.damageItem(1, entityplayer);
        }
    	if(itemstack != null && itemstack.itemID != Item.shears.shiftedIndex && itemstack.itemID == Item.wheat.shiftedIndex){
    		if(tamed){
    			if(health < 10){
    				itemstack.stackSize--;
    				health++;
    			}
    		}else{
        		itemstack.stackSize--;
        		int i = rand.nextInt(5);
        		if(i == 2){
        			tamed = true;
        			showHeartsOrSmokeFX(false);
        			showHeartsOrSmokeFX(true);
        			birthtime = getBTime();
        			return true;
        		}else{
        			showHeartsOrSmokeFX(false);
        		}
    		}
    	}else if(itemstack == null){
    		mc.displayGuiScreen(new GuiAnimalFarmingInfo(tamed, "Sheep", birthtime, this));
    	}else if(itemstack.itemID != Item.shears.shiftedIndex){
    		mc.displayGuiScreen(new GuiAnimalFarmingInfo(tamed, "Sheep", birthtime, this));
    	}
    		
        return false;
    }

    public void writeEntityToNBT(NBTTagCompound nbttagcompound)
    {
        super.writeEntityToNBT(nbttagcompound);
        nbttagcompound.setBoolean("Sheared", getSheared());
        nbttagcompound.setByte("Color", (byte)getFleeceColor());
        nbttagcompound.setBoolean("Tamed", tamed);
        nbttagcompound.setInteger("Timeto", birthtime);
        
        nbttagcompound.setInteger("FleeceReset", reFleece);
    }

    public void readEntityFromNBT(NBTTagCompound nbttagcompound)
    {
        super.readEntityFromNBT(nbttagcompound);
        setSheared(nbttagcompound.getBoolean("Sheared"));
        setFleeceColor(nbttagcompound.getByte("Color"));
        tamed = nbttagcompound.getBoolean("Tamed");
        birthtime = nbttagcompound.getInteger("Timeto");
        
        reFleece = nbttagcompound.getInteger("FleeceReset");
    }

    protected String getLivingSound()
    {
        return "mob.sheep";
    }

    protected String getHurtSound()
    {
        return "mob.sheep";
    }

    protected String getDeathSound()
    {
        return "mob.sheep";
    }

    public int getFleeceColor()
    {
        return dataWatcher.getWatchableObjectByte(16) & 0xf;
    }

    public void setFleeceColor(int i)
    {
        byte byte0 = dataWatcher.getWatchableObjectByte(16);
        dataWatcher.updateObject(16, Byte.valueOf((byte)(byte0 & 0xf0 | i & 0xf)));
    }

    public boolean getSheared()
    {
        return (dataWatcher.getWatchableObjectByte(16) & 0x10) != 0;
    }

    public void setSheared(boolean flag)
    {
        byte byte0 = dataWatcher.getWatchableObjectByte(16);
        if(flag)
        {
            dataWatcher.updateObject(16, Byte.valueOf((byte)(byte0 | 0x10)));
        } else
        {
            dataWatcher.updateObject(16, Byte.valueOf((byte)(byte0 & 0xffffffef)));
        }
    }

    public static int getRandomFleeceColor(Random random)
    {
        int i = random.nextInt(100);
        if(i < 5)
        {
            return 15;
        }
        if(i < 10)
        {
            return 7;
        }
        if(i < 15)
        {
            return 8;
        }
        if(i < 18)
        {
            return 12;
        }
        return random.nextInt(500) != 0 ? 0 : 6;
    }

    public static final float fleeceColorTable[][] = {
        {
            1.0F, 1.0F, 1.0F
        }, {
            0.95F, 0.7F, 0.2F
        }, {
            0.9F, 0.5F, 0.85F
        }, {
            0.6F, 0.7F, 0.95F
        }, {
            0.9F, 0.9F, 0.2F
        }, {
            0.5F, 0.8F, 0.1F
        }, {
            0.95F, 0.7F, 0.8F
        }, {
            0.3F, 0.3F, 0.3F
        }, {
            0.6F, 0.6F, 0.6F
        }, {
            0.3F, 0.6F, 0.7F
        }, {
            0.7F, 0.4F, 0.9F
        }, {
            0.2F, 0.4F, 0.8F
        }, {
            0.5F, 0.4F, 0.3F
        }, {
            0.4F, 0.5F, 0.2F
        }, {
            0.8F, 0.3F, 0.3F
        }, {
            0.1F, 0.1F, 0.1F
        }
    };
    
    public void onUpdate()
    {
    	super.onUpdate();
    	if(!worldObj.multiplayerWorld){
        if(tamed){
        	if(mc.thePlayer.getCurrentEquippedItem() != null && mc.thePlayer.getCurrentEquippedItem().itemID == mod_AnimalFarming.roundUp.shiftedIndex && ItemRoundUp.pos && (ItemRoundUp.posi == 3 || ItemRoundUp.posi == 5)){
        		this.setPathToEntity(worldObj.getPathToEntity(mc.thePlayer, this, 8));
        	}
        }
    	if((dataWatcher.getWatchableObjectByte(16) & 0x10) != 0){
        	if(reFleece-- > 0){
        		//System.out.println(reFleece);
        	}else{
        		reFleece = getFTime();
        		setSheared(false);
        		setFleeceColor(getRandomFleeceColor(new Random()));
        	}
    	}else{
    		//System.out.println("NOTSHEARED");
    	}
    	if(!GuiAnimalFarmingInfo.breed){
        	if(urged){
        		List l = worldObj.getEntitiesWithinAABBExcludingEntity(this, boundingBox.expand(2D, 2D, 2D));
        		for(int i = 0; i < l.size(); i++){
        			Entity e = (Entity)l.get(i);
        			if(e == other){
        				GiveBirth(mc);
        			}
        		}
        		this.setPathToEntity(worldObj.getPathToEntity(this, other, 16f));
        		if(waiter-- <= 0 || other == null){
        			urged = false;
        			birthtime = getBTime() / 2;
        		}
        	}
        	if(tamed && !urged){
        		if(mc.thePlayer.ridingEntity != null && mc.thePlayer.ridingEntity == this){
        			updateKeys();
        		}
            	if(/*!canEntityBeSeen(mc.thePlayer) && */((birthtime-- == 0 || birthtime < 0))){
            		List l = worldObj.getEntitiesWithinAABBExcludingEntity(this, boundingBox.expand(32D, 32D, 32D));
            		boolean found = false;
            		for(int i = 0; i < l.size(); i++){
            			Entity entity = (Entity)l.get(i);
            			if(entity.getClass() == EntitySheep.class){
            				EntitySheep c = (EntitySheep)entity;
            				if(c.tamed){
            					waiter = 25*20;
                				other = (EntitySheep)entity;
                				urged = true;
                				found = true;
                				this.setPathToEntity(worldObj.getPathToEntity(this, other, 16f));
                				break;
            				}
            			}
            		}
            		if(!found){
            			birthtime = getBTime() / 4;
            		}
            	}else{
            		//System.out.println(birthtime);
            	}
        	}
    	}
    	}
    }


	private void updateKeys() {
		motionX = 0;
		motionZ = 0;
		rotationYaw = mc.thePlayer.rotationYaw;
		prevRotationYaw = mc.thePlayer.rotationYaw;
		isJumping = mc.thePlayer.isJumping;
		 
	        if(isJumping)
	        {
	        	boolean flag = isInWater();
	 	        boolean flag1 = handleLavaMovement();
	 	        if(flag)
	            {
	                motionY += 0.039999999105930328D;
	            } else
	            if(flag1)
	            {
	                motionY += 0.039999999105930328D;
	            } else
	            if(onGround)
	            {
	                jump();
	                mc.thePlayer.jump();
	            }
	        }
	        
		    if(!isCollidedVertically){
		    	addVelocity(mc.thePlayer.motionX * 5, .035, mc.thePlayer.motionZ * 5);
		    }else{
		    	addVelocity(mc.thePlayer.motionX * 3, 0, mc.thePlayer.motionZ * 3);
		    }
		moveEntityWithHeading(mc.thePlayer.moveStrafing, mc.thePlayer.moveForward);
	}

	private int getBTime() {
		return 18000 + rand.nextInt(1000);
	}
	private int getFTime() {
		return 36000 + rand.nextInt(2000);
	}

	public boolean GiveBirth(Minecraft mc) {
    		if(rand.nextInt(100) > 20){
        		EntitySheep cow = new EntitySheep(mc.theWorld);
        		cow.setPosition(posX, posY, posZ);
        		if(rand.nextInt(10)==0){
        			cow.tamed = false;
        		}else{
        			cow.tamed = true;
        		}
        		showHeartsOrSmokeFX(false);
        		showHeartsOrSmokeFX(true);
        		worldObj.playSoundAtEntity(this, "random.pop", .3f, .5f);
        		urged = false;
        		birthtime = getBTime();
        		mc.theWorld.entityJoinedWorld(cow);
        		return true;
        	}else{
        		showHeartsOrSmokeFX(false);
        		urged = false;
        		birthtime = getBTime() / 4;
        		return false;
        	}
	}
    
    protected boolean canDespawn()
    {
        return !tamed;
    }
    
    void showHeartsOrSmokeFX(boolean flag)
    {
        String s = "heart";
        if(!flag)
        {
            s = "smoke";
        }
        for(int i = 0; i < 7; i++)
        {
            double d = rand.nextGaussian() * 0.02D;
            double d1 = rand.nextGaussian() * 0.02D;
            double d2 = rand.nextGaussian() * 0.02D;
            worldObj.spawnParticle(s, (posX + (double)(rand.nextFloat() * width * 2.0F)) - (double)width, posY + 0.5D + (double)(rand.nextFloat() * height), (posZ + (double)(rand.nextFloat() * width * 2.0F)) - (double)width, d, d1, d2);
        }

    }
    
	public boolean isMovementBlocked(){
		return mc.thePlayer.ridingEntity != null && mc.thePlayer.ridingEntity == this;
	}
    
	boolean tamed = false;
	boolean urged = false;
	EntitySheep other;
	int birthtime = getBTime();
	int reFleece = getFTime();
	Minecraft mc = GetMinecraft.getMC();
	int waiter;

}
