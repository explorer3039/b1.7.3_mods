package net.minecraft.src;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.client.Minecraft;

import org.lwjgl.input.Mouse;

public class ItemRoundUp extends Item {

	public static boolean pos = false;
	public static boolean on = false;
	public static int posi = 5;
	
	protected ItemRoundUp(int i) {
		super(i);
	}
	
    public boolean shouldRotateAroundWhenRendering()
    {
        return true;
    }
    
    public void onUpdate(ItemStack itemstack, World world, Entity entity, int i, boolean flag)
    {
    	if(flag){
    		if(Mouse.getEventButtonState() && !on){
    			if(Mouse.getEventButton() == 0){
    				if(GetMinecraft.getMC().inGameHasFocus){
    					on = true;
    					onClick();
    				}
    			}
    		}else if(!Mouse.getEventButtonState()){
    			on = false;
    		}
    	}
    }
    
    private void onClick() {
    	String s = "";
		switch(posi){
		case 1: posi = 2; s = "Pigs only"; break;
		case 2: posi = 3; s = "Sheep only"; break;
		case 3: posi = 4; s = "Chickens only"; break;
		case 4: posi = 5; s = "All Tamed Animals"; break;
		case 5: posi = 1; s = "Cows only"; break;
		}
		GetMinecraft.getMC().thePlayer.addChatMessage(s);
		
	}

	public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer entityplayer)
    {
    	if(pos){
    		pos = false;
    		world.playSoundAtEntity(entityplayer, "random.click", .3f, .3f);
    		entityplayer.addChatMessage("Animals Will Stop Following You");

    	}else{
    		pos = true;
    		world.playSoundAtEntity(entityplayer, "random.click", .3f, .7f);
    		entityplayer.addChatMessage("Animals Will Now Follow You");
    		
    	}
        return itemstack;
    }


    /*public boolean onItemUse(ItemStack itemstack, EntityPlayer entityplayer, World world, int i, int j, int k, int l)
    {
    	if(pos){
    		pos = !pos;
    		world.playSoundAtEntity(entityplayer, "random.click", .3f, .8f);
    		/*li.clear();
    		pos = !pos;
    		list = world.getEntitiesWithinAABBExcludingEntity(entityplayer, entityplayer.boundingBox.expand(25d, 25d, 25d));
    		for(int i1 = 0; i1 < list.size(); i1++){
    			EntityAnimal e = (EntityAnimal)list.get(i1);
    			if(e.getClass() == EntityCow.class){
    				EntityCow cow = (EntityCow)list.get(i1);
    				if(cow.tamed){
    					li.add(e);
    				}
    			}
    			if(e.getClass() == EntityChicken.class){
    				EntityChicken cow = (EntityChicken)list.get(i1);
    				if(cow.tamed){
    					li.add(e);
    				}
    			}
    			if(e.getClass() == EntityPig.class){
    				EntityPig cow = (EntityPig)list.get(i1);
    				if(cow.tamed){
    					li.add(e);
    				}
    			}
    			if(e.getClass() == EntitySheep.class){
    				EntitySheep cow = (EntitySheep)list.get(i1);
    				if(cow.tamed){
    					li.add(e);
    				}
    			}
    		}
    		entityplayer.addChatMessage("Added " + li.size() + " to round up list");
    		
    	}else{
    		pos = !pos;
    		world.playSoundAtEntity(entityplayer, "random.click", .3f, .3f);
    		for(int a = 0; a < li.size(); a++){
    			EntityAnimal e = li.get(a);
    			e.setPathToEntity(world.getEntityPathToXYZ(e, i, j, k, 75));
    		}
    	}
    	
        return false;
    }*/

    //List list;
    //ArrayList<EntityAnimal> li = new ArrayList<EntityAnimal>();
    
}
