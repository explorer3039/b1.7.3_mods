package net.minecraft.src;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.lang.reflect.Field;
import net.minecraft.client.Minecraft;
public class GetMinecraft{

	public static Minecraft mc;
	
    public static Minecraft getMC()
    {
    	
        if(mc == null)
        {
            try
            {
                ThreadGroup threadgroup = Thread.currentThread().getThreadGroup();
                int i = threadgroup.activeCount();
                Thread athread[] = new Thread[i];
                threadgroup.enumerate(athread);
                for(int j = 0; j < athread.length; j++)
                {
                    if(!athread[j].getName().equals("Minecraft main thread"))
                    {
                        continue;
                    }
                    mc = (Minecraft)getPrivateValue(java.lang.Thread.class, athread[j], "target");
                    break;
                }

            }catch(Exception e){
            	System.out.println("ERROR: " + e.getMessage());
            	BufferedWriter write;
				try {
					PrintStream s = new PrintStream("ANOTHERERRORLOG.txt");
					e.printStackTrace(s);
					s.close();
					write = new BufferedWriter(new FileWriter("ERRORLOG.txt", false));
					write.write("ERROR Grabbing Minecraft Instance!:");
					write.newLine();
					write.write(e.getMessage());
					write.close();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
            	
            	
            }
            mod_AnimalFarming f = new mod_AnimalFarming();
        }
        return mc;
    }
    
    public static Object getPrivateValue(Class class1, Object obj, String s) throws IllegalArgumentException, SecurityException, NoSuchFieldException
    {
        try
        {
            Field field = class1.getDeclaredField(s);
            field.setAccessible(true);
            return field.get(obj);
        }
        catch(IllegalAccessException illegalaccessexception)
        {
            return null;
        }
    }
}