package net.minecraft.src;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Properties;

public class mod_AnimalFarming {
	public static Item roundUp = new ItemRoundUp(9922).setIconCoord(5, 3).setItemName("roundup");
	public static Item mounter = new Item(9923).setIconCoord(8, 6).setMaxStackSize(1).setMaxDamage(100).setItemName("mounter");
	public mod_AnimalFarming(){
		init();
		
		AddName(roundUp, "RoundUp");
		AddName(mounter, "Mounter");
		CraftingManager.getInstance().addRecipe(new ItemStack(roundUp), new Object[] {
			"#  ", " # ", "  #", Character.valueOf('#'), Item.stick
			
		});
		CraftingManager.getInstance().addRecipe(new ItemStack(mounter), new Object[] {
			"###", "XYX", Character.valueOf('#'), Item.leather, Character.valueOf('X'), Item.ingotIron
			, Character.valueOf('Y'), Item.diamond
			
		});
	}

	
	private void init() {
		/*try{
			Field f = Session.class.getDeclaredField("registeredBlocksList");
			f.setAccessible(true);
			list = (List)f.get(null);
			if(list != null){
				System.out.println("ISNOTNULL");
			}else{
				System.out.println("ISNULL");
			}
		}catch(Exception e){
			e.printStackTrace();
		}*/
		
	}


	public static void AddName(Item i, String s){
		String s1 = null;
		if(i.getItemName() != null){
			s1 = (new StringBuilder(String.valueOf(i.getItemName()))).append(".name").toString();
		}
		AddTheName(s1, s);
	}
	
	public static void AddName(Block b, String s){
		String s1 = null;
		if(b.getBlockName() != null){
			s1 = (new StringBuilder(String.valueOf(b.getBlockName()))).append(".name").toString();
		}
		AddTheName(s1, s);
	}
	
    private static void AddTheName(String s1, String s) {
    	if(s1 != null){
    		try{
    			Properties properties;
    			Field f = StringTranslate.class.getDeclaredFields()[1];
    			f.setAccessible(true);
    			properties = (Properties) f.get(StringTranslate.getInstance());
    			if(properties == null){
    			}else{
    				properties.put(s1, s);
    			}
    		}catch(Exception error){
    			System.out.println("Error Adding ItemName:\n");
    			error.printStackTrace();
    		}
    	}
	}
    //List list;

}
