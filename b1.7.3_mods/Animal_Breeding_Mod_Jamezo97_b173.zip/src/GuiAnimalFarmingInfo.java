package net.minecraft.src;

import org.lwjgl.input.Keyboard;

public class GuiAnimalFarmingInfo extends GuiScreen{
	
	public GuiAnimalFarmingInfo(boolean tamed, String string, int birthtime, EntityCow cowe){
		tame = tamed;
		name = string;
		timeLeft = birthtime;
		cow = cowe;
	}
	public GuiAnimalFarmingInfo(boolean tamed, String string, int birthtime, EntityPig cowe){
		tame = tamed;
		name = string;
		timeLeft = birthtime;
		pig = cowe;
	}
	public GuiAnimalFarmingInfo(boolean tamed, String string, int birthtime, EntitySheep cowe){
		tame = tamed;
		name = string;
		timeLeft = birthtime;
		sheep = cowe;
	}
	public GuiAnimalFarmingInfo(boolean tamed, String string, int birthtime, EntityChicken cowe){
		tame = tamed;
		name = string;
		timeLeft = birthtime;
		chicken = cowe;
	}
	
	public void initGui(){
		controlList.clear();
		Keyboard.enableRepeatEvents(true);
		controlList.add(new GuiButton(0, width / 2 - 100, height / 4 + 120, "Exit"));
		controlList.add(new GuiButton(1, width / 2 - 100, height / 4 + 60, "Untame"));
		controlList.add(new GuiButton(2, width / 2 - 100, height / 4 + 90, "Pause All Breeding(" + (breed + "").toUpperCase() + ")"));
		GuiButton g = (GuiButton)controlList.get(1);
		g.enabled = false;
		//controlList.add(new GuiButton(0, (width - 100) / 2, (height - 50) / 2, 100, 50, "Exit" ));
	}
    public void drawScreen(int i, int j, float f)
    {
    	drawDefaultBackground();
    	drawCenteredString(fontRenderer, name, width / 2, 20, 0xffffff);
    	if(tame){
    		drawCenteredString(fontRenderer, "This Animal Is Tamed", width / 2, 40, 0xffffff);
    		drawCenteredString(fontRenderer, "It has approximately " + (int)Math.round(timeLeft / 25) + " seconds left, untill it attempts to reproduce", width / 2, 70, 0xffffff);
    		drawCenteredString(fontRenderer, "(TIP: If the time is not going down, make sure the animal cannot see you!)", width / 2, 100, 0xffffff);
    		GuiButton g = (GuiButton)controlList.get(1);
    		g.enabled = true;
    		
    	}else{
    		drawCenteredString(fontRenderer, "This Animal Is Not Tamed", width / 2, 70, 0xffffff);
    	}
    	
    	
    	
    	
    	super.drawScreen(i, j, f);
    }
    
    protected void actionPerformed(GuiButton guibutton)
    {
    	if(guibutton.id == 0){
    		mc.displayGuiScreen(null);
    	}
    	if(guibutton.id == 1){
    		if(name.toLowerCase().equals("cow")){
    			cow.tamed = false;
    			tame = false;
    		}
    		if(name.toLowerCase().equals("pig")){
    			pig.tamed = false;
    			tame = false;
    		}
    		if(name.toLowerCase().equals("sheep")){
    			sheep.tamed = false;
    			tame = false;
    		}
    		if(name.toLowerCase().equals("chicken")){
    			chicken.tamed = false;
    			tame = false;
    		}
    		GuiButton g = (GuiButton)controlList.get(1);
    		g.enabled = false;
    	}
    	if(guibutton.id == 2){
    		breed = !breed;
    		guibutton.displayString = "Pause All Breeding(" + (breed + "").toUpperCase() + ")";
    	}
    }
    
    boolean tame;
    public static boolean breed = false;
    String name;
    int timeLeft;
    
    EntityCow cow;
    EntityPig pig;
    EntitySheep sheep;
    EntityChicken chicken;

}
