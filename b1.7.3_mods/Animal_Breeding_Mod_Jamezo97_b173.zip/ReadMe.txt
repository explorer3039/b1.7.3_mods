
----------To install on windows----------

Go Start>Run and type in "%appdata%"     (without quotation marks)
Or press the Windows key and the R key at the same time. and type in "%appdata%"

Look for a folder called ".minecraft"   Open it

Find a folder called "bin"   Open it

Right click "minecraft.jar" and press open with 7-zip or WinRar (you may just have "Open archive")

Drag the files from inside the "Drag These Files Into Your Minecraft Jar" folder, into your minecraft.jar.

If you haven't already done so, DELETE THE META-INF FOLDER!

Run minecraft and enjoy farming animals.

------------------------------------------
This mod does many things, such as:
It adds two new Items to the game: A "Mounter" and a "RoundUp"(stick).
If you have tamed an animal, you can use the Mounter to get it.
You keep your Mounter, but it's damage increases. Until it eventually breaks

With the RoundUp(Stick) you can get certain animals to follow you. This way, you can lead them into a pen without pushing them everywhere.

To tame a sheep, cow or pig, feed them wheat.
To tame a chicken, feed them seeds.

Once they are tamed, you can feed them their corrosponding item to heal them.

Right click on them to open up a GUi, where you can untame them, or stop every animal in the world (which is tamed) from breeding.

It also tells you how many seconds left untill it tries to "mate" with another animal (if it can find one).

Tamed animals do not despawn.

Sheep's wool grows back, but changes colour.

And that's about it. Just keep tamed animals together, and they will breed.
------------------------------------------

Check the images for crafting recipes.