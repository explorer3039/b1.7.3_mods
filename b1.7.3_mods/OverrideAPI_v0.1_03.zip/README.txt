OverrideAPI v0.1_03

 *It becomes powerful*

You can:

1) Add buttons! You can add a button to GuiScreen without overriding or editing its class.

2) Override a GuiScreen so your one appears instead of original.

3) Override a vanilla block with your one.

NO base class is edited. This API should be compatible with anything.

Feel free to use it in your mods! :D

ChangeLog:

1) Cleaned source, no more unused imports and @SuppressWarning

2) Fixed some bugs like spam in console with NullPointerException and possible mess with GuiScreens in-game

Credit:

- mine_diver

- rek (thanks for that trick with selectedButton, now I don't need to override the whole mouse input proccess xd)