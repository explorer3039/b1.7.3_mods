package net.minecraft.src.overrideapi.utils.gui;

import java.lang.reflect.Field;
import java.util.List;

import net.minecraft.src.GuiButton;
import net.minecraft.src.GuiScreen;
import net.minecraft.src.ModLoader;
import net.minecraft.src.ScaledResolution;
import net.minecraft.src.overrideapi.OverrideAPI;
import net.minecraft.src.overrideapi.proxy.ArrayListProxy;
import net.minecraft.src.overrideapi.proxy.EntityRendererProxyProxy;
import net.minecraft.src.overrideapi.utils.Reflection;

public class GuiHandler {
    public GuiHandler() {
        controlListField.setAccessible(true);
        selectedButtonField.setAccessible(true);
    }
    public void OnTickInGUI() {
        if (firstTick) {
        	ModLoader.getMinecraftInstance().entityRenderer = new EntityRendererProxyProxy(ModLoader.getMinecraftInstance());
            firstTick = false;
        }
        if (OverrideAPI.guiScreenOverrides.containsKey(ModLoader.getMinecraftInstance().currentScreen.getClass())
                && !OverrideAPI.guiScreenOverrides.get(ModLoader.getMinecraftInstance().currentScreen.getClass()).isInstance(ModLoader.getMinecraftInstance().currentScreen))
            try {
                ModLoader.getMinecraftInstance().currentScreen = OverrideAPI.guiScreenOverrides.get(ModLoader.getMinecraftInstance().currentScreen.getClass()).newInstance();
                ModLoader.getMinecraftInstance().setIngameNotInFocus();
                ScaledResolution scaledresolution = new ScaledResolution(ModLoader.getMinecraftInstance().gameSettings,
                        ModLoader.getMinecraftInstance().displayWidth,
                        ModLoader.getMinecraftInstance().displayHeight);
                int i = scaledresolution.getScaledWidth();
                int j = scaledresolution.getScaledHeight();
                ModLoader.getMinecraftInstance().currentScreen.setWorldAndResolution(ModLoader.getMinecraftInstance(), i, j);
                ModLoader.getMinecraftInstance().skipRenderWorld = false;
                OverrideAPI.LOGGER.info("Overrided " + ModLoader.getMinecraftInstance().currentScreen.getClass().getSimpleName());
            } catch (Exception e) {e.printStackTrace();}
        try {
            if (selectedButtonField.get(ModLoader.getMinecraftInstance().currentScreen) != null
                    && prevSelectedButton != selectedButtonField.get(ModLoader.getMinecraftInstance().currentScreen))
                for (ButtonHandler handler : OverrideAPI.buttonHandlers)
                    handler.actionPerformed(ModLoader.getMinecraftInstance().currentScreen,
                            (GuiButton)selectedButtonField.get(ModLoader.getMinecraftInstance().currentScreen));
            prevSelectedButton = (GuiButton)selectedButtonField.get(ModLoader.getMinecraftInstance().currentScreen);
        } catch (Exception e) {e.printStackTrace();}
        try {
        } catch (Exception e) {e.printStackTrace();}
    }
    public void beforeDrawScreen() {
    	if (callOnNextTick || prevGuiScreen != ModLoader.getMinecraftInstance().currentScreen) {
            callOnNextTick = false;
            OverrideAPI.LOGGER.info("Detected GuiScreen change! ButtonHandlers are about to be run");
            OverrideAPI.minButtonID = 0;
            try {
                @SuppressWarnings("unchecked")
                List<GuiButton> controlList = (List<GuiButton>)controlListField.get(ModLoader.getMinecraftInstance().currentScreen);
                List<GuiButton> proxy = new ArrayListProxy<GuiButton>();
                proxy.addAll(controlList);
                controlListField.set(ModLoader.getMinecraftInstance().currentScreen, proxy);
                for (ButtonHandler handler : OverrideAPI.buttonHandlers)
                    handler.initGui(ModLoader.getMinecraftInstance().currentScreen, proxy);
            } catch (Exception e) {e.printStackTrace();}
        }
    }
    public void onTick() {
        prevGuiScreen = ModLoader.getMinecraftInstance().currentScreen;
        prevDisplayWidth = ModLoader.getMinecraftInstance().displayWidth;
        prevDisplayHeight = ModLoader.getMinecraftInstance().displayHeight;
    }
    public void controlListClear() {
        if (prevDisplayWidth != ModLoader.getMinecraftInstance().displayWidth
                || prevDisplayHeight != ModLoader.getMinecraftInstance().displayHeight) {
            OverrideAPI.LOGGER.info("Detected resize! ButtonHandlers will be run in the next tick");
            callOnNextTick = true;
        }
    }
    private final Field controlListField = Reflection.findField(GuiScreen.class, new String[] {"e", "controlList"});
    private final Field selectedButtonField = Reflection.findField(GuiScreen.class, new String[] {"a", "selectedButton"});
    private boolean firstTick = true;
    private boolean callOnNextTick = false;
    private GuiButton prevSelectedButton = null;
    private GuiScreen prevGuiScreen = null;
    private int prevDisplayWidth = -1;
    private int prevDisplayHeight = -1;
}
