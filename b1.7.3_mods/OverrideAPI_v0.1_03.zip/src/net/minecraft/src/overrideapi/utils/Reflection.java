package net.minecraft.src.overrideapi.utils;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

public class Reflection {
	public static Object invokePrivateStaticMethod(Class<?> target, String name, Object[] args, Class<?>...parameterTypes) {
		try {
			Method method = target.getDeclaredMethod(name, parameterTypes);
			method.setAccessible(true);
			return method.invoke(null, args);
		} catch (Exception e) {e.printStackTrace();return null;}
	}
	public static Object invokePrivateMethod(Object target, String name, Object[] args, Class<?>...parameterTypes) {
        try {
            Method method = target.getClass().getDeclaredMethod(name, parameterTypes);
            method.setAccessible(true);
            return method.invoke(target, args);
        } catch (Exception e) {e.printStackTrace();return null;}
    }
	@SuppressWarnings("unchecked")
    public static void publicConstructor(@SuppressWarnings("rawtypes") Class target, Class<?>...parameterTypes) {
        try {
            modifiersField.setInt(target, target.getConstructor(parameterTypes).getModifiers() & ~Modifier.PROTECTED);
            modifiersField.setInt(target, target.getConstructor(parameterTypes).getModifiers() & ~Modifier.PRIVATE);
            modifiersField.setInt(target, target.getConstructor(parameterTypes).getModifiers() | ~Modifier.PUBLIC);
        } catch (Exception e) {e.printStackTrace();}
 	}
	public static void publicField(Field field) {
	    try {
            field.setAccessible(true);
            modifiersField.setInt(field, field.getModifiers() & ~Modifier.FINAL);
        } catch (Exception e) {e.printStackTrace();}
	}
	public static Field findField(Class<?> target, String[] names) {
	    for (Field field : target.getDeclaredFields())
	        for (String name : names)
	            if (field.getName().equals(name))
	                return field;
	    return null;
	}
	public static Field modifiersField;
	static {
	    try {
	        modifiersField = Field.class.getDeclaredField("modifiers");
	        modifiersField.setAccessible(true);
	    } catch (Exception e) {}
	}
}
