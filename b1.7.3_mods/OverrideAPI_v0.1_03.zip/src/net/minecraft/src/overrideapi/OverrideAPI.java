package net.minecraft.src.overrideapi;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import net.minecraft.src.Block;
import net.minecraft.src.GuiButton;
import net.minecraft.src.GuiScreen;
import net.minecraft.src.ModLoader;
import net.minecraft.src.overrideapi.modloader.BaseModProxy;
import net.minecraft.src.overrideapi.utils.Reflection;
import net.minecraft.src.overrideapi.utils.gui.ButtonHandler;
import net.minecraft.src.overrideapi.utils.gui.GuiScreenOverride;

public class OverrideAPI {
    /**
     * With this method you can override Minecraft GuiScreens with your ones.
     * Method requires only one parameter - your class that extends GuiScreen and has GuiOverride annotation.
     * REMEMBER, if you have some parameters in constructor of your GuiOverride class, this will crash.
     * 
     * @param override
     */
    public static void overrideGuiScreen(Class<? extends GuiScreen> override) {
        if (notInitialized[0]) {
            ModLoader.SetInGUIHook(MLProxy, true, false);
            notInitialized[0] = false;
            LOGGER.info("Initialized OnTickInGUI hook");
        }
        guiScreenOverrides.put(override.getAnnotation(GuiScreenOverride.class).value(), override);
        LOGGER.info("Added GUIScreen override");
    }
    /**
     * This method can override vanilla blocks, like grass, stone, obsidian, etc, with your ones.
     * First parameter - target block, e.g Block.stone; Second parameter - your Block class.
     * REMEMBER, if you have some parameters in constructor of your Block class, this will crash.
     * 
     * @param target
     * @param override
     * @return
     */
    public static Block overrideVanillaBlock(Block target, Class<? extends Block> override) {
        try {
            Block.blocksList[target.blockID] = null;
            for (Constructor<?> constructor : target.getClass().getConstructors())
                Reflection.publicConstructor(target.getClass(), constructor.getParameterTypes());
            Block overrideInst = override.newInstance();
            for (int i = 0; i < Block.class.getDeclaredFields().length; i++) {
                try {
                    if (((Block)Block.class.getDeclaredFields()[i].get(null)).equals(target)) {
                        Field field = Block.class.getDeclaredFields()[i];
                        Reflection.publicField(field);
                        field.set(null, overrideInst);
                        LOGGER.info("Overrided " + target.getBlockName());
                        break;
                    }
                } catch (Exception e) {}
            }
            return overrideInst;
        } catch (Exception e) {e.printStackTrace();return null;}
    }
    /**
     * If you have a class that implements ButtonHandler, register it with this method so it'll be run
     * 
     * @param buttonHandler
     */
    public static void registerButtonHandler(ButtonHandler buttonHandler) {
        if (notInitialized[0]) {
            ModLoader.SetInGUIHook(MLProxy, true, false);
            notInitialized[0] = false;
            LOGGER.info("Initialized OnTickInGUI hook");
        }
        buttonHandlers = Arrays.copyOf(buttonHandlers, buttonHandlers.length + 1);
        buttonHandlers[buttonHandlers.length - 1] = buttonHandler;
    }
    /**
     * With this method you can get a button ID for the current GuiScreen
     * 
     * @param guiscreen
     * @return
     */
    public static int getUniqueButtonID() {
        if (minButtonID == 0)
            try {
                Field controlListField = Reflection.findField(GuiScreen.class, new String[] {"e", "controlList"});
                controlListField.setAccessible(true);
                @SuppressWarnings("unchecked")
                List<GuiButton> controlList = (List<GuiButton>)controlListField.get(ModLoader.getMinecraftInstance().currentScreen);
                for (GuiButton guibutton : controlList)
                    if (guibutton.id < minButtonID)
                        minButtonID = guibutton.id;
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        minButtonID--;
        return minButtonID;
    }
    public final static Logger LOGGER = Logger.getLogger("Override API");
    public final static BaseModProxy MLProxy = new BaseModProxy();
    private final static boolean notInitialized[] = new boolean[] {true};
    public final static Map<Class<? extends GuiScreen>, Class<? extends GuiScreen>> guiScreenOverrides = new HashMap<Class<? extends GuiScreen>, Class<? extends GuiScreen>>();
    public static ButtonHandler buttonHandlers[] = new ButtonHandler[0];
    public static int minButtonID = 0;
}