package net.minecraft.src.overrideapi;

public class info {
	public static final String VERSION = "v0.1_03";
}
