package net.minecraft.src.overrideapi.modloader;

import net.minecraft.client.Minecraft;
import net.minecraft.src.BaseMod;
import net.minecraft.src.GuiScreen;
import net.minecraft.src.overrideapi.info;
import net.minecraft.src.overrideapi.utils.gui.GuiHandler;;

public class BaseModProxy extends BaseMod {
	
    public boolean OnTickInGUI(Minecraft minecraft, GuiScreen guiscreen)
    {
        GUIHANDLER.OnTickInGUI();
        return true;
    }
    
	public String Version() {
		return info.VERSION;
	}
	
	public final GuiHandler GUIHANDLER = new GuiHandler();
}
