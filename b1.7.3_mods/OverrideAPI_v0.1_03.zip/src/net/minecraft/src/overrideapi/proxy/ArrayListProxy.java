package net.minecraft.src.overrideapi.proxy;

import java.util.ArrayList;

import net.minecraft.src.overrideapi.OverrideAPI;

@SuppressWarnings("serial")
public class ArrayListProxy<T> extends ArrayList<T> {
    @Override
    public void clear() {
        super.clear();
        OverrideAPI.MLProxy.GUIHANDLER.controlListClear();
    }
}
