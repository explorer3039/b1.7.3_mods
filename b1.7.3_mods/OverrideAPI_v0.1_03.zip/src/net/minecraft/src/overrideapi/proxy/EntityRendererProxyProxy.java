package net.minecraft.src.overrideapi.proxy;

import net.minecraft.client.Minecraft;
import net.minecraft.src.EntityRendererProxy;
import net.minecraft.src.overrideapi.OverrideAPI;

public class EntityRendererProxyProxy extends EntityRendererProxy {

	public EntityRendererProxyProxy(Minecraft minecraft) {
		super(minecraft);
		mcGame = minecraft;
	}
	
	@Override
	public void updateCameraAndRender(float f) {
	    if (mcGame.currentScreen != null)
	        OverrideAPI.MLProxy.GUIHANDLER.beforeDrawScreen();
        OverrideAPI.MLProxy.GUIHANDLER.onTick();
		super.updateCameraAndRender(f);
	}
	
	private final Minecraft mcGame;
}
