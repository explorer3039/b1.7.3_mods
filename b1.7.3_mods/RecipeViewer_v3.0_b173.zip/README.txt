This is Recipe Viewer v3.0 for Minecraft Beta 1.7.3 Client

DESCRIPTION
This mod implements an NEI style recipe searcher for Beta 1.7.3 with the following features:
- Find the recipes for an item by hovering it and pressing 'R'
- Find the uses for an item by hovering it and pressing 'U'
- Go to the previous recipe you searched with 'BACKSPACE'
- View all recipes with 'I'
- If your inventory contains all the items in a recipe you can click the '+' button to automatically fill the recipe in
- You can also resize the GUI by dragging the bottom right corner of it.
You can configure the keybinds in the controls, and you can disable features in the config file if you wish.

INSTALL
1. Install Modloader
2. Delete META-INF from the minecraft.jar
3. Insert this zip into the .minecraft/mods folder
4. ???
5. Success!

SUPPORTED MODS
IndustrialCraft2 v1.00 - Macerator, Extractor, Compressor, Canning Machine
Aether Mod v1.02 - Enchanter, Freezer (Compatible with older/mp versions)
Uranium Mod - Reactor
Flan's Planes - Plane Workbench
Buildcraft - Auto fill recipe support for Automatic Crafting Table
TooManyItems - You can find recipes for any item in the TMI sidebar

If you would like a mod to be supported or further support for an existing mod, feel free to ask me on the mod station discord @rek

CREDIT
Original recipe book mods this was built upon - Risugami & Shockah
References to relevant source code for Aether - mine_diver
Coding mastermind - me, rek