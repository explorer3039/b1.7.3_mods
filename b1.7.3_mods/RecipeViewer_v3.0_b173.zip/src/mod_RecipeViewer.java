// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.lwjgl.input.Mouse;

import ic2.ItemBattery;
import ic2.TileEntityCompressor;
import ic2.TileEntityExtractor;
import ic2.TileEntityMacerator;
import net.minecraft.client.Minecraft;

// Referenced classes of package net.minecraft.src:
//            BaseMod, ItemRecipeBook, Item, ModLoader, 
//            ItemStack

public class mod_RecipeViewer extends BaseMod
{

	public String Version()
    {
        return "v3.0";
    }
	
	public mod_RecipeViewer()
    {
		if (!configFile.exists())
			writeConfig();
		readConfig();
		
		ModLoader.RegisterKey(this, pushRecipe, false);
		if (optionsSeperateKeyBindForUses) ModLoader.RegisterKey(this, pushUses, false);
		if(optionsPrevRecipesKeybindEnabled) ModLoader.RegisterKey(this, popRecipe, false);
		if (optionsAllRecipesKeybindEnabled) ModLoader.RegisterKey(this, allRecipes, false);
		try
        {
			Class.forName("TMIController");
			tmiInstalled = true;
         }
		catch (ClassNotFoundException e) { 
			tmiInstalled = false;
		}
    }
	
	public void KeyboardEvent(KeyBinding event)
    {
		if (event == this.pushRecipe || event == this.pushUses) {
			GuiScreen gui = ModLoader.getMinecraftInstance().currentScreen;
			if (gui instanceof GuiContainer) {
				
				ItemStack newFilter = null;
				
				ScaledResolution scaledresolution = new ScaledResolution(ModLoader.getMinecraftInstance().gameSettings, ModLoader.getMinecraftInstance().displayWidth, ModLoader.getMinecraftInstance().displayHeight);
				int i = scaledresolution.getScaledWidth();
				int j = scaledresolution.getScaledHeight();
				int posX = (Mouse.getEventX() * i) / ModLoader.getMinecraftInstance().displayWidth;
				int posY = j - (Mouse.getEventY() * j) / ModLoader.getMinecraftInstance().displayHeight - 1;
	            Slot slot = getSlotAtPosition((GuiContainer)gui, posX, posY);
				if (slot != null) newFilter = slot.getStack(); 
				
				//DEBUG
				//tmiInstalled = true;
				//
				if (newFilter == null && tmiInstalled ) {
					try
			        {
						newFilter = (ItemStack)ModLoader.getPrivateValue(net.minecraft.src._tmi_MgItemPanel.class, (_tmi_MgItemPanel)ModLoader.getPrivateValue(net.minecraft.src.TMIView.class, (TMIView)ModLoader.getPrivateValue(net.minecraft.src.TMIController.class, (TMIController)ModLoader.getPrivateValue(net.minecraft.src.GuiContainer.class, (GuiContainer)gui, "tmi"), "view"), "itemPanel"), "hoverItem");
			        }
			        catch(Exception e) { e.printStackTrace(); }
				}
				if(newFilter == null) {
					if(gui instanceof GuiRecipeViewer)
						newFilter = ((GuiRecipeViewer)gui).getHoverItem();
				}
				if(newFilter != null) {
					if(gui instanceof GuiRecipeViewer)
						((GuiRecipeViewer)gui).push(newFilter, event == this.pushUses);
					else {
						Minecraft mc = ModLoader.getMinecraftInstance();
						GuiRecipeViewer newgui = new GuiRecipeViewer(newFilter, event == this.pushUses, gui);
						mc.currentScreen = newgui;
			            newgui.setWorldAndResolution(mc, i, j);
					}
						
				}
			}
		}
		else if (event == this.popRecipe) {
			GuiScreen gui = ModLoader.getMinecraftInstance().currentScreen;
			if (gui instanceof GuiRecipeViewer) {
				((GuiRecipeViewer) gui).pop();
			}
		}
		else if (event == this.allRecipes) {
			GuiScreen gui = ModLoader.getMinecraftInstance().currentScreen;
			if (gui instanceof GuiRecipeViewer) {
				((GuiRecipeViewer) gui).push(null, false);
			}
			else if (gui instanceof GuiContainer){
				Minecraft mc = ModLoader.getMinecraftInstance();
				GuiRecipeViewer newgui = new GuiRecipeViewer(null, false, gui);
				mc.currentScreen = newgui;
				ScaledResolution scaledresolution = new ScaledResolution(mc.gameSettings, mc.displayWidth, mc.displayHeight);
				int i = scaledresolution.getScaledWidth();
				int j = scaledresolution.getScaledHeight();
	            newgui.setWorldAndResolution(mc, i, j);
			}
			else {
				ModLoader.getMinecraftInstance().displayGuiScreen(new GuiRecipeViewer());
			}
		}
    }	
	
	private Slot getSlotAtPosition(GuiContainer gui, int i, int j)
    {
        for(int k = 0; k < gui.inventorySlots.slots.size(); k++)
        {
            Slot slot = (Slot)gui.inventorySlots.slots.get(k);
            if(getIsMouseOverSlot(gui, slot, i, j))
            {
                return slot;
            }
        }
        return null;
    }

    private boolean getIsMouseOverSlot(GuiContainer gui, Slot slot, int i, int j)
    {
    	int kq = (gui.width - gui.xSize) / 2;
        int l = (gui.height - gui.ySize) / 2;
        i -= kq;
        j -= l;
        return i >= slot.xDisplayPosition - 1 && i < slot.xDisplayPosition + 16 + 1 && j >= slot.yDisplayPosition - 1 && j < slot.yDisplayPosition + 16 + 1;
    }
    
    public static ArrayList<TabRecipeViewer> getTabs() {
		if (tabs == null) {
			tabs = new ArrayList<TabRecipeViewer>();
			
			tabs.add(new TabRecipeViewerCrafting());
			tabs.add(new TabRecipeViewerFurnace());
			
			List modList = ModLoader.getLoadedMods();
			for (Object obj : modList) {
				BaseMod mod = (BaseMod)obj;
				ArrayList<ItemStack> fuels = new ArrayList<ItemStack>();
				if (mod.getClass().getName() == "mod_Planes") {
					tabs.add(new TabRecipeViewerPlanes());
					continue;
				}
				if (mod.getClass().getName() == "mod_Uranium") {
					fuels.add(new ItemStack (mod_Uranium.uraniumDust));
					fuels.add(new ItemStack (mod_Uranium.uraniumCoal));
					fuels.add(new ItemStack (mod_Uranium.skullUranium));
					for(Block block: Block.blocksList) {
						if(block != null && ModLoader.AddAllFuel(block.blockID) > 0) 
							fuels.add(new ItemStack(block));
							
					}
					for(Item item: Item.itemsList) {
						if(item != null && ModLoader.AddAllFuel(item.shiftedIndex) > 0) fuels.add(new ItemStack(item));
					}
					tabs.add(new TabRecipeViewerFurnace(ReactorRecipes.smelting().getSmeltingList(), fuels, "/uraniumTextures/reactorgui.png", mod_Uranium.reactorIdle));
					continue;
				}
				if (mod.getClass().getName() == "mod_IC2") {
					fuels.add(new ItemStack(Item.redstone));
					fuels.add(new ItemStack(mod_IC2.itemBatSU));
					for(Item item: Item.itemsList) {
						if(item != null && item instanceof ItemBattery) fuels.add(new ItemStack(item));
					}
					Block machine = mod_IC2.blockMachine;
					tabs.add(new TabRecipeViewerFurnace(TileEntityMacerator.recipes, fuels, "/IC2sprites/GUIMacerator.png", machine, 3));
					tabs.add(new TabRecipeViewerFurnace(TileEntityExtractor.recipes, fuels, "/IC2sprites/GUIExtractor.png", machine, 4));
					tabs.add(new TabRecipeViewerFurnace(TileEntityCompressor.recipes, fuels, "/IC2sprites/GUICompressor.png", machine, 5));
					tabs.add(new TabRecipeViewerIC2CanningMachine(fuels, "/IC2sprites/GUICanner.png", machine, 6));
					continue;
				}
				if (mod.getClass().getName() == "mod_Aether") {
					tabs.add(new TabRecipeViewerAether(TileEntityEnchanter.class, new ArrayList<ItemStack>(Arrays.asList(new ItemStack(AetherItems.AmbrosiumShard))), "/aether/gui/enchanter.png", AetherBlocks.Enchanter));
					try
			        {
						Class.forName("TileEntityFreezer");
						tabs.add(new TabRecipeViewerAether(TileEntityFreezer.class, new ArrayList<ItemStack>(Arrays.asList(new ItemStack(AetherBlocks.Icestone))), "/aether/gui/enchanter.png", AetherBlocks.Freezer));
					} catch (ClassNotFoundException e) { }
				}
				if (mod.getClass().getName() == "mod_BuildCraftFactory") {
					buildcraftFactoryInstalled = true;
					continue;
				}
			}
		}
        return tabs;
	}
    
    public static void writeConfig() {
		try {
			BufferedWriter configWriter = new BufferedWriter(new FileWriter(configFile));
			configWriter.write("// Config file for Recipe Viewer");

			Field[] fields = mod_RecipeViewer.class.getFields();
			for (Field field : fields) {
				if (field.getName().contains("options"))
					try {
						configWriter.write(System.lineSeparator() + field.getName().replaceFirst("options", "")
								+ "=" + field.get(null).toString());
					} catch (Exception exception) {
						exception.printStackTrace();
					}
			}
			configWriter.close();
		} catch (Exception exception) {
			exception.printStackTrace();
		}
	}
    
    public void readConfig() {
		try {
			BufferedReader configReader = new BufferedReader(new FileReader(configFile));
			String s;
			while ((s = configReader.readLine()) != null) {
				if (s.charAt(0) == '/' && s.charAt(1) == '/') {
					continue; // Ignore comments
				}
				if (s.contains("=")) {
					String as[] = s.split("=");
					Field field = mod_RecipeViewer.class.getField("options" + (as[0]));

					if (field.getType() == int.class) {
						field.set(this, Integer.parseInt(as[1]));
					} else if (field.getType() == Boolean.class) {
						field.set(this, Boolean.parseBoolean(as[1]));
					}
				}
			}
			configReader.close();
		} catch (Exception exception) {
			exception.printStackTrace();
		}
	}
	
    private static ArrayList<TabRecipeViewer> tabs;
    
    private static File configFile = new File((Minecraft.getMinecraftDir()) + "/config/RecipeViewer.cfg");
    
    public static int optionsGuiWidth = 251;
    public static int optionsGuiHeight = 134;
    
    public static Boolean optionsSeperateKeyBindForUses = true;
    public static Boolean optionsPrevRecipesKeybindEnabled = true;
    public static Boolean optionsAllRecipesKeybindEnabled = true;
    public static Boolean optionsDraggableGui = true;
    
    public static boolean buildcraftFactoryInstalled;
    
    private boolean tmiInstalled;
    
    private KeyBinding pushRecipe = new KeyBinding("Get Recipes", 19);
    private KeyBinding pushUses = new KeyBinding("Get Uses", 22);
    private KeyBinding popRecipe = new KeyBinding("Previous Recipe", 14);
    private KeyBinding allRecipes = new KeyBinding("Show All Recipes", 23);
    
}
