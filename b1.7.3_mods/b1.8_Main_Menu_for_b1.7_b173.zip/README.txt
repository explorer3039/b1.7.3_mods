This mod in summary, takes all the code from the b1.8 main menu and shoves it into b1.7

None of this code was by me, all is owned by Mojang. I simply did the porting.

By LO6AN