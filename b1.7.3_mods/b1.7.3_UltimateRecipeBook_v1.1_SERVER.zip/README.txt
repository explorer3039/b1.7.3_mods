This is UltimateRecipeBook v1.1 for Minecraft Beta 1.7.3 Server
Compatible with clients that have v1.1 installed

DESCRIPTION
This mod combines Risugami's Recipe Book and Shockah's Crafting Book into 1 item.
It can be crafted with an ink sack, crafting table and book.

INSTALL
1. Install ModLoaderMP Unofficial v2
2. DO NOT delete META-INF from the minecraft_server.jar
3. Insert this zip into the server/mods folder
4. ???
5. Success!

CREDIT
Original recipe book mods which I have shamelessly stolen - Risugami & Shockah
Combo of books, multiplayer port and bad code - me, rek

CHANGELOG for v1.1
- Huge code improvements despite a low difference for user
- Packets sent to server reduced
- Classes formalised and refined
- Indicator slot on book to show it cannot be moved
- Book now retains item in filter slot until gui is closed
- Item ID changed to not conflict with Risugami's book