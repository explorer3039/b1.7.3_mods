// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;


// Referenced classes of package net.minecraft.src:
//            BaseMod, ItemRecipeBook, Item, ModLoader, 
//            ItemStack

public class mod_URB extends BaseModMp
{

    public mod_URB()
    {
        book = (new ItemURB(RecipeBookID - 256)).setIconIndex(Item.book.iconIndex).setItemName("recipeBook");
        //ModLoader.AddName(book, "Recipe Book");
        
        
        ModLoader.AddShapelessRecipe(new ItemStack(book, 1, 0), new Object[] {
        		Block.workbench, Item.book, new ItemStack(Item.dyePowder, 1, 0)
        });
        ModLoader.AddShapelessRecipe(new ItemStack(book, 1, 1), new Object[] {
        		new ItemStack(book, 1, 0)
            //Block.workbench, Item.book, new ItemStack(Item.dyePowder, 1, 0)
        });
        ModLoader.AddShapelessRecipe(new ItemStack(book, 1, 0), new Object[] {
        		new ItemStack(book, 1, -1)
                //Block.workbench, Item.book, new ItemStack(Item.dyePowder, 1, 0)
        });
        
    }

    public String Version()
    {
        return "v1.1";
    }
    
   
    
    public void HandlePacket(Packet230ModLoader packet, EntityPlayerMP player)
	{
    	player.inventory.getCurrentItem().setItemDamage(packet.dataInt[0]);
    	if (packet.dataInt[1] == 1) {
    		if (packet.dataInt[2] != -1) {
    			player.currentCraftingInventory.windowId = packet.dataInt[2];
    		}
    		else {
    			ModLoader.OpenGUI(player, 15,  player.inventory, new ContainerURBFiltered(player.inventory));
		
    			//player.currentCraftingInventory = new ContainerURBFiltered(player.inventory);
				
			}
    	}
	}

	
    
    public static Item book;
    public static int RecipeBookID = 398;

}
