// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;

// Referenced classes of package net.minecraft.src:
//            Slot, ItemStack, ModLoader, EntityPlayerSP, 
//            InventoryPlayer, IInventory

public class SlotURBOutput extends Slot
{

    public SlotURBOutput(IInventory iinventory, int i, int j, int k)
    {
        super(iinventory, i, j, k);
    }

    public boolean isItemValid(ItemStack itemstack)
    {
        return false;
    }

    public void onPickupFromSlot(ItemStack itemstack)
    {
        putStack(new ItemStack(itemstack.itemID, itemstack.stackSize, itemstack.getItemDamage()));
        super.onPickupFromSlot(itemstack);
        //ModLoader.getMinecraftInstance().thePlayer.inventory.setItemStack(null);
    }
}
