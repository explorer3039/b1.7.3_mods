// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;


// Referenced classes of package net.minecraft.src:
//            Item, ModLoader, GuiRecipesCraft, EntityPlayer, 
//            ItemStack, World

public class ItemURB extends Item
{

    protected ItemURB(int i)
    {
        super(i);
        setItemName(getClass().getName());
        setIconCoord(11, 3);
        maxStackSize = 1;
        
    }

    public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer entityplayer)
    {
    	
    	if (itemstack.getItemDamage() == 0) {
    		ModLoader.OpenGUI(entityplayer, 15,  entityplayer.inventory, new ContainerURBFiltered(entityplayer.inventory));
    	}
    	return itemstack;
    }
    
 
}
