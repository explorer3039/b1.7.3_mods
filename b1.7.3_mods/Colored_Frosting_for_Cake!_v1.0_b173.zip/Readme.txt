Block & Item IDs can be configured in the property file in ".minecraft\mods\zdmshadow's Mods" 

-----------------------
Required Mods
-----------------------
* ModLoader

----------------------
How-To-Install
----------------------
*Copied & pasted from Risugami's thread*

"Windows:
1) Open up %appdata%, if you don't know how to do this, start>run, then type in %appdata%
2) Browse to .minecraft/bin
3) Open up minecraft.jar with WinRAR or 7zip.
4) Drag and drop the necessary files into the jar.
5) Delete the META-INF folder in the jar.
6) Run Minecraft, enjoy!

Macintosh:
1) Go to Applications>Utilities and open terminal.
2) Type in the following, line by line:

      cd ~
      mkdir mctmp
      cd mctmp
      jar xf ~/Library/Application\ Support/minecraft/bin/minecraft.jar


3) Outside of terminal, copy all the files and folders into the mctmp directory.
4) Back inside terminal, type in the following:

      rm META-INF/MOJANG_C.*
      jar uf ~/Library/Application\ Support/minecraft/bin/minecraft.jar ./
      cd ..
      rm -rf mctmp


5) Run Minecraft, enjoy!"

 

