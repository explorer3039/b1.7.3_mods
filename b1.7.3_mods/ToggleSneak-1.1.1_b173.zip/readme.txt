ToggleSneak v1.1.1 Beta 1.7.3 ReadMe


Description
===========
This mod will allow you to specify a key for toggling sneak. If toggled on, the usual sneak key will work inversely.
This Mod now requires Modloader

Install
=======
1) Instal Modloader.
2) Delete META-INF folder.
3) Put .zip file into the mods folder.
4) Run Minecraft and enjoy!

Warning:
This will corrupt any mods using the same Files. It is tested compatible with modloader and Zan's Minimap.

History
======
v1.1.1 Fixed bug where Sneak would be altered while in any gui
v1.1.0 Made Modloader Mod
v1.0.0 Initial Release

Legal/Copyright
===============
This mod (plugin, a patch to Minecraft source, henceforth "Mod" or "The Mod"), by the terms of http://www.minecraft.net/copyright.jsp is sole property of the Mod author (Melanchrom, henceforth "Owner" or "The Owner"). By default it may only be distributed on minecraftforums.net. It may only be mirrored or reposted with advance written permission of the Owner. Electronic Mail is fine if you wait for a response. URL shorteners or otherattempts to make money off The Owner's Mod are strictly forbidden without advance written permission.