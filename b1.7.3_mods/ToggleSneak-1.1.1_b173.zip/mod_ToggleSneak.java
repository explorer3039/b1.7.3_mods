package net.minecraft.src;

import java.util.logging.Logger;

import net.minecraft.client.Minecraft;

import org.lwjgl.input.Keyboard;

/**
* @author Melanchrom (melanchrom at web.de)
* Website: {@link http://}
* Source code: {@link http://}
*
*/

public class mod_ToggleSneak extends BaseMod
{
	Minecraft mc;
	KeyBinding ToggleSneak;
	boolean SneakToggled;
	
	public mod_ToggleSneak()
	{
		mc = ModLoader.getMinecraftInstance();
		
		SneakToggled = false;
		
        ToggleSneak = new KeyBinding("Toggle Sneak", Keyboard.KEY_LCONTROL); /* KeyBinding */
        ModLoader.RegisterKey(this, ToggleSneak, false);
		
		ModLoader.SetInGameHook(this, true, false);
	}
	
	@Override
	public String Version()
	{
		return "1.1.1 (1.7.3)";
	}
	
	public final void KeyboardEvent(KeyBinding keyBinding)
	{
		if(mc.currentScreen == null)
			SneakToggled = !SneakToggled;
	}
	
	public boolean OnTickInGame(Minecraft minecraft)
	{
		boolean flag = false;
		boolean SneakKey = Keyboard.isKeyDown(mc.gameSettings.keyBindSneak.keyCode);
		
		if(!(mc.currentScreen == null))
			SneakKey = false;

		//if(!(SneakKey && SneakToggled) && (SneakKey || SneakToggled))
		if(SneakKey ^ SneakToggled)
			flag = true;
		mc.thePlayer.movementInput.checkKeyForMovementInput(mc.gameSettings.keyBindSneak.keyCode, flag);
		return true;
	}
}