How to install:
- install ModLoader Beta 1.5_01v3+ and AudioMod as per the instructions
- if this zip contains a RESOURCES/ folder, extract the contents within it into .minecraft/resources (refer to the mod install tutorial http://tiny.cc/modinstall for how to find .minecraft).
- put this zip file into .minecraft/mods (without unzipping). If you do not have a mods directory, create it.
- you don't need to add any files to minecraft.jar thanks to modloader's external loading. but if you want, you can add the contents of this zip into minecraft.jar, of course.

Usage:
- this mod creates a config file in .minecraft/mods/kodaichi at first run, along
  with help text.
