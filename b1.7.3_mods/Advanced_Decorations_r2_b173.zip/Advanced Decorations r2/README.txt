================================================

Advanced Decorations Mod by Elementface

================================================

Programmed with Minecraft Coder Pack (MCP) and Drjava
MCP wiki: http://mcp.ocean-labs.de/index.php/Main_Page
Drjava website: http://www.drjava.org/

================================================

Programmed to be compatable with ModLoader
ModLoader Minecraftforum.net forum: http://www.minecraftforum.net/topic/75440-v166-risugamis-mods-updates/

================================================

Copyright: Free to distribute with credit given to Elementface upon sharing/uploading. Source code is free to edit
and share with credit given to Elementface upon sharing/uploading

================================================



INSTALLATION GUIDE:


Step One: Download and instal ModLoader (follow their instructions to the tee or this installation will fail)
Step Two: Unzip the .zip this file is located in
Step Three: Open your minecraft.jar using something like 7zip or jzip
Step Four: copy/paste everything in "Mod" folder into minecraft.jar
Step Five: Enjoy!



=================================================


USER'S GUIDE:

To create colored cobblestone, just place a cobble of any color and a dye of a primary, secondary,
or white or black colour similar to cloth. See below for an example:

[] [] []
Wc Rp []
[] [] []

Wc = white cobblestone
Rp = red paste

This will give you red cobblestone


==================================================


CHANGELOG:

r2:
--Updated for MC v1.7_3
r1:
--Advanced Decorations Realeased

