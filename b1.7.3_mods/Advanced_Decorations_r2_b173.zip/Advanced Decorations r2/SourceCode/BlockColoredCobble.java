//  Coded by: Elementface
//  About: June 1st, 2011
//  Class name: BlockRedCobble
//  Purpose: Defines all the color cobblestones in mod_AdvancedDecorations
//  Notes: Modloader compatable


package net.minecraft.src;

public class BlockColoredCobble extends Block
{ 
     
     protected BlockColoredCobble(int i, int j)
     {
          super(i, j, Material.rock);
     }

}