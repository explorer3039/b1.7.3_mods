//  Coded by: Elementface
//  About: June 30, 2011
//  Class Name: mod_AdvancedDecorations
//  Purpose: Adds more decorative blocks
//  Notes: Compatable with ModLoader; uses Item IDs 125-255

package net.minecraft.src;

    public class mod_AdvancedDecorations extends BaseMod
         //  Extends BaseMod from ModLoader so you can use ModLoader stuff
    {
       //  cobblestones
       public static final Block RedCobble;
       public static final Block BlueCobble;
       public static final Block GreenCobble;
       public static final Block YellowCobble;
       public static final Block PurpleCobble;
       public static final Block OrangeCobble;
       public static final Block WhiteCobble;
       public static final Block BlackCobble;
       
       
       static
       {
            // All the colored cobbles use the same defining block class, BlockColoredCobble, 
            //   because they all have the same property except for their texures
            RedCobble = (new BlockColoredCobble(125, ModLoader.addOverride("/terrain.png", 
               "/EFCI_AdvancedDecorations_Textures/Cobbles/RedCobble.png")))
               .setHardness(0.3F).setResistance(10F).setStepSound(Block.soundStoneFootstep)
               .setBlockName("Red Cobblestone");
            BlueCobble = (new BlockColoredCobble(126, ModLoader.addOverride("/terrain.png", 
               "/EFCI_AdvancedDecorations_Textures/Cobbles/BlueCobble.png")))
               .setHardness(0.3F).setResistance(10F).setStepSound(Block.soundStoneFootstep)
               .setBlockName("Blue Cobblestone");
            GreenCobble = (new BlockColoredCobble(127, ModLoader.addOverride("/terrain.png", 
               "/EFCI_AdvancedDecorations_Textures/Cobbles/GreenCobble.png")))
               .setHardness(0.3F).setResistance(10F).setStepSound(Block.soundStoneFootstep)
               .setBlockName("Green Cobblestone");
            YellowCobble = (new BlockColoredCobble(128, ModLoader.addOverride("/terrain.png", 
               "/EFCI_AdvancedDecorations_Textures/Cobbles/YellowCobble.png")))
               .setHardness(0.3F).setResistance(10F).setStepSound(Block.soundStoneFootstep)
               .setBlockName("Yellow Cobblestone");
            PurpleCobble = (new BlockColoredCobble(129, ModLoader.addOverride("/terrain.png", 
               "/EFCI_AdvancedDecorations_Textures/Cobbles/PurpleCobble.png")))
               .setHardness(0.3F).setResistance(10F).setStepSound(Block.soundStoneFootstep)
               .setBlockName("Purple Cobblestone");
            OrangeCobble = (new BlockColoredCobble(130, ModLoader.addOverride("/terrain.png", 
               "/EFCI_AdvancedDecorations_Textures/Cobbles/OrangeCobble.png")))
               .setHardness(0.3F).setResistance(10F).setStepSound(Block.soundStoneFootstep)
               .setBlockName("Orange Cobblestone");
            WhiteCobble = (new BlockColoredCobble(131, ModLoader.addOverride("/terrain.png", 
               "/EFCI_AdvancedDecorations_Textures/Cobbles/WhiteCobble.png")))
               .setHardness(0.3F).setResistance(10F).setStepSound(Block.soundStoneFootstep)
               .setBlockName("White Cobblestone");
            BlackCobble = (new BlockColoredCobble(132, ModLoader.addOverride("/terrain.png", 
               "/EFCI_AdvancedDecorations_Textures/Cobbles/BlackCobble.png")))
               .setHardness(0.3F).setResistance(10F).setStepSound(Block.soundStoneFootstep)
               .setBlockName("Black Cobblestone");
       }
       
       
       
       
       public mod_AdvancedDecorations()
       {
          // Massive list of recipies so that any colored cobble can be converted to any other color
          // Creating recipies with dyes are special; since dyes are defined with an item ID AND damage,
          // you have to define the recipie with an item stack of dye(s) instead of just and item.
          // It's pretty simple to do: instead of Block.cobblestone or Item.stick, you use 
          // 'new ItemStack(Item.dyePowder, 2, (damage number for dye))'. Just replace (damage number for dye)
          // for the damage number coresponding to the right dye. For example: 1 is red, and 15 is white.
          // Just look up a list of item codes and look at the second number attatched to 351.
          ModLoader.AddName( RedCobble, "Red Cobblestone" );
          ModLoader.RegisterBlock( RedCobble );
          ModLoader.AddRecipe(new ItemStack(RedCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), Block.cobblestone, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 1)
          }); // From cobble
          ModLoader.AddRecipe(new ItemStack(RedCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), BlueCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 1)
          }); // From blue
          ModLoader.AddRecipe(new ItemStack(RedCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), GreenCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 1)
          }); // From green
          ModLoader.AddRecipe(new ItemStack(RedCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), YellowCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 1)
          }); // From yellow
          ModLoader.AddRecipe(new ItemStack(RedCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), PurpleCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 1)
          }); // From Purple
          ModLoader.AddRecipe(new ItemStack(RedCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), OrangeCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 1)
          }); // From Orange
          ModLoader.AddRecipe(new ItemStack(RedCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), WhiteCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 1)
          }); // From White
          ModLoader.AddRecipe(new ItemStack(RedCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), BlackCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 1)
          }); // From Black
          
          
          
          ModLoader.AddName( BlueCobble, "Blue Cobblestone" );
          ModLoader.RegisterBlock( BlueCobble );
          ModLoader.AddRecipe(new ItemStack(BlueCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), Block.cobblestone, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 4)
          }); // From cobble
          ModLoader.AddRecipe(new ItemStack(BlueCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), RedCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 4)
          }); // From red
          ModLoader.AddRecipe(new ItemStack(BlueCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), GreenCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 4)
          }); // From green
          ModLoader.AddRecipe(new ItemStack(BlueCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), YellowCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 4)
          }); // From Yellow
          ModLoader.AddRecipe(new ItemStack(BlueCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), PurpleCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 4)
          }); // From Purple
          ModLoader.AddRecipe(new ItemStack(BlueCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), OrangeCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 4)
          }); // From Orange
          ModLoader.AddRecipe(new ItemStack(BlueCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), WhiteCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 4)
          }); // From White
          ModLoader.AddRecipe(new ItemStack(BlueCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), BlackCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 4)
          }); // From Black
          
          
          
          ModLoader.AddName( GreenCobble, "Green Cobblestone" );
          ModLoader.RegisterBlock( GreenCobble );
          ModLoader.AddRecipe(new ItemStack(GreenCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), Block.cobblestone, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 2)
          }); // From cobble
          ModLoader.AddRecipe(new ItemStack(GreenCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), RedCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 2)
          }); // From red
          ModLoader.AddRecipe(new ItemStack(GreenCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), BlueCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 2)
          }); // From blue
          ModLoader.AddRecipe(new ItemStack(GreenCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), YellowCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 2)
          }); // From yellow
          ModLoader.AddRecipe(new ItemStack(GreenCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), PurpleCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 2)
          }); // From Purple
          ModLoader.AddRecipe(new ItemStack(GreenCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), OrangeCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 2)
          }); // From Orange
          ModLoader.AddRecipe(new ItemStack(GreenCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), WhiteCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 2)
          }); // From White
          ModLoader.AddRecipe(new ItemStack(GreenCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), BlackCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 2)
          }); // From Black
          
          
          
          ModLoader.AddName( YellowCobble, "Yellow Cobblestone" );
          ModLoader.RegisterBlock( YellowCobble );
          ModLoader.AddRecipe(new ItemStack(YellowCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), Block.cobblestone, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 11)
          }); // From cobble
          ModLoader.AddRecipe(new ItemStack(YellowCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), RedCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 11)
          }); // From red
          ModLoader.AddRecipe(new ItemStack(YellowCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), BlueCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 11)
          }); // From blue
          ModLoader.AddRecipe(new ItemStack(YellowCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), GreenCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 11)
          }); // From green
          ModLoader.AddRecipe(new ItemStack(YellowCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), PurpleCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 11)
          }); // From Purple
          ModLoader.AddRecipe(new ItemStack(YellowCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), OrangeCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 11)
          }); // From Orange
          ModLoader.AddRecipe(new ItemStack(YellowCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), WhiteCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 11)
          }); // From White
          ModLoader.AddRecipe(new ItemStack(YellowCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), BlackCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 11)
          }); // From Black
          
          
          
          ModLoader.AddName( PurpleCobble, "Purple Cobblestone" );
          ModLoader.RegisterBlock( PurpleCobble );
          ModLoader.AddRecipe(new ItemStack(PurpleCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), Block.cobblestone, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 5)
          }); // From cobble
          ModLoader.AddRecipe(new ItemStack(PurpleCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), RedCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 5)
          }); // From red
          ModLoader.AddRecipe(new ItemStack(PurpleCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), BlueCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 5)
          }); // From blue
          ModLoader.AddRecipe(new ItemStack(PurpleCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), GreenCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 5)
          }); // From green
          ModLoader.AddRecipe(new ItemStack(PurpleCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), YellowCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 5)
          }); // From Yellow
          ModLoader.AddRecipe(new ItemStack(PurpleCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), OrangeCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 5)
          }); // From Orange
          ModLoader.AddRecipe(new ItemStack(PurpleCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), WhiteCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 5)
          }); // From White
          ModLoader.AddRecipe(new ItemStack(PurpleCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), BlackCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 5)
          }); // From Black
          
          
          
          ModLoader.AddName( OrangeCobble, "Orange Cobblestone" );
          ModLoader.RegisterBlock( OrangeCobble );
          ModLoader.AddRecipe(new ItemStack(OrangeCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), Block.cobblestone, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 14)
          }); // From cobble
          ModLoader.AddRecipe(new ItemStack(OrangeCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), RedCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 14)
          }); // From red
          ModLoader.AddRecipe(new ItemStack(OrangeCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), BlueCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 14)
          }); // From blue
          ModLoader.AddRecipe(new ItemStack(OrangeCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), GreenCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 14)
          }); // From green
          ModLoader.AddRecipe(new ItemStack(OrangeCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), YellowCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 14)
          }); // From Yellow
          ModLoader.AddRecipe(new ItemStack(OrangeCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), PurpleCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 14)
          }); // From Purple
          ModLoader.AddRecipe(new ItemStack(OrangeCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), WhiteCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 14)
          }); // From White
          ModLoader.AddRecipe(new ItemStack(OrangeCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), BlackCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 14)
          }); // From Black
          
          
          
          ModLoader.AddName( WhiteCobble, "White Cobblestone" );
          ModLoader.RegisterBlock( WhiteCobble );
          ModLoader.AddRecipe(new ItemStack(WhiteCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), Block.cobblestone, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 15)
          }); // From cobble
          ModLoader.AddRecipe(new ItemStack(WhiteCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), RedCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 15)
          }); // From red
          ModLoader.AddRecipe(new ItemStack(WhiteCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), BlueCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 15)
          }); // From blue
          ModLoader.AddRecipe(new ItemStack(WhiteCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), GreenCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 15)
          }); // From green
          ModLoader.AddRecipe(new ItemStack(WhiteCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), YellowCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 15)
          }); // From Yellow
          ModLoader.AddRecipe(new ItemStack(WhiteCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), PurpleCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 15)
          }); // From Purple
          ModLoader.AddRecipe(new ItemStack(WhiteCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), OrangeCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 15)
          }); // From Orange
          ModLoader.AddRecipe(new ItemStack(WhiteCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), BlackCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 15)
          }); // From Black
          
          
          
          ModLoader.AddName( BlackCobble, "Black Cobblestone" );
          ModLoader.RegisterBlock( BlackCobble );
          ModLoader.AddRecipe(new ItemStack(BlackCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), Block.cobblestone, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 0)
          }); // From cobble
          ModLoader.AddRecipe(new ItemStack(BlackCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), RedCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 0)
          }); // From red
          ModLoader.AddRecipe(new ItemStack(BlackCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), BlueCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 0)
          }); // From blue
          ModLoader.AddRecipe(new ItemStack(BlackCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), GreenCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 0)
          }); // From green
          ModLoader.AddRecipe(new ItemStack(BlackCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), YellowCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 0)
          }); // From Yellow
          ModLoader.AddRecipe(new ItemStack(BlackCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), PurpleCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 0)
          }); // From Purple
          ModLoader.AddRecipe(new ItemStack(BlackCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), OrangeCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 0)
          }); // From Orange
          ModLoader.AddRecipe(new ItemStack(BlackCobble, 1), new Object[] {
          "xy", Character.valueOf('x'), WhiteCobble, Character.valueOf('y'), 
               new ItemStack(Item.dyePowder, 2, 0)
          }); // From White
          
          
       }
       
       
       public String Version()
       {
          return "1";
       }
    }