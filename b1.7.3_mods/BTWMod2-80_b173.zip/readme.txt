FlowerChild's Better Than Wolves Mod V2.80
(Compatible with Minecrat Version 1.7.3)

[*** COPYRIGHT NOTICE ***]
 This document is Copyright �(2011) and is the intellectual property of the author. It may be not be reproduced under any circumstances except for personal, private use as long as it remains in its unaltered, unedited form. It may not be placed on any web site or otherwise distributed publicly without advance written permission. Use of this mod on any other website is strictly prohibited, and a violation of copyright.
 
Note: I DO NOT grant redistribution rights to this mod to anyone that asks, whether that be for a mod-pack or whatever. Don't bother asking, as it won't happen.
[************************]

For detailed item descriptions (including crafting recipes), an up to date version of this mod, video feature demonstrations, and other useful info, please consult the following thread in the Minecraft forums:

http://www.minecraftforum.net/viewtopic.php?f=1032&t=275333

****** Installation Instructions ******

1) Make sure minecraft is not running.
2) Install Risugami's ModLoader (http://www.minecraftforum.net/viewtopic.php?f=1032&t=80246)
3) Open your minecraft.jar with Winrar or other program
4) Delete the META-INF folder in minecraft.jar (you should have already done this when you installed ModLoader)
5) Copy all the files and folders in this mod's MINECRAFT-JAR folder into your minecraft.jar (overwriting any existing files).
6) Profit!

NOTE: This mod can NOT be installed by using the ModLoader method of simply copying this zip file into the ".minecraft/mods/" folder.  It modifies base classes, and thus this ModLoader functionality can not be supported (as explicitly stated in the ModLoader documentation).  You MUST copy the appropriate files into minecraft.jar as described above for this mod to function properly.

***OPTIONAL***

-FOR ADVANCED USERS ONLY: If you want to remap the block and item ids to ensure compatibility with another mod copy BTWConfig.txt into your \.minecraft folder and edit it to your liking.  WARNING: Make sure you know what you're 
doing if you attempt this.  Tampering with this file can corrupt save games and result in crashes if you screw up.  YOU HAVE BEEN WARNED.

********* Compatability Information **********

The mod author makes no claims to compatibility with other mods.  However, for those trying to get this mod to work with others,
the following technical information is provided:

Base Classes Modified By This Mod:

BlockCake
BlockDetectorRail
BlockFire
BlockRail
BlockSand
BlockTallGrass
BlockTrapDoor
EntityArrow
EntityLiving
EntityMinecart
EntityWolf
ItemHoe
World
WorldGenBigTree
WorldGenForest
WorldGenTaiga2
WorldGenTrees

********** Change Log ************

Version 2.80

-Added the Bellows.
-Added Glue.
-Added Tallow.
-Added the Haft.
-Added alternate recipe for the Wood Blade using Glue instead of goo balls.
-Added alternate recipe for the sticky piston using Glue instead of goo balls.
-Changed the Turntable recipe to use wood Panels instead of wood.
-Adjusted the visual offset of the Turntable switch to be aligned with the markers on its texture.
-Fixed problem with Gear Boxes attached to Wind Mills still sometimes breaking after rain had stopped.
-Removed changes to BlockPistonBase class and moved the code in question elsewhere for the sake of compatibility with piston mods.
-Corrected orientation problem when placing Pistons with the Block Dispenser.
-Increased the size of a couple of arrays in the modified BlockFire class to avoid incompatibilities with MC Extended.

Version 2.71

-Added the Wood Blade as an item.
-Changed Water Wheel recipe to require Wood Blades instead of wood, and to get rid of gear in centre.
-Changed Wind Mill recipe to get rid of gear in centre.
-Reduced the number of settings on the Turntable from 11 to 4 (.5 seconds/1 seconds/2 seconds/4 seconds).
-Reduced the height to which the Turntable rotates blocks above it from 12 to 2.
-Changed the Turntable recipe to replace the Axle with Redstone, and the Redstone with a Gear.
-Fixed problem with repeater always setting its delay to 4 when rotated by the Turntable.
-Fixed a rather major bug in the Detector Block logic that was introduced within the past couple of versions and which was causing it to malfunction under a wide range of circumstances.
-Fixed problem with upwards-facing Detector Blocks taking up to 5 seconds to detect something in front of them.


Version 2.70

-Added the Turntable.  Let the good times rotate!
-Added Rollers as a new item that acts as an additional filter-type in the Hopper.
-Changed Axle to drop sticks when destroyed, instead of wood, since it can now be crafted using Moulding.
-Changed rope to set an upwards facing Anchor into motion when a Pulley causes the rope to descend on the Anchor.
-Changed placement code for Water Wheels and Wind Mills so that they can not extend beyond max-height (128) in the world.

Version 2.66

-Updated to version 1.7.3 of Minecraft.

Version 2.65 (Unreleased)

-Added ability for Minecart Rails (of all types) and Redstone Wire to be lifted by Platforms.  Note that sloped-rails can not be lifted in this manner and will break if you attempt to do so.  Also, redstone is non-functional while in transit and its shape will change to reflect this.
-Added alternate recipe for Axle using Moulding instead of Wood blocks.
-Restored the ability to "stick" objects (like torches) to the Companion Cube.
-Increased the amount of iron used in the Cauldron recipe to be more consistent with other full-block recipes in the game (2 extra ingots fill in the empty spaces at the top of the Cauldron recipe).
-Fixed a few problems with pistons interacting with the empty space directly in front of a Detector Block.
-Changed moving Platforms and Anchors to break when pushed by pistons to correct a number of problems that this behavior caused.
-Fixed problem with Water Wheels and Wind Mills occasionally duplicating when the axle they were attached to was pushed by a piston.
-Fixed problem with Axles remaining powered after being pushed by pistons, when they shouldn't be powered in their new location.
-Fixed problems with Hibachis being pushed by pistons and not updating their state properly.
-Fixed problem with Light Block not updating properly when pushed by piston.  Note that this involved introducing a small delay (1/10th of a second) between when a Light Block is powered and when it actually lights up, so it may affect existing circuits in a *very* minor way.
-Made changes to Mojang's wolf-code so you can still order them to follow you even if they glitch out and don't recognize you as their owner.  HOWEVER they will likely still not attack your targets and such, as fixing that would require modification of another base-class.  Note: These bugs are entirely Mojang's, I'm just trying to help people out by fixing them up a bit.
-Fixed problem with sand and gravel not always falling properly through the empty space in front of a detector block.
-Changed the way moving Platforms handle collisions to prevent the player occasionally going through them when they stop.
-Changed the way Cauldron renders to fix some slight visual glitches.
-Fixed entity duplication bug with the Block Dispenser.
-Changed Block Dispenser to be able to place and swallow leaf blocks.
-Changed moving Platforms and Anchors to destroy Water Wheels and Wind Mills that they pass through.
-Fixed problem with Block Dispenser swallowing the extended arms of pistons.
-Fixed problem with Block Dispenser not placing pistons properly.

Version 2.64

-Updated the mod to version 1.7.2 of Minecraft.
-Fixed slight rendering glitch with the Cauldron that would appear around the top edges.
-Changed Block Dispenser recipe to tone down the amount of mossy cobble used, and to use smooth stone at the base.
-Changed Hibachi recipe to use smooth stone at the base instead of cobble.
-Changed the Detector Block recipe to use smooth stone at the base instead of cobble.
-Changed the Mill Stone recipe to use smooth stone at the base instead of cobble.
-Changed the way the Mill Stone and sideways-facing Saws eject items so that they do not wind up on top of the device in question.

Version 2.63

-Fixed Block Dispenser destroying block if its inventory is full.
-Changed Block Dispenser recipe to include more mossy cobble to compensate for no longer requireing regular dispenser.
-Changed Saw Placement to be based on player orientation rather than on the block face the saw is placed on (just like Gear Boxes).
-Changed the way the Saw drops items it generates when sawing blocks to prevent them getting stuck in neighbouring blocks.
-Similar to the changes to the Saw, changed the way the Mill Stone drops processed items so they don't get lodged in neighbouring blocks.
-Change the Saw to drop a belt when it is destroyed through misuse.
-Fixed problem with "fcFaceGearBoxAwayFromPlayer" config file setting not working properly.
-Added ability for the Saw to process Corners into Gears.
-Added the ability for the Saw to process Companion Cubes.
-Added ability for Mill Stone to grind sugar-cane into sugar.
-Created custom icon for flour to help differentiate it from sugar.
-Created custom renderer for the Hand Crank when it is in item form to help differentiate it from a lever.
-Added text messages when there's not enough room around a Wind Mill or Water Wheel to place them.
-Changed Platforms and Anchors so that player and mobs won't "pop" on top of them from below.
-Changed Platforms and Anchors so that they deal damage to players and mobs if they descend on them.
-Fixed problems associated with having 2 Anchors connected to Platforms within 2 blocks of each other resulting in Platforms being lifted incorrectly by connected Pullies.
-Added the ability for the Cauldron to "swallow" items dropped on top of it, just like a Hopper.
-Changed Nethercoal recipe to only produce 1 piece of coal instead of 2 for balance purposes.

Version 2.62

-Fixed shimmering rendering problem on Platform when viewed from a distance.
-Fixed problem with moving Anchor occasionally breaking the rope it's attached to for no discernable reason.
-Fixed gaps in Rope that would occasionally form above an Anchor when the connected Pulley was rapidly powered on and off.
-Powered cake.

Version 2.61

-Changed the crafting recipes for Platforms to use Wicker for the top and bottom surfaces.
-Adjusted the rendering of Platforms to fit the change to the Wicker recipe.
-Added custom inventory renderer for the Platform.
-Changed Mill Stone texture to make it more obvious that it needs to be powered from the top or bottom.
-Fixed Block Detector not being able to see moving Anchors and Platforms.
-Added config file setting to change the way Gear Boxes place so that the output faces away from you.
-Changed the Detector Block recipe to use one lapis block instead of two.
-Added *small* chance that Hemp Seeds will drop when you destroy tall grass.
-Changed the way items pass over filtered Hoppers.  They no longer need to descend a level to continue.
-Changed the way mechanical devices update there state to try to avoid problems with them falling out of sync.  This affect the Gear Box, the Hopper, and the Pulley.
-Fixed items popping on top of Platforms when they are lowered onto them.
-Food is now turned into "Foul Food" when you put Dung into a Heated cauldron with it.

Version 2.60

-Added the Platform.
-Added the Pulley.
-Fixed crash bug when you right clicked on a Wind Mill with nothing in your hand.
-Changed Nethercoal recipe to be shapeless.
-Fixed Block Dispenser to not be able to swallow the purple nether-portal blocks.
-Eliminated the need for a seperate Anchor item.  Similar to what I did for the Axle in version 2.10, please place any Anchor items you may have in your inventory into the world, and then re-harvest them to convert them to the proper block type.  If you have an anchor that still looks like a 2D bitmap in your inventory, then this needs to be done as I will recycle the item ID in a future release.
-Changed Block Dispenser Recipe to no longer require a regular dispenser at its centre.

Version 2.59

-Adjusted output of Mill Stone when grinding wool to match changes that Mojang recently made to the string to wool recipe.
-Added growling sound to wolves when they produce dung to help distinguish the event from background mechanical noise.
-Tweaked Gear Box placement code to always orient opposite the face of the block you place it on.  This should make Gear Box placement much more consistent and intuitive.
-Got rid of a couple of custom textures for the mod that were duplicates of ones already found in the game to save on Texture IDs. This affects the bottom of the cauldron and the bottom of the Hibachi.
-Created new custom icon for Rope.
-Added collision to drying cement so that you can walk over it instead of just passing right through it.
-Changed Cement to whimper when poured, and to scream when powered by redstone (just like the old Booster Blocks used to).
-Totally removed placement restrictions on the hatch.  It can now be placed anywhere, with or without a supporting side-block (before it just wouldn't be removed if the side-block was).
-Fixed Block Dispenser processing of snow blocks.
-Changed Block Dispenser to be able to swallow uneaten cake.  However, cake that has slices already eaten from it will still be destroyed if the Block Dispenser attempts to swallow it.
-Changed Block Dispenser to be able to dispense the Hatch.
-Changed Block Dispenser to be able to pick-up clay blocks.
-Fixed the Block Dispenser being able to swallow mob spawners.  Sorry guys, this felt way too much like a cheat to me.
-Changed Block Dispenser to fire its inventory contents in order instead of randomly.  This basically allows you to create sequences of blocks that you wish to place and could even be used to create multi-frame animations using multiple Block Dispensers and colored wool.  There's now an icon in the Dispenser's inventory to indicate which slot will be dispensed next, and manually changing the inventory of the dispenser will reset this indicator to the first inventory slot.

Version 2.58

-Quick bug-fix for problems with converting gravel into sand and flint with the Hopper filter.


Version 2.575

-Changed Wolves so they will not produce Dung or Wolf Chops, or consume loose food, if you are playing multiplayer.
-Added the ability for Wicker to separate gravel into flint and sand when used as a filter on the Hopper.
-Added config file setting to disable the axe modifications, for compatibility with other mods.
-Added the tanning process and Tanned Leather.
-Added the Strap.
-Added the Belt.
-Changed crafting recipe for the Saw to use a Belt.
-Added custom icon for Scoured Leather.
-Fixed problem with wolves cannibalising their own flesh as they die.
-Added wolves turning rabid if you try to feed them Wolf Chops.
-Changed pet Wolves to ditch their collar and display the angry texture if you piss them off.
-Added ability to use clay as "filler" in the Hopper.  The Hopper won't eject clay, so you can fill inventory slots with it to change the Hopper's effective capacity and how long it takes to fill up.
-Removed the placement restrictions on the Anchor, as, like with the hatch, they were serving no useful purpose in a game where blocks of stone can hang suspended in mid-air anyways.

Version 2.55

-Modified the hatch in vanilla Minecraft so that it is no longer destroyed when the block next to it is.  This allows the placement of hatches in the middle of floors, and makes them more versatile overall without affecting their functionality in any other way.
-Added particles to the blade of the Saw to indicate when it is getting mechanically powered.
-Changed Dung production to take into account light levels.  Wolves now output more Dung in very low light conditions (light level of 5 and below).
-Adjusted the overall rate of dung production.  An unfed wolf should now produce Dung on average once every 4 in-game days.  A fed wolf, once a day.  A fed wolf in the dark, twice a day.
-Made the recipe for making two panels into one wood or stone block, shapeless.  This means the panels no longer need to be placed side by side in the crafting grid, but that if you have two panels in any two seperate squares of the grid, they can form a block.
-Added shapeless conversion recipes to convert 2 pieces of Moulding into 1 wood Panel, and 2 corners into 1 piece of Moulding.
-Added ability to color wool and Wind Mills brown using Dung through the usual methods for dye. You can't do it to sheep however, as they tend to react rather badly when you try to rub Dung all over them.
-Changed Hopper to only deposit items into the first slot of a furnace.  This allows for the smelting of stacks greater than 64 items, or the consecutive smelting of different kinds of items in the same furnace.
-Added the Grate as an item.
-Added Wicker as an item.
-Added an extra inventory slot to the Hopper in which you may place various items that act as a filter on what items the hopper will "swallow".  You can use a ladder, a hatch, a Grate, or Wicker as a filter.

Version 2.50

-Added Dung.
-Fixed problem with Fishing Rod displaying as a gear when the line is cast.
-Tweaked Rope item icon to make it more visible.
-Changed wolf to be able to consume nearby food laying on the ground.
-Fixed problem with Detector Block occasionally not detecting precipitation quickly enough to prevent damage to Gear Boxes attached to Wind Mills. 


Version 2.40

-Added the Wind Mill.  For real this time :)
-Added Fabric made of Hemp Fibers.
-Changed the name of the Wind Mill Blade to the 'Sail'.
-Changed the crafting recipe for the Sail to use Fabric instead of Wool.
-Added the ability to individually color each blade of the Wind Mill with dye.
-Changed Detector Block to properly sense snow falling if it is facing upwards.
-Changed Wind Mill to spin out of control in snow storms.

Version 2.31

-Updated the mod to version 1.6.6 of Minecraft.
-Modified properties of all wood-based blocks in the mod so that the axe would be an effective tool on them.
-Also modified the same for all wood based-blocks in the vanilla game so that axes generally behave as you would expect (this affects the note block, wood stairs, work bench, sign, wood door, added wind mills, juke box, fence, pumpkin, Jack'O'Lantern, and the trap door) instead of not working in weird instances as was typical of the game before this change. 

Version 2.30

-Reduced drag on carts without riders.  This effectively increases the distance such a cart can travel without losing speed from 6 blocks between powered rails, to 12 blocks.
-Increased the hardness of Panels.
-Added the ability for the saw to cut Panels into Moulding, and Moulding into Corners.
-Fixed Saw to not be able to be powered from the direction in which its blade is facing.
-Added the ability for the Saw to process Sugar Cane, Wheat, and Hemp.

Version 2.25

-Updated the mod to version 1.6.5 of Minecraft.
-Isolated the code for the Block Dispenser from the regular Dispenser.  This was largely an internal change to aid in updating and to allow for future changes, with the only noticable effect being that the Block Dispenser Gui now correctly displays "Block Dispenser" instead of the old "Dispenser".
-Added shift-click functionality for transferring to and from inventory of the Block Dispenser.
-Added crafting recipe to convert 2 Omni-Slabs back into a block (either smooth stone or wood) by placing them side by side in the crafting area.
-Removed the ability to grind wood into wood Omni-Slabs in the Mill Stone, since you can now create them with the Saw, and it's really not the intent of the Mill to be used for solid blocks like this.  You can still create the smoothstone Omni-Slabs in this manner however (at least for now).
-Fixed problem with mobs and players taking damage from sides of the Saw other than where the blade was located.  Note that this will likely require adjustments to any mob-grinders that involve the Saw.
-Optimized the Water Wheel to only perform updates of certain costly aspects of its state far less frequently.  Theoretically, this should allow for placement of about 20 times as many water wheels without any drop in preformance. It wasn't a problem before, but now it's REALLY not a problem ;)
-Renamed Omni-Slab to the "Panel", because "Omni-Slab" just sounded idiotic, and I was beginning to feel more and more like a tard every time I said it :)
-Changed Block Dispenser so that it could swallow Glow Stone blocks intact.
-Changed Detector Block so that it could instantly react to trees growing in front of it.
-Added Better Than Wolves themed character-skin to the download for those of you who want to show your support for the mod in-game or in SMP :)

Version 2.20

-Added the Saw.
-Modified the Mill Stone to ALWAYS eject ALL processed items to the sides of the mill.  This opens the door to automated milling.
-Fixed problem with Block Dispenser generating pink particles when operating in fron of a Detector Block.
-Fixed Block Dispenser being able to pick-up fire, although I have to admit, it was kinda cool :)
-Changed name of Lens to "NOT A BLOCK" so that people that hack their inventories hopefully stop bothering me about it.  Disabled the crafting recipe as well, although I don't think anyone had discovered it (I had forgotten it was in there), and changed the texture to horrid day-glow pink to further hammer the point home :)
-Changed Item Render for Omni-Slab to make it easier to distringuish from a regular slab.


Version 2.10

-Added the Hopper.
-Changed Detector Block to trigger if it is facing upwards and rain or snow falls on it.  I couldn't test with snow however (rain works fine), so if someone happens to run into a snow-storm and could let me know if it works, I'd be much obliged :)
-Reviewed all the blocks in the mod and made sure they had appropriate hit-effect textures.
-Added functionality to Gear Box where if it is receiving redstone power, it disengages the gears and will not output any power, regardless of the input state.  This effectively allows you to turn mechanical power on and off through redstone control.
-The Hand Crank now breaks if you try to power more than one device with it simultaneously.
-The Axle now breaks into component parts if it is powered in an inappropriate way (for example, a total axle length of over 3 blocks).
-The Mill Stone and Cauldron now eject their contents when they are destroyed (like chests or the Block Dispenser).
-Created custom renderer for Axle block in ineventory.
-Eliminated the need for the Axle Item (the one that looks like a stick).  Please place any items of this type you have in the world, and then remove the block again to reset them to the appropriate state.  The ItemID will be recycled in future versions of the mod.
-Changed the Water Wheel to not be stackable.  I think it's a large enough object to warrant this :)

Version 2.01

WARNING: Version 2.01 of this mod requires a reinstall of the mod onto a clean copy of Minecraft!  Many base-class modifications have been eliminated, so installing over an old copy will likely result in a crash.  ALSO: The old Minecart Pressure Plates and Soul Boosters have been completely eliminated from this version.  MAKE SURE YOU ELIMINATE ALL INSTANCES OF THESE ITEMS FROM YOUR SAVE GAME BEFORE INSTALLING THIS VERSION.

-Added Axle
-Added Gear Box
-Added Water Wheel
-Changed gear recipe to use fewer sticks.
-Added icon for hemp. Thanks to Battosay for the texture (modified)!
-Completely eliminated the old Minecart Booster and Minecart Pressure Plates from the mod.
-Eliminated base-class modifications to: EntityFallingSand.class, EntityMinecart.class, ItemBlock.class, and ItemReed.class.

Version 1.87

-Added ability for player to retract rope from an anchor, by right clicking on it with anything other than a rope in his hand (Thanks to Thalmane for suggesting this!)
-Added ability for Mill Stone to convert wool blocks into string.
-Added ability for Mill Stone to "process" Companion Cubes.
-Added custom Donut icon (thanks to Craftineer for the texture!)
-Companion cubes now show their appreciation for being put out of their misery.
-Boosted resistance of Anchor to make it more obvious that it needs to be destroyed with a Pick.

Version 1.86

-Fixed problem with the Item IDs for Hemp Fibers and Scoured Leather becoming confused.
-Fixed issue with the way food stacks in the Cauldron.


Version 1.85

-Added the Omni-Slab in wood and stone varieties.
-Upgraded the mod to the latest versions of MCP and Modloader to hopefully solve some compatibility issues.
-Modified title screen to display mod-specific instructions and dispense general wisdom.

Version 1.80

-Added the Anchor.
-Added the Rope.
-Changed Gear recipe to produce 2 Gears instead of just 1.
-Fixed problem with the Block Dispenser destroying specific kinds of items in its inventory if the block in front of it already contained something.
-Added collision to the base of the Hand Crank, so that you can now step up onto it, and don't just walk right through it.

Version 1.70

-Added the Hand Crank as a new block type.
-Added the Mill Stone as a new block type.
-Added Gears as an item.
-Added Flour as an Item.
-Added Hemp Fibers as an item.
-Added Scoured Leather as an item.
-Added smelting recipe to bake Bread from Flour in the furnace.
-Added Donuts (cook flour in the cauldron).
-Modified cauldron to spit out cooked items should its inventory be incapable of containing them.
-Changed Block Dispenser so it no longer spits out an item if there is a non-opaque object in front of it.

Version 1.61

-Tweaked the way hemp grows.  It should be *slightly* faster to grow now, especially in dense fields.
-Hemp now only grows under direct sunlight OR if there is a powerful light source up to two blocks above it.  Light-blocks to the side of the plant will no longer work.
-Made Companion Cubes and Hemp Crops flammable.  This means lightning can now send a whole field of hemp up in flames.  You can also set it ablaze when the authorities arrive.
-Rate of hemp seed drop when using hoe on grass is now based on the hoe's material (stone drops more than wood, etc.)  Consistent with other tools in the game, gold is the most effecient (but least durable), with diamond probably being the best mix between effeciency and durability.
-Added custom texture for hemp seeds to make them easier to differentiate from wheat.
-Changed Hibachi code to fix potential performance issues, and to stop it going out in the rain.
-Boosted the hardness of the Hibachi and Cauldron to be more consistent with other block types.
-Added ability for Block Dispenser to "process" chickens.

Version 1.60

-Added Hemp.
-Made changes to Block Dispenser which should allow it to plant seeds from other mods.

Version 1.52

-Fixed crash bug when Block Dispenser picked up redstone dust, which probably affected other block-types as well.

Version 1.51

-Fixed problem with block dispenser not properly handling coloured wool.  This should also resolve potential problems with different sapling types and other similar blocks that may be included in the game in the future, or which are features in other mods.
-Fixed problem with multiple Block Dispensers being able to swallow entities (minecarts, wolves, etc.) at the same time.
-Changed Block Dispenser to not dispense *anything* (objects and entities included), if the block in front of it is blocked.  This may help in the construction of more complex mechanisms and is more consistent with overall behaviour.
-Fixed problem with light-blocks not powering each other indirectly.
-Fixed detector block interacting in weird ways with various other block types (redstone wire, crops, trees, etc.)
-Added sound effect to Detector Block when triggered.
-Added sound effect to Block Dispenser when it is dispensing/swallowing entities (like minecarts and boats).
-Added config file setting for using Minecraft default textures for light blocks.  This is for people using custom texture packs that feel the mod's custom textures clash with other in-game elements.


Version 1.50

-Added the Detector Block
-Disabled Minecart Pressure Plate functionality.  This is likely the last version they'll be in the game in any way shape or form, and I will soon recycle their block ids (along with the booster block).  If you haven't removed them from your worlds yet: DO IT SOON!!!!
-Changed threshold value on angle when placing Companion Cube and Block Dispenser so that they aren't accidentally placed facing up or down as frequently.  You'll have to be looking up or down at a steeper angle now to place them in the corresponding directions.
-Removed maximum value of 255 on block and item IDs in the config file for increased compatibility with Minecraft Extended mod.

Version 1.40

-Added new detector rail-types: wood and obsidian, and modified the way the normal (stone) detector rails works.  Wood triggers on any minecart.  Stone triggers on any minecart containing something (chest, furnace, or mob).  Obsidian only triggers if a minecart contains a player.
-Changed Iron Pressure Plates to Obsidian Pressure Plates.  For greater visibility contrast relative to stone pressure plates, because it makes sense that it takes more weight to move obsidian than stone (not so much with iron), to give an in-game use for obsidian, and because it's impossible to see the difference between a stone and iron detector rail (given how small the pressure plate is on the rail).
-Disabled crafting recipes for minecart pressure plates (since they are replaced by the detector rails), and when a minecart pressure plate already in the game is destroyed, it now drops its constituent resources so that players may recover them.  Note that these blocks will be completely removed from the mod in a future version so it is in your best interest to recover these resources now before they dissapear (same with the old minecart boosters).
-Completely disabled minecart booster functionality in ongoing process of phasing them out.  If you haven't cleared them out of your saves yet, and recovered the resources, now is the time to do it before they are completely gone.
-Fixed problem with nethercoal recipe that didn't allow it to be crafted in any slot.
-Reorganized the way the mod assigns block and item ids, to hopefully resolve an incompatibility problem with other mods.
-Added ability for the Dispenser Block to swallow minecarts, boats...and wolves.
-Added the Companion Cube.


Version 1.31

-Created seperate texture directory for the mod to make tracking down the graphics files associated with it easier.
-Retextured the Hibachi, and replaced the iron in the crafting recipe with cobble.  I think this fits the idea of the Hibachi being an "open-top furnace" and makes sense since stone would melt at higher temperatures than iron.  It also reduces the mod's overdependance on iron.  
-Retextured Cauldron.  Meat your new friend.
-Retextured Light Block.
-Retextured the Block Dispenser.  Also toned down the amount of mossy cobble used in its crafting recipe.
-Retextured cement.


Version 1.30

-Added a new block type: Cauldrons.
-Added Wolfchops (raw and cooked).  Finally!  A use for wolves!
-Added Nethercoal item.


Version 1.25

-Updated mod to be compatible with version 1.5_01 of Minecraft.
-Removed the recipe for the minecart booster as its functionality is replaced by the booster-rail.
-When minecart boosters already in a save file are destroyed, they now return the ingrediants originally used in crafting them.  This can be used by players to salvage any resources they may have already invested in the boosters.
-Changed code to properly register the blocks in the mod through modloader.
-Changed the crafting recipe for cement to use soulsand instead of goo since it is no longer used by the booster, can be more reliably found in-game (some folks seem to never be able to find slimes), and since it makes sense in terms of the logic behind the recipe.  Of course, Steve is now solidfying souls into concrete, with all the moral ramifications that entails...
-Removed mods dependency on modifying TileEntityDispenser base class.
-Removed mods dependency on modifying BlockFire base class.
-Fixed problems where block dispenser would occasionally pick-up flint when removing a gravel block, and cobble when picking up smoothstone.
-Changed block dispenser to be able to place blocks in squares containing entities (like wolves), and to not eject a block in item-form if the block in front of it is already occupied.
-Changed block dispenser to pick-up tnt instead of triggering it to make beahaviour more consistent with other block types, to make construction of semi and full auto cannons more interesting (while convenient the way they were, it really feels like they should have separate loading, priming, and firing mechanisms), and to provide the player with a method of desposing of placed TnT. 
-Changed block dispenser to be able to plant seeds.
-Added a slight turn-on and turn-off delay to Hibachi. Fixes a number of subtle problems with how they behave and makes their function a little more believable and consistent with the rest of the redstone elements in the game.
-Partially implemented cauldron.  This feature is not complete, but I wanted to release a version compatible with 1.5_01 as quickly as possible, so I disabled the crafting recipe and left it in as is.  If you edit it into the game (you can't build it legitimately), it will be an entirely nonfunctional and utterly boring block :)

Version 1.24

-Totally isolated cement code from BlockFLuid and BlockFlowing, eliminating this mod's need to change those base class files.
-Put in fixed distance limit on how far cement could spread.  This increases the distance it can flow on level ground, to aid in it's use in construction, while limiting its down-hill spread restricting its use for griefing and its potentail for disaster.
-Changed the way cement spreads.  Unlike other in-game fluids, it doesn't only flow towards downward slopes, but instead spreads in a circular pattern around the point at which it is put down.
-Changed various aspects about the way cement displays to make it more aesthetically pleasing.
-Added dry time to cement which causes it to slowly dry instead of just instantly turning solid after being placed.
-Added partially dry state to cement which changes the visual when it's about to solidify, and also blends its height closer to that of a full block to smooth the transition.


Version 1.23

-Fixed some problems with how cement spreads, toning down its tendancy to form "the tidal wave of doom"
-Removed custom cement texture and removed mod's dependecy on a modified terrain.png
-Fixed cement bucket recipe so that it can be built in any crafting slot

Version 1.22

-Modified Block Dispensers to be able to place/collect smooth stone without converting it to cobble.
-Toned down the amount of iron used in some of the crafting recipes, as it was extremely heavy.  This affects the recipes for the Hibachi, Minecart Boosters, and Minecart Plates.
-Fixed problem with minecart pressure plate running current to far too many neighboring blocks.  It now needs to have wire running directly to it to supply current.
-Fixed problem with Hibachi burning while submerged in liquid (water, lava & cement) through constantly reigniting.  The Hibachi will no longer burn under these conditions.

Version 1.21

-Added ability for player to orient Block Dispensers upwards and downwards
-Changed Block Dispensers to only accept direct redstone current to the dispenser block, or the block directly above it. 
-Changed Hibachi to accept Redstone current From Block Above


Version 1.20

-Added Block Dispensers.


Version 1.01

-Added ModLoader support.
-Added iron pressure plates.
-Added wood and iron versions of the minecart pressure plater (stone pressure plates from previous versions automatically convert to wood to preserve their functionality).

Version 1.0

-Initial Release