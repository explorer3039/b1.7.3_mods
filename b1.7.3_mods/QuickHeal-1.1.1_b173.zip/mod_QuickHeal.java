package net.minecraft.src;

import java.util.logging.Logger;

import net.minecraft.client.Minecraft;

import org.lwjgl.input.Keyboard;

/**
* @author Melanchrom (melanchrom at web.de)
* Website: {@link http://}
* Source code: {@link http://}
*
*/

public class mod_QuickHeal extends BaseMod
{
	private static final Logger log = Logger.getLogger("mod_QuickHeal");
	private Minecraft mc;
	private KeyBinding HealKey;
	public static final int INVENTORY_SIZE = 36;
	public static final int POLLING_DELAY = 3;
    public static final int POLLING_TIMEOUT = 1500;
	private Integer[] Items;
	private Integer[] Heals;
	private boolean MultiPlayer;
	private int ClickCount;
	private boolean Moved = false;
	private boolean Correct = false;
	private int LastHealthLag = 20;
	private int Counter = 0;
	
    public mod_QuickHeal()
    {        
        // Register key
        mc = ModLoader.getMinecraftInstance();
        HealKey = new KeyBinding("Heal", Keyboard.KEY_C); /* KeyBinding */
        ModLoader.RegisterKey(this, HealKey, false);
        Items = new Integer[0];
        Heals = new Integer[0];
        MultiPlayer = mc.isMultiplayerWorld();
        
        ModLoader.SetInGameHook(this, true, true);
        
        for(int i = 0; i<32000; i++)
        {
        	Boolean Fail = false;
        	int j = 0;
        	try
        	{
        		j = ((ItemFood)Item.itemsList[i]).getHealAmount();
        	}
        	catch(Throwable t)
        	{
        		Fail = true;
        	}
        	if(!Fail)
        	{
        		Integer[] Store = new Integer[Items.length + 1];
        		int k = 0;
        		for(k = 0; k < Items.length; k++)
        		{
        			Store[k] = Items[k];
        		}
        		Store[k] = i;
        		Items = Store;
        		Store = new Integer[Heals.length + 1];
        		for(k = 0; k < Heals.length; k++)
        		{
        			Store[k] = Heals[k];
        		}
        		Store[k] = j;
        		Heals = Store;
        		log.info("ID gefunden: " + i + " und " + k);
        	}
        }
        for(int i = 0; i < Items.length; i++)
        {
        	log.info("Platz: " + i + " ID: " + Items[i] + " Heals: " + Heals[i]);
        }
    }
	
	@Override
	public String Version()
	{
		return "1.1.1 (1.7.3)";
	}
	
	public final void KeyboardEvent(KeyBinding keyBinding)
	{
        MultiPlayer = mc.isMultiplayerWorld();
		if( keyBinding == HealKey)
		{
			Heal();
		}
	}
	
	public boolean OnTickInGame(Minecraft minecraft)
	{
		if(Correct)
			Counter++;
		if((mc.thePlayer.inventory.getItemStack() != null) && Correct && Counter > 10)
		{
			ClickLeft(0);
			Correct = false;
		}
		if(Moved && LastHealthLag != (20 - mc.thePlayer.health))
		{
			ClickLeft(0, true);
			Moved = false;
			Correct = true;
		}
		return true;
	}
	
	private void Heal()
	{
		int healthLag = 20 - mc.thePlayer.health;
		LastHealthLag = healthLag;
		int i = 0;
		Integer[] Slots = new Integer[0];
		Integer[] SlotsHeal = new Integer[0];
		
		Slots = GetFoodSlots();
		SlotsHeal = GetHeals(Slots);
		
		log.info("Health: " + mc.thePlayer.health + " Missing: " + healthLag);
		
		for(i = 0; i < Slots.length; i++)
		{
			log.info("Slot " + Slots[i] + " Heals:" + SlotsHeal[i]);
		}
		if(Slots.length > 0 && healthLag > 0)
		{
			i = 0;
			while(i < Slots.length)
			{
				if(SlotsHeal[i] <= healthLag || healthLag > 15)
					break;
				i++;
			}
			if(i < Slots.length)
			{
				if(MultiPlayer)
				{
					int currentItem = mc.thePlayer.inventory.currentItem;
					mc.thePlayer.inventory.currentItem = 0;
					ClickCount = 0;
					
					ClickLeft(Slots[i]);
					ClickLeft(0);
					if(mc.thePlayer.inventory.getItemStack() != null)
					{
						ClickLeft(Slots[i]);
						Moved = true;
					}
					UseCurrentItem();
					if(Moved)
					{
						ClickLeft(Slots[i]);
						ClickLeft(0);
					}
					mc.thePlayer.inventory.currentItem = currentItem;
				}
				else
				{
					mc.thePlayer.inventory.getStackInSlot(Slots[i]).useItemRightClick(mc.theWorld, mc.thePlayer);
					log.info("Stacksize: " + mc.thePlayer.inventory.getStackInSlot(Slots[i]).stackSize);
					if(mc.thePlayer.inventory.getStackInSlot(Slots[i]).stackSize < 1)
					{
						mc.thePlayer.inventory.decrStackSize(Slots[i], 1);
					}
					Heal();
				}
			}
		}
	}
	
	private Integer[] GetFoodSlots()
	{
		Integer[] Slots = new Integer[0];
		int i = 0;
		int j = 0;
		int k = 0;
		
		for( i = 0; i<INVENTORY_SIZE; i++)
		{
			for(j = 0; j < Items.length; j++)
			{
				if(mc.thePlayer.inventory.getStackInSlot(i) != null)
				{
					if(Items[j] == mc.thePlayer.inventory.getStackInSlot(i).itemID)
					{
		        		Integer[] Store = new Integer[Slots.length + 1];
		        		for(k = 0; k < Slots.length; k++)
		        		{
		        			Store[k] = Slots[k];
		        		}
		        		Store[k] = i;
		        		Slots = Store;
		        		break;
					}
				}
			}
		}
		return Slots;
	}
	
	private Integer[] GetHeals(Integer[] Slots)
	{
		Integer[] SlotsHeal = new Integer[Slots.length];
		
		for(int i = 0; i < SlotsHeal.length; i++)
		{
			for(int j = 0; j < Items.length; j++)
			{
				if(Items[j] == mc.thePlayer.inventory.getStackInSlot(Slots[i]).itemID)
				{
					SlotsHeal[i] = Heals[j];
					break;
				}
			}
		}
		
		return SlotsHeal;
	}
	
	private boolean ClickLeft(int Slot)
	{
		return ClickLeft(Slot, false);
	}
	
	private boolean ClickLeft(int Slot, boolean IgnoreUseless)
	{
		ItemStack Current = (mc.thePlayer.inventory.getItemStack() != null) ? mc.thePlayer.inventory.getItemStack().copy() : null;
		ItemStack InSlot = (mc.thePlayer.inventory.getStackInSlot(Slot) != null) ? mc.thePlayer.inventory.getStackInSlot(Slot).copy() : null;
		boolean Useless = false;
		int TimeOut;
		ClickCount++;
		
		log.info("Click Slot: " + Slot);
		
		if(Current == null && InSlot == null)
		{
			Useless = true;
		}
		else if(Current == null || InSlot == null)
		{
		}
		else if(Current.itemID == InSlot.itemID)
		{
			if(InSlot.stackSize >= InSlot.getMaxStackSize())
			{
				Useless = true;
			}
		}
		TimeOut = POLLING_TIMEOUT;
		
		if(!Useless || IgnoreUseless)
		{
			mc.playerController.func_27174_a(mc.thePlayer.inventorySlots.windowId, (Slot < 9) ? Slot  +36 : Slot, 0, false, (EntityPlayer)mc.thePlayer);
			int pollingTime = 0;
			
			while (((ItemStack.areItemStacksEqual(InSlot, mc.thePlayer.inventory.getStackInSlot(Slot)) && !IgnoreUseless)||(IgnoreUseless && mc.thePlayer.inventory.getItemStack() != null))  && pollingTime < TimeOut)
			{
				trySleep(POLLING_DELAY);
				pollingTime += POLLING_DELAY;
			}
			if (pollingTime >= TimeOut)
			{
				log.warning("Click timeout " + ClickCount);
			}
		}
		else
		{
			log.warning("Click useless " + ClickCount);
		}
		return true;
	}
	
	private void UseCurrentItem()
	{
		ItemStack Current = (mc.thePlayer.inventory.getCurrentItem() != null) ? mc.thePlayer.inventory.getCurrentItem().copy() : null;
		if(Current != null)
		{
			
			mc.playerController.sendUseItem((EntityPlayer)mc.thePlayer, mc.theWorld, mc.thePlayer.inventory.getCurrentItem());
			int pollingTime = 0;
			
			while (Current == mc.thePlayer.inventory.getCurrentItem() && pollingTime < POLLING_TIMEOUT)
			{
				trySleep(POLLING_DELAY);
				pollingTime += POLLING_DELAY;
			}
			if (pollingTime >= POLLING_TIMEOUT)
			{
				log.warning("Use timeout");
			}
		}	
		else
		{
			log.warning("Current Epty !?");
		}
	}

	public static void trySleep(int delay)
	{
		try
		{
			Thread.sleep(delay);
		}
		catch (InterruptedException e)
		{
			// Do nothing
		}
	}
}

