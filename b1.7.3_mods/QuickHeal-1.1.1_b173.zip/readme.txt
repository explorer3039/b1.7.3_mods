QuickHeal v1.1.1 Beta 1.7.3 ReadMe


Description
===========
This mod provides you with a key for instant healing. Upon Pressing the healing key, you will automatically eat all food you have until health is fully recovered in singleplayer. In multiplayer you will only one food item if it won't heal you too much.
This mod uses Modloader.

Install
=======
1) Instal Modloader.
2) Delete META-INF folder.
3) Put .zip file into the mods folder.
4) Run Minecraft and enjoy!

History
======
v1.1.1	- Fixed: Eating wrong item
	- Fixed: (hopefully) handheld item seeming to disappear
v1.1.0	- Added SMP Support
	- Stopped food wasting
	- Complete Healing for SSP (not yet possible for SMP)
v1.0.0	Initial Release

Legal/Copyright
===============
This mod (plugin, a patch to Minecraft source, henceforth "Mod" or "The Mod"), by the terms of http://www.minecraft.net/copyright.jsp is sole property of the Mod author (Melanchrom, henceforth "Owner" or "The Owner"). By default it may only be distributed on minecraftforums.net. It may only be mirrored or reposted with advance written permission of the Owner. Electronic Mail is fine if you wait for a response. URL shorteners or otherattempts to make money off The Owner's Mod are strictly forbidden without advance written permission.