Inventory Watch will conflict with any mod that modifies either ix.class or ob.class. It will conflict. That said, Inventory Watch is a modder's resource, so other mods are highly encouraged to try working with it instead.

RISUGAMI'S DEATH CHEST:
This does conflict, but with Risugami's permission I have a rewrite of it that uses Inventory Watch, it's called Death Chest Rewritten v1.2.

AETHER:
Auto Refill may sometimes use two buckets instead of one when trying to fill them with poison from an aechor plant. This is due to how the aechor plant is coded. To fix the problem, copy this into your minecraft.jar: EntityAechorPlant.class.
