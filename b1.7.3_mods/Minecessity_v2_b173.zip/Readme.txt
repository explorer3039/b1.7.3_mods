Minecessity v2

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
INSTALLATION INSTRUCTION

-Delete Meta-inf
-Install ModLoader
-Put all files into minecraft.jar
-Run the game
 +If first run doesn't work, try again
-Have fun

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
Copyright Will.ez