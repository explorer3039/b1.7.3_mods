*They're coded to generate in light level <= 8 and with at least 2 faces touching stone.
*Changed hardness from 4 to 0.4
*Craft 4 webs using 5 strings in an X shape
*Also changed the sound to the wool sound