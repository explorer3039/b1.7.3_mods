INSTALL INSTRUCTIONS FOR MINECRAFT VERSION 1.7.3:

0. Make sure minecraft is closed
1. Start with a fresh .minecraft folder, make sure to back up your saves
2. Open Minecraft.jar with Winrar
3. Delete the META-INF folder
4. Install ModLoader
5. Drag and drop the contents of the "Survival" folder into your minecraft.jar
6. Start up Minecraft normally

DISCALIMER:
I am not reponsible for any corrupted saves, or any damage this mod may inflict on your Minecraft or computer.