For windows : 
Go to your minecraft .jar (Go to run -> (type in) %appdata% -> .minecraft -> bin -> minecraft.jar)
Open that (and back up that and yours saves IF you want), extract the ModLoader files into there 
if you don't have them already, then extract the Gui Painting Selection files into there. 

I would suggest backing up your saves. You never know what could happen.