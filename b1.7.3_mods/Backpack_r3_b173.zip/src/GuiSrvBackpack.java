public class GuiSrvBackpack extends dw {
	private lw backpack;

	public GuiSrvBackpack(lw inventory, lw backpack) {
		this.backpack = backpack;
		int i = 2;

		int j = (i - 4) * 18;
		int m;
		for (int k = 0; k < i; k++) {
			for (m = 0; m < 9; m++) {
				a(new gp(backpack, m + k * 9, 8 + m * 18, 18 + k * 18));
			}
		}

		for (int k = 0; k < 3; k++) {
			for (m = 0; m < 9; m++) {
				a(new gp(inventory, m + k * 9 + 9, 8 + m * 18, 103 + k * 18 + j));
			}
		}
		for (int k = 0; k < 9; k++) a(new gp(inventory, k, 8 + k * 18, 161 + j));
	}

	public boolean b(gs player) {
		return backpack.a_(player);
	}
}