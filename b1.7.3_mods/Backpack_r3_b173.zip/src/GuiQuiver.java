import org.lwjgl.opengl.GL11;

public class GuiQuiver extends id {
	private lw inventory;
	private lw quiver;
	private int n = 0;

	public GuiQuiver(lw inventory, lw quiver) {
		super(new GuiSrvQuiver(inventory, quiver));
		this.inventory = inventory;
		this.quiver = quiver;
		f = false;

		int i = 222;
		int j = i - 108;
		n = 2;

		i = (j + n * 18);
	}

	protected void k() {
		g.b(quiver.c(), 8, 6, 4210752);
		g.b(inventory.c(), 8, 48, 4210752);
	}

	protected void a(float paramFloat) {
		int sprite = b.p.b("/Shockah/Backpack/guiQuiver.png");
		GL11.glColor4f(1F, 1F, 1F, 1F);
		b.p.b(sprite);

		int posX = (c-a)/2;
		int posY = (d-i)/2;
		b(posX,posY,0,0,a,i);
	}
}