public class ix implements lw {
	public iz a[];
	public iz b[];
	public int c;
	public gs d;
	private iz f;
	public boolean e;

	public ix(gs gs1) {
		a = new iz[36];
		b = new iz[4];
		c = 0;
		e = false;
		d = gs1;
	}

	public iz b() {
		if(c < 9 && c >= 0)
		return a[c];
		else
		return null;
	}

	private int f(int k) {
		for(int l = 0; l < a.length; l++)
		if(a[l] != null && a[l].c == k)
		return l;

		return -1;
	}

	private int d(iz iz1) {
		for(int k = 0; k < a.length; k++)
		if(a[k] != null && a[k].c == iz1.c && a[k].d() && a[k].a < a[k].c() && a[k].a < d() && (!a[k].f() || a[k].i() == iz1.i()))
		return k;

		return -1;
	}

	private int j() {
		for(int k = 0; k < a.length; k++)
		if(a[k] == null)
		return k;

		return -1;
	}

	public void a(int k, boolean flag) {
		int l = f(k);

		if(l >= 0 && l < 9) {
			c = l;
			return;
		} else {
			return;
		}
	}

	public void b(int k) {
		if(k > 0)
		k = 1;

		if(k < 0)
		k = -1;

		for(c -= k; c < 0; c += 9);

		for(; c >= 9; c -= 9);
	}

	private int e(iz iz1) {
		int k = iz1.c;
		int l = iz1.a;
		int i1 = d(iz1);

		if(i1 < 0)
		i1 = j();

		if(i1 < 0)
		return l;

		if(a[i1] == null)
		a[i1] = new iz(k, 0, iz1.i());

		int j1 = l;

		if(j1 > a[i1].c() - a[i1].a)
		j1 = a[i1].c() - a[i1].a;

		if(j1 > d() - a[i1].a)
		j1 = d() - a[i1].a;

		if(j1 == 0) {
			return l;
		} else {
			l -= j1;
			a[i1].a += j1;
			a[i1].b = 5;
			return l;
		}
	}

	public void e() {
		for(int k = 0; k < a.length; k++)
		if(a[k] != null)
		a[k].a(d.aI, ((sn) (d)), k, c == k);
	}

	public boolean c(int k) {
		int l = f(k);

		if(l < 0)
		return false;

		if(--a[l].a <= 0)
		a[l] = null;

		return true;
	}

	public boolean a(iz iz1) {
		if (mod_Backpack.addItem(iz1,true)) return true;
		if (addThisInv(iz1)) return true;
		if (mod_Backpack.addItem(iz1,false)) return true;
		return false;
	}
	
	public boolean addThisInv(iz iz1) {
		if(!iz1.g()) {
			int k;

			do {
				k = iz1.a;
				iz1.a = e(iz1);
			} while(iz1.a > 0 && iz1.a < k);

			return iz1.a < k;
		}

		int l = j();

		if(l >= 0) {
			a[l] = iz.b(iz1);
			a[l].b = 5;
			iz1.a = 0;
			return true;
		} else return false;
	}

	public iz a(int k, int l) {
		iz aiz[] = a;

		if(k >= a.length) {
			aiz = b;
			k -= a.length;
		}

		if(aiz[k] != null) {
			if(aiz[k].a <= l) {
				iz iz1 = aiz[k];
				aiz[k] = null;
				return iz1;
			}

			iz iz2 = aiz[k].a(l);

			if(aiz[k].a == 0)
			aiz[k] = null;

			return iz2;
		} else {
			return null;
		}
	}

	public void a(int k, iz iz1) {
		iz aiz[] = a;

		if(k >= aiz.length) {
			k -= aiz.length;
			aiz = b;
		}

		aiz[k] = iz1;
	}

	public float a(uu uu1) {
		float f1 = 1.0F;

		if(a[c] != null)
		f1 *= a[c].a(uu1);

		return f1;
	}

	public sp a(sp sp1) {
		for(int k = 0; k < a.length; k++)
		if(a[k] != null) {
			nu nu1 = new nu();
			nu1.a("Slot", (byte)k);
			a[k].a(nu1);
			sp1.a(((ij) (nu1)));
		}

		for(int l = 0; l < b.length; l++)
		if(b[l] != null) {
			nu nu2 = new nu();
			nu2.a("Slot", (byte)(l + 100));
			b[l].a(nu2);
			sp1.a(((ij) (nu2)));
		}

		return sp1;
	}

	public void b(sp sp1) {
		a = new iz[36];
		b = new iz[4];

		for(int k = 0; k < sp1.c(); k++) {
			nu nu1 = (nu)sp1.a(k);
			int l = nu1.c("Slot") & 0xff;
			iz iz1 = new iz(nu1);

			if(iz1.a() == null)
			continue;

			if(l >= 0 && l < a.length)
			a[l] = iz1;

			if(l >= 100 && l < b.length + 100)
			b[l - 100] = iz1;
		}
	}

	public int a() {
		return a.length + 4;
	}

	public iz f_(int k) {
		iz aiz[] = a;

		if(k >= aiz.length) {
			k -= aiz.length;
			aiz = b;
		}

		return aiz[k];
	}

	public String c() {
		return "Inventory";
	}

	public int d() {
		return 64;
	}

	public int a(sn sn) {
		iz iz1 = f_(c);

		if(iz1 != null)
		return iz1.a(sn);
		else
		return 1;
	}

	public boolean b(uu uu1) {
		if(uu1.bA.i())
		return true;

		iz iz1 = f_(c);

		if(iz1 != null)
		return iz1.b(uu1);
		else
		return false;
	}

	public iz d(int k) {
		return b[k];
	}

	public int f() {
		int k = 0;
		int l = 0;
		int i1 = 0;

		for(int j1 = 0; j1 < b.length; j1++)
		if(b[j1] != null && (b[j1].a() instanceof wa)) {
			int k1 = b[j1].j();
			int l1 = b[j1].h();
			int i2 = k1 - l1;
			l += i2;
			i1 += k1;
			int j2 = ((wa)b[j1].a()).bl;
			k += j2;
		}

		if(i1 == 0)
		return 0;
		else
		return ((k - 1) * l) / i1 + 1;
	}

	public void e(int k) {
		for(int l = 0; l < b.length; l++) {
			if(b[l] == null || !(b[l].a() instanceof wa))
			continue;

			b[l].a(k, ((sn) (d)));

			if(b[l].a == 0) {
				b[l].a(d);
				b[l] = null;
			}
		}
	}

	public void g() {
		for(int k = 0; k < a.length; k++)
		if(a[k] != null) {
			d.a(a[k], true);
			a[k] = null;
		}

		for(int l = 0; l < b.length; l++)
		if(b[l] != null) {
			d.a(b[l], true);
			b[l] = null;
		}
	}

	public void y_() {
		e = true;
	}

	public void b(iz iz1) {
		f = iz1;
		d.b(iz1);
	}

	public iz i() {
		return f;
	}

	public boolean a_(gs gs1) {
		if(d.be)
		return false;

		return gs1.g(((sn) (d))) <= 64D;
	}

	public boolean c(iz iz1) {
		for(int k = 0; k < b.length; k++)
		if(b[k] != null && b[k].c(iz1))
		return true;

		for(int l = 0; l < a.length; l++)
		if(a[l] != null && a[l].c(iz1))
		return true;

		return false;
	}
}
