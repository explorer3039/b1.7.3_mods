import net.minecraft.client.Minecraft;

public class InventoryBackpack extends InventoryExtraSlots {
	public InventoryBackpack() {
		super("Backpack",18);
	}
	
	public void load(nu nbtCompound) {
		sp list = nbtCompound.l("BackpackItems");
		for (int i = 0; i < list.c(); i++) {
			nu cmp1 = (nu)list.a(i);
			int slot = cmp1.c("Slot") & 0xFF;
			a(slot,new iz(cmp1));
		}
	}

	public void save(nu nbtCompound) {
		sp list = new sp();
		for (int i = 0; i < a(); i++) {
			if (f_(i) != null) {
				nu cmp1 = new nu();
				cmp1.a("Slot",(byte)i);
				f_(i).a(cmp1);
				list.a(cmp1);
			}
		}
		nbtCompound.a("BackpackItems",list);
	}
	
	public boolean isEquipped() {
		Minecraft game = ModLoader.getMinecraftInstance();
		
		iz armorChest = game.h.c.b[2];
		boolean isBackpack = (armorChest != null);
		if (isBackpack) isBackpack = armorChest.c == mod_Backpack.iBACKPACK.bf;
		
		return isBackpack;
	}
}