package net.minecraft.src;

import java.io.*;
import net.minecraft.client.Minecraft;

public class mod_FFTorch extends BaseMod {

    public static Block fft_a_nr;
    public static Block fft_i_nr;
    public static Block fft_a_yr;
    public static Block fft_i_yr;
	
	public static Achievement fftach, ehmine;
	
	public static int fft_texture1, fft_texture2, fft_texture3, fft_texture4;
	
    public String modname = "FFTorch";
	
    public static int blockID1 = 208;
    public static int blockID2 = 209;
    public static int blockID3 = 210;
    public static int blockID4 = 211;
	
    public static int achid1 = 1005;
    public static int achid2 = 1006;
	
    public static boolean acact = true;	
	public static boolean sswp = false;
	public static boolean svspr = false;
	
	public void loadConfig() {
		File dir = Minecraft.getAppDir("minecraft/mods/"+modname+"/");
		File file = new File(dir, "config.txt");
		File file2 = new File(dir, "ID_cfg.txt");
		
		System.out.println("Flip Flop Torches Mod - load config");
		
		try {
			if (!file.exists()) {
			
				System.out.println("- config.txt not found - try to find older Versions of config files...");
				
				if (file2.exists()) {	
					FileReader fstream = new FileReader(file2);
					BufferedReader in = new BufferedReader(fstream);
					in.readLine();
					blockID1 = Integer.valueOf(in.readLine());
					blockID2 = Integer.valueOf(in.readLine());
					blockID3 = Integer.valueOf(in.readLine());
					blockID4 = Integer.valueOf(in.readLine());
					in.readLine();
					achid1 = Integer.valueOf(in.readLine());
					achid2 = Integer.valueOf(in.readLine());
					in.readLine();
					acact = Boolean.valueOf(in.readLine());
					System.out.println("- ID_cfg.txt successfully readed.");
				} else
					System.out.println("- ID_cfg.txt not found. Load mod defaults!");
				
				FileWriter fstream = new FileWriter(file,true);
				BufferedWriter out = new BufferedWriter(fstream);
				out.write("< BLOCK ID'S >\n");
				out.write(Integer.toString(blockID1)+"\n");
				out.write(Integer.toString(blockID2)+"\n");
				out.write(Integer.toString(blockID3)+"\n");
				out.write(Integer.toString(blockID4)+"\n");
				out.write("< ACHIEVEMENT ID'S >\n");
				out.write(Integer.toString(achid1)+"\n");
				out.write(Integer.toString(achid2)+"\n");
				out.write("< ACHIEVEMENTS ACTIVE >\n");
				out.write(Boolean.toString(acact)+"\n");
				out.write("< TURN STATUS WHEN POWERED >\n");
				out.write(Boolean.toString(sswp)+"\n");
				out.write("< SAVE TERRAIN SPRITES >\n");
				out.write(Boolean.toString(svspr));
				out.close();
				System.out.println("- config.txt successfully created.");

			} else {

				FileReader fstream = new FileReader(file);
				BufferedReader in = new BufferedReader(fstream);
				
				in.readLine();
				blockID1 = Integer.valueOf(in.readLine());
				blockID2 = Integer.valueOf(in.readLine());
				blockID3 = Integer.valueOf(in.readLine());
				blockID4 = Integer.valueOf(in.readLine());
				in.readLine();
				achid1 = Integer.valueOf(in.readLine());
				achid2 = Integer.valueOf(in.readLine());
				in.readLine();
				acact = Boolean.valueOf(in.readLine());
				in.readLine();
				sswp = Boolean.valueOf(in.readLine());
				in.readLine();
				svspr = Boolean.valueOf(in.readLine());			
			
				System.out.println("- config.txt successfully readed.");
			}
			System.out.println("- Block IDs are now: " + Integer.toString(blockID1) + ", " + Integer.toString(blockID2) + ", " + Integer.toString(blockID3) + " and " + Integer.toString(blockID4));
			System.out.println("- Achievement IDs are now: " + Integer.toString(achid1) + " and " + Integer.toString(achid2));
			System.out.println("- Achievements are " + (acact ? "enabled" : "disabled"));
			System.out.println("- Switch status when powered: " + (sswp ? "yes" : "no"));
			System.out.println("- Save terrain sprites: " + (svspr ? "yes" : "no"));
			
		}
		catch (IOException e) {
			System.out.println(e);
		}
		
	}
	
    public mod_FFTorch()
	{
		loadConfig();
		
		fft_texture1 = ModLoader.addOverride("/terrain.png", "/FFTorch/fft_i_i.png");
		fft_texture2 = ( svspr ? fft_texture1 : ModLoader.addOverride("/terrain.png", "/FFTorch/fft_i_a.png"));
		fft_texture3 = ModLoader.addOverride("/terrain.png", "/FFTorch/fft_a_i.png");
		fft_texture4 = ( svspr ? fft_texture3 : ModLoader.addOverride("/terrain.png", "/FFTorch/fft_a_a.png"));

		fft_i_nr = (new BlockFFTorch(blockID1, fft_texture1, false, false)).setHardness(0.0F).setBlockName("flipflop").disableNeighborNotifyOnMetadataChange();
        fft_a_nr = (new BlockFFTorch(blockID2, fft_texture3, true, false)).setHardness(0.0F).setLightValue(0.5F).setBlockName("flipflop").disableNeighborNotifyOnMetadataChange();
		fft_i_yr = (new BlockFFTorch(blockID3, fft_texture2, false, true)).setHardness(0.0F).setBlockName("flipflop").disableNeighborNotifyOnMetadataChange();
		fft_a_yr = (new BlockFFTorch(blockID4, fft_texture4, true, true)).setHardness(0.0F).setLightValue(0.5F).setBlockName("flipflop").disableNeighborNotifyOnMetadataChange();
		
        ModLoader.RegisterBlock(fft_i_nr);
        ModLoader.RegisterBlock(fft_a_nr);
        ModLoader.RegisterBlock(fft_i_yr);
        ModLoader.RegisterBlock(fft_a_yr);
		
		if( acact ) {
			ehmine = (new Achievement(achid2, "ehmine", 8, 2, Item.pickaxeSteel, AchievementList.buildBetterPickaxe)).registerAchievement();
			fftach = (new Achievement(achid1, "fftach", 8, 4, fft_a_nr, ehmine)).registerAchievement();
		}
		
		ModLoader.AddName(fft_i_nr, "Flip Flop Torch");
		ModLoader.AddRecipe(new ItemStack(fft_i_nr, 1), new Object[]
		{
               "#",
               "I",
               "R",
               Character.valueOf('#'), new ItemStack(Item.dyePowder, 1, 4), // lapis lazuli
               Character.valueOf('I'), Item.stick, // stick
               Character.valueOf('R'), Item.redstone, // redstone dust
		});
		
		if( acact ) {
			ModLoader.AddAchievementDesc(ehmine, "Enhanced Mining", "Build an iron pickaxe.");
			ModLoader.AddAchievementDesc(fftach, "Flipping Out", "Build a flip flop torch with redstone, stick and lapis lazuli.");
		}
    }
	
	public void TakenFromCrafting(EntityPlayer entityplayer, ItemStack itemstack) {
		if( acact ) {
			if(itemstack.itemID == Item.pickaxeSteel.shiftedIndex) {
				entityplayer.addStat(ehmine, 1);
			}
			if(itemstack.itemID == fft_i_nr.blockID) {
				entityplayer.addStat(fftach, 1);
			}
		}
	}

	@Override
	public String Version() 
	{
		return "1.1";
	}
}