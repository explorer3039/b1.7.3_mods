1. Copy all .class files, the "Carbon Images" file, the "Steel Armor Images" file, and the "Steel Tool Images" file into minecraft.jar
2. Copy the "steel_1" and "steel_2" images into the armor folder
3. Start Minecraft, and ENJOY!

Warning: You must have ModLoader installed! This should not conflict with any mods but if it does, please contact me at: mctotg@gmail.com.