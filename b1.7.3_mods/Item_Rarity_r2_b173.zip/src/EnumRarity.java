import java.lang.reflect.Field;
import java.util.Properties;

public enum EnumRarity {
	Common(0,""),Uncommon(1,"\247a"),Rare(2,"\247b"),Epic(3,"\2475"),Artifact(4,"\247e"),Legendary(5,"\247c");
	
	public final String colorCode;
	public final int level;
	
	EnumRarity(int level, String colorCode) {
		this.level = level;
		this.colorCode = colorCode;
	}
	
	public String toString() {
		return colorCode;
	}
	
	public static EnumRarity getRarity(String str) {
		for (EnumRarity e : values()) {
			if (e.colorCode.isEmpty()) continue;
			if (str.startsWith(e.colorCode)) return e;
		}
		return Common;
	}
	
	private static Properties props = null;
	
	public static void setRarity(EnumRarity rarity, Object... instances) {
		for (Object obj : instances) setRarity(rarity,obj);
	}
	private static void setRarity(EnumRarity rarity, Object instance) {
		String tag = null;
		if ((instance instanceof gm)) {
			gm item = (gm)instance;
			if (item.a() != null) tag = item.a() + ".name";
		} else if ((instance instanceof uu)) {
			uu block = (uu)instance;
			if (block.o() != null) tag = block.o() + ".name";
		} else if ((instance instanceof iz)) {
			iz stack = (iz)instance;
			if (stack.l() != null) tag = stack.l() + ".name";
		}
		if (tag != null) {
			if (props == null) getProps();
			
			String tooltip = props.getProperty(tag);
			if (tooltip != null) {
				EnumRarity tmp = getRarity(tooltip);
				if (tmp != Common) tooltip = tooltip.substring(tmp.colorCode.length());
				tooltip = rarity+tooltip;
				props.put(tag,tooltip);
			}
		}
	}
	
	private static void getProps() {
		if (props != null) return;
		try {
			Field field = nh.class.getDeclaredFields()[1];
			field.setAccessible(true);
			props = (Properties)field.get(nh.a());
		} catch (Exception e) {e.printStackTrace();}
	}
}