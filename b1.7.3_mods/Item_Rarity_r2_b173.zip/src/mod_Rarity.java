public class mod_Rarity extends BaseMod {
	public String Version() {return "r2";}
	
	public mod_Rarity() {
		EnumRarity.setRarity(EnumRarity.Uncommon,uu.H,uu.P,uu.ai,uu.bb,uu.bc,uu.bd,uu.bg,gm.h,gm.i,gm.n,gm.E,gm.F,gm.G,gm.H,gm.K,gm.P,
				gm.aj,gm.ak,gm.al,gm.am,gm.aw,gm.aR,new iz(gm.aU,1,4),gm.aX);
		EnumRarity.setRarity(EnumRarity.Rare,uu.an,uu.aq,uu.ay,uu.aZ,uu.be,gm.l,gm.x,gm.y,gm.z,gm.A,gm.O,gm.af,gm.ag,gm.ah,gm.ai,gm.ar,
				gm.bd,gm.be);
	}
}