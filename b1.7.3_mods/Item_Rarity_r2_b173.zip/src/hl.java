import java.util.Properties;

public class hl extends sn
{
	public iz a;
	private int e;
	public int b = 0;
	public int c;
	private int f = 5;
	public int rare;

	public float d = (float)(Math.random() * 3.141592653589793D * 2.0D);

	public hl(fd paramfd, double paramDouble1, double paramDouble2, double paramDouble3, iz paramiz) {
		super(paramfd);
		b(0.25F, 0.25F);
		this.bf = (this.bh / 2.0F);
		e(paramDouble1, paramDouble2, paramDouble3);
		this.a = paramiz;

		this.aS = (float)(Math.random() * 360.0D);

		this.aP = (float)(Math.random() * 0.2000000029802322D - 0.1000000014901161D);
		this.aQ = 0.2000000029802322D;
		this.aR = (float)(Math.random() * 0.2000000029802322D - 0.1000000014901161D);
		
		rare = getRarity();
	}

	protected boolean n()
	{
		return false;
	}

	public hl(fd paramfd)
	{
		super(paramfd);
		b(0.25F, 0.25F);
		this.bf = (this.bh / 2.0F);
	}

	protected void b()
	{
	}

	public void w_()
	{
		super.w_();
		
		if (aN < -128) K();
		
		if (this.c > 0) this.c -= 1;
		this.aJ = this.aM;
		this.aK = this.aN;
		this.aL = this.aO;

		this.aQ -= 0.03999999910593033D;
		if (this.aI.f(in.b(this.aM), in.b(this.aN), in.b(this.aO)) == ln.h) {
			this.aQ = 0.2000000029802322D;
			this.aP = ((this.bs.nextFloat() - this.bs.nextFloat()) * 0.2F);
			this.aR = ((this.bs.nextFloat() - this.bs.nextFloat()) * 0.2F);
			this.aI.a(this, "random.fizz", 0.4F, 2.0F + this.bs.nextFloat() * 0.4F);
		}
		c(this.aM, (this.aW.b + this.aW.e) / 2.0D, this.aO);
		b(this.aP, this.aQ, this.aR);

		float f1 = 0.98F;
		if (this.aX) {
			f1 = 0.5880001F;
			int i = this.aI.a(in.b(this.aM), in.b(this.aW.b) - 1, in.b(this.aO));
			if (i > 0) {
				f1 = uu.m[i].bB * 0.98F;
			}
		}

		this.aP *= f1;
		this.aQ *= 0.9800000190734863D;
		this.aR *= f1;

		if (this.aX) {
			this.aQ *= -0.5D;
		}

		this.e += 1;
		this.b += 1;
		if (this.b >= 6000)
		K();
	}

	public boolean k_()
	{
		return this.aI.a(this.aW, ln.g, this);
	}

	protected void a(int paramInt) {
		a((sn)null, paramInt);
	}

	public boolean a(sn paramsn, int paramInt) {
		ai();
		this.f -= paramInt;
		if (this.f <= 0) {
			K();
		}
		return false;
	}

	public void b(nu paramnu) {
		paramnu.a("Health", (short)(byte)this.f);
		paramnu.a("Age", (short)this.b);
		paramnu.a("Item", this.a.a(new nu()));
	}

	public void a(nu paramnu) {
		this.f = (paramnu.d("Health") & 0xFF);
		this.b = paramnu.d("Age");
		nu localnu = paramnu.k("Item");
		this.a = new iz(localnu);
	}

	public void b(gs paramgs) {
		if (this.aI.B) return;

		int i = this.a.a;
		if ((this.c == 0) && (paramgs.c.a(this.a))) {
			if (this.a.c == uu.K.bn) paramgs.a(ep.g);
			if (this.a.c == gm.aD.bf) paramgs.a(ep.t);
			ModLoader.OnItemPickup(paramgs, this.a);
			this.aI.a(this, "random.pop", 0.2F, ((this.bs.nextFloat() - this.bs.nextFloat()) * 0.7F + 1.0F) * 2.0F);
			paramgs.b(this, i);

			if (this.a.a <= 0) K();
		}
	}
	
	public void K() {
		if (a.a == 0 || aN < -128) {
			super.K();
			return;
		}
		
		if (rare >= 2) return;
		if (b >= 6000 && rare >= 1) return;
		super.K();
	}
	
	public int getRarity() {
		return EnumRarity.getRarity(getTooltip(a)).level;
	}
	
	private static String getTooltip(iz item) {
		try {
			String str = ((Properties)ModLoader.getPrivateValue(nh.class,nh.a(),1)).getProperty(item.l()+".name");
			return str == null ? "" : str;
		} catch (IllegalArgumentException e) {
		} catch (SecurityException e) {
		} catch (NoSuchFieldException e) {}
		return "";
	}
}