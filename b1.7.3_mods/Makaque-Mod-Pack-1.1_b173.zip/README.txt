			Makaque Mod-Pack
			Version 1.1
			For Minecraft 1.7.3 client



**Installation**

Just like any other mod really.
1. Have ModLoader installed already (many tutorials exist for this).
2. Open your .minecraft folder (if you have the above mod installed then you know where this is for your OS).
3. Open the bin folder, open minecraft.jar (assuming you have some kind of archive manager like winrar or 7zip).
4. Open the Makaque-Mod-Pack-*.zip, then the enclosed Makaque-Mod-Pack-* folder.
5. Drag all the files from Makaque-Mod-Pack-* folder into your minecraft.jar (being careful not to drag them into one of the folders).
6. Have fun being awesome!




**Recipes & Descriptions**


	*Thunderbolt*

	RLR
	RLL
	RRL
	
	or

	LRR
	LLR
	RLR
	
	R = redstone dust
	L = lapis lazuli
	
	Thunderbolts used to craft the handle of the Hammer of Thor and are also fired from it. When fired, they explode with more than three times the force of a creeper.

	____________________
	
	*Hammer of Thor*
	
	TTD
	
	T = Thunderbolt
	D = diamond block
	
	The Hammer of Thor can be used as either a weapon or a mining tool. As a mining tool the hammer is five times as effective as a diamond pickaxe and has five times as many
	uses before breaking. As a melee weapon, the Hammer of Thor will one hit kill any living entity. Right clicking while holding the Hammer of Thor will fire a Thunderbolt if the player has 
	Thunderbolts in his/her inventory. Firing Thunderbolts will not damage the Hammer. The Hammer of Thor is also effective against wood.
	
	____________________
	
	*Freezer*
	
	iii
	i i
	rSr
	
	i = iron ingot
	r = redstone dust
	S = snow block
	
	The freezer is used to freeze porkchops and fish in order to make them stackable. The freezer's interface is much like that of a furnace. Any fuel which can be used in a 
	furnace can also be used in a freezer, much like a portable cooler running on propane.
	
	____________________
	
	*Soft Leather*
	
	l
	
	l = leather
	
	Soft leather is leather which has been worked until it's nice and pliable.
	
	____________________
	
	*Running gear (Client only)*
	
	This description is for all the running gear as a whole. A full suit of running gear will allow the player to run 50% faster. Any armor worn will decrease the effectiveness
	of running gear by half of increase value of the corresponding piece of running gear. For instance, a running vest will increase running speed by 25% on it's own. However,
	an armor chestplate will reduce the effectiveness of all other running gear by 12.5%. 
	When the player's speed increase is above 20%, the player's step height increases to one block, so the player can run up hillsides without jumping (it's pretty awesome).
	
		*Running Shoes*
	
		s s
		l l
		l l
	
		s = string
		l = soft leather
	
		Running shoes are boots which allow you to run 12.5% faster unless hindered by armor.
	
		____________________
	
		*Running Shorts*
	
		lsl
		l l
		l l
	
		l = soft leather
		s = string
	
		Running shorts are leggings which allow you to run 7.5% faster unless hindered by armor.
	
		____________________
	
		*Running Vest*
	
		l l
		lsl
		lsl
	
		l = soft leather
		s = string
	
		The running vest is a chestplate which allows you to run 0.25% faster unless hindered by armor.
	
		____________________
	
		*Headband*
	
		www
		w w
	
		w = wool
	
		The headband is a helmet which allows you to run 5% faster unless hindered by armor.
	
	____________________
	
	*Sludge Clump*
	
	s
	w
	
	s = sulfur
	w = bucket of water
	
	A nasty chunky clump of sludge. used in the making of creeper's bane.
	
	____________________
	
	*Green Powder*
	
	s =>Furnace => g
	
	s = sludge clump
	g = green powder
	
	Having distilled the sludge in a furnace, this pile of green residue is left behind.
	
	____________________
	
	*Creeper's Bane Ingot*
	
	ggg
	ggg
	
	g = green powder
	
	A heafty bar of creeper's bane. The bane of all creepers.
	
	____________________
	
	*Creeper's Bane Block*
	
	ccc
	ccc
	ccc
	
	c = creeper's bane ingot
	
	This green block is as hard as stone for most intents. But as it is creeper's bane, this block will withstand any explosion. 
	
	____________________
	
	*Creeper's Bane Sword*
	
	c
	c
	s
	
	c = creeper's bane ingot
	s = stick
	
	The sword of creeper's bane. Much like the master sword, only for creepers. It lasts as long as iron, deals as much damage as wood against most enemies, 
	and kills any creeper with just one swing.
	
	____________________
	
	*Creeper's Bane Arrow*
	
	c
	s
	f
	
	c = creeper's bane ingot
	s = stick
	f = feather
	
	With a creeper's bane tip, this arrow will kill any creeper with just one shot, but will only do half the damage of a normal arrow against any other enemy.
	
	____________________
	
	*Lavaquarium*
	
	ggg
	glg
	ggg
	
	g = glass
	l = lava bucket
	
	The lavaquarium is a decorative piece/light source/safe lava storage unit. It's lava sealed behing a very thin layer of glass. How does this glass withstand
	the temperature? Why doesn't it burn me? I'll tell you why. Because it's Minecraft glass! That's super high temperature polymerized glass. No doubt. But be 
	careful. If you shatter the cage you unleash the fury.
	This piece was added because I like how brightly lava lights up caves, but find it too dangerous to leave lying around. 
	
	____________________
	
	*Artificial Sun*
	
	lll
	lll
	lll
	
	l = lavaquarium
	
	Have you ever thought to yourself, "Man this cave is huge. I wish there was an awesome way to light up a ridiculous area without wasting so many torches"? Well
	here is your solution. Just plop down the artificial sun block and run like hell. Count backwards from ten and, POP! You have yourself a nice "compact" indoor sun 
	(or outdoor, if that's your thing). If you don't like your new sun, just dig through the surface layers until you find the original artificial sun (the generator block).
	Destroy it and the entire thing will just disappear.
	The sun will destroy any non-solid or glass blocks when it generates. So if you want an enclosed sphere with no holes, just plop it down on a glass tower.
	
	____________________
	
	*Better Bow*
	
	sb
	s c
	sb
	
	s = string
	b = stick
	c = coal
	
	A lightweight, durable, carbon fiber bow. This bow is capable of shooting more types of arrows than a wooden bow. Press the 'v' while holding the better bow to 
	scroll through arrow types.
	
	____________________
	
	*Torch Arrow*
	
	a
	t
	a
	
	a = arrow
	t = torch
	
	Upon sticking into a wall or the ground, the torch this arrow carries will continue to glow. Thus, it's good for shedding light into those hard to reach corners. 
	If you choose instead to take this arrow into battle, it will do the same damage as a normal arrow, in addition to setting ablaze any enemy it strikes.
