Craftable Mob Drops & Dungeon Items (+NETHER) v4.2 [for 1.7.3]
By mattop101


Thanks for Downloading!

DESCRIPTION

This mod allows you to craft most default Mob Drops and Dungeon Items in Minecraft.
Please be aware that this mod DOES require ModLoader. More info in 'Installation.txt'

Spiders will now drop web as well as string and wolves will now drop gold ingots! Hooray!

In the reversibles update (v4.0+) many items will now, when placed in the crafting grid, give back the resources that you used to create them. For example if I crafted a chest, I could place that chest back into the crafting grid and get my 8 wooden planks back! You may find it quite useful. (Please note that reversibles are not shown below in screenshots as it's reasonably self explanitory)

Please note that in this latest update, apples can no longer be crafted, instead leaves now have a small chance of dropping apples as well as sapling! Also Golden Apples are much more easy to make. Instead of 72 golden ingots, it now only requires 4!

Screenshots of the new recipes and furnace fuels can be found in the 'Screenshots' folder.

Enjoy!


INSTALLATION

THIS MOD REQUIRES MODLOADER!
It can be downloaded here: http://www.minecraftforum.net/viewtopic.php?t=80246

To install, copy the contents of the 'class' folder to your 'minecraft.jar' file. This includes the 'craftables' directory.
REMEMBER TO DELETE THE 'META-INF' FOLDER IN MINECRAFT.JAR OR THE MOD WILL NOT WORK!


To find 'minecraft.jar'...
1. Open the start menu
2. Type in "show hidden files" into the search box
3. Click on the "show hidden files and folders" option, should show up under control panel
4. Under "Hidden files and folders", select the option that says; "show hidden files, folders, and drives"
5. Close the folder options window
6. Open the start menu
7. Open "Computer" or "My Computer"
8. Double-click on the hard drive
9. Double-click on the "Users" folder
10. Double-click on the folder with your username
11. Double-click on the "AppData" folder
12. Double-click on the "Roaming" folder
13. Double-click on the ".minecraft" folder
14. Double-click on the "bin" folder
