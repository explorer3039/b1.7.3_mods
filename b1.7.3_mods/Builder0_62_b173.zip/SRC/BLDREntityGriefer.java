package net.minecraft.src;

//Griefer - Aggressive Builder who builds incomplete and bad looking structures
//May do additional things
//Killable under all circumstances
//Attack idle builders and explorers (may seek player)
//HomeSeeker Convert with flint and Steel, gunpowder, tnt, etc
public class BLDREntityGriefer extends BLDREntityBuilder{
	BLDREntityGriefer(World world){
		super(world);

		buildCount = 5; //replace later
		health = 30;
		maxWait = 240;
		buildBlock = Block.tnt.blockID; //not actually used for building; just drop item
		int rrNum = rand.nextInt(3);
		if(rrNum == 0)
			texture = "/mob/Griefer1.png";
		else if(rrNum == 1){ //female Texture 1
			texture = "/mob/Griefer2.png";
			grieferFlags |= 0x01;
		}
		else{ //female Texture 2
			texture = "/mob/Griefer3.png";
			grieferFlags |= 0x01;
		}
		if(BLDRBlueprints.singlePrints.size() > 0)
			blueNum = rand.nextInt(BLDRBlueprints.singlePrints.size());
		else
			blueNum = -1;
		while(BLDRBlueprints.singlePrints.size() > 2 && (blueNum == mod_Builders.explorerSingleBlockIndex || blueNum == mod_Builders.traderBakerShopIndex))
			blueNum = rand.nextInt(BLDRBlueprints.singlePrints.size());
        
		tradeGiveNum = 0;
        tradeReceiveNum = 0;
        tradeRatio = 100;
	}
	
	//overwritten path setting method; dont occur if no clip
	protected void func_31026_E()
    {
		if((grieferFlags & 0x02) == 0)
			super.func_31026_E();
    }
	
	//drop additional items if doing additional stuff
	public void onDeath(Entity entity)
    {
        super.onDeath(entity);
        if((grieferFlags & 0x04) == 0)
        	dropItem(Item.flintAndSteel.shiftedIndex, 1);
        if((grieferFlags & 0x10) == 0)
        	dropItem(Item.bucketLava.shiftedIndex, 1);
        if((grieferFlags & 0x40) == 0)
        	dropItem(Item.bow.shiftedIndex, 1);
        if((grieferFlags & 0x80) == 0)
        	dropItem(Block.pressurePlateStone.blockID, 1);
    }
	
	//update later
	public boolean getCanSpawnHere()
    {
		if(worldObj.isDaytime()){
			if(mod_Builders.countBuilders(this.getClass()) >= BLDRBuilderConfig.cobbleSpawnMaxDay)
				return false;
			else
				return rand.nextInt(100) < BLDRBuilderConfig.cobbleSpawnRateDay && super.getCanSpawnHere();
		}
		else{
			if(mod_Builders.countBuilders(this.getClass()) >= BLDRBuilderConfig.cobbleSpawnMaxNight)
				return false;
			else
				return rand.nextInt(100) < BLDRBuilderConfig.cobbleSpawnRateNight && super.getCanSpawnHere();
		}
    }
	
	public void writeEntityToNBT(NBTTagCompound nbttagcompound)
    {
        super.writeEntityToNBT(nbttagcompound);
        nbttagcompound.setByte("GrieferFlags", grieferFlags);
    }

    public void readEntityFromNBT(NBTTagCompound nbttagcompound)
    {
        super.readEntityFromNBT(nbttagcompound);
        grieferFlags = nbttagcompound.getByte("GrieferFlags");
    }
    
    public void onUpdate()
    {
    	if(currentAction >= 1 && currentAction <= 6 && actionTimer == 10099 && ((builderFlags >> 1) & 1) != 1){
    		if(BLDRBlueprints.singlePrints.size() > 0)
    			blueNum = rand.nextInt(BLDRBlueprints.singlePrints.size());
    		else
    			blueNum = -1;
    		while(BLDRBlueprints.singlePrints.size() > 2 && (blueNum == mod_Builders.explorerSingleBlockIndex || blueNum == mod_Builders.traderBakerShopIndex))
    			blueNum = rand.nextInt(BLDRBlueprints.singlePrints.size());
    	}
    	super.onUpdate();
	}
	
	protected void setRandomCharacteristics(){
		super.setRandomCharacteristics();
		grieferFlags = 0;
    	if(rand.nextFloat() < 0.10F) grieferFlags |= 0x02; //10% - no clip
    	if(rand.nextFloat() < 0.25F) grieferFlags |= 0x04; //25% - fire starter
    	if(rand.nextFloat() < 0.3F) grieferFlags |= 0x08; //30% - 1 x 1 tower builder
    	if(rand.nextFloat() < 0.15F) grieferFlags |= 0x10; //15% - lava flooder
    	if(rand.nextFloat() < 0.10F) grieferFlags |= 0x20; //10% - tnt destroyer
    	if(rand.nextFloat() < 0.4F) grieferFlags |= 0x40; //40% - aggressive to player
    	if(rand.nextFloat() < 0.3F) grieferFlags |= 0x80; //30% - tnt trapper
    }
	
	//targets whoever attacks it
	public boolean attackEntityFrom(Entity entity, int i)
    {
		boolean flag = super.attackEntityFrom(entity, i);
		
		if(entity != null) playerToAttack = entity;
		return flag;
    }
	
	//4 conversions
	protected void initConvert(int x, String s){
		if(x == Block.tnt.blockID){
			grieferFlags &= 0xbf; //remove aggressiveness
			grieferFlags |= 0x20; //tnt destroyer
			grieferFlags |= 0x80; //tnt trapper
			moveSpeed += 0.25D;
			health += 15;
		}
		else if(x == Item.gunpowder.shiftedIndex){
			grieferFlags &= 0xbf; //remove aggressiveness
			grieferFlags |= 0x80; //tnt trapper
			moveSpeed += 0.15D;
			health += 5;
		}
		else if(x == Item.bucketLava.shiftedIndex){
			grieferFlags &= 0xbf; //remove aggressiveness
			grieferFlags |= 0x04; //lava flooder
			moveSpeed += 0.20D;
			health += 10;
		}
		else if(x == Item.flintAndSteel.shiftedIndex){
			grieferFlags &= 0xbf; //remove aggressiveness
			grieferFlags |= 0x04; //fire starter
			moveSpeed += 0.30D;
			health += 20;
		}
    }
	
	public ItemStack getChestItem(){
    	return chestItems[rand.nextInt(chestItems.length)].copy();
    }
	
	public boolean canRenovateBuild(){
    	return true;
    }
    
    protected ItemStack getThrownItem(){
    	return new ItemStack(Item.appleGold);
    }
    
    protected boolean canTossMeat(){
    	return health < 7;
    }
    
    protected int getChunkOffsetX(){
    	return 2;
    }
    
    protected int getChunkOffsetZ(){
    	return -9;
    }
    
    protected ItemStack getHealingItem(){
    	return new ItemStack(Item.appleGold);
    }

    public int getMaxHp(){
    	return 45;
    }
    
    protected boolean canBeHurt(){
    	return true;
    }
	
	/**
	 * bit 1 = Female - NOT DONE (set female names)
	 * bit 2 = No clip on; walks through walls and flys - NOT DONE
	 * bit 3 = Uses Flint & Steel to start fires on burnable blocks - NOT DONE
	 * bit 4 = Builds 1 x 1 Towers as high as possible while jumping on the top of the tower - NOT DONE
	 * bit 5 = Places lava source blocks with a lava bucket - NOT DONE
	 * bit 6 = Places tnt blocks and buttons, and triggers the tnt and runs. - NOT DONE
	 * bit 7 = Player included in list of targets - NOT DONE
	 * bit 8 = Places tnt traps; digs out 2 stone, places tnt, stone, stone pressure plate - NOT DONE
	 */
	public byte grieferFlags;
	
	//migrate female builder concept to base builder class and add females to all types of builders
	static final String[] femaleNames = new String[]{
		"Molly", "Laura", "Angie", "Sarah", "Vonna", "Dinah", "Carrie", "Penny", "Lisa", "Blossom", "Pam",
		"Lulu", "Wendy", "Lesley", "Ruth", "Helga", "Olga", "Vanessa", "Valerie", "Crona", "Yuena", "Zoocha",
		"Tammy", "Ms. Sky", "Harriet", "Berrie", "Carla", "Peggy", "Shana", "Queen", "Mexa", "Paulie", "Georgia",
		"Ronnie", "Bonny", "Bunny", "Kitty", "Kitten", "Wanda", "Nina", "Luanne", "Kelly", "Jill", "Holly",
		"Coco", "Brandy", "Honeydew", "Michelle", "Christy", "Simone", "Simona", "Laurie", "Leslie", "Honey",
		"Sugar", "Cinnamon", "Star", "Cherrylove", "Bill", "Steve", "Dew", "Nerdina", "Bubbles", "Butters",
		"Samantha"
	};
	
	static final ItemStack[] chestItems = (new ItemStack[]{
        	new ItemStack(Block.pumpkinLantern, 1), new ItemStack(Block.pumpkin, 1), new ItemStack(Block.tnt, 1),
        	new ItemStack(Item.gunpowder, 1), new ItemStack(Item.gunpowder, 2), new ItemStack(Item.gunpowder, 1),
        	new ItemStack(Item.flintAndSteel, 1), new ItemStack(Item.mapItem, 1, 8), new ItemStack(Item.coal, 1),
        	new ItemStack(Item.paper, 1), new ItemStack(Item.flint, 1), new ItemStack(Item.record13, 1),
        	new ItemStack(Item.bucketLava, 1), new ItemStack(Item.axeDiamond, 1, Item.axeDiamond.getMaxDamage() - 315), new ItemStack(Item.flintAndSteel, 1, 10),
        	new ItemStack(Item.shovelGold, 1), new ItemStack(Item.swordDiamond, 1, Item.swordDiamond.getMaxDamage() - 50), new ItemStack(Item.bootsDiamond, 1, Item.bootsDiamond.getMaxDamage() - 15),
        	new ItemStack(Item.pickaxeGold, 1, Item.pickaxeGold.getMaxDamage() / 2)
        });
}
