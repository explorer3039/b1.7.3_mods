package net.minecraft.src;
// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

import org.lwjgl.opengl.GL11;

public class BLDRRenderBuilder extends RenderLiving
{

    public BLDRRenderBuilder(ModelBiped modelbiped, float f)
    {
        super(modelbiped, f);
        field_4013_a = modelbiped;
        modelBipedMain = (ModelBiped)mainModel;
    }

    //from RenderBiped
    protected void renderEquippedItems(EntityLiving entityliving, float f)
    {
        ItemStack itemstack = entityliving.getHeldItem();
        if(itemstack != null)
        {
            GL11.glPushMatrix();
            field_4013_a.bipedRightArm.postRender(0.0625F);
            GL11.glTranslatef(-0.0625F, 0.4375F, 0.0625F);
            if(itemstack.itemID < 256 && RenderBlocks.renderItemIn3d(Block.blocksList[itemstack.itemID].getRenderType()))
            {
                float f1 = 0.5F;
                GL11.glTranslatef(0.0F, 0.1875F, -0.3125F);
                f1 *= 0.75F;
                GL11.glRotatef(20F, 1.0F, 0.0F, 0.0F);
                GL11.glRotatef(45F, 0.0F, 1.0F, 0.0F);
                GL11.glScalef(f1, -f1, f1);
            } else
            if(Item.itemsList[itemstack.itemID].isFull3D())
            {
                float f2 = 0.625F;
                GL11.glTranslatef(0.0F, 0.1875F, 0.0F);
                GL11.glScalef(f2, -f2, f2);
                GL11.glRotatef(-100F, 1.0F, 0.0F, 0.0F);
                GL11.glRotatef(45F, 0.0F, 1.0F, 0.0F);
            } else
            {
                float f3 = 0.375F;
                GL11.glTranslatef(0.25F, 0.1875F, -0.1875F);
                GL11.glScalef(f3, f3, f3);
                GL11.glRotatef(60F, 0.0F, 0.0F, 1.0F);
                GL11.glRotatef(-90F, 1.0F, 0.0F, 0.0F);
                GL11.glRotatef(20F, 0.0F, 0.0F, 1.0F);
            }
            renderManager.itemRenderer.renderItem(entityliving, itemstack);
            GL11.glPopMatrix();
        }
    }

    public void doRenderLiving(EntityLiving entityliving, double d, double d1, double d2, 
            float f, float f1)
    {
    	double d3 = d1 - (double)entityliving.yOffset;
    	modelBipedMain.isSneak = entityliving.isSneaking();
        if(entityliving.isSneaking())
        {
            d3 -= 0.125D;
        }
        super.doRenderLiving(entityliving, d, d3, d2, f, f1);
        if(BLDRBuilderConfig.enableNames == true)
        	doRenderBuilder((BLDREntityBuilder) entityliving, d, d3, d2, f, f1);
    }

    public void doRender(Entity entity, double d, double d1, double d2, 
            float f, float f1)
    {
    	doRenderLiving((EntityLiving)entity, d, d1, d2, f, f1);
    }
    
    public void doRenderBuilder(BLDREntityBuilder entitybuilder, double d, double d1, double d2, 
            float f, float f1)
    {
    	float f2 = 1.6F;
        float f3 = 0.01666667F * f2;
        float f4 = entitybuilder.getDistanceToEntity(renderManager.livingPlayer);
        float f5 = entitybuilder.isSneaking() ? 4F : 12F;
        float f6 = 0.2F;
        if(f4 < f5){
            String s0 = (entitybuilder.builderFlags & 1) == 1 ? "�3*�f" : "�f";
            String s = s0.concat(entitybuilder.name.concat(" the " + EntityList.getEntityString(entitybuilder)));
        	displayText(s, 0.01666667F, 0xa0dc6e7b, (float)d, (float)d1 + f3 + f6, (float)d2, entitybuilder);
        	if(entitybuilder.mouseHighlight){
        		String s00 = "~_~".concat(entitybuilder.getActionDescrip()).concat("~_~");
        		f6 += 0.2F;
        		displayText(s00, 0.01666667F, 0x20ffffff, (float)d, (float)d1 + f3 + f6, (float)d2, entitybuilder);
        	}
        }
    }
    
    private void displayText(String s, float f, int i, float f1, float f2, float f3, BLDREntityBuilder entitybuilder)
    {
        FontRenderer fontrenderer = getFontRendererFromRenderManager();
        GL11.glPushMatrix();
        GL11.glTranslatef(f1, f2 + 2.3F, f3);
        GL11.glNormal3f(0.0F, 1.0F, 0.0F);
        GL11.glRotatef(-renderManager.playerViewY, 0.0F, 1.0F, 0.0F);
        GL11.glRotatef(renderManager.playerViewX, 1.0F, 0.0F, 0.0F);
        GL11.glScalef(-f, -f, f);
        GL11.glDisable(2896 /*GL_LIGHTING*/);
        GL11.glDepthMask(false);
        GL11.glDisable(2929 /*GL_DEPTH_TEST*/);
        GL11.glEnable(3042 /*GL_BLEND*/);
        GL11.glBlendFunc(770, 771);
        Tessellator tessellator = Tessellator.instance;
        GL11.glDisable(3553 /*GL_TEXTURE_2D*/);
        tessellator.startDrawingQuads();
        int j = fontrenderer.getStringWidth(s) / 2;
        setTextColor(tessellator, entitybuilder);
        tessellator.addVertex(-j - 1, -1D, 0.0D);
        tessellator.addVertex(-j - 1, 8D, 0.0D);
        tessellator.addVertex(j + 1, 8D, 0.0D);
        tessellator.addVertex(j + 1, -1D, 0.0D);
        tessellator.draw();
        GL11.glEnable(3553 /*GL_TEXTURE_2D*/);
        fontrenderer.drawString(s, -fontrenderer.getStringWidth(s) / 2, 0, i);
        GL11.glEnable(2929 /*GL_DEPTH_TEST*/);
        GL11.glDepthMask(true);
        fontrenderer.drawString(s, -fontrenderer.getStringWidth(s) / 2, 0, -1);
        GL11.glEnable(2896 /*GL_LIGHTING*/);
        GL11.glDisable(3042 /*GL_BLEND*/);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        GL11.glPopMatrix();
    }
    
    protected void setTextColor(Tessellator tessellator, BLDREntityBuilder entitybuilder){
        switch (entitybuilder.currentAction){
        case 0:
        	tessellator.setColorRGBA_F(0.0F, 0.0F, 0.0F, 0.25F); //Idle
    		break;
        case 1:
        	tessellator.setColorRGBA_F(0.0F, 0.0F, 0.8F, 0.25F); //Reno Phase 1
    		break;
        case 2:
        	tessellator.setColorRGBA_F(0.0F, 0.1F, 0.7F, 0.25F); //Reno Phase 2
    		break;
        case 3:
        	tessellator.setColorRGBA_F(0.0F, 0.2F, 0.6F, 0.25F); //Opaque Phase 1
    		break;
        case 4:
        	tessellator.setColorRGBA_F(0.0F, 0.3F, 0.5F, 0.25F); //Opaque Phase 2
    		break;
        case 5:
        	tessellator.setColorRGBA_F(0.0F, 0.4F, 0.4F, 0.25F); //Non-Opaque Phase
    		break;
        case 6:
        	tessellator.setColorRGBA_F(0.0F, 0.5F, 0.3F, 0.25F); //Finish Phase
    		break;
    	case 7:
    		tessellator.setColorRGBA_F(1F, 1F, 0.0F, 0.25F); //Following Player (non-renovate)
    		break;
    	case 8:
    		tessellator.setColorRGBA_F(0.55F, 0.75F, 0.0F, 0.25F); //Following/Aiding Mayor
    		break;
    	case 9:
    		tessellator.setColorRGBA_F(1F, 0.9F, 0.2F, 0.25F); //Following Player (renovate)
    		break;
    	case 10:
    		tessellator.setColorRGBA_F(0.7F, 0.3F, 0.7F, 0.25F); //ready to renovate
    		break;
    	case 18:
    		tessellator.setColorRGBA_F(0.2F, 0.7F, 0.2F, 0.25F); //Trade-Chest
    		break;
    	case 19:
    		tessellator.setColorRGBA_F(1F, 0.0F, 0.0F, 0.25F); //Renting
    		break;
    	case 20:
    		tessellator.setColorRGBA_F(0.0F, 1F, 0.0F, 0.25F); //Running
    		break;
    	default:
    		tessellator.setColorRGBA_F(0.2F, 0.3F, 0.4F, 0.25F); //Other
    		break;
    	}
    }

    protected ModelBiped field_4013_a; //from RenderBiped
    private ModelBiped modelBipedMain;

}
