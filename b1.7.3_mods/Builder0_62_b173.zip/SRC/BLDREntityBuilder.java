package net.minecraft.src;

import java.lang.reflect.Field;
// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode
/* 
 	EntityBuilder 0.51 created by OgreSean
	Description: EntityBuilder is the base class for a set of human mobs who build structures.
					
*/
import java.util.List;

public class BLDREntityBuilder extends EntityCreature
{
//IDEA: When mouse over builder, make text appear above name that tells what builder is doing.
	//constructor
    public BLDREntityBuilder(World world)
    {
        super(world);
        mouseHighlight = false;
        currentAction = 0;
        actionTimer = 0;
        updateTimer = 0;
        
        homeRange = 0;
        homeX = -1;
        homeY = -1;
        homeZ = -1;
        rentPayments = 0;
        homeAttitude = 0;
        payTimer = -1;
        
        //pre-existing variable default settings
        moveSpeed = 0.8F + rand.nextFloat() / 3F;
        
        leader = null;
        
        //freelance build related
        iA = 0;
        jA = 0;
        kA = 0;
        blueNum = 0;
        direction = 0;
        	//Modes
        noMove = false;
        	//Trade Chest related
        tradeGiveNum = 5;
        tradeReceiveNum = 0;
        tradeRatio = 20;
        xT = 0;
        yT = 0;
        zT = 0;
        	//misc.
        name = getName();
        tradeChestDistance = 0;
        
        //Meat Toss
        tossMeat = null;
        runDirection = 0;

        rotationPitchX = 0.0F;
        rotationYawX = 0.0F;
        builderFlags = 0L;
        setRandomCharacteristics();
    }

    
    
    
    //overriden functions
    /*********************************************************/
    
  //called by moveEntityWithHeading function; moves Entity short distance
    //overriden to allow moveSpeeds above 1.0F
    public void moveFlying(float f, float f1, float f2)
    {
        if(moveSpeed <= 1.0F)
        	super.moveFlying(f, f1, f2);
        else
        	super.moveFlying(f, f1, f2 * moveSpeed);
    }
    
    //does not despawn while renting, not moving, or if set to not despawn
    protected boolean canDespawn()
    {
    	return super.canDespawn() && currentAction != 20 && !noMove && (builderFlags & 1) != 1;
    }
    
    //overwritten heal method
    public void heal(int i)
    {
        if(health <= 0)
        {
            return;
        }
        health += i;
        if(health > getMaxHp())
        {
            health = getMaxHp();
        }
        heartsLife = heartsHalvesLife / 2;
    }
    
  //Builders unable to be die while busy
  //Builders toss a piece of a meat away from them and run from whoever attacked them, if idle
    public boolean attackEntityFrom(Entity entity, int i)
    {
    	if(currentAction == 0)
        {
    		//if can not toss meat, use super
    		if(!canTossMeat() || !(entity instanceof EntityCreature) || entity instanceof BLDREntityBuilder)
    			return super.attackEntityFrom(entity, i);
    		
    		//if not tossing meat, set attacker to meat toss target
    		if(tossMeat == null){
    			tossMeat = (EntityCreature) entity;
    			currentAction = 19;
    			actionTimer = 0;
    		}
    			
            return super.attackEntityFrom(entity, i);
        }
        else if(canBeHurt())
        	return super.attackEntityFrom(entity, i);
        else
        	return super.attackEntityFrom(entity, 0);
    }
    
    
    
    
    public void onDeath(Entity entity)
    {
    	//if aiding mayor before death, reduce mayor's builderCount
        if(currentAction == 8 && leader instanceof BLDREntityMayor){
        	BLDREntityMayor eM = (BLDREntityMayor) leader;
        	currentAction = 0;
        	eM.builderCount--;
        	actionTimer = 0;
        }
		super.onDeath(entity);
    }
    
    public void writeEntityToNBT(NBTTagCompound nbttagcompound)
    {
        super.writeEntityToNBT(nbttagcompound);
        nbttagcompound.setString("BuilderName", name);
        nbttagcompound.setString("texture", texture);
        nbttagcompound.setByte("CurrentAction", currentAction);
        nbttagcompound.setShort("ActionTimer", actionTimer);
        nbttagcompound.setLong("BuilderFlags", builderFlags);
        //set build variables if necessary
        if(currentAction >= 1 && currentAction <= 6){
        	String blueprintName = BLDRBlueprints.singlePrintNames.get(blueNum);
        	nbttagcompound.setString("BlueprintName", blueprintName);
        	nbttagcompound.setInteger("iB", iB);
        	nbttagcompound.setInteger("jB", jB);
        	nbttagcompound.setInteger("kB", kB);
        	nbttagcompound.setInteger("iA", iA);
        	nbttagcompound.setInteger("jA", jA);
        	nbttagcompound.setInteger("kA", kA);
        	nbttagcompound.setByte("Direction", direction);
        	nbttagcompound.setFloat("RotationYawX", rotationYawX);
        	nbttagcompound.setFloat("RotationPitchX", rotationPitchX);
    		nbttagcompound.setInteger("BuildBlock", buildBlock);
        }
        //set trade chest variables if necessary
        else if(currentAction == 18){
        	nbttagcompound.setInteger("xT", xT);
        	nbttagcompound.setInteger("yT", yT);
        	nbttagcompound.setInteger("zT", zT);
        	nbttagcompound.setInteger("ChestDistance", tradeChestDistance);
        }
        //set renting variables if necessary
        else if(currentAction == 20){
        	nbttagcompound.setByte("homeAttitude", homeAttitude);
        	nbttagcompound.setInteger("homeRange", homeRange);
        	nbttagcompound.setInteger("homeX", homeX);
        	nbttagcompound.setInteger("homeY", homeY);
        	nbttagcompound.setInteger("homeZ", homeZ);
        	nbttagcompound.setByte("rentPayments", rentPayments);
        }
        /*else if(currentAction == 21)
        	nbttagcompound.setByte("heightToClimb", heightToClimb);*/
    }

    public void readEntityFromNBT(NBTTagCompound nbttagcompound)
    {
        super.readEntityFromNBT(nbttagcompound);
        if(!nbttagcompound.hasKey("BuilderName"))
        {
            name = "Jason";
        }
        else
        	name = nbttagcompound.getString("BuilderName");
        texture = nbttagcompound.getString("texture");
        currentAction = nbttagcompound.getByte("CurrentAction");
        actionTimer = nbttagcompound.getShort("ActionTimer");
        builderFlags = nbttagcompound.getLong("BuilderFlags");
        if(((builderFlags >> 2) & 1) != 1) mod_Builders.builderList.add(this);
        
      //get build variables if necessary
        if(currentAction >= 1 && currentAction <= 6){
        	String blueprintName = nbttagcompound.getString("BlueprintName");
        	blueNum = BLDRBlueprints.singlePrintNames.indexOf(blueprintName);
        	if(blueNum == -1){
        		currentAction = 0;
        		blueNum = 0;
        		actionTimer = 0;
        	}else{
        		iB = nbttagcompound.getInteger("iB");
        		jB = nbttagcompound.getInteger("jB");
        		kB = nbttagcompound.getInteger("kB");
        		iA = nbttagcompound.getInteger("iA");
        		jA = nbttagcompound.getInteger("jA");
        		kA = nbttagcompound.getInteger("kA");
        		direction = nbttagcompound.getByte("Direction");
        		rotationYawX = nbttagcompound.getFloat("RotationYawX");
        		rotationPitchX = nbttagcompound.getFloat("RotationPitchX");
        		noMove = true;
        		buildBlock = nbttagcompound.getInteger("BuildBlock");
        	}
        }
        //get trade-chest variables if necessary
        else if(currentAction == 18){
        	xT = nbttagcompound.getInteger("xT");
        	yT = nbttagcompound.getInteger("yT");
        	zT = nbttagcompound.getInteger("zT");
        	tradeChestDistance = nbttagcompound.getInteger("ChestDistance");
        }
      //get renting variables if necessary
        else if(currentAction == 20)
        {
            homeAttitude = nbttagcompound.getByte("homeAttitude");
            homeRange = nbttagcompound.getInteger("homeRange");
            homeX = nbttagcompound.getInteger("homeX");
            homeY = nbttagcompound.getInteger("homeY");
            homeZ = nbttagcompound.getInteger("homeZ");
            rentPayments = nbttagcompound.getByte("rentPayments");
        }
        /*else if(currentAction == 21)
        	heightToClimb = nbttagcompound.getByte("heightToClimb");*/
        	
    }


    //Builders don't spawn on top of leaves, or underneath other blocks
    public boolean getCanSpawnHere()
    {
    	int i = MathHelper.floor_double(posX);
        int j = MathHelper.floor_double(boundingBox.minY);
        int k = MathHelper.floor_double(posZ);
        return worldObj.getBlockId(i, j - 1, k) != Block.leaves.blockID && worldObj.canBlockSeeTheSky(i, j, k) && super.getCanSpawnHere(); //prevent leaf spawning
    }

	protected String getLivingSound()
    {
        return "builder.builderLiving";
    }

    protected String getHurtSound()
    {
        return "builder.builderHurt";
    }

    protected String getDeathSound()
    {
        return "builder.builderHurt";
    }
	
	public ItemStack getHeldItem()
    {
        return heldObj;
    }
	
	protected int getDropItemId()
    {
        return buildBlock;
    }
	
	//if builder idle, and player holding nothing, make builder follow player
	public boolean interact(EntityPlayer entityplayer)
    {
		ItemStack itemstack = entityplayer.inventory.getCurrentItem();
		if(itemstack == null)
		{
			if(currentAction == 0){ //Begin following
				currentAction = 7;
				leader = entityplayer;
				actionTimer = 0;
			}
			else if(currentAction == 10){ //Begin following while ready to renovate
				currentAction = 9;
				leader = entityplayer;
				actionTimer = 0;
			}
			else if(currentAction == 7){ //Stop following
				currentAction = 0;
				if(heldObj != null && heldObj.getItem() instanceof ItemFood){
					this.prevSwingProgress = 0.0F;
					this.swingProgress = 0.0F;
					heldObj = null;
				}
				leader = null;
				//builder who stops following immediately attempts to build
				actionTimer = (short) (maxWait - 1);
				actionTimer |= (1 << 14);
			}
			else if(currentAction == 9){ //Stop following and return to renovation ready
				currentAction = 10;
				if(heldObj != null && heldObj.getItem() instanceof ItemFood){
					this.prevSwingProgress = 0.0F;
					this.swingProgress = 0.0F;
					heldObj = null;
				}
				leader = null;
				//builder who stops following immediately attempts to build
				actionTimer = (short) (maxWait - 1);
			}
			return true;
		}
		else if((itemstack.itemID == Item.paper.shiftedIndex || itemstack.itemID == Item.sign.shiftedIndex) && canRenovateBuild()) //paper makes renovate build
		{
			if(currentAction != 0 && currentAction != 7 && currentAction != 9 && currentAction != 10)
				return false;
			else if(currentAction == 0)
				currentAction = 10;
			else if(currentAction == 7)
				currentAction = 9;
			stateNextBlueprint();
			if(itemstack.itemID == Item.sign.shiftedIndex)
				builderFlags |= (1 << 1);
			else if(itemstack.itemID == Item.paper.shiftedIndex)
				builderFlags &= ~(long)(1 << 1);
				
			return true;
		}
		else if(itemstack.itemID == Item.bucketMilk.shiftedIndex && (builderFlags & 1) != 1){ //milk makes never despawn except through death
			itemstack.itemID = Item.bucketEmpty.shiftedIndex;
			builderFlags |= 1; //does not despawn
			builderFlags |= (1 << 2); //no longer on Builder List
			//display message from builder stating his appreciation
			String str = (new StringBuilder().append("�5<").append(this.name)).append("> �fThanks for the refreshing milk!  I'll be sure to stick around.").toString();
			mod_Builders.minecraft_b.ingameGUI.addChatMessage(str);
			return true;
		}
		else
		{
			return false;
		}
    }
	

	//By overwriting these methods, movement is stopped completely   
	public void moveEntity(double d, double d1, double d2)
    {
		if(!noMove)
			super.moveEntity(d, d1, d2);
    } 
	
    protected boolean isMovementBlocked()
    {
    	return noMove && super.isMovementBlocked();
    }
    
  //getBlockPathWeight
	///makes builder run in a direction
    protected float getBlockPathWeight(int i, int j, int k)
    {
    	float xDif = (float) (posX - i);
    	float zDif = (float) (posZ - k);
    	
    	switch (runDirection){
    	case 1:
    		return ((xDif + zDif) / 2F);
    	case 2:
    		return -((xDif + zDif) / 2F);
    	case 3:
    		return ((xDif - zDif) / 2F);
    	case 4:
    		return -((xDif - zDif) / 2F);
    	default:
    		return super.getBlockPathWeight(i, j, k);
    	}
    }
	
    
    //overriden onUpdate function
	public void onUpdate()
    {
        super.onUpdate();
        
        checkForHighlight();
        
        if(((builderFlags >> 2) & 1) != 1) mod_Builders.builderCount--;
        
		actionTimer++; //timer increments every update, about 20 times a second
		if(updateTimer++ == 101) //timer increments every update, about 20 times a second
			updateTimer = 1;
		
		//if not moving set pitch and yaw properly
		if(noMove){
	        rotationPitch = rotationPitchX;
	        rotationYaw = rotationYawX;
		}
		
		//pay player
		if(payTimer > -1){
			payPlayer();
		}
		
		//idle update
		if(currentAction == 0)
			idleUpdate();
		
		//if following, manage chance of healing and keeping actionTimer low
		else if(currentAction == 7 || currentAction == 9 || currentAction == 8 && actionTimer < 10000){
			if(actionTimer > 40) actionTimer = 0;
			if(((builderFlags >> 6) & 1) == 1 && leader instanceof EntityLiving && ((actionTimer == 0 && rand.nextFloat() < 0.1F) || heldObj != null && heldObj.getItem() instanceof ItemFood)){
				healWeakTarget((EntityLiving) leader, false);
			}
		}
		
		//begin renovation phase (unless sign used)
		else if(currentAction == 10 && actionTimer == maxWait){
			actionTimer = 0;
			if(((builderFlags >> 1) & 1) != 1)currentAction = 1;
			else currentAction = 3;
		}
		
		//throw meat and run
		else if(currentAction == 19){
			throwMeatAndRun();
		}
		
		//tradeChest
		else if(currentAction == 18)
			tradeChestUpdate();

		
		
		
		//Follow leader if not attacking anything, and far from leader
		if(!noMove && playerToAttack == null && leader != null && this.getDistanceToEntity(leader) > 4D && this.getDistanceToEntity(leader) < 25D){
			setPathToEntity(worldObj.getPathToEntity(this, leader, 25F));
		}
		
		//Stay in range of home location, if renting and not attacking anything (Explorer Only)
		else if(currentAction == 20 && playerToAttack == null && this.getDistance(homeX, homeY, homeZ) > homeRange){
			setPathToEntity(worldObj.getEntityPathToXYZ(this, homeX, homeY, homeZ, (float) this.getDistance(homeX, homeY, homeZ) + 5));
		}
		
		//stop from building if buildCount is 0, or if renting
		
		doEvery25Updates(); //Misc. stuff that occurs every 25 Updates
		
		//if mayor is ready to have builders build, start "build for mayor" process
		if(actionTimer < 10200 && currentAction == 8 && leader instanceof BLDREntityMayor && ((BLDREntityMayor) leader).mayorCounter > 10049){
			actionTimer = 10200;
			noMove = true;
		}
		
		
		//Action Phases
		if(currentAction >= 1 && currentAction <= 6)
			freelanceBuild(); //Build structure while unassociated with town
		else if(currentAction == 8){
			if(actionTimer >= 10200 && actionTimer < 10500)
				mayorWallBuild(); //Build wall for mayor
			else if(actionTimer >= 10600)
				townRenovation(); //After building wall for mayor, renovate half of the land.
		}
		
		
	}
	
	
	
	
	//new functions
    /*********************************************************/
	
	
	
	
	
	
	
	//determines if able to place a block at specified location
	protected boolean canPlaceBlock(int i, int j, int k, int l){ //checks if Builder can place block at coordinates
		if(j > 125)
			return false;
		if(BLDRBuilderConfig.buildAnywhere == true || ((currentAction == 2 || currentAction == 1) && actionTimer < 10050))
			return true;
		int bID2 = worldObj.getBlockId(i, j, k); //block id of block within designated spot
		if(l == -1){ //determines if ground block underneath
			return !(bID2 == 0 || bID2 == Block.waterStill.blockID || bID2 == Block.waterMoving.blockID || bID2 == Block.lavaStill.blockID
			|| bID2 == Block.lavaMoving.blockID || bID2 == Block.fire.blockID || bID2 == Block.snow.blockID || bID2 == Block.ice.blockID);
		}
		else if(l == 0){ //ground layer only
			int bID1 = worldObj.getBlockId(i, j - 1, k); //block id of block below designated spot
			if(!(bID1 == 0 || bID1 == Block.waterStill.blockID || bID1 == Block.waterMoving.blockID || bID1 == Block.lavaStill.blockID
					|| bID1 == Block.lavaMoving.blockID || bID1 == Block.fire.blockID || bID1 == Block.snow.blockID || bID1 == Block.ice.blockID) 
					&& (bID2 == 0 || bID2 == Block.fire.blockID || bID2 == Block.snow.blockID
							|| bID2 == Block.cactus.blockID || bID2 == Block.crops.blockID || bID2 == Block.leaves.blockID
							 || bID2 == Block.mushroomBrown.blockID || bID2 == Block.mushroomRed.blockID || bID2 == Block.plantRed.blockID
							 || bID2 == Block.reed.blockID || bID2 == Block.sapling.blockID || bID2 == Block.plantYellow.blockID || bID2 == Block.ice.blockID)){
							 //|| bID2 == Block.waterStill.blockID || bID2 == Block.waterMoving.blockID || bID2 == Block.lavaStill.blockID
							 //|| bID2 == Block.lavaMoving.blockID)){
				
				return true;
			}
			else
				return false;
		}
		else{
			if(bID2 == 0 || bID2 == Block.fire.blockID || bID2 == Block.snow.blockID){// || bID2 == Block.waterStill.blockID
					//|| bID2 == Block.waterMoving.blockID || bID2 == Block.lavaStill.blockID || bID2 == Block.lavaMoving.blockID){
					return true;
			}
			else
				return false;
		}
	}
	
	//places a block at the specified location, and sets the metadata if necessary
	protected void placeBlock(int i, int j, int k, int blockID){ //Builder places block at coordinates
		int bID = blockID > 0 ? blockID & 255 : blockID;
		int meta = blockID > 0 ? (blockID >> 10) & 15 : 0;
		if((bID == 64 || bID == 71) && (worldObj.getBlockId(i, j-1, k) == 64 || worldObj.getBlockId(i, j-1, k) == 71)) //if block underneath is door, stop
			return;
		worldObj.setBlockWithNotify(i, j, k, 0);
		if(bID == -1){ //default block
			worldObj.setBlockWithNotify(i, j, k, buildBlock);
		}
		else if(bID == -2){ //place HomeBlock
			bID = homeBlocks[rand.nextInt(homeBlocks.length)];
			worldObj.setBlockWithNotify(i, j, k, bID);
		}
		else
			worldObj.setBlockAndMetadataWithNotify(i, j, k, bID, meta);
		
		if(bID == 65){ //if ladder, set metadata
			Block.ladder.onBlockPlaced(worldObj, i, j, k, meta);
		}
		else if(bID == 54){ //if Chest, place items in chest
			int rNum1 = rand.nextInt(10);
			int rNum2;
			//	getChestItem();
			TileEntityChest tEC = (TileEntityChest) worldObj.getBlockTileEntity(i, j, k);
	    	if(tEC == null) return;
	    	//if giveTake true, add random item to chest.
	    	for(int ii = 0; ii < rNum1; ii++){
	    		rNum2 = rand.nextInt(27);
	    		if(tEC.getStackInSlot(rNum2) == null)
	    			tEC.setInventorySlotContents(rNum2, getChestItem());
	    	}
		}
		else if(bID == 64 || bID == 71){ //if door, set metadata
			if(meta == 0) meta = rand.nextInt(4) + 4;
			worldObj.setBlockMetadataWithNotify(i, j, k, meta);
    		worldObj.setBlockAndMetadataWithNotify(i, j+ 1, k, bID, 8 + meta);
		}
		else if(bID == 61){ //if furnace, place items in furnace
			TileEntityFurnace tEF = (TileEntityFurnace) worldObj.getBlockTileEntity(i, j, k);
			if(tEF == null) return;
			tEF.setInventorySlotContents(0, new ItemStack(Block.sand.blockID, rand.nextInt(16) + 5, 0));
			tEF.setInventorySlotContents(1, new ItemStack(Block.wood.blockID, rand.nextInt(8) + 5, 0));
			tEF.setInventorySlotContents(2, new ItemStack(Block.glass.blockID, rand.nextInt(5) + 3, 0));
		}
		else if(bID == Block.dispenser.blockID){ //if dispenser, place arrows in it
			TileEntityDispenser tED = (TileEntityDispenser) worldObj.getBlockTileEntity(i, j, k);
			if(tED == null) return;
			tED.setInventorySlotContents(0, new ItemStack(Item.arrow.shiftedIndex, rand.nextInt(32) + 2, 0));
		}
		else if(bID == Block.waterMoving.blockID || bID == Block.lavaMoving.blockID){ //if water or lava, set meta data to 0
			worldObj.setBlockMetadata(i, j, k, 0);
		}
		if(bID != 0)
			worldObj.playSoundAtEntity(this, "random.pop", getSoundVolume(), (rand.nextFloat() - rand.nextFloat()) * 0.2F + 1.0F);
	}
	
	//Builder swings while turning head and body, before placing a block.
	protected void preBuildMovement(int swingNum, int i, int j, int k){
		prevSwingProgress = swingNum * 0.125F;
		swingProgress = swingNum * 0.125F;
		faceBlock(i, j, k, 12F);
	}
	

    //Makes Builder turn toward and look at a certain block.
    public void faceBlock(double i, double j, double k, float f) //f determines max rotation (in degrees)
    {
        faceBlock(this, i, j, k, f);
        rotationPitchX = rotationPitch;
        rotationYawX = rotationYaw;
    }
    
    //Makes an Entity turn toward and look at a certain block.
    public void faceBlock(EntityLiving eL, double i, double j, double k, float f) //f determines max rotation (in degrees)
    {
        double d = i - eL.posX;
        double d2 = k - eL.posZ;
        double d1;
        d1 = j - (eL.posY + (double)eL.getEyeHeight());
        double d3 = MathHelper.sqrt_double(d * d + d2 * d2);
        float f1 = (float)((Math.atan2(d2, d) * 180D) / 3.1415927410125732D) - 90F;
        float f2 = (float)(-(Math.atan2(d1, d3) * 180D) / 3.1415927410125732D);
        eL.prevRotationPitch = eL.rotationPitch;
        eL.prevRotationYaw = eL.rotationYaw;
        eL.rotationPitch = -updateBuilderRotation(eL.rotationPitch, f2, f);
        eL.rotationYaw = updateBuilderRotation(eL.rotationYaw, f1, f);
    }

    //Randomizes build coordinates for freelance building
    protected void randomizeBuildCoordinates(){
    	//randomly determine which nearby block to build at
    	
    	int rand1 = rand.nextInt(2) == 0 ? 2 : -2; 
		int rand2 = rand.nextInt(2) == 0 ? 2 : -2;
		int noB1;
		int noB2;
		
		//based on direction, determine what spot cannot be built in.
		if(direction == 0 || direction == 4){
			noB1 = -2;
			noB2 = -2;
		}
		else if(direction == 1 || direction == 5){
			noB1 = 2;
			noB2 = 2;
		}
		else if(direction == 2 || direction == 6){
			noB1 = -2;
			noB2 = 2;
		}
		else if(direction == 3 || direction == 7){
			noB1 = 2;
			noB2 = -2;
		}
		else{
			noB1 = -2;
			noB2 = -2;
		}
		
		if(rand1 == noB1 && rand2 == noB2){
			rand2 = -rand2;
		}
		
		//set build coordinates
    	iB = MathHelper.floor_double(posX) + rand1;
		jB = MathHelper.floor_double(boundingBox.minY);
		kB = MathHelper.floor_double(posZ) + rand2;	
    }
    
    //returns closest Monster Mob to builder
    public EntityMob getNearestTarget(Entity entity, double d)
    {
        double d1 = 9999D;
        EntityMob entitymob2 = null;
        List list = worldObj.getEntitiesWithinAABBExcludingEntity(entity, boundingBox.expand(d, d, d));
        for(int i = 0; i < list.size(); i++)
        {
            Entity entity1 = (Entity)list.get(i);
            if(!(entity1 instanceof EntityMob) || entity1 == entity.ridingEntity || entity1 == entity.riddenByEntity)
            {
                continue;
            }
            double d2 = entity1.getDistanceSq(entity.posX, entity.posY, entity.posZ);
            if((d2 < d1) && ((EntityMob)entity1).canEntityBeSeen(entity))
            {
                d1 = d2;
                entitymob2 = (EntityMob)entity1;
            }
        }

        return entitymob2;
    }
    

    
    //changes contents of town chest
    public boolean modifyTownChest(boolean giveTake, ItemStack cItem){
    	TileEntityChest tEC = (TileEntityChest) worldObj.getBlockTileEntity(xT, yT, zT);
    	if(tEC == null) return false;
    	//if giveTake true, add random item to chest.
		int rNum = rand.nextInt(27);
    	if(giveTake == true){
    		if(tEC.getStackInSlot(rNum) == null)
    			tEC.setInventorySlotContents(rNum, cItem);
    		else
    			return false;
    	}
    	//if giveTake false, take away random item from chest.
    	else{
    		if(tEC.getStackInSlot(rNum) != null){
    			cItem = tEC.getStackInSlot(rNum).copy();
    			tEC.setInventorySlotContents(rNum, null);
    		}
    		else
    			return false;
    	}
    	return true;
    }
    
    //used to determine which item a Builder will place into town chests or chests in Blueprints.
    public ItemStack getChestItem(){
    	return null;
    }
    
    //determines what item Builder holds while flattening terrain
    public ItemStack determineDigItem(int i, int j, int k){
    	int bID = worldObj.getBlockId(i, j, k);
    	if(bID == Block.blockClay.blockID || bID == Block.blockSnow.blockID || bID == Block.dirt.blockID ||
    			bID == Block.grass.blockID || bID == Block.gravel.blockID || bID == Block.sand.blockID ||
    			bID == Block.snow.blockID || bID == Block.tilledField.blockID || bID == Block.slowSand.blockID){
    		return new ItemStack(Item.shovelSteel.shiftedIndex, 1, 0);
    	}
    	else if(bID == Block.wood.blockID || bID == Block.planks.blockID){
    		return new ItemStack(Item.axeSteel.shiftedIndex, 1, 0);
    	}
    	else if(bID == Block.leaves.blockID){
    		return new ItemStack(Item.swordSteel.shiftedIndex, 1, 0);
    	}
    	else if(bID == Block.waterMoving.blockID || bID == Block.waterStill.blockID ||
    			bID == Block.lavaMoving.blockID || bID == Block.lavaStill.blockID){
    		return new ItemStack(Item.bucketEmpty.shiftedIndex, 1, 0);
    	}
    	else{
    		return new ItemStack(Item.pickaxeSteel.shiftedIndex, 1, 0);
    	}
    }
    
    //occurs every 25 ticks
    public void doEvery25Updates(){
    	if(updateTimer % 25 == 0){ 
    		//check for nearby BuilderSigns, if idle
    		if(currentAction == 0 && mod_Builders.signsList != null && mod_Builders.signsList.size() > 0){
    			checkForBuilderSigns();
    		}
			//if renting and owing payment, when player nearby, pay player
    		else if(currentAction == 20){
    			handleRent();
    		}
    			
			//if leader died, set leader to null
			if(leader != null && leader.isDead)
				leader = null;
			
			//if leader despawned, stop following
			if(leader == null && (currentAction > 6 && currentAction < 10)){
				if(currentAction == 9) //following while ready to renovate
					currentAction = 10; //ready to renovate
				else
					currentAction = 0; //idle
				actionTimer = 0;
			}
			
			
		}
    }
    
    //build structure
    public void freelanceBuild(){
    	if(actionTimer == 10 && onGround == false){
    		actionTimer -= 8; 
    	}
		else if(actionTimer == 10 && onGround == true){  //determine initial block_place location
			if(buildCount != 0 && blueNum != -1){
				
					actionTimer = 10000;
					noMove = true;
					setPosition(posX, MathHelper.floor_double(boundingBox.minY), posZ);
					if(worldObj.getBlockId(MathHelper.floor_double(posX), MathHelper.floor_double(boundingBox.minY) - 1, MathHelper.floor_double(posZ)) == 0)
						setPosition(posX, posY - 1, posZ);

			        direction = uniDirectionalStructures() ? 0 : Integer.valueOf(rand.nextInt(8)).byteValue();
					randomizeBuildCoordinates();
			}
			else{
				actionTimer = 0;
				currentAction = 0;
			}
		}
		
		//If chosen location can be built in, Enter Planning Phase
		
    	//If renovating, skip paper phase
		else if(actionTimer == 10005 && currentAction == 1)
			actionTimer = 10048;
    	
		//First, switch item to Paper
		else if(actionTimer == 10005 && blueNum != mod_Builders.explorerSingleBlockIndex)
			heldObj = new ItemStack(Item.paper, 1);
    	
		
		//Second, check each other spot needed to build house
    	//if buildPhase = 0 or - 1, all blocks return true
		else if(actionTimer == 10010){
			if(blueNum == -1){ //fail if blueprint invalid
				actionTimer = 10099;
			}
			if(!canPlaceBlock(iB + determineStructureRotation(true), jB + jA, kB + determineStructureRotation(false), jA) && (BLDRBlueprints.singlePrints.get(blueNum).get(jA).get(iA).get(kA) != 0)){ //Fail Case - Back to idle Phase
				actionTimer = 10099;
			}
			if(actionTimer != 10099 && incrementBuildIndex(BLDRBlueprints.singlePrints.get(blueNum).get(jA).get(iA).size(), BLDRBlueprints.singlePrints.get(blueNum).get(jA).size(), BLDRBlueprints.singlePrints.get(blueNum).size()) == 3){
				heldObj = null;
				actionTimer = 10048;
			}
		}
		
		//Have builder look at space that he wants to build in
		else if(actionTimer > 10010 && actionTimer <= 10013){
			faceBlock(iB + determineStructureRotation(true), jB + jA, kB + determineStructureRotation(false), 30F);
			if(((builderFlags >> 4) & 1) == 1 && actionTimer < 10013) actionTimer++;
		}
		
		//every quarter second, view next block in blueprints
		else if(actionTimer == 10014){
			actionTimer = 10009;
		}
		
		//If every spot checks out, then Enter building phases
		//First, check if spot is valid
		else if(actionTimer == 10050){
			if((BLDRBlueprints.singlePrints.get(blueNum).get(jA).get(iA).get(kA) == 0 && currentAction > 2)
					|| (currentAction == 1 && canPlaceBlock(iB + determineStructureRotation(true), jB - 1, kB + determineStructureRotation(false), -1))
					|| (currentAction == 2 && canPlaceBlock(iB + determineStructureRotation(true), jB + jA, kB + determineStructureRotation(false), jA))
					|| ((currentAction == 3 || currentAction == 4) && BLDRBlueprints.singlePrints.get(blueNum).get(jA).get(iA).get(kA) > 0 && (!Block.blocksList[BLDRBlueprints.singlePrints.get(blueNum).get(jA).get(iA).get(kA)].isOpaqueCube() || BLDRBlueprints.singlePrints.get(blueNum).get(jA).get(iA).get(kA) == Block.sand.blockID || BLDRBlueprints.singlePrints.get(blueNum).get(jA).get(iA).get(kA) == Block.gravel.blockID))
					|| (currentAction == 5 && (BLDRBlueprints.singlePrints.get(blueNum).get(jA).get(iA).get(kA) < 0 || (BLDRBlueprints.singlePrints.get(blueNum).get(jA).get(iA).get(kA) == 64 && worldObj.getBlockId(iB + determineStructureRotation(true), jB + jA, kB + determineStructureRotation(false)) == 64 || BLDRBlueprints.singlePrints.get(blueNum).get(jA).get(iA).get(kA) == 71 && worldObj.getBlockId(iB + determineStructureRotation(true), jB + jA, kB + determineStructureRotation(false)) == 71) || (Block.blocksList[BLDRBlueprints.singlePrints.get(blueNum).get(jA).get(iA).get(kA)].isOpaqueCube() && BLDRBlueprints.singlePrints.get(blueNum).get(jA).get(iA).get(kA) != Block.sand.blockID && BLDRBlueprints.singlePrints.get(blueNum).get(jA).get(iA).get(kA) != Block.gravel.blockID)))){ //if no block needed for spot, check next block
				if(BLDRBuilderConfig.buildAnywhere == true && BLDRBlueprints.singlePrints.get(blueNum).get(jA).get(iA).get(kA) == 0 && (currentAction == 3 || currentAction == 4))
					placeBlock(iB + determineStructureRotation(true), jB + jA, kB + determineStructureRotation(false), 0);
				if(currentAction == 3 && BLDRBlueprints.singlePrints.get(blueNum).get(jA).get(iA).get(kA) > 0 && !Block.blocksList[BLDRBlueprints.singlePrints.get(blueNum).get(jA).get(iA).get(kA)].isOpaqueCube())
					currentAction++;
				actionTimer = 10049;
				
				byte indexResult = incrementBuildIndex(BLDRBlueprints.singlePrints.get(blueNum).get(jA).get(iA).size(), BLDRBlueprints.singlePrints.get(blueNum).get(jA).size(), BLDRBlueprints.singlePrints.get(blueNum).size());
				if(currentAction == 1 && indexResult == 2){
					currentAction++;
					jA--;
				}
				else if(indexResult == 3){
					heldObj = null;
					//Enter next phase
					currentAction++;
					if(currentAction == 4 || currentAction == 6){
						buildCount--;
						actionTimer = 10099; //End Phase
						builderFlags &= ~(long)(1 << 1);
					}
				}
				
			}
			else if(!canPlaceBlock(iB + determineStructureRotation(true), jB + jA, kB + determineStructureRotation(false), jA) && currentAction > 2){ //Fail Case - Back to idle Phase
				actionTimer = 10099;
			}
			else{
				//determine hold item
				if(currentAction == 2)
					heldObj = this.determineDigItem(iB + determineStructureRotation(true), jB + jA, kB + determineStructureRotation(false));
				else if(currentAction == 1 || BLDRBlueprints.singlePrints.get(blueNum).get(jA).get(iA).get(kA) < 0)
					heldObj = new ItemStack(buildBlock, 1, 0);
				else
					heldObj = new ItemStack(BLDRBlueprints.singlePrints.get(blueNum).get(jA).get(iA).get(kA), 1, 0);
			}
		}
		
		//arm movement and turning toward build location
		else if(actionTimer > 10050 && actionTimer <= 10054){
			preBuildMovement(((actionTimer - 10050)*2), iB + determineStructureRotation(true), jB + jA, kB + determineStructureRotation(false));
			if(((builderFlags >> 4) & 1) == 1 && actionTimer < 10054) actionTimer++;
		}
		
		//block removal/placing phase
		else if(actionTimer == 10056){
			if(currentAction > 2 && !canPlaceBlock(iB + determineStructureRotation(true), jB + jA, kB + determineStructureRotation(false), jA)){ //Fail Case - Back to idle Phase
				actionTimer = 10099;
			}
			else{

				//place ground block (phase 1)
				int bID2 = worldObj.getBlockId(iB + determineStructureRotation(true), jB - 1, kB + determineStructureRotation(false));
				if(currentAction == 1){
					placeBlock(iB + determineStructureRotation(true), jB - 1, kB + determineStructureRotation(false), -1);	
				}
				//remove block (phase 2)
				else if(currentAction == 2){
					bID2 = worldObj.getBlockId(iB + determineStructureRotation(true), jB + jA, kB + determineStructureRotation(false));
					if(bID2 != 0 && bID2 != Block.fire.blockID && bID2 != Block.snow.blockID){
					int dropNum = Block.blocksList[bID2].quantityDropped(rand);
					if(dropNum <= 0)
						dropNum = 1;
					
					if(Block.blocksList[bID2].idDropped(0, rand) != 0 && (Block.blocksList[bID2].idDropped(0, rand) != Block.sapling.blockID || rand.nextInt(15) == 0)){
						ItemStack blockDrop;
						blockDrop = new ItemStack(Block.blocksList[bID2].idDropped(0, rand), dropNum, 0);
						EntityItem entityitem;
						entityitem = new EntityItem(worldObj, iB + determineStructureRotation(true), jB + jA + 0.4D, kB + determineStructureRotation(false), blockDrop);
						entityitem.delayBeforeCanPickup = 10;
						entityitem.age = 5400;
						worldObj.entityJoinedWorld(entityitem);
					}
					
					worldObj.playSoundAtEntity(this, Block.blocksList[worldObj.getBlockId(iB + determineStructureRotation(true), jB + jA, kB + determineStructureRotation(false))].stepSound.stepSoundDir(), getSoundVolume(), (rand.nextFloat() - rand.nextFloat()) * 0.2F + 1.0F);
					worldObj.setBlockWithNotify(iB + determineStructureRotation(true), jB + jA, kB + determineStructureRotation(false), 0);
					}
				}
				//place block (phase 1,2,3)
				else
					placeBlock(iB + determineStructureRotation(true), jB + jA, kB + determineStructureRotation(false), BLDRBlueprints.singlePrints.get(blueNum).get(jA).get(iA).get(kA));
				
				if(currentAction == 2 && (bID2 == Block.sand.blockID || bID2 == Block.gravel.blockID ))
					actionTimer = 10017;
				else{
					actionTimer = 10049;
					byte indexResult = incrementBuildIndex(BLDRBlueprints.singlePrints.get(blueNum).get(jA).get(iA).size(), BLDRBlueprints.singlePrints.get(blueNum).get(jA).size(), BLDRBlueprints.singlePrints.get(blueNum).size());
					if(currentAction == 1 && indexResult == 2){
						currentAction++;
						jA--;
					}
					else if(indexResult == 3){
						heldObj = null;
						//Enter next phase
						currentAction++;
						if(currentAction == 4 || currentAction == 6){
							buildCount--;
							actionTimer = 10099; //End Phase
							builderFlags &= ~(long)(1 << 1);
						}
						else
							actionTimer = 10048;
					}
				}
			}
		}
		
		//End Phase
		else if(actionTimer == 10100){
			actionTimer = 0; //Return to Idle Phase
			currentAction = 0; //Return to default action State
			noMove = false;
			heldObj = null;
			kA = 0;
			iA = 0;
			jA = 0;
			prevSwingProgress = 0.0F;
			swingProgress = 0.0F;
		}
    }
    
    //build wall for mayor
    public void mayorWallBuild(){
    	//Mayor Wall-Building Phase
		
    	//movement
		if(actionTimer > 10200 && actionTimer <= 10208 && leader instanceof BLDREntityMayor){
			BLDREntityMayor eM = (BLDREntityMayor) leader;
			preBuildMovement((actionTimer - 10200), eM.xM + eM.xMO, eM.yM + eM.yMO + eM.yMO2, eM.zM + eM.zMO);
			if(((builderFlags >> 4) & 1) == 1 && actionTimer < 10208) actionTimer++;
		}
		
		//if possible place block
		else if(actionTimer == 10209 && leader instanceof BLDREntityMayor){
			BLDREntityMayor eM = (BLDREntityMayor) leader;
			if(eM.mayorCounter < 10050 && !(eM.mayorCounter >= 9500 && eM.mayorCounter <= 9510)){
				actionTimer = 0;
				noMove = false;
				currentAction = 0;
				leader = null;
				eM.builderCount--;
			}
			else if(eM.mayorCounter >= 9500 && eM.mayorCounter <= 9510){ //if mayor has entered renovation mode, enter renovation mode
				actionTimer = 10600;
				yMHeight = MathHelper.floor_double(eM.boundingBox.minY);
			}
			
			if(actionTimer == 10209){
				placeBlock(eM.xM + eM.xMO, eM.yM + eM.yMO + eM.yMO2, eM.zM + eM.zMO, -1);
				actionTimer = 10200;
				if(eM.yMO2 < 2) //if 3 high spot isn't complete, place block.
					++eM.yMO2;
				else{
					eM.yMO2 = 0;
				
					//1. check x: 7 to -7 for all z+7
					if(eM.xMO > -(eM.townRadius * 2) && eM.zMO == 0){
						--eM.xMO;
						if(canPlaceBlock(eM.xM + eM.xMO, eM.yM + eM.yMO, eM.zM + eM.zMO, 0) && canPlaceBlock(eM.xM + eM.xMO, eM.yM + eM.yMO + 1, eM.zM + eM.zMO, 1) && canPlaceBlock(eM.xM + eM.xMO, eM.yM + eM.yMO + 2, eM.zM + eM.zMO, 1)){
							
						}
						else if(canPlaceBlock(eM.xM + eM.xMO, eM.yM + eM.yMO + 1, eM.zM + eM.zMO, 0) && canPlaceBlock(eM.xM + eM.xMO, eM.yM + eM.yMO + 2, eM.zM + eM.zMO, 1) && canPlaceBlock(eM.xM + eM.xMO, eM.yM + eM.yMO + 3, eM.zM + eM.zMO, 1)){
							++eM.yMO;
						}
						else if(canPlaceBlock(eM.xM + eM.xMO, eM.yM + eM.yMO - 1, eM.zM + eM.zMO, 0) && canPlaceBlock(eM.xM + eM.xMO, eM.yM + eM.yMO, eM.zM + eM.zMO, 1) && canPlaceBlock(eM.xM + eM.xMO, eM.yM + eM.yMO + 1, eM.zM + eM.zMO, 1)){
							--eM.yMO;
						}
						//if not placeable, fail process
						else{
							actionTimer = 0;
							noMove = false;
							eM.mayorCounter = 0;
							eM.noMove = false;
							eM.currentAction = 0;
						}
					}
					//2. check z: 7 to -7 for all x-7
					else if(eM.zMO > -(eM.townRadius * 2) && eM.xMO == -(eM.townRadius * 2)){
						--eM.zMO;
						if(canPlaceBlock(eM.xM + eM.xMO, eM.yM + eM.yMO, eM.zM + eM.zMO, 0) && canPlaceBlock(eM.xM + eM.xMO, eM.yM + eM.yMO + 1, eM.zM + eM.zMO, 1) && canPlaceBlock(eM.xM + eM.xMO, eM.yM + eM.yMO + 2, eM.zM + eM.zMO, 1)){
							
						}
						else if(canPlaceBlock(eM.xM + eM.xMO, eM.yM + eM.yMO + 1, eM.zM + eM.zMO, 0) && canPlaceBlock(eM.xM + eM.xMO, eM.yM + eM.yMO + 2, eM.zM + eM.zMO, 1) && canPlaceBlock(eM.xM + eM.xMO, eM.yM + eM.yMO + 3, eM.zM + eM.zMO, 1)){
							++eM.yMO;
						}
						else if(canPlaceBlock(eM.xM + eM.xMO, eM.yM + eM.yMO - 1, eM.zM + eM.zMO, 0) && canPlaceBlock(eM.xM + eM.xMO, eM.yM + eM.yMO, eM.zM + eM.zMO, 1) && canPlaceBlock(eM.xM + eM.xMO, eM.yM + eM.yMO + 1, eM.zM + eM.zMO, 1)){
							--eM.yMO;
						}
						//if not placeable, fail process
						else{
							actionTimer = 0;
							noMove = false;
							eM.mayorCounter = 0;
							eM.noMove = false;
							eM.currentAction = 0;
						}
					}
					//3. check x: -7 to 7 for all z-7
					else if(eM.xMO < 0 && eM.zMO == -(eM.townRadius * 2)){
						++eM.xMO;
						if(canPlaceBlock(eM.xM + eM.xMO, eM.yM + eM.yMO, eM.zM + eM.zMO, 0) && canPlaceBlock(eM.xM + eM.xMO, eM.yM + eM.yMO + 1, eM.zM + eM.zMO, 1) && canPlaceBlock(eM.xM + eM.xMO, eM.yM + eM.yMO + 2, eM.zM + eM.zMO, 1)){
							
						}
						else if(canPlaceBlock(eM.xM + eM.xMO, eM.yM + eM.yMO + 1, eM.zM + eM.zMO, 0) && canPlaceBlock(eM.xM + eM.xMO, eM.yM + eM.yMO + 2, eM.zM + eM.zMO, 1) && canPlaceBlock(eM.xM + eM.xMO, eM.yM + eM.yMO + 3, eM.zM + eM.zMO, 1)){
							++eM.yMO;
						}
						else if(canPlaceBlock(eM.xM + eM.xMO, eM.yM + eM.yMO - 1, eM.zM + eM.zMO, 0) && canPlaceBlock(eM.xM + eM.xMO, eM.yM + eM.yMO, eM.zM + eM.zMO, 1) && canPlaceBlock(eM.xM + eM.xMO, eM.yM + eM.yMO + 1, eM.zM + eM.zMO, 1)){
							--eM.yMO;
						}
						//if not placeable, fail process
						else{
							actionTimer = 0;
							noMove = false;
							eM.mayorCounter = 0;
							eM.noMove = false;
							eM.currentAction = 0;
						}
					}
					//4. check z: -7 to 7 for all x+7
					else if(eM.zMO < 0 && eM.xMO == 0){
						++eM.zMO;
						//if both zMO and xMO = 0, end building altogether
						if(eM.xMO == 0 && eM.zMO == 0){
							eM.mayorCounter = 9500;
						}
						else if(canPlaceBlock(eM.xM + eM.xMO, eM.yM + eM.yMO, eM.zM + eM.zMO, 0) && canPlaceBlock(eM.xM + eM.xMO, eM.yM + eM.yMO + 1, eM.zM + eM.zMO, 1) && canPlaceBlock(eM.xM + eM.xMO, eM.yM + eM.yMO + 2, eM.zM + eM.zMO, 1)){
							
						}
						else if(canPlaceBlock(eM.xM + eM.xMO, eM.yM + eM.yMO + 1, eM.zM + eM.zMO, 0) && canPlaceBlock(eM.xM + eM.xMO, eM.yM + eM.yMO + 2, eM.zM + eM.zMO, 1) && canPlaceBlock(eM.xM + eM.xMO, eM.yM + eM.yMO + 3, eM.zM + eM.zMO, 1)){
							++eM.yMO;
						}
						else if(canPlaceBlock(eM.xM + eM.xMO, eM.yM + eM.yMO - 1, eM.zM + eM.zMO, 0) && canPlaceBlock(eM.xM + eM.xMO, eM.yM + eM.yMO, eM.zM + eM.zMO, 1) && canPlaceBlock(eM.xM + eM.xMO, eM.yM + eM.yMO + 1, eM.zM + eM.zMO, 1)){
							--eM.yMO;
						}
						//if not placeable, fail process
						else{
							actionTimer = 0;
							noMove = false;
							eM.mayorCounter = 0;
							eM.noMove = false;
							eM.currentAction = 0;
						}
						
					}
				}
			}
		}
		else if(actionTimer > 10214){
			actionTimer = 0;
			currentAction = 0;
			prevSwingProgress = 0.0F;
			swingProgress = 0.0F;
		}
    }
    
    //check and modify town chest
    public void checkTownChest(){
    	//Begin trade chest phase
		if(actionTimer == 101){
			int gtItem = rand.nextInt(10);
			if(gtItem < 2 && tradeGiveNum > 0){ //place item in chest (20% chance)
				heldObj = getChestItem();
				noMove = true;
				setPosition(posX, MathHelper.floor_double(boundingBox.minY), posZ);
			}
			else if(gtItem > 1 && gtItem < 6){ //take item from chest (40% chance)
				actionTimer = 126;
				heldObj = null;
				noMove = true;
				setPosition(posX, MathHelper.floor_double(boundingBox.minY), posZ);
			}
			else //Do nothing (40% chance)
				actionTimer = 0;
		}
		else if(actionTimer > 107 && actionTimer < 116){
			preBuildMovement(116 - actionTimer, xT, yT, zT);
		}
		else if(actionTimer == 116){ //add item to chest
			if(modifyTownChest(true, heldObj.copy()))
				tradeGiveNum--;
			actionTimer = 0;
			heldObj = null;
			noMove = false;
			prevSwingProgress = 0F;
			swingProgress = 0F;
		}
		else if(actionTimer > 126 && actionTimer < 135){
			preBuildMovement(8 - (135 - actionTimer), xT, yT, zT);
		}
		else if(actionTimer == 136){ //take item from chest
			if(modifyTownChest(false, heldObj)){
				if(heldObj != null)
					tradeReceiveNum += heldObj.stackSize;
			}
		}
		else if(actionTimer >= 146){ //end trade chest phase
			actionTimer = 0;
			heldObj = null;
			noMove = false;
			prevSwingProgress = 0F;
			swingProgress = 0F;
			while(tradeReceiveNum > tradeRatio){
				tradeReceiveNum = tradeReceiveNum - tradeRatio;
				tradeGiveNum++;
			}
		}
    }
    
    //Renovate half of town to be flat.
    public void townRenovation(){
    	//Begin Mayor-Ground Renovation Phase
		//Select Block to renovate, based on Mayor's M coordinates
	if(actionTimer == 10603 && leader instanceof BLDREntityMayor){
		
		BLDREntityMayor eM = (BLDREntityMayor) leader;
		if(eM.mayorCounter < 9502 && eM.mayorCounter > 8999)
			actionTimer--;
		else if(eM.mayorCounter < 9600 && eM.mayorCounter >= 9502){
			xMDig = eM.xM;
			yMDig = eM.yM;
			zMDig = eM.zM;
			int yMDig2 = yMDig + 10;
			
			//increment y pointer until top block found
			while(!worldObj.canBlockSeeTheSky(xMDig, yMDig, zMDig) && yMDig < yMDig2)
				yMDig++;
			
			//change mayor's x and z pointers as necessary
			eM.zM++;
			if(eM.zM > MathHelper.floor_double(eM.posZ) + (eM.townRadius - 1)){
				eM.zM = MathHelper.floor_double(eM.posZ) - (eM.townRadius - 1);
				eM.xM++;
				if(eM.xM > MathHelper.floor_double(eM.posX) - 1){
					//end renovation
					eM.mayorCounter = 9600;
					
				}
			}
			
		}
		else{
			eM.builderCount--;
			if(eM.traderMax < (eM.townRadius - 1) / 2){
				//replace builder with new Trader or Baker
				BLDREntityBuilder eT;
				if(eM.traderMax == 0) //first trader is always Baker
					eT = new BLDREntityBaker(worldObj);
				else
					eT = new BLDREntityTrader(worldObj);
				eT.setPosition(posX, posY, posZ);
				eT.name = this.name;
				eT.texture = this.texture;
				eT.buildBlock = this.buildBlock;
				if(worldObj.entityJoinedWorld(eT)){
					isDead = true;
					eT.iB = MathHelper.floor_double(eM.posX) - (eM.townRadius - 1);
					eT.jB = MathHelper.floor_double(eM.boundingBox.minY);
					eT.kB = MathHelper.floor_double(eM.posZ);
					eT.direction = 0;
					eT.currentAction = 3;
					eT.actionTimer = 10000;
					eT.noMove = true;
					eT.kB -= (eM.townRadius - 1 - (4 * eM.traderMax));
				
					eM.traderMax++;
				}
				else{
					noMove = false;
					currentAction = 0;
					actionTimer = 0;
					leader = null;
					prevSwingProgress = 0F;
					swingProgress = 0F;
					heldObj = null;
				}
			}
			else{
				noMove = false;
				currentAction = 0;
				actionTimer = 0;
				leader = null;
				prevSwingProgress = 0F;
				swingProgress = 0F;
				heldObj = null;
				prevSwingProgress = 0.0F;
				swingProgress = 0.0F;
			}
		}
	}
	else if(actionTimer == 10603 && !(leader instanceof BLDREntityMayor)){
		actionTimer = 0;
		noMove = false;
		prevSwingProgress = 0F;
		swingProgress = 0F;
		heldObj = null;
		currentAction = 0;
	}
	//either skip down 1 block, dig/mine the block, or place a block
	else if(actionTimer == 10605 && leader instanceof BLDREntityMayor){
		//EntityMayor eM = (EntityMayor) leader;
		//if not level with mayor, and there is block, renovate block(timer not changed)

		int bID2 = worldObj.getBlockId(xMDig, yMDig, zMDig);
		if(yMHeight - 1 < yMDig && (bID2 != 0 && bID2 != Block.fire.blockID && bID2 != Block.snow.blockID)){
			heldObj = this.determineDigItem(xMDig, yMDig, zMDig);
		}
		//if not level with mayor, and no block(air), skip down 1 block(timer = 10604)
		else if(yMHeight - 1 < yMDig && (bID2 == 0 || bID2 == Block.fire.blockID || bID2 == Block.snow.blockID)){
			yMDig--;
			actionTimer = 10604;
		}
		//if level with block underneath mayor, and no block, place build block(timer = 10620)
		else if(yMHeight - 1 >= yMDig &&(bID2 == 0 || bID2 == Block.fire.blockID || bID2 == Block.snow.blockID)){
			actionTimer = 10620;
			heldObj = new ItemStack(buildBlock, 1, 0);
		}
		//if level with block underneath mayor, and block, get next block from mayor
		else
			actionTimer = 10601;
	}
	//movement for mining/digging block
	else if(actionTimer > 10607 && actionTimer <= 10616){
		preBuildMovement(8 - (10616 - actionTimer), xMDig, yMDig, zMDig);
		if(((builderFlags >> 4) & 1) == 1 && actionTimer < 10616) actionTimer++;
	}
	//Remove block, and spawn block_destroyed item if possible
	else if(actionTimer == 10617){
		//remove block and spawn item that block gives
		int bID2 = worldObj.getBlockId(xMDig, yMDig, zMDig);
		if(bID2 != 0 && bID2 != Block.fire.blockID && bID2 != Block.snow.blockID){
			int dropNum = Block.blocksList[bID2].quantityDropped(rand);
			if(dropNum <= 0)
				dropNum = 1;
			
			if(Block.blocksList[bID2].idDropped(0, rand) != 0 && (Block.blocksList[bID2].idDropped(0, rand) != Block.sapling.blockID || rand.nextInt(15) == 0)){
				ItemStack blockDrop;
				blockDrop = new ItemStack(Block.blocksList[bID2].idDropped(0, rand), dropNum, 0);
				EntityItem entityitem;
				entityitem = new EntityItem(worldObj, xMDig, yMDig + 0.4, zMDig, blockDrop);
				entityitem.delayBeforeCanPickup = 10;
				entityitem.age = 5400;
				worldObj.entityJoinedWorld(entityitem);
			}
			
			worldObj.playSoundAtEntity(this, Block.blocksList[worldObj.getBlockId(xMDig, yMDig, zMDig)].stepSound.stepSoundDir(), getSoundVolume(), (rand.nextFloat() - rand.nextFloat()) * 0.2F + 1.0F);
			worldObj.setBlockWithNotify(xMDig, yMDig, zMDig, 0);
			
		}
    	//check next block down
    	actionTimer = 10604;
    	yMDig--;
	}
	//movement for placing final block
	else if(actionTimer > 10622 && actionTimer <= 10631){
		preBuildMovement(8 - (10631 - actionTimer), xMDig, yMDig, zMDig);
		if(((builderFlags >> 4) & 1) == 1 && actionTimer < 10631) actionTimer++;
	}
	//Place final block if needed
	else if(actionTimer == 10632){
		//place block
		int bID2 = worldObj.getBlockId(xMDig, yMDig, zMDig);
		if(bID2 == 0 || bID2 == Block.fire.blockID || bID2 == Block.snow.blockID){
			this.placeBlock(xMDig, yMDig, zMDig, buildBlock);
		}
    	//get next block to renovate
    	actionTimer = 10601;
	}
	//end phase
	else if(actionTimer > 10633 ){
		actionTimer = 0;
		noMove = false;
		prevSwingProgress = 0F;
		swingProgress = 0F;
		heldObj = null;
		currentAction = 0;
	}
    }
    /* DIRECTION 0 - No Metadata Change
     * 1 2 3 4 5
     * 6 7 8 9 1
     * 2 D 4 5 6
     * \
     * DIRECTION 1 -
     * 6 5 4 D 2
     * 1 9 8 7 6
     * 5 4 3 2 1
     */
    public int determineStructureRotation(boolean b){
    	//true is for x axis, and false is for z axis
    	switch(direction){
    	case 0:
    		return b ? iA : kA; //no metadata change
    	case 1:
    		return b ? (-iA) : (-kA);
    	case 2:
    		return b ? iA : (-kA);
    	case 3:
    		return b ? (-iA) : kA;
    	case 4:
    		return b ? kA : iA;
    	case 5:
    		return b ? (-kA) : (-iA);
    	case 6:
    		return b ? kA : (-iA);
    	case 7:
    		return b ? (-kA) : iA;
    	default:
    		return b ? iA : kA;
    	}
    }
    
    protected boolean isAlwaysHappy(){
    	return false;
    }
    
    //used for Builders who claim ownership of a place that is available for rent
    public void claimOwnership(BLDRBuilderSigns b){
    	currentAction = 20;
    	actionTimer = 0;
    	homeX = b.xCoord;
    	homeY = b.yCoord;
    	homeZ = b.zCoord;
    	homeRange = b.num1;
    	
    	//determine attitude
    	int temp = rand.nextInt(homeDescrip.length);
    	
    	//if homeseeker, attitude always is good
    	while(isAlwaysHappy() && temp >= 7)
    		temp -= 7;
    	
    	if(temp < 7)
    		homeAttitude = 0; //Grateful
    	else if(temp < 17)
        	homeAttitude = 1; //Satisfied
    	else
    		homeAttitude = 2; //Unappreciative
    	

    	actionTimer = (short) (rentDelays[homeAttitude] - 3);
    	
    	//change text of sign
    	TileEntitySign tes = (TileEntitySign) worldObj.getBlockTileEntity(homeX, homeY, homeZ);
    	tes.signText[0] = "Welcome to";
    	tes.signText[1] = name.concat("'s");
    	tes.signText[2] = homeDescrip[temp];
    	tes.signText[3] = "home";
    	
    	//if player within range, give a happy message from Builder
    	if(mod_Builders.minecraft_b.thePlayer != null && !mod_Builders.minecraft_b.thePlayer.isDead && this.getDistanceToEntity(mod_Builders.minecraft_b.thePlayer) < 10){
    		String str;
    		if(homeAttitude == 0)
    			str = (new StringBuilder().append("�2<").append(this.name)).append("> �1Thanks for giving me a place to live!").toString();
    		else if(homeAttitude == 1)
    			str = (new StringBuilder().append("�2<").append(this.name)).append("> �1I agree to rent this location.").toString();
    		else
    			str = (new StringBuilder().append("�2<").append(this.name)).append("> �1Is this it? Fine. I'll live in this dump...").toString();
			mod_Builders.minecraft_b.ingameGUI.addChatMessage(str);
    	}
    }
    
    public boolean canRenovateBuild(){
    	return false;
    }
    
    private void stateNextBlueprint(){
    	//modify blueNum to next bluePrint
		blueNum++;
		if(blueNum >= BLDRBlueprints.singlePrints.size())
			blueNum = 0;
		//if no buildCounts left, add one
		if(buildCount == 0)
			buildCount++;
		//set actionTimer to 0
		actionTimer = 0;
		
		//display message from builder stating what he will build
		String str = (new StringBuilder().append("<").append(this.name)).append("> Ready to build ").append(BLDRBlueprints.singlePrintNames.get(blueNum)).append("!").toString();
		mod_Builders.minecraft_b.ingameGUI.addChatMessage(str);
    }
    
    private void payPlayer(){
    	//if player not available, cancel
		if(mod_Builders.minecraft_b.thePlayer == null || mod_Builders.minecraft_b.thePlayer.isDead){
			payTimer = -1;
			noMove = false;
			swingProgress = 0F;
			prevSwingProgress = 0F;
		}
		else if(payTimer == 0){
			heldObj = null;
			noMove = true;
			setPosition(posX, MathHelper.floor_double(boundingBox.minY), posZ);
		}
		else if(payTimer < 8){
			preBuildMovement(8 - payTimer, MathHelper.floor_double(mod_Builders.minecraft_b.thePlayer.posX), MathHelper.floor_double(mod_Builders.minecraft_b.thePlayer.posY), MathHelper.floor_double(mod_Builders.minecraft_b.thePlayer.posZ));
		}
		else if(payTimer == 8){
			payTimer = -2;
			noMove = false;
			
			//spawn all necessary trade items at player
			for(int i = 0; i < rentPayments; i++)
	        	worldObj.entityJoinedWorld(new EntityItem(worldObj, mod_Builders.minecraft_b.thePlayer.posX, mod_Builders.minecraft_b.thePlayer.posY + 0.2D, mod_Builders.minecraft_b.thePlayer.posZ, this.getChestItem()));
			
			rentPayments = 0;
			swingProgress = 0F;
			prevSwingProgress = 0F;
		}
		
		payTimer++;
    }
    
    private void throwMeatAndRun(){
    	//if target does not exist, cancel process
		if(tossMeat == null && actionTimer <= 9){
			actionTimer = 0;
			currentAction = 0;
			prevSwingProgress = 0;
			swingProgress = 0;
		}
		else if(actionTimer == 0){
			playerToAttack = tossMeat;
		}
		else if(actionTimer < 9){
			prevSwingProgress = 0.125F * actionTimer;
			swingProgress = 0.125F * actionTimer;
		}
		else if(actionTimer == 9){
			prevSwingProgress = 0;
			swingProgress = 0;
			playerToAttack = null;
			moveSpeed *= 4.0F;
			
			//determine run direction
			double xDif = (posX - tossMeat.posX);
	    	double zDif = (posZ - tossMeat.posZ);
	    	if(xDif < 0 && zDif < 0)
	    		runDirection = 1;
	    	else if(xDif >= 0 && zDif >= 0)
	    		runDirection = 2;
	    	else if(xDif < 0 && zDif >= 0)
	    		runDirection = 3;
	    	else if(xDif >= 0 && zDif < 0)
	    		runDirection = 4;
	    	else
	    		runDirection = 0;
	    	
			//create EntityItem for raw meat, that cannot be picked up, and will despawn in 15 seconds
	    	EntityItem meat = new EntityItem(worldObj, posX, posY, posZ, getThrownItem());
	    	if(worldObj.entityJoinedWorld(meat)){
	    		meat.age = 5700;
	    		meat.delayBeforeCanPickup = 600;
	    		meat.motionY = 0.5 + rand.nextFloat() / 2;
	    		meat.motionX = xDif >= 0 ? -0.56D : 0.56D;
	    		meat.motionZ = zDif >= 0 ? -0.56D : 0.56D;
	    		tossMeat.playerToAttack = meat;
	    		tossMeat = null;
	    	}
		}
		else if(actionTimer > 300){
			actionTimer = 0;
			currentAction = 0;
			runDirection = 0;
			moveSpeed = moveSpeed / 4.0F;
		}
    }
    
    private void checkForBuilderSigns(){
    	for(int i = 0; i < mod_Builders.signsList.size(); i++){
			BLDRBuilderSigns b = mod_Builders.signsList.get(i);
			
			//if variable is null, remove from list
			if(b == null){
				mod_Builders.signsList.remove(i);
				i--;
				continue;
			}
			//only check signs within range
			else if(this.getDistance(b.xCoord, b.yCoord, b.zCoord) < b.range){
				//if sign does not exist, remove from list
				if(!b.signExists()){
					mod_Builders.signsList.remove(i);
					i--;
					continue;
				}
				
				//If sign is For Rent Sign, assign that location as home.
				if(b.type == 1){
					claimOwnership(b);
					mod_Builders.signsList.remove(i);
					i--;
					break;
				}
				
				//If Construction Zone sign, set ready to build
				else if(b.type == 2){
					if(actionTimer < maxWait - 3)
						actionTimer = (short) (maxWait - 3);
					if(buildCount <= 0)
						buildCount = 1;
					continue;
				}
				
				//If Private Property sign, set actionTimer, mayorCounter, and breakTimer to 0
				//but only if not told to renovate
				else if(b.type == 3 && currentAction != 1){
					actionTimer = 0;
					setTimers((short) 0);
					continue;
				}
			}
		}
    }
    
    private void handleRent(){
    	if(actionTimer >= (((builderFlags >> 5) & 1) == 1 ? rentDelays[homeAttitude] / 3 : rentDelays[homeAttitude])){
			actionTimer = 0;
			rentPayments++;
		}
		if(rentPayments > 0 && payTimer == -1 && mod_Builders.minecraft_b.thePlayer != null 
			&& !mod_Builders.minecraft_b.thePlayer.isDead && this.getDistanceToEntity(mod_Builders.minecraft_b.thePlayer) < 8){
		
			//Builder states rent is coming
			String str;
			if(homeAttitude == 0)
				str = (new StringBuilder().append("�2<").append(this.name)).append("> �1Here's the rent for such a great place to live!").toString();
			else if(homeAttitude == 1)
				str = (new StringBuilder().append("�2<").append(this.name)).append("> �1Here is today's rent.").toString();
			else
				str = (new StringBuilder().append("�2<").append(this.name)).append("> �1Ugh... fine, I'll hand over the rent for this crummy place.").toString();
			mod_Builders.minecraft_b.ingameGUI.addChatMessage(str);
			
		//begin payment process
			payTimer = 0;
		}
    }
    
    protected boolean uniDirectionalStructures(){
    	return false;
    }
    
    protected float updateBuilderRotation(float f, float f1, float f2)
    {
        float f3;
        for(f3 = f1 - f; f3 < -180F; f3 += 360F) { }
        for(; f3 >= 180F; f3 -= 360F) { }
        if(f3 > f2)
        {
            f3 = f2;
        }
        if(f3 < -f2)
        {
            f3 = -f2;
        }
        return f + f3;
    }
    
    protected byte incrementBuildIndex(int sizeZ, int sizeX, int sizeY){
    	kA++;
		if(kA >= sizeZ){
			kA = 0;
			iA++;
			if(iA >= sizeX){
				iA = 0;
				jA++;
				if(jA >= sizeY){
					kA = 0;
					iA = 0;
					jA = 0;
					return 3;
				}
				return 2;
			}
			return 1;
		}
		return 0;
    }
    
    //called when actionTimer = maxWait
    protected void selectIdleAction(){
    	if(((actionTimer >> 14) & 1) == 1) {
    		currentAction = 3;
    		return;
    	}
    	switch(BLDRBuilderConfig.freeLanceStyle){
    	case 0: //no freelance building
    		break;
    	case 1: //build anywhere
    		currentAction = 3;
    		break;
    	case 2:
    		if(withinBuildRegion((int) (posX / 16), (int) (posZ / 16))) currentAction = 3;
    		break;
    	case 3:
    		if(withinBuildRegion((int) (posX / 16) + getChunkOffsetX(), (int) (posZ / 16) + getChunkOffsetZ())) currentAction = 3;
    		break;
    	default:
    		break;
    	}
    }
    
    protected boolean withinBuildRegion(int xChunk, int zChunk){
    	int regionX = Math.abs(xChunk / 8);
    	int regionZ = Math.abs(zChunk / 8);
    	return regionX % 2 == 1 && regionZ % 2 == 1;
    }
    
    protected int getChunkOffsetX(){
    	return 0;
    }
    
    protected int getChunkOffsetZ(){
    	return 0;
    }
    
    protected boolean canTossMeat(){
    	return true;
    }
    
    protected void idleUpdate(){
    	if((actionTimer & 2047) == maxWait){
    		selectIdleAction();
    		actionTimer = 0;
    	}
    	/*else if(((builderFlags >> 7) & 1) == 1 && findPlaceToClimbTo()){
    		actionTimer = 0;
    		currentAction = 21;
    	}*/
    }
    
    protected void tradeChestUpdate(){
    	if(actionTimer < (((builderFlags >> 3) & 1) == 1 ? 25 : 50) && (getDistance(xT, yT, zT) > tradeChestDistance * 2 || worldObj.getBlockTileEntity(xT, yT, zT) == null)){
			currentAction = 0;
			actionTimer = 0;
			return;
		}
		else if(actionTimer == (((builderFlags >> 3) & 1) == 1 ? 25 : 50)){
			//modify chest
			if(getDistance(xT, yT, zT) <= tradeChestDistance)
				actionTimer = 100;
			else
				actionTimer = 0;
		}
		else if(actionTimer >= 100){
			//modify chest
			checkTownChest(); //Check Town Chest and modify contents
		}
    }
    
    protected boolean canBeHurt(){
    	return currentAction >= 7 && currentAction <= 10 || currentAction >= 18 && currentAction <= 20;
    }
    
    protected ItemStack getThrownItem(){
    	return new ItemStack(Item.stick);
    }
    
    protected void setTimers(short x){
    	
    }
    
    protected void initConvert(int x, String s){
    	
    }
    
    protected void healWeakTarget(EntityLiving healTarget, boolean b){
    	if(heldObj != null && heldObj.getItem() instanceof ItemFood && getDistanceToEntity(healTarget) > 6D){
			prevSwingProgress = 0.0F;
			swingProgress = 0.0F;
    		heldObj = null;
    	}
    	if(actionTimer == 0 && getDistanceToEntity(healTarget) <= 6D){
    		if(b || !b && healTarget.health < 10){
    			heldObj = getHealingItem();
    		}
    	}
    	else if(actionTimer > 0 && actionTimer < 17){ //handle hand motion
			prevSwingProgress = 0.0625F * actionTimer;
			swingProgress = 0.0625F * actionTimer;
    	}
    	else if(actionTimer == 17){
			prevSwingProgress = 0.0F;
			swingProgress = 0.0F;
    		healTarget.heal(((ItemFood)heldObj.getItem()).getHealAmount());
    		heldObj = null;
			worldObj.playSoundAtEntity(this, "builder.explorerGulp", getSoundVolume(), (rand.nextFloat() - rand.nextFloat()) * 0.2F + 1.0F);
			mod_Builders.spawnParticlesAtEntity(this, "reddust", 16);
    	}
    	
    }
    
    public int getMaxHp(){
    	return 20;
    }
    
    public int getClimbBlockID(){
    	return buildBlock;
    }
    
    protected ItemStack getHealingItem(){
    	return new ItemStack(Item.appleGold);
    }
    
    //Returns true if can climb up to higher block
    /*public boolean findPlaceToClimbTo(){
    	if(rand.nextFloat() > 0.03F) return false; //only 3% chance to attempt a climb
    	int i = MathHelper.floor_double(posX);
    	int j = MathHelper.floor_double(boundingBox.minY);
    	int k = MathHelper.floor_double(posZ);
    	if(j + 16 > 127) return false;
    	
    	//get highest air block above self
    	int airhead;
    	for(airhead = j + 2; worldObj.isAirBlock(i, airhead, k) && airhead < j + 16; airhead++);
    	//check all 8 directions
    	int high = 0;
    	int next;
    	for(next = j + 2; !worldObj.isAirBlock(i - 1, next, k) && next < j + 16; next++);
    	if(next > high && airhead > next + 2) high = next;
    	for(next = j + 2; !worldObj.isAirBlock(i + 1, next, k) && next < j + 16; next++);
    	if(next > high && airhead > next + 2) high = next;
    	for(next = j + 2; !worldObj.isAirBlock(i, next, k) && next < j + 16; next++);
    	if(next > high && airhead > next + 2) high = next;
    	for(next = j + 2; !worldObj.isAirBlock(i - 1, next, k - 1) && next < j + 16; next++);
    	if(next > high && airhead > next + 2) high = next;
    	for(next = j + 2; !worldObj.isAirBlock(i + 1, next, k - 1) && next < j + 16; next++);
    	if(next > high && airhead > next + 2) high = next;
    	for(next = j + 2; !worldObj.isAirBlock(i, next, k - 1) && next < j + 16; next++);
    	if(next > high && airhead > next + 2) high = next;
    	for(next = j + 2; !worldObj.isAirBlock(i - 1, next, k + 1) && next < j + 16; next++);
    	if(next > high && airhead > next + 2) high = next;
    	for(next = j + 2; !worldObj.isAirBlock(i + 1, next, k + 1) && next < j + 16; next++);
    	if(next > high && airhead > next + 2) high = next;
    	for(next = j + 2; !worldObj.isAirBlock(i, next, k + 1) && next < j + 16; next++);
    	if(next > high && airhead > next + 2) high = next;
    	
    	if(high == 0) return false;
    	
    	heightToClimb = (byte) (high - j);
    	return true;
    }*/
    
    protected void setRandomCharacteristics(){
    	if(rand.nextFloat() < 0.45F) builderFlags |= (1 << 3); //trades twice as often
    	if(rand.nextFloat() < 0.4F) builderFlags |= (1 << 4); //builds twice as fast
    	if(rand.nextFloat() < 0.2F) builderFlags |= (1 << 5); //pays rent three times as often
    	if(rand.nextFloat() < 0.3F) builderFlags |= (1 << 6); //heals weak leader while following leader
    	//if(rand.nextFloat() < 0.25F) builderFlags |= (1 << 7); //if wandering while idle, will use blocks to get up to high locations
    }
    
    protected String getName(){
    	return Names[rand.nextInt(Names.length)];
    }
    
    protected void checkForHighlight(){
    	if(mod_Builders.minecraft_b != null && mod_Builders.minecraft_b.objectMouseOver != null && mod_Builders.minecraft_b.objectMouseOver.typeOfHit == EnumMovingObjectType.ENTITY && mod_Builders.minecraft_b.objectMouseOver.entityHit == this)
    		mouseHighlight = true;
    	else
    		mouseHighlight = false;
    }
    
    protected String getActionDescrip(){
    	switch(currentAction){
    	case 0:
    		return "Idle";
    	case 1:
    		if(blueNum < 0) return "Nothing";
    		else return "Placing floor blocks for ".concat(BLDRBlueprints.singlePrintNames.get(blueNum));
    	case 2:
    		if(blueNum < 0) return "Nothing";
    		else return "Renovating terrain for ".concat(BLDRBlueprints.singlePrintNames.get(blueNum));
    	case 3:
    		if(blueNum < 0) return "Nothing";
    		else return (actionTimer < 10015 ? "Preparing to build ": "Placing solid blocks for ").concat(BLDRBlueprints.singlePrintNames.get(blueNum));
    	case 4:
    		if(blueNum < 0) return "Nothing";
    		else return (actionTimer < 10015 ? "Preparing to build ": "Placing solid blocks for ").concat(BLDRBlueprints.singlePrintNames.get(blueNum));
    	case 5:
    		if(blueNum < 0) return "Nothing";
    		else return "Placing non-solid blocks for ".concat(BLDRBlueprints.singlePrintNames.get(blueNum));
    	case 6:
    		if(blueNum < 0) return "Nothing";
    		else return "Done building ".concat(BLDRBlueprints.singlePrintNames.get(blueNum));
    	case 7:
    		return "Following";
    	case 8:
    		if(leader instanceof BLDREntityBuilder)
    			return "Aiding Mayor ".concat(((BLDREntityBuilder)leader).name);
    		else return "Nothing";
    	case 9:
    		return "Following & Ready to Renovate";
    	case 10:
    		return "Ready to Renovate";
    	case 18:
    		return "Trading in town";
    	case 19:
    		return "Fleeing";
    	case 20:
    		return "Renting";
    	default:
    		return "Unknown";
    	}
    }
    /*
    *//**
	 * @purpose This method sets all of the default values for this action
	 *//*
	protected static void setDefaultValues(BLDREntityBuilder ess){
		ess.nums = new float[5];
    	ess.nums[0] = 0.0F; //block damage
    	ess.nums[1] = 0.0F; //block damage sound effect
    	ess.nums[2] = 0.0F; //number blocks destroyed
    	ess.nums[3] = 9999F; //rotationYaw
    	ess.nums[4] = 9999F; //rotationPitch
    	ess.prevSwingProgress = 0.0F;
    	ess.swingProgress = 0.0F;
    	//ess.actionTimer = 10;
	}
    
    *//**
	 * @purpose This method makes the survivor turn his head toward his coordinates.
	 *//*
    protected static void faceCoordinates(BLDREntityBuilder ess){
		if(ess.nums[3] == 9999F) ess.nums[3] = ess.rotationYaw;
		if(ess.nums[4] == 9999F) ess.nums[4] = ess.rotationPitch;
		double d = ess.coords[0] - ess.posX;
        double d2 = ess.coords[2] - ess.posZ;
        double d1;
        float f = 30F;
        d1 = ess.coords[1] - (ess.posY + (double)ess.getEyeHeight());
        double d3 = MathHelper.sqrt_double(d * d + d2 * d2);
        float f1 = (float)((Math.atan2(d2, d) * 180D) / 3.1415927410125732D) - 90F;
        float f2 = (float)(-(Math.atan2(d1, d3) * 180D) / 3.1415927410125732D);
        ess.prevRotationPitch = ess.nums[4];
        ess.prevRotationYaw = ess.nums[3];
        ess.nums[4] = updateSurvivorRotation(ess.nums[4], f2, f); //minus removed
        ess.nums[3] = updateSurvivorRotation(ess.nums[3], f1, f);
        ess.rotationYaw = ess.nums[3];
        ess.rotationPitch = ess.nums[4];
	}
	
	protected static float updateSurvivorRotation(float f, float f1, float f2)
    {
        float f3;
        for(f3 = f1 - f; f3 < -180F; f3 += 360F) { }
        for(; f3 >= 180F; f3 -= 360F) { }
        if(f3 > f2)
        {
            f3 = f2;
        }
        if(f3 < -f2)
        {
            f3 = -f2;
        }
        return f + f3;
    }
	
	*//**
	 * @purpose This method makes the survivor emulate the arm swinging and block destroying behavior of a player.
	 * @num[0] Used as currentDamage
	 * @num[1] Used for block damaging sound
	 * @num[2] Used for total number of blocks collected
	 * @num[3] Used for handling rotationYaw
	 * @num[4] Used for handling rotationPitch
	 *//*
	protected static void swingToolAndDamageBlock(BLDREntityBuilder ess){
		//get block at coordinates
		faceCoordinates(ess);
		int bid = ess.worldObj.getBlockId(ess.coords[0], ess.coords[1], ess.coords[2]);
		Block block = Block.blocksList[bid];
		if(block != null){
			//block cracking effect
			//drawBlockBreaking(ess, 1.0F); //probably won't work right
			//block destroying effect
			ModLoader.getMinecraftInstance().effectRenderer.addBlockHitEffects(ess.coords[0], ess.coords[1], ess.coords[2], ess.rand.nextInt(6));
			
			//block sound effect
			ess.nums[1] = ess.nums[1] > 400F ? 0.0F : ess.nums[1] + 1.0F;
			if(ess.nums[1] % 4F == 0.0F)
        	{
            	ModLoader.getMinecraftInstance().sndManager.playSound(block.stepSound.func_1145_d(), (float)ess.coords[0] + 0.5F, (float)ess.coords[1] + 0.5F, (float)ess.coords[2] + 0.5F, (block.stepSound.getVolume() + 1.0F) / 8F, block.stepSound.getPitch() * 0.5F);
        	}
			
			//arm swinging effect
			swingArm(ess);
			
			//block destroying progress
			ess.nums[0] += ess.blockStrength(block);
			if(ess.nums[0] > 1.0F){ //block destruction complete
		    	
				//block destruction effect
				ModLoader.getMinecraftInstance().effectRenderer.addBlockDestroyEffects(ess.coords[0], ess.coords[1], ess.coords[2], bid, 0);
				
				//destroy block
				ItemStack itemstack = ess.pack.getCurrentItem();
		        boolean flag1 = ess.canHarvestBlock(Block.blocksList[bid]);
		        if(itemstack != null && itemstack.itemID > 255) //damage item
		        {
		        	Item.itemsList[itemstack.itemID].onBlockDestroyed(itemstack, ess.coords[0], ess.coords[1], ess.coords[2], 0, ess);
		            if(itemstack.stackSize == 0)
		            {
		                ess.pack.setInventorySlotContents(ess.pack.currentItem, null);
		            }
		        }
		        if(flag1)
		        {
		        	int i1 = bid == Block.snow.blockID ? 1 : Block.blocksList[bid].quantityDropped(ess.worldObj.rand);
		                for(int j1 = 0; j1 < i1; j1++)
		                {
		                     int k1 = bid == Block.snow.blockID ? Item.snowball.shiftedIndex : Block.blocksList[bid].idDropped(0, ess.worldObj.rand);
		                    if(k1 > 0)
		                    {
		                        float f1 = 0.7F;
		                        double d = (double)(ess.worldObj.rand.nextFloat() * f1) + (double)(1.0F - f1) * 0.5D;
		                        double d1 = (double)(ess.worldObj.rand.nextFloat() * f1) + (double)(1.0F - f1) * 0.5D;
		                        double d2 = (double)(ess.worldObj.rand.nextFloat() * f1) + (double)(1.0F - f1) * 0.5D;
		                        EntityItem entityitem = new EntityItem(ess.worldObj, (double)ess.coords[0] + d, (double)ess.coords[1] + d1, (double)ess.coords[2] + d2, new ItemStack(k1, 1, Block.blocksList[bid].damageDropped(0)));
		                      //make item fly toward survivor
				                double md = ess.posX - entityitem.posX;
				                double md1 = ess.posY - entityitem.posY;
				                double md2 = ess.posZ - entityitem.posZ;
				                double md3 = MathHelper.sqrt_double(md * md + md1 * md1 + md2 * md2);

				                entityitem.setVelocity(md / md3 * 0.30000000000000003D, md1 / md3 * 0.30000000000000003D, md2 / md3 * 0.30000000000000003D);
				                entityitem.delayBeforeCanPickup = 0;
				                ess.worldObj.entityJoinedWorld(entityitem);
								ess.playerToAttack = entityitem;
		                    }
		                }
		        }
				ess.worldObj.setBlockWithNotify(ess.coords[0], ess.coords[1], ess.coords[2], 0);
				ess.actionTimer = 90;
				ess.nums[2] += 1.0F;
				ess.nums[3] = 9999F;
		        ess.nums[4] = 9999F;
			}
			else
				ess.actionTimer = 80;
		}
		else ess.actionTimer = 90;
	}
	
	protected static void swingArm(BLDREntityBuilder ess){
		//arm swinging effect
		ess.prevSwingProgress = ess.swingProgress;
		ess.swingProgress = ess.swingProgress == 0.875F ? 0.0F : ess.swingProgress + 0.125F;
	}*/
    
    /**
     * Current Action Byte; designates which action Builder is currently doing
     *** 0: Idle
     *** 1: Renovating Terrain Phase 1(Single Build)
     *** 2: Renovating Terrain Phase 2(Single Build)
     *** 3: Placing Opaque Blocks Phase 1 (Single Build)
     *** 4: Finished Building (after placing only Opaque Blocks / Placing Opaque Blocks Phase 2(Single Build)
     *** 5: Placing non-Opaque Blocks (Single Build)
     *** 6: Finished Building (after placing non-Opaque Blocks)
     *** 7: Following Player
     *** 8: Following Mayor / Building town for Mayor
     *** 9: Following Player and ready to renovate
     *** 10: Ready to Renovate
     *- 11: Multi-Renovate Phase 1(Multi Build)
     *- 12: Multi-Renovate Phase 2 / Multi-Check (Multi Build)
     *- 13: Multi-Place Opaque Phase 1(Multi Build)
     *- 14: Multi-Place Opaque Phase 2(Multi Build) /Finished Building
     *- 15: Multi-Place non-Opaque (Multi Build)
     *- 16: Finished Building
     *- 17: Following Builder/Multi-Host (Hosting Multi Build blueprint)
     *** 18: Trade-Chest
     *** 19: Fleeing from attacker
     *** 20: Renting / Paying Rent(uses PayTimer)
     *-- 21: Climbing via block-placing
    */ 
    protected byte currentAction;
    protected short actionTimer; //times how long each action has gone on for
    protected byte updateTimer; //handles timed updates (from 0 to 120)
    
    /**
     * Builder Flags (to be expanded in future)
     * Bit 1: Builder cannot despawn except through death
     * Bit 2: Builder not going to renovate, or change what he builds until successful
     * Bit 3: Not on builders List (created via conversion, told not to despawn, etc)
     * Bit 4: Trades twice as often
     * Bit 5: Builds twice as fast
     * Bit 6: Pays rent three times as often
     * Bit 7: Heals Leader when leader weak
     * Bit 8: Jumps while placing blocks underneath self to climb up to high locations
     */
    public long builderFlags; 

	//protected int waitTimer; //increments every update; When equal to maxWait, designated block randomly appears near builder.
	protected int buildCount; //number of structures builder can built
	protected short maxWait; //used for calculating maximumWait time for waitTimer.  Minimum must be 80;
	protected int buildBlock; //designates block that is placed by builder
	
	protected int iB; //x coordinate of starting spot to place block in
	protected int jB; //y coordinate of starting spot to place block in
	protected int kB; //z coordinate of starting spot to place block in
	protected int iA; //x increment for BluePrints array
	protected int jA; //y increment for BluePrints array
	protected int kA; //z increment for BluePrints array
	protected int blueNum; //Number designating what structure will be built
    public byte direction; //rotates blueprints
    public float rotationYawX;
    public float rotationPitchX;
    
	protected ItemStack heldObj; //Determines held item
	protected boolean noMove; //disables movement if enabled
    protected Entity leader; //Player or mayor that builder is following
    public int xT; //X coordinate of town treasure chest
    public int yT; //Y coordinate of town treasure chest
    public int zT; //Z coordinate of town treasure chest
    public int tradeGiveNum; //# of items that can be placed in treasure chest
    public int tradeReceiveNum; //# of items that have been received from chest
    public int tradeRatio; //# of item that must be received in order to give new items.
    public int xMDig; //X Dig position for mayor
    public int yMDig; //Y Dig position for mayor
    public int zMDig; //Z Dig position for mayor
    public int yMHeight; //mayor's y position while renovating
    public String name; //holds builder's name
    public int tradeChestDistance;
    
    
    //Meat tossing related
    public EntityCreature tossMeat; //Entity to toss meat for
    public byte runDirection; //determines running direction
    
    //variables related to Renting
    public int homeRange;
    public int homeX;
    public int homeY;
    public int homeZ;
    public byte rentPayments; //number of payments remaining
    public byte homeAttitude; //attitude that renter has
    public byte payTimer;
    
    //variables related to Climbing
    //public byte heightToClimb;
    
    //protected float nums[]; //misc float values
    //protected int coords[]; //misc int values used for coordinates
    protected boolean mouseHighlight;
    
    public static final int homeBlocks[] = new int[]{
    	Block.bookShelf.blockID, Block.chest.blockID, Block.jukebox.blockID,
    	Block.stoneOvenIdle.blockID, Block.workbench.blockID, Block.dispenser.blockID, 
    	Block.cake.blockID, Block.musicBlock.blockID
    };
    
  //10 characters max
    public static final String Names[] = new String[]{
    	"Bob", "John", "Sean", "Perry", "Leforge", "Gary", "Vance", "Steve", "William",
    	"Steven", "Henry", "Picard", "Kirk", "Tom", "Mark", "Benjamin", "Matthew", "Paul",
    	"Larry", "Luke", "Anakin", "Leo", "Patrick", "Rick", "Enrique", "Cecil", "Sid",
    	"Jason", "Khaos", "Greyland", "Hercules", "Kiron", "Leonard", "Merion", "Greg", "Devon",
    	"Adam", "Ahab", "Tobias", "James", "Marco", "Thor", "Logan", "Goober", "Cuddles",
    	"Notch", "Nanders", "Mr. L", "Craig", "Bruce", "Clark", "Billy", "Marco", "Polo",
    	"Pickles", "Sr. Huego", "Polly", "Sneasle", "Hero", "Cloud", "Aegis", "Maxim", "Kondo",
    	"HoneyDew", "Xephos"
    };
    
    public static final String homeDescrip[] = new String[]{
    	"fantastic", "lovely", "grand", "incredible", "awesome", "charming", "beautiful", //early payment (7)
    	"pleasant", "good", "humble", "nice", "happy", "decent", "well built", "great", "fairly good", "acceptable", //regular-payment (10)
       	"poorly built", "ugly", "hideous", "stupid", "horrible", "pathetic", "worthless" //late-payment (7)
    };
    
    protected static final int rentDelays[] = new int[]{12000, 24000, 36000};
    
    
}