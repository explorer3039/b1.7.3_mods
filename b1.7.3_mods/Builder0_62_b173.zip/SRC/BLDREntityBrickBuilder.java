package net.minecraft.src;

//BrickBuilder: Places Brick blocks; fast building speed; 25 hp; 500 blocks; day(rare)/night(none). Planned{Advanced structures}

public class BLDREntityBrickBuilder extends BLDREntityBuilder{

	public BLDREntityBrickBuilder(World world) {
		super(world);
		buildCount = BLDRBuilderConfig.brickStructureLimit;
		if(rand.nextInt(2) == 1)
			texture = "/mob/BrickBuilder1.png";
		else
			texture = "/mob/BrickBuilder2.png";
		health = 30;
		maxWait = 100;
		if(rand.nextInt(10) < 9) //90% chance of having Brick Blocks
			buildBlock = BLDRBuilderConfig.brickCommonBlock;
		else //10% chance of having planks
			buildBlock = BLDRBuilderConfig.brickRareBlock;
		
		if(BLDRBlueprints.singlePrints.size() > 0)
			blueNum = rand.nextInt(BLDRBlueprints.singlePrints.size());
		else
			blueNum = -1;
		while(BLDRBlueprints.singlePrints.size() > 2 && (blueNum == mod_Builders.explorerSingleBlockIndex || blueNum == mod_Builders.traderBakerShopIndex))
			blueNum = rand.nextInt(BLDRBlueprints.singlePrints.size());

        tradeGiveNum = tradeGiveNum - rand.nextInt(3);
        tradeReceiveNum = rand.nextInt(8);
        tradeRatio = tradeRatio - rand.nextInt(8);
	}
	
	protected void initConvert(int x, String s){
		if(x == Item.brick.shiftedIndex){
			builderFlags |= (1 << 5); //pays rent three times as often
			moveSpeed += 0.2D;
			health += 5;
		}
		else if(x == Block.brick.blockID){
			builderFlags |= (1 << 4); //builds twice as fast
			health += 10;
		}
    }
	
	public void onDeath(Entity entity)
    {
        super.onDeath(entity);
    }
	
	public boolean getCanSpawnHere()
    {
		if(worldObj.isDaytime()){
			if(mod_Builders.countBuilders(this.getClass()) >= BLDRBuilderConfig.brickSpawnMaxDay)
				return false;
			else
				return rand.nextInt(100) < BLDRBuilderConfig.brickSpawnRateDay && super.getCanSpawnHere();
		}
		else{
			if(mod_Builders.countBuilders(this.getClass()) >= BLDRBuilderConfig.brickSpawnMaxNight)
				return false;
			else
				return rand.nextInt(100) < BLDRBuilderConfig.brickSpawnRateNight && super.getCanSpawnHere();
		}
    }
	
    public void writeEntityToNBT(NBTTagCompound nbttagcompound)
    {
        super.writeEntityToNBT(nbttagcompound);
    }

    public void readEntityFromNBT(NBTTagCompound nbttagcompound)
    {
        super.readEntityFromNBT(nbttagcompound);
    }
    
    
    public void onUpdate()
    {
    	if(currentAction >= 1 && currentAction <= 6 && actionTimer == 10099 && ((builderFlags >> 1) & 1) != 1){
    		if(BLDRBlueprints.singlePrints.size() > 0)
    			blueNum = rand.nextInt(BLDRBlueprints.singlePrints.size());
    		else
    			blueNum = -1;
    		while(BLDRBlueprints.singlePrints.size() > 2 && (blueNum == mod_Builders.explorerSingleBlockIndex || blueNum == mod_Builders.traderBakerShopIndex))
    			blueNum = rand.nextInt(BLDRBlueprints.singlePrints.size());
    	}
    	else if(currentAction == 0 && updateTimer % 10 == 0){
    		if(claySpot == null){
    			claySpot = spotClay();
    		}
    	}
    	
    	if(claySpot != null && mod_Builders.minecraft_b.thePlayer.getDistanceToEntity(this) < 8){
    		int blockDist = MathHelper.floor_double(mod_Builders.minecraft_b.thePlayer.getDistance(claySpot.xCoord, claySpot.yCoord, claySpot.zCoord));
    		String str = (new StringBuilder().append("�2<").append(this.name)).append("> �1There is clay about ").append(blockDist).append(" meters from where you're standing.").toString();
    		ModLoader.getMinecraftInstance().ingameGUI.addChatMessage(str);
    		claySpot = null;
    	}
    	super.onUpdate();
	}
    
    protected void jump()
    {
    	double d = (rand.nextDouble() / 10D);
        motionY = 0.44999998688697815D + d;
        motionX *= 1.4 + d;
        motionZ *= 1.4 + d;
    }
    
    private Vec3D spotClay(){
    	double d = rand.nextDouble() * 10;
    	Vec3D vec3d = getPosition(1.0F);
        Vec3D vec3d1 = getLook(1.0F);
        Vec3D look = vec3d.addVector(vec3d1.xCoord * d, vec3d1.yCoord * d, vec3d1.zCoord * d);
    	int x = MathHelper.floor_double(look.xCoord);
    	int y = MathHelper.floor_double(look.yCoord);
    	int z = MathHelper.floor_double(look.zCoord);
    	
    	for(int i = x - 4; i < x + 4; i++)
    		for(int j = y - 4; j < y + 4; j++)
    			for(int k = z - 4; k < z + 4; k++)
    				if(worldObj.getBlockId(i, j, k) == Block.blockClay.blockID)
    					return Vec3D.createVector(i, j, k);
    	
    	return null;
    }
    
    public ItemStack getChestItem(){
    	return chestItems[rand.nextInt(chestItems.length)].copy();
    }
    
    public boolean canRenovateBuild(){
    	return true;
    }
    
    protected ItemStack getThrownItem(){
    	return new ItemStack(Item.appleRed);
    }
    
    protected int getChunkOffsetX(){
    	return 5;
    }
    
    protected int getChunkOffsetZ(){
    	return 4;
    }
    
    protected ItemStack getHealingItem(){
    	return new ItemStack(Item.appleRed);
    }
    
    public int getMaxHp(){
    	return 30;
    }
    
    protected Vec3D claySpot;
    
    static final private ItemStack[] chestItems = (new ItemStack[]{
        	new ItemStack(Block.planks, 1), new ItemStack(Block.brick, 1), new ItemStack(Block.brick, 1),
        	new ItemStack(Block.blockClay, 1), new ItemStack(Item.clay, 1), new ItemStack(Item.brick, 1),
        	new ItemStack(Item.coal, 1), new ItemStack(Item.bucketWater, 1), new ItemStack(Item.paper, 1),
        	new ItemStack(Item.bootsChain, 1, 50), new ItemStack(Item.plateLeather, 1, 37), new ItemStack(Item.bed, 1),
        	new ItemStack(Block.wood, 1, 1), new ItemStack(Item.bucketMilk, 1), new ItemStack(Item.clay, 1),
        	new ItemStack(Block.sand, 1), new ItemStack(Item.shovelGold, 1), new ItemStack(Block.stoneOvenIdle, 1),
        	new ItemStack(Item.helmetLeather, 1)
        });

}
