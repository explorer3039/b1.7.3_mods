package net.minecraft.src;

import java.lang.reflect.Type;
import java.util.List;


public class BLDREntityExplorer extends BLDREntityBuilder{

	/*
	 * Actions: None for now
	 */
	public BLDREntityExplorer(World world) {
		super(world);
		int rrNum = rand.nextInt(4);

    	determineTexture(rrNum);
    	determineStats(rrNum);
		
		attackMode = false;
		swingTimer = 0;
		healTimer = 0;

        tradeGiveNum = tradeGiveNum + rand.nextInt(3);
        tradeReceiveNum = rand.nextInt(2);
        tradeRatio = tradeRatio + rand.nextInt(5);
        healMode = false;
        dodgeTimer = 0;
        blueNum = mod_Builders.explorerSingleBlockIndex;
        if(rand.nextFloat() < 0.4F && mod_Builders.explorerFancyBeaconIndex != -1){
        	blueNum = mod_Builders.explorerFancyBeaconIndex;
		}
	}
	
	protected void initConvert(int x, String s){
		if(x == Block.torchWood.blockID){
			moveSpeed += 0.15D;
			health += 8;
			if(weaponType < 4) weaponType++;
		}
		else if(x == Item.swordWood.shiftedIndex){
			builderFlags |= (1 << 3); //trades twice as often
			tradeGiveNum += 6;
			moveSpeed += 0.25D;
			health += 16;
			if(weaponType < 3) weaponType += 2;
		}
    }
	
	//Make Explorers that bump into animals start riding them
	public void applyEntityCollision(Entity entity)
    {
        if((entity instanceof EntityAnimal && entity.getEntityString() != null && !entity.getEntityString().contains("Horse") && !(entity instanceof EntityWolf)) && ridingEntity == null && entity.riddenByEntity == null)
        {
        	mountEntity(entity);
        	EntityCreature entC = (EntityCreature) entity;
        	entC.moveSpeed = 1.1004F;
        	entC.playerToAttack = null;
        	if(entC == entityliving){
        		entityliving = null;
        	}
            return;
        }
        else
        	super.applyEntityCollision(entity);
    }

	public void onDeath(Entity entity)
    {
        if(weaponType == 5) //Explorers holding a bow drop some arrows as well
			dropItem(Item.arrow.shiftedIndex, rand.nextInt(2) + 1);
		if(entity instanceof EntityPlayer){ //When killed by a player, drops a number of trade chest items
			int numDrop = rand.nextInt(healths[weaponType] / 10) + 1;
			for(int i = 0; i < numDrop; i++)
				mod_Builders.dropChestItem(this);
		}
        super.onDeath(entity);
    }
	
	public boolean getCanSpawnHere()
    {
		if(worldObj.isDaytime()){
			if(mod_Builders.countBuilders(this.getClass()) >= BLDRBuilderConfig.explorerSpawnMaxDay)
				return false;
			else
				return rand.nextInt(100) < BLDRBuilderConfig.explorerSpawnRateDay && super.getCanSpawnHere();
		}
		else{
			if(mod_Builders.countBuilders(this.getClass()) >= BLDRBuilderConfig.explorerSpawnMaxNight)
				return false;
			else
				return rand.nextInt(100) < BLDRBuilderConfig.explorerSpawnRateNight && super.getCanSpawnHere();
		}
        
    }
	

    protected Entity findTargetToAttack(){
    	if(currentAction == 0 || currentAction >= 7 && currentAction <= 10){
    		entityliving = getNearestTarget(this, 13D);
    		if(entityliving != null){
    			attackMode = true;
    			actionTimer = 0;
    		}
    		return entityliving;
    	}
    	else
    		return null;
    }
    
    public boolean interact(EntityPlayer entityplayer)
    {
    	if(attackMode == true)
    		return false;
    	else
    		return super.interact(entityplayer);
    }
    
    
    public void writeEntityToNBT(NBTTagCompound nbttagcompound)
    {
        super.writeEntityToNBT(nbttagcompound);
        nbttagcompound.setInteger("WeaponType", weaponType);
    }

    public void readEntityFromNBT(NBTTagCompound nbttagcompound)
    {
        super.readEntityFromNBT(nbttagcompound);
        weaponType = nbttagcompound.getInteger("WeaponType");
    }
    
    public void onUpdate()
    {
    	super.onUpdate();
    	//keep waitTimer low while in daytime
		if(dodgeTimer > 0)
    		dodgeTimer--;
    	if(worldObj.difficultySetting == 0 && entityliving instanceof EntityPlayer){
    		playerToAttack = null;
    		entityliving = null;
    	}
    	if(currentAction == 0 && actionTimer == 8){
    		if(rand.nextFloat() < 0.4F && mod_Builders.explorerFancyBeaconIndex != -1){
            	blueNum = mod_Builders.explorerFancyBeaconIndex;
    		}
    		else{
    			blueNum = mod_Builders.explorerSingleBlockIndex;
    		}
    	}
    	//if riding an animal make that animal move according to the Explorer's Path variable
    	if(ridingEntity instanceof EntityAnimal){
    		rideAnimal();
		}
    	//if not swinging, make randomly change weapon if explorer #4
		if(exp4 == true && swingTimer <= cooldowns[weaponType] && rand.nextInt(45) == 0){
			changeWeapon();
			if(swingTimer > cooldowns[weaponType])
				swingTimer = cooldowns[weaponType];
		}
		//find enemy to attack every second
    	if(updateTimer % 20 == 0 && attackMode == false && entityliving == null && healMode == false){
    		Entity eee = findTargetToAttack();
    		if(attackMode == true)
    			playerToAttack = eee;
    			
    		//if MineColony detected, make Explorer follow nearby minecolony workers.
    		if(mod_Builders.mineColonyDetected == true && leader == null)
    			leader = findMineColonyWorker(this, 16D);
    	}
    	if(attackMode == true && healMode == false && entityliving != null){
    		//switch to weapon if not holding it already
    		if(heldObj == null || heldObj.itemID != weapons[weaponType].itemID)
    			heldObj = weapons[weaponType];
    		//if not using gold pickaxe, make explorer randomly speed up and slow down
    		if(rand.nextInt(20) == 0 && weaponType != 6){
    			moveSpeed += (rand.nextFloat() / 2) - 0.25;
    			if(moveSpeed > 1.5F)
    				moveSpeed = 1.5F;
    			else if(moveSpeed < 0.5F)
    				moveSpeed = 0.5F;
    		}
    		
    		swingAtTarget();
    		

    		if(entityliving.isDead == true){
    			entityliving = null;
    		}
    	}
    	else if(attackMode == true && entityliving == null){
    		attackMode = false;
    		heldObj = null;
    		swingTimer = 0;
    		swingProgress = 1F;
    		moveSpeed = defaultMoveSpeed;
    	}
    	if(currentAction == 8 && buildBlock == BLDRBuilderConfig.explorerBlock){
    		buildBlock = BLDRBuilderConfig.explorerMBlock;
    	}
    	else if(currentAction == 0 && buildBlock == BLDRBuilderConfig.explorerMBlock){
    		buildBlock = BLDRBuilderConfig.explorerBlock;
    	}
    	else if(health > 0 && health <= healths[weaponType] / 4 && healMode == false && rand.nextInt(100 - healths[weaponType]) == 0)
    		healMode = true;
    	else if(healMode == true && health > 0){
    		healSelf();
    	}
	}
    
    protected void attackEntity(Entity entity, float f)
    {
        if(f < 14F && weaponType == 5 && (EntityLiving) entity == entityliving)
        {
            double d = entity.posX - posX;
            double d1 = entity.posZ - posZ;
            if(attackTime == 0)
            {
            	float arrowSpeed = 1 + rand.nextFloat() * 3; //(maximum 300% speed boost)
                EntityArrow entityarrow = new EntityArrow(worldObj, this);
                entityarrow.posY += 1.3999999761581421D; 
                double d2 = entity.posY - 0.20000000298023224D - entityarrow.posY;
                float f1 = MathHelper.sqrt_double(d * d + d1 * d1) * 0.2F;
                worldObj.playSoundAtEntity(this, "random.bow", 1.0F, 1.0F / (rand.nextFloat() * 0.4F + 0.8F));
                worldObj.entityJoinedWorld(entityarrow);
                entityarrow.setArrowHeading(d, (d2 + (double)f1), d1, 0.6F * arrowSpeed, 4F);
                if(entity instanceof EntityPlayer)
                	attackTime = 10;
                else
                    attackTime = 10 + rand.nextInt(20); //added random attacktime
            }
            rotationYaw = (float)((Math.atan2(d1, d) * 180D) / 3.1415927410125732D) - 90F;
            hasAttacked = true;
        }
    }
    
    //make Explorers fight back against anything that attacks them
    public boolean attackEntityFrom(Entity entity, int i)
    {
    	//attack fails while dodging
    	if(dodgeTimer > 0)
    		return false;
    	
        if(entity instanceof EntityLiving && attackMode == false && currentAction == 0 || currentAction >= 7 && currentAction <= 10)
        {
        	
            playerToAttack = entity;
            entityliving = (EntityLiving) entity;
            if(entity instanceof EntityPlayer && currentAction == 7){
            	currentAction = 0;
            	leader = null;
            }
            attackMode = true;
        }
        //If Explorer riding an animal, occasionally redirect damage to that animal
        if(ridingEntity instanceof EntityAnimal && rand.nextInt(5) == 0){
        	ridingEntity.attackEntityFrom(entity, i);
        	return true;
        }
        //Make Explorers randomly dodge enemy attacks
        if(rand.nextInt(cooldowns[weaponType]) < 2 && entity != null && ridingEntity == null){
        	mod_Builders.dodgeAttack(entity, this, i);
        	dodgeTimer = 20;
        	mod_Builders.spawnParticlesAtEntity(this, "explode", 5);
        	return false;
        }
        return super.attackEntityFrom(entity, i);
    }
    
    public ItemStack getChestItem(){
    	return chestItems[rand.nextInt(chestItems.length)].copy();
    }
    
    protected void jump() //controls jump height (overrided); called when jumping
    {
        if(rand.nextInt(20) == 0)
    		motionY = 0.83999998688697815D;
    	else
    		motionY = 0.47999998688697815D;
    }
    
    protected void fall(float f) //controls what happens when falling
    {
        super.fall(f / 2F);
        //make explorer drop random item after long fall
        if(f > 6F && rand.nextInt(3) == 0){
        	mod_Builders.dropChestItem(this);
        	mod_Builders.spawnParticlesAtEntity(this, "explode", 5);
        }
    }
    
    //Method only called if MineColony is also installed
    public Entity findMineColonyWorker(Entity entity, double d){
    	if(mod_Builders.mineColonyDetected == true){
    		double d1 = -1D;
            Entity worker = null;
            
            
            for(int i = 0; i < worldObj.loadedEntityList.size(); i++)
            {
                Entity entity1 = (Entity)worldObj.loadedEntityList.get(i);
                
                if(!(mod_Builders.colonyWorker.isInstance(entity1)) || entity1 == entity || entity1 == entity.ridingEntity || entity1 == entity.riddenByEntity)
                {
                    continue;
                }
                double d2 = entity1.getDistanceSq(entity.posX, entity.posY, entity.posZ);
                if((d < 0.0D || d2 < d * d) && (d1 == -1D || d2 < d1) && ((EntityLiving)entity1).canEntityBeSeen(entity))
                {
                    d1 = d2;
                    worker = entity1;
                }
            }

            return worker;
    	}
    	else
    		return null;
    }
    
    private void useWeapon(){
    	if(weaponType < 7){
    		//damage target based on weapon with a possible single damage point added or lost.
    		entityliving.attackEntityFrom(this, weaponDamages[weaponType] + rand.nextInt(3) - 1);
			//Reset swingtimer between 0 and half the weapon's cooldown
			swingTimer = rand.nextInt(cooldowns[weaponType] / 2);
			//make the damaged enemy propel higher into the air when hit
			entityliving.motionY += 0.1D * ((double) rand.nextInt(3));
			//for pickaxe weilding explorer, increase distance the damaged enemy is flung
			if(weaponType == 6){
				entityliving.motionY += 0.15D;
				entityliving.motionX *= 2.1D;
				entityliving.motionZ *= 2.1D;
				//speed up after each hit
				if(moveSpeed < 3.0F)
					moveSpeed += 0.08F;
				//make enemies randomly drop their drop item after a hit
				if(rand.nextInt(20) == 0){
					int dNum = entityliving.getDropItemId();
					if(dNum != 0){
						EntityItem entityitem;
						entityitem = new EntityItem(worldObj, entityliving.posX, entityliving.posY + 0.2, entityliving.posZ, new ItemStack(dNum, 1, 0));
						entityitem.delayBeforeCanPickup = 10;
						entityitem.age = 4800;
						worldObj.entityJoinedWorld(entityitem);
						mod_Builders.spawnParticlesAtEntity(entityliving, "smoke", 7);
					}
				}
			}
    	}
    	else if(weaponType == 7){ //flint and steel
    		entityliving.attackEntityFrom(null, 1);
    		entityliving.fire = 400;
    		swingTimer = 0;
    		if(entityliving.moveSpeed < 0.95F)
    			entityliving.moveSpeed = 0.95F;
    	}
    	else if(weaponType == 8){ //golden axe
    		boolean crit = false;
    		if(rand.nextFloat() > 0.1F) //regular hit
    			entityliving.attackEntityFrom(this, 5);
    		else{ //critical hit
    			entityliving.attackEntityFrom(this, 10);
    			crit = true;
    		}

    		swingTimer = 0;
    		if(crit){
    			entityliving.motionY += 0.25D;
				entityliving.motionX *= 1.6D;
				entityliving.motionZ *= 1.6D;
				entityliving.moveStrafing = 0.3F;
				entityliving.moveSpeed = entityliving.moveSpeed / 2F;
    		}
    	}
    	else if(weaponType == 9){ //bone
    		entityliving.attackEntityFrom(this, 1);

    		swingTimer = 0;
    		if(rand.nextFloat() < 0.1F)
    			entityliving.moveSpeed = 0.001F;
    	}
    	else if(weaponType == 10){ //stick
    		entityliving.attackEntityFrom(this, 1);
    		this.attackEntityFrom(entityliving, 1);
    		motionY += 0.2F;
    		motionX *= 1.8F;
    		motionZ *= 1.8F;
    		swingTimer = 0;
    	}
    }
    
    private void changeWeapon(){
    	weaponType = rand.nextInt(weapons.length);
    	if(weaponType < 6)
    		weaponType = 1; //given gold sword if any sword chosen
    }
    
    private void rideAnimal(){
    	PathEntity targetLocation;
		PathPoint targetPoint[];
		int xpoint;
		int ypoint;
		int zpoint;
		try {
			targetLocation = ((PathEntity) ModLoader.getPrivateValue(EntityCreature.class, this, "a"));
			if(targetLocation != null){
				targetPoint = ((PathPoint[]) ModLoader.getPrivateValue(PathEntity.class, targetLocation, "b"));
				if(targetPoint != null){
					xpoint = targetPoint[targetPoint.length - 1].xCoord;
					ypoint = targetPoint[targetPoint.length - 1].yCoord;
					zpoint = targetPoint[targetPoint.length - 1].zCoord;
					((EntityCreature) ridingEntity).setPathToEntity(worldObj.getEntityPathToXYZ(ridingEntity, xpoint, ypoint, zpoint, 30F));
				}
			}
				
		} catch (Throwable e) {
		}
		
		if(rand.nextInt(50) == 0 && ridingEntity instanceof EntityAnimal && ((EntityLiving) ridingEntity).onGround == true){
    		ridingEntity.motionY = 0.36 + rand.nextDouble() / 2;
    	}
    }
    
    private void swingAtTarget(){
    	//increment swingTimer only while near target
		if(getDistanceToEntity(entityliving) < swingRanges[weaponType] && swingTimer <= cooldowns[weaponType]){
    		swingTimer++;	
		}
		//if swingTimer is high enough, begin swinging
		else if(swingTimer > cooldowns[weaponType] && swingTimer <= cooldowns[weaponType] + 8){
			prevSwingProgress = (swingTimer - cooldowns[weaponType]) * 0.125F;
			swingProgress = (swingTimer - cooldowns[weaponType]) * 0.125F;
			swingTimer++;
			//Back up while swinging
			if(swingTimer - cooldowns[weaponType] == 3 && weaponType != 5 && onGround){
				motionX = posX - entityliving.posX > 0 ? 0.4 + (rand.nextFloat() / 10) : -0.4 - (rand.nextFloat() / 10);
				motionZ = posZ - entityliving.posZ > 0 ? 0.4 + (rand.nextFloat() / 10) : -0.4 - (rand.nextFloat() / 10);
			}
		}
		//once swing completed, deal damage if target is close enough
		else if(swingTimer == cooldowns[weaponType] + 9){
			if(this.getDistanceToEntity(entityliving) < swingRanges[weaponType] + rand.nextFloat()){
				useWeapon();
			}
			//if miss, reset swingTimer
			else{
				swingTimer = rand.nextInt(cooldowns[weaponType] / 2);
			}
		}
    }
    
    private void determineTexture(int i){
		if(i == 0)
			texture = "/mob/Explorer1.png";
		else if(i == 1)
			texture = "/mob/Explorer2.png";
		else if(i == 2){
			texture = "/mob/Explorer3.png";
		}
		else if(i == 3){
			if(rand.nextInt(30) == 0){
				if(mod_Builders.minecraft_b.thePlayer.skinUrl != null){
					skinUrl = mod_Builders.minecraft_b.thePlayer.skinUrl;
				}


				texture = "/mob/char.png";
				
				name = mod_Builders.minecraft_b.session.username;
				if(name != null && name.contains("Player"))
					name = "OgreSean";
			}
			else
				texture = "/mob/Explorer1.png";
		}
		else
			texture = "/mob/Explorer2.png";
    }
    
    private void determineStats(int i){
		buildBlock = BLDRBuilderConfig.explorerBlock;
		buildCount = BLDRBuilderConfig.explorerBlockLimit;
    	if(i == 2){
			maxWait = 120;
			buildCount *= 2;
			weaponType = 6;
			moveSpeed = 0.68F;
			defaultMoveSpeed = 0.68F;
    		exp4 = false;
    	}
    	else if(i == 3){
    		exp4 = true;
			moveSpeed = 1.05F;
			defaultMoveSpeed = 1.05F;
			maxWait = 110;
    		weaponType = rand.nextInt(weapons.length);
    	}
    	else{
    		weaponType = rand.nextInt(6);
    		moveSpeed = 0.95F;
    		defaultMoveSpeed = 0.95F;
    		maxWait = 250;
    		exp4 = false;
    	}
    	

		health = healths[weaponType] + rand.nextInt(7) - 3;
    	
    	if("Notch".equals(name)){
			moveSpeed = 1.5F;
			defaultMoveSpeed = 1.5F;
			health = 100;
        }
    }
    
    private void healSelf(){
    	healTimer++;
		if(healTimer == 1)
			heldObj = new ItemStack(Item.appleRed);
			
		else if(healTimer == 29){
			heldObj = null;
			heal((healths[weaponType] / 4) + rand.nextInt(5 + (healths[weaponType] / 10)));
			worldObj.playSoundAtEntity(this, "builder.explorerGulp", getSoundVolume(), (rand.nextFloat() - rand.nextFloat()) * 0.2F + 1.0F);
			healTimer = 0;
			mod_Builders.spawnParticlesAtEntity(this, "reddust", 16);
			healMode = false;
		}
    }
    
    public int getMaxHp(){
    	return name.equals("Notch") ? 100 : healths[weaponType] + 5;
    }
    
    protected boolean canTossMeat(){
    	return false;
    }
    
    protected int getChunkOffsetX(){
    	return -6;
    }
    
    protected int getChunkOffsetZ(){
    	return -2;
    }
    
  //called when actionTimer = maxWait
    protected void selectIdleAction(){
    	if(!attackMode && !(worldObj.isDaytime() && worldObj.getBlockLightValue(MathHelper.floor_double(posX), MathHelper.floor_double(posY), MathHelper.floor_double(posZ)) > 2))
    		super.selectIdleAction();
    }
    
    protected ItemStack getHealingItem(){
    	return new ItemStack(Item.porkRaw);
    }
    
    public int getClimbBlockID(){
    	return Block.gravel.blockID;
    }

    protected boolean attackMode;
    protected boolean healMode;
    protected int weaponType; //Type of Weapon held when in attack mode
    protected EntityLiving entityliving; //Enemy mob
    protected int swingTimer; //timer for swinging weapon in combat
    protected int healTimer; //timer for healing
    protected float defaultMoveSpeed;
    protected boolean exp4; //if explorer 4, make randomly change weapons
    protected int dodgeTimer; //immune to damage while above 0
    
    static final ItemStack[] weapons = (new ItemStack[]{
    	new ItemStack(Item.swordWood, 1), new ItemStack(Item.swordGold, 1), new ItemStack(Item.swordStone, 1),
    	new ItemStack(Item.swordSteel, 1), new ItemStack(Item.swordDiamond, 1), new ItemStack(Item.bow, 1),
    	new ItemStack(Item.pickaxeGold, 1), new ItemStack(Item.flintAndSteel, 1), new ItemStack(Item.axeGold, 1),
    	new ItemStack(Item.bone, 1), new ItemStack(Item.stick, 1)
    });
    static final ItemStack[] chestItems = (new ItemStack[]{
        	new ItemStack(Block.torchWood, 1), new ItemStack(Block.pumpkinLantern, 1), new ItemStack(Item.pocketSundial, 1),
        	new ItemStack(Block.torchWood, 1), new ItemStack(Block.torchWood, 1), new ItemStack(Block.torchWood, 1),
        	new ItemStack(Block.torchWood, 2), new ItemStack(Block.torchWood, 3), new ItemStack(Block.web, 1),
        	new ItemStack(Block.musicBlock, 1), new ItemStack(Block.mushroomRed, 1), new ItemStack(Block.railDetector, 1),
        	new ItemStack(Item.saddle, 1), new ItemStack(Item.arrow, 1), new ItemStack(Item.legsGold, 1), new ItemStack(Item.compass, 1),
        	new ItemStack(Item.appleRed, 1), new ItemStack(Item.flintAndSteel, 1), new ItemStack(Item.plateLeather, 1), new ItemStack(Item.bowlSoup, 1),
        	new ItemStack(Item.bow, 1), new ItemStack(Item.fishingRod, 1), new ItemStack(Item.bucketWater, 1), new ItemStack(Item.swordGold, 1),
        	new ItemStack(Item.bootsSteel, 1), new ItemStack(Item.swordStone, 1), new ItemStack(Item.dyePowder, 1, 0), new ItemStack(Item.bone, 1),
        	new ItemStack(Block.tnt, 1), new ItemStack(Item.shovelDiamond, 1, Item.shovelDiamond.getMaxDamage() - 46), new ItemStack(Item.axeGold, 1, 16), new ItemStack(Item.plateDiamond, 1, Item.plateDiamond.getMaxDamage() - 35)
        });
    static final int[] weaponDamages = new int[]{
    	4, 4, 6, 8, 10, 2, 3, 0, 5, 1, 1
    };
    static final int[] healths = new int[]{
    	20, 25, 30, 35, 45, 25, 40, 30, 30, 30, 30
    };
    static final int[] cooldowns = new int[]{
    	16, 14, 10, 8, 6, 12, 6, 14, 24, 4, 7
    };
    static final double[] swingRanges = new double[]{
    	3.1D, 3.2D, 3.4D, 3.8D, 4.5D, 3.0D, 4.0D, 6.0D, 3.6D, 3.5D, 3.2D
    };
}
