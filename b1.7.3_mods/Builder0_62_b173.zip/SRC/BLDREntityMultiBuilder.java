package net.minecraft.src;

public class BLDREntityMultiBuilder extends BLDREntityBuilder{

	public BLDREntityMultiBuilder(World world) {
		super(world);
		buildCount = BLDRBuilderConfig.multiStructureLimit;
		int num = rand.nextInt(3) + 1;
		texture = new StringBuilder("/mob/MultiBuilder").append(num).append(".png").toString();
		health = 30;
		maxWait = 125;
		buildBlock = blockIDs[rand.nextInt(blockIDs.length)];
		if(BLDRBlueprints.singlePrints.size() > 0)
			blueNum = rand.nextInt(BLDRBlueprints.singlePrints.size());
		else
			blueNum = -1;
		while(BLDRBlueprints.singlePrints.size() > 2 && (blueNum == mod_Builders.explorerSingleBlockIndex || blueNum == mod_Builders.traderBakerShopIndex))
			blueNum = rand.nextInt(BLDRBlueprints.singlePrints.size());
		
        tradeGiveNum = tradeGiveNum + rand.nextInt(3);
        tradeReceiveNum = rand.nextInt(6);
        tradeRatio = tradeRatio - rand.nextInt(7);
	}
	
	protected void initConvert(int x, String s){
		if(x == Block.workbench.blockID){
			builderFlags |= (1 << 4); //builds twice as fast
			tradeRatio += 5;
		}
		else if(x == Block.ladder.blockID){
			moveSpeed += 0.27D;
			health += 7;
			tradeGiveNum += 7;
		}
    }
	
	public void onDeath(Entity entity)
    {
		int j = rand.nextInt(3) + 1;
		for(int i = 0; i < j; i++)
			dropItem(blockIDs[rand.nextInt(blockIDs.length)], 1); // drop random blocks
		super.onDeath(entity);
    }
	
	public boolean getCanSpawnHere()
    {
		if(worldObj.isDaytime()){
			if(mod_Builders.countBuilders(this.getClass()) >= BLDRBuilderConfig.multiSpawnMaxDay)
				return false;
			else
				return rand.nextInt(100) < BLDRBuilderConfig.multiSpawnRateDay && super.getCanSpawnHere();
		}
		else{
			if(mod_Builders.countBuilders(this.getClass()) >= BLDRBuilderConfig.multiSpawnMaxNight)
				return false;
			else
				return rand.nextInt(100) < BLDRBuilderConfig.multiSpawnRateNight && super.getCanSpawnHere();
		}
    }
	
    public void writeEntityToNBT(NBTTagCompound nbttagcompound)
    {
        super.writeEntityToNBT(nbttagcompound);
    }

    public void readEntityFromNBT(NBTTagCompound nbttagcompound)
    {
        super.readEntityFromNBT(nbttagcompound);
    }
    
    public void onUpdate()
    {
    	if(currentAction >= 1 && currentAction <= 6 && actionTimer == 10099 && ((builderFlags >> 1) & 1) != 1){
    		if(BLDRBlueprints.singlePrints.size() > 0)
    			blueNum = rand.nextInt(BLDRBlueprints.singlePrints.size());
    		else
    			blueNum = -1;
    		while(BLDRBlueprints.singlePrints.size() > 2 && (blueNum == mod_Builders.explorerSingleBlockIndex || blueNum == mod_Builders.traderBakerShopIndex))
    			blueNum = rand.nextInt(BLDRBlueprints.singlePrints.size());
    		buildBlock = blockIDs[rand.nextInt(blockIDs.length)];
    	}
    	if(currentAction == 0 && dashTimer == -1 && rand.nextFloat() < 0.001)
    		dash();
    	if(dashTimer > 0)
    		dashTimer--;
    	else if(dashTimer == 0){
    		dashTimer = -1;
    		moveSpeed = 0.8F;
    	}
    	super.onUpdate();
	}
    
    public void dash(){
    	dashTimer = 60 + rand.nextInt(60);
    	moveSpeed = 1.6F;
    }
    
    public ItemStack getChestItem(){
    	return chestItems[rand.nextInt(chestItems.length)].copy();
    }
    
    public boolean canRenovateBuild(){
    	return true;
    }
    
    protected ItemStack getThrownItem(){
    	return new ItemStack(Item.cookie);
    }
    
    protected int getChunkOffsetX(){
    	return 7;
    }
    
    protected int getChunkOffsetZ(){
    	return -7;
    }
    
    protected ItemStack getHealingItem(){
    	return new ItemStack(Item.porkCooked);
    }
    
    public int getMaxHp(){
    	return 30;
    }
    
    protected int dashTimer;

    static final ItemStack[] chestItems = (new ItemStack[]{
        	new ItemStack(Block.blockClay.blockID, 1, 0), new ItemStack(Block.ladder.blockID, 1, 0), new ItemStack(Block.blockSnow.blockID, 1, 0),
        	new ItemStack(Block.pumpkin.blockID, 1, 0), new ItemStack(Block.wood.blockID, 1, 0), new ItemStack(Block.pumpkinLantern.blockID, 1, 0),
        	new ItemStack(Block.bookShelf.blockID, 1, 0), new ItemStack(Block.cobblestoneMossy.blockID, 1, 0), new ItemStack(Block.wood.blockID, 1, 0),
        	new ItemStack(Block.brick.blockID, 1, 0), new ItemStack(Block.stone.blockID, 1, 0), new ItemStack(Block.dirt.blockID, 1, 0),
        	new ItemStack(Block.obsidian.blockID, 1, 0), new ItemStack(Block.web.blockID, 1, 0), new ItemStack(Block.bookShelf.blockID, 1, 0),
        	new ItemStack(Block.jukebox.blockID, 1, 0), new ItemStack(Block.dispenser.blockID, 1, 0), new ItemStack(Block.chest.blockID, 1, 0),
        	new ItemStack(Block.workbench.blockID, 1, 0), new ItemStack(Block.cloth.blockID, 1, 0), new ItemStack(Block.planks.blockID, 1, 0)
        });
    
    static final int blockIDs[] = new int[]{
    	Block.dirt.blockID, Block.brick.blockID, Block.blockSnow.blockID,
    	Block.cobblestone.blockID, Block.wood.blockID, Block.stone.blockID,
    	Block.stone.blockID, Block.planks.blockID, Block.dirt.blockID,
    	Block.planks.blockID, Block.cloth.blockID, Block.planks.blockID,
    	Block.cobblestoneMossy.blockID, Block.brick.blockID, Block.planks.blockID,
    	Block.sandStone.blockID, Block.sandStone.blockID, Block.stone.blockID
    };
    
}
