package net.minecraft.src;

import java.util.List;
/*
 * Unique Actions
 * 0: Idle/Leading people
 * -1: Building Town Wall
 * -2: Created Town / Ready to place stuff in Trade Chest
 */
public class BLDREntityMayor extends BLDREntityBuilder{

	public BLDREntityMayor(World world) {
		super(world);
		buildCount = 0;
		moveSpeed = 0.75F;
		if(rand.nextFloat() < 0.5F)
			texture = "/mob/Mayor3.png";
		else
			texture = "/mob/Mayor4.png";
		health = 35;
		maxWait = 550;
		buildBlock = Block.bookShelf.blockID;
		blueNum = 0;
		builderCount = 0;
		mayorCounter = 0;
		yMO2 = 0;
        tradeGiveNum = tradeGiveNum + rand.nextInt(15);
        tradeReceiveNum = rand.nextInt(15);
        tradeRatio = tradeRatio - rand.nextInt(15);
        traderMax = 0;
		heldObj = new ItemStack(mayorItems[rand.nextInt(mayorItems.length)], 1);
		townRadius = 7 + rand.nextInt(6);
		scoreValue = 100;
	}
	
	protected void initConvert(int x, String s){
		if(x == Block.bookShelf.blockID){
			moveSpeed += 0.05D;
			health += 10;
			tradeGiveNum += 10;
			builderFlags |= (1 << 3); //trades twice as often
			builderFlags |= (1 << 5); //pays rent three times as often
		}
		else if(x == Item.book.shiftedIndex){
			moveSpeed += 0.025D;
			health += 5;
			tradeGiveNum += 4;
		}
		
		if(s == "/mob/HomeSeeker1.png" || s == "/mob/HomeSeeker4.png")
			texture = "/mob/Mayor1.png";
		else if(s == "/mob/HomeSeeker2.png")
			texture = "/mob/Mayor2.png";
    }
	
	public void onDeath(Entity entity)
    {
        super.onDeath(entity);
        if(entity instanceof EntityPlayer){
			if(((EntityPlayer) entity).score == 1000)
				dropItem(Item.appleGold.shiftedIndex, 1);
		}
    }
	
	public boolean getCanSpawnHere()
    {
		if(worldObj.isDaytime()){
			if(mod_Builders.countBuilders(this.getClass()) >= BLDRBuilderConfig.mayorSpawnMaxDay)
				return false;
			else
				return rand.nextInt(100) < BLDRBuilderConfig.mayorSpawnRateDay && super.getCanSpawnHere();
		}
		else{
			if(mod_Builders.countBuilders(this.getClass()) >= BLDRBuilderConfig.mayorSpawnMaxNight)
				return false;
			else
				return rand.nextInt(100) < BLDRBuilderConfig.mayorSpawnRateNight && super.getCanSpawnHere();
		}
    }
	
    public void writeEntityToNBT(NBTTagCompound nbttagcompound)
    {
        super.writeEntityToNBT(nbttagcompound);
        nbttagcompound.setInteger("TownRadius", townRadius);
        if(currentAction == -2){
        	nbttagcompound.setInteger("CCposX", xT);
        	nbttagcompound.setInteger("CCposY", yT);
        	nbttagcompound.setInteger("CCposZ", zT);
        	nbttagcompound.setInteger("ChestDistance", tradeChestDistance);
        }
    }

    public void readEntityFromNBT(NBTTagCompound nbttagcompound)
    {
        super.readEntityFromNBT(nbttagcompound);
        townRadius = nbttagcompound.getInteger("TownRadius");
        if(currentAction == -2){
        	if(nbttagcompound.hasKey("CCposX"))
        	{
            	xT = nbttagcompound.getInteger("CCposX");
        	}
        	if(nbttagcompound.hasKey("CCposY"))
        	{
            	yT = nbttagcompound.getInteger("CCposY");
        	}
        	if(nbttagcompound.hasKey("CCposZ"))
        	{
            	zT = nbttagcompound.getInteger("CCposZ");
        	}

        	tradeChestDistance = nbttagcompound.getInteger("ChestDistance");
        }
    }
    
    public void onUpdate()
    {
    	super.onUpdate();
    	
    	//stop all mayor functions if mayor is renting.
    	if(currentAction == 20)
    		return;
    	else if(currentAction == -2) //Mayor adds stuff to trade chest after settled
    		tradeChestUpdate();
    	

    	if(actionTimer != -2) mayorCounter++;
    	
    	//Insert here: If any idle builders nearby, set their attack target to this mayor.
    	if(updateTimer % 30 == 0 && (currentAction == 0 || currentAction == 7) && mayorCounter < 500){
			BLDREntityBuilder bldr = getNearestIdleBuilder(this, townRadius * 2);
			if(bldr != null){ //Make nearby builders move toward Mayor 
				bldr.leader = this;
				bldr.currentAction = 8;
				builderCount++;
			}
		}
    	else if(updateTimer % 30 == 0 && currentAction == -2){
			BLDREntityBuilder bldr = getNearestIdleBuilder2(this, townRadius * 2);
			if(bldr != null){ //Make nearby builders set their trade chest to the mayor's
				bldr.currentAction = 18;
				bldr.xT = xT;
				bldr.yT = yT;
				bldr.zT = zT;
				bldr.tradeChestDistance = townRadius + 1;
			}

			//if Humans+ detected, randomly spawn settlers and wanderers
			/*if(mod_Builders.humansPlusDetected){
				//should spawn settlers and wanderers once every minute or so.
				if(rand.nextInt(36) == 0){
					try {
						EntityLiving eL;
						if(rand.nextFloat() < 0.6F)
							eL = (EntityLiving) mod_Builders.humanSettler.getConstructor(new Class[] {World.class}).newInstance(new Object[] {worldObj});
						else
							eL = (EntityLiving) mod_Builders.humanWanderer.getConstructor(new Class[] {World.class}).newInstance(new Object[] {worldObj});
						eL.setPosition(posX, posY, posZ);
						worldObj.entityJoinedWorld(eL);
						mod_Builders.spawnParticlesAtEntity(eL, "explode", 14);
						worldObj.playSoundAtEntity(this, eL.getLivingSound(), getSoundVolume(), (rand.nextFloat() - rand.nextFloat()) * 0.2F + 1.0F);
		    			
						
					} catch (Throwable e) {
						e.printStackTrace();
					}
				}
			}*/
		}
    	
    	//Insert here: if builderCount at least 3, begin looking for prospective town location
    	if(mayorCounter == 200 && (builderCount < 3 || currentAction == -2 || currentAction != 0)){
    		mayorCounter = 0;
    	}
    	else if(mayorCounter == 200 && builderCount >= 2){
    		mayorCounter = 10000;
    		currentAction = -1;
			actionTimer = 0;
    		noMove = true;
			xMO = 0;
			yMO = 0;
			zMO = 0;
			yMO2 = 0;
			heldObj = new ItemStack(Item.paper, 1);
    		//Set search coordinates
        	xM = MathHelper.floor_double(posX) + townRadius;
    		yM = MathHelper.floor_double(boundingBox.minY);
    		zM = MathHelper.floor_double(posZ) + townRadius;	
    		//place Mayor on ground
    		setPosition(posX, MathHelper.floor_double(boundingBox.minY), posZ);
    	}
    	
    	
    	//Step 1: Set starting Y coordinate
    	else if(mayorCounter == 10001){
    		//move yPointer up, up to 10 times, until correct block found.
    		for(int pb = 0; pb < 11; pb++){
    			if(canPlaceBlock(xM, yM + pb, zM, 0) && canPlaceBlock(xM, yM + pb + 1, zM, 1) && canPlaceBlock(xM, yM + pb + 2, zM, 1)){
    				mayorCounter = 10010;
    				yM = yM + pb;
    				break;
    			}
    		}
    		//if couldn't find spot by moving yPoint up, try moving down
    		if(mayorCounter == 10001){
    			for(int pb = 1; pb < 11; pb++){
        			if(canPlaceBlock(xM, yM - pb, zM, 0) && canPlaceBlock(xM, yM - pb + 1, zM, 1) && canPlaceBlock(xM, yM - pb + 2, zM, 1)){
        				mayorCounter = 10010;
        				yM = yM - pb;
        				break;
        			}
        		}
    		}
    		//if no spot found, give up on these coordinates
    		if(mayorCounter == 10001){
    			mayorCounter = 0;
    			noMove = false;
    			heldObj = null;
    			currentAction = 0;
    			actionTimer = 0;
    		//	xMO = 0;
    		//	yMO = 0;
    		//	zMO = 0;
    		}
    	}
    	
    	//Face Blocks being checked
    	else if(mayorCounter > 10015 && mayorCounter <= 10018){
			faceBlock(xM + xMO, yM + yMO, zM + zMO, 30F);
			if(((builderFlags >> 4) & 1) == 1 && actionTimer < 10018) actionTimer++;
		}
    	
    	//Step 2: Check all other necessary coordinates
    	//first check x: 7 to -7 for z + 7
    	else if(mayorCounter == 10019){
    		if(xMO > -(townRadius * 2)){
    			if(canPlaceBlock(xM + xMO, yM + yMO, zM + zMO, 0) && canPlaceBlock(xM + xMO, yM + yMO + 1, zM + zMO, 1) && canPlaceBlock(xM + xMO, yM + yMO + 2, zM + zMO, 1)){
    				if(xMO == -(townRadius)){
    					xDR = xM + xMO;
    					yDR = yM + yMO;
    					zDR = zM + zMO;
    				}
    				xMO--;
    				mayorCounter = 10015;
    			}
    			else if(canPlaceBlock(xM + xMO, yM + yMO + 1, zM + zMO, 0) && canPlaceBlock(xM + xMO, yM + yMO + 2, zM + zMO, 1) && canPlaceBlock(xM + xMO, yM + yMO + 3, zM + zMO, 1)){
    				if(xMO == -(townRadius)){
    					xDR = xM + xMO;
    					yDR = yM + yMO + 1;
    					zDR = zM + zMO;
    				}
    				yMO++;
    				xMO--;
    				mayorCounter = 10015;
    			}
    			else if(canPlaceBlock(xM + xMO, yM + yMO - 1, zM + zMO, 0) && canPlaceBlock(xM + xMO, yM + yMO, zM + zMO, 1) && canPlaceBlock(xM + xMO, yM + yMO + 1, zM + zMO, 1)){
    				if(xMO == -(townRadius)){
    					xDR = xM + xMO;
    					yDR = yM + yMO - 1;
    					zDR = zM + zMO;
    				}
    				yMO--;
    				xMO--;
    				mayorCounter = 10015;
    			}
    			//if not placeable, fail process
    			if(mayorCounter == 10019){
    				mayorCounter = 0;
        			noMove = false;
        			heldObj = null;
        			currentAction = 0;
        			actionTimer = 0;
    			}
    		}
    		else //once finished, enter next phase
    			mayorCounter = 10025;
    	}
    	
    	//Face Blocks being checked
    	else if(mayorCounter > 10025 && mayorCounter <= 10028){
			faceBlock(xM + xMO, yM + yMO, zM + zMO, 30F);
			if(((builderFlags >> 4) & 1) == 1 && actionTimer < 10028) actionTimer++;
		}
    	//second check z: 7 to -7 for x - 7
    	else if(mayorCounter == 10029){
    		if(zMO > -(townRadius * 2)){
    			if(canPlaceBlock(xM + xMO, yM + yMO, zM + zMO, 0) && canPlaceBlock(xM + xMO, yM + yMO + 1, zM + zMO, 1) && canPlaceBlock(xM + xMO, yM + yMO + 2, zM + zMO, 1)){
    				zMO--;
    				mayorCounter = 10025;
    			}
    			else if(canPlaceBlock(xM + xMO, yM + yMO + 1, zM + zMO, 0) && canPlaceBlock(xM + xMO, yM + yMO + 2, zM + zMO, 1) && canPlaceBlock(xM + xMO, yM + yMO + 3, zM + zMO, 1)){
    				yMO++;
    				zMO--;
    				mayorCounter = 10025;
    			}
    			else if(canPlaceBlock(xM + xMO, yM + yMO - 1, zM + zMO, 0) && canPlaceBlock(xM + xMO, yM + yMO, zM + zMO, 1) && canPlaceBlock(xM + xMO, yM + yMO + 1, zM + zMO, 1)){
    				yMO--;
    				zMO--;
    				mayorCounter = 10025;
    			}
    			//if not placeable, fail process
    			if(mayorCounter == 10029){
    				mayorCounter = 0;
        			noMove = false;
        			heldObj = null;
        			currentAction = 0;
        			actionTimer = 0;
    			}
    		}
    		else //once finished, enter next phase
    			mayorCounter = 10035;
    	}
    	//Face Blocks being checked
    	else if(mayorCounter > 10035 && mayorCounter <= 10038){
			faceBlock(xM + xMO, yM + yMO, zM + zMO, 30F);
			if(((builderFlags >> 4) & 1) == 1 && actionTimer < 10038) actionTimer++;
		}
    	//third check x: -7 to 7 for z - 7
    	else if(mayorCounter == 10039){
    		if(xMO < 0){
    			if(canPlaceBlock(xM + xMO, yM + yMO, zM + zMO, 0) && canPlaceBlock(xM + xMO, yM + yMO + 1, zM + zMO, 1) && canPlaceBlock(xM + xMO, yM + yMO + 2, zM + zMO, 1)){
    				xMO++;
    				mayorCounter = 10035;
    			}
    			else if(canPlaceBlock(xM + xMO, yM + yMO + 1, zM + zMO, 0) && canPlaceBlock(xM + xMO, yM + yMO + 2, zM + zMO, 1) && canPlaceBlock(xM + xMO, yM + yMO + 3, zM + zMO, 1)){
    				yMO++;
    				xMO++;
    				mayorCounter = 10035;
    			}
    			else if(canPlaceBlock(xM + xMO, yM + yMO - 1, zM + zMO, 0) && canPlaceBlock(xM + xMO, yM + yMO, zM + zMO, 1) && canPlaceBlock(xM + xMO, yM + yMO + 1, zM + zMO, 1)){
    				yMO--;
    				xMO++;
    				mayorCounter = 10035;
    			}
    			//if not placeable, fail process
    			if(mayorCounter == 10039){
    				mayorCounter = 0;
        			noMove = false;
        			heldObj = null;
        			currentAction = 0;
        			actionTimer = 0;
    			}
    		}
    		else //once finished, enter next phase
    			mayorCounter = 10045;
    	}
    	//Face Blocks being checked
    	else if(mayorCounter > 10045 && mayorCounter <= 10048){
			faceBlock(xM + xMO, yM + yMO, zM + zMO, 30F);
			if(((builderFlags >> 4) & 1) == 1 && actionTimer < 10048) actionTimer++;
		}
    	//fourth check z: -7 to 7 for x + 7
    	else if(mayorCounter == 10049){
    		if(zMO < 0){
    			if(canPlaceBlock(xM + xMO, yM + yMO, zM + zMO, 0) && canPlaceBlock(xM + xMO, yM + yMO + 1, zM + zMO, 1) && canPlaceBlock(xM + xMO, yM + yMO + 2, zM + zMO, 1)){
    				zMO++;
    				mayorCounter = 10045;
    			}
    			else if(canPlaceBlock(xM + xMO, yM + yMO + 1, zM + zMO, 0) && canPlaceBlock(xM + xMO, yM + yMO + 2, zM + zMO, 1) && canPlaceBlock(xM + xMO, yM + yMO + 3, zM + zMO, 1)){
    				yMO++;
    				zMO++;
    				mayorCounter = 10045;
    			}
    			else if(canPlaceBlock(xM + xMO, yM + yMO - 1, zM + zMO, 0) && canPlaceBlock(xM + xMO, yM + yMO, zM + zMO, 1) && canPlaceBlock(xM + xMO, yM + yMO + 1, zM + zMO, 1)){
    				yMO--;
    				zMO++;
    				mayorCounter = 10045;
    			}
    			//if not placeable, fail process
    			if(mayorCounter == 10049){
    				mayorCounter = 0;
        			noMove = false;
        			heldObj = null;
        			currentAction = 0;
        			actionTimer = 0;
    			}
    		}
    		//
    		else{ //once finished, enter final step
    			mayorCounter = 10050;
    			prevSwingProgress = 0.45F;
    			swingProgress = 0.45F;
    		}
    	}
    	
    	//Step 3: Wait while Builders build wall
    	else if(mayorCounter == 10060){
    		faceBlock(xM + xMO, yM + yMO, zM + zMO, 45F);
    		if(builderCount == 0){ // if all builders killed, fail process
				mayorCounter = 0;
    			noMove = false;
    			heldObj = null;
    			currentAction = 0;
    			actionTimer = 0;
    		}
    		else
    			mayorCounter = 10050;
    	}
    	
    	//NOTE: mayorCounter will be set to 9500 by a builder when wall is finished
    	//when mayor is above air, immediately place him downward
    	else if(mayorCounter == 9501){
    		xM = MathHelper.floor_double(posX) - (townRadius - 1);
    		yM = MathHelper.floor_double(boundingBox.minY);
    		zM = MathHelper.floor_double(posZ) - (townRadius - 1);
    		
    	}
    	else if(mayorCounter == 9510){
    		if(builderCount == 0){ // if all builders killed, fail process
				mayorCounter = 0;
    			noMove = false;
    			heldObj = null;
    			currentAction = 0;
    			actionTimer = 0;
    		}
    		else
    			mayorCounter = 9502;
    	}
    	//NOTE: mayorCounter will be set to 9600 when land is finished being renovated
    	//Final Step: When builders finish wall, place door, torches, chest, & signs in proper location\
    	else if(mayorCounter == 9601){
			prevSwingProgress = 0F;
			swingProgress = 0F;
    		worldObj.setBlockWithNotify(xDR, yDR + 1, zDR, 0);
    		worldObj.setBlockWithNotify(xDR, yDR, zDR, 0);
    		if(worldObj.setBlockAndMetadataWithNotify(xDR, yDR, zDR, Block.doorWood.blockID, 0x4 + 0x2))
    			worldObj.setBlockAndMetadataWithNotify(xDR, yDR + 1, zDR, Block.doorWood.blockID, 0x8 + 0x4 + 0x2);
    		//worldObj.setBlockMetadata(xDR, yDR + 1, zDR, 0x8); //testing
    		//worldObj.setBlockMetadata(xDR, yDR, zDR, 4); //testing
    		worldObj.setBlockAndMetadataWithNotify(xDR, yDR + 2, zDR + 1, Block.signWall.blockID, 0x3);
    		TileEntity tE = worldObj.getBlockTileEntity(xDR, yDR + 2, zDR + 1);
    		TileEntitySign tES;
    		if(tE != null){
    			tES = (TileEntitySign) tE;
    			if(tES != null)
    				tES.signText = new String[]{"Welcome to the", "small trading", "village of", new String(townNames1[rand.nextInt(townNames1.length)].concat(townNames2[rand.nextInt(townNames2.length)]))};
    		}
    		//noMove = false;
    		//mayorCounter = 0;
    		heldObj = null;
    		currentAction = -2;
			actionTimer = 0;
			tradeChestDistance = townRadius + 1;
    		//place town treasure chest
    		xT = MathHelper.floor_double(posX);
            yT = MathHelper.floor_double(boundingBox.minY) - 1;
            zT = MathHelper.floor_double(posZ);
            worldObj.setBlock(xT, yT, zT, Block.chest.blockID);
    		worldObj.setBlock(xT, yT + 1, zT, Block.signPost.blockID);
    		//set torches in town; if works, remove special settings for placing torch
    		if(Block.torchWood.canPlaceBlockAt(worldObj, xT, yT + 2, zT - (townRadius - 1)))
    			worldObj.setBlockWithNotify(xT, yT + 2, zT - (townRadius - 1), Block.torchWood.blockID);
    		if(Block.torchWood.canPlaceBlockAt(worldObj, xT + (townRadius - 1), yT + 2, zT))
    			worldObj.setBlockWithNotify(xT + (townRadius - 1), yT + 2, zT, Block.torchWood.blockID);
    		
    		TileEntity tE2 = worldObj.getBlockTileEntity(xT, yT + 1, zT);
    		TileEntitySign tES2;
    		if(tE2 != null){
    			tES2 = (TileEntitySign) tE2;
    			if(tES2 != null)
    				tES2.signText = new String[]{"Community", "trading chest.", "Share your", "items here!"};
    		}
    		
    	}
    	//keep mayor still until all builders done
    	else if(mayorCounter == 9610){
    		if(builderCount == 0){
    			noMove = false;
    			mayorCounter = 0;
				worldObj.playSoundAtEntity(this, "builder.townGasps", getSoundVolume(), (rand.nextFloat() - rand.nextFloat()) * 0.2F + 1.0F);
    		}
    		else
    			mayorCounter = 9605;
    	}
	}
    
    public boolean interact(EntityPlayer entityplayer)
    {
    	if(mayorCounter < 200 && super.interact(entityplayer) == true){
    		if(currentAction == 0)
    			mayorCounter = 199;
    		return true;
    	}
    	else
    		return false;
    }
    
    public BLDREntityBuilder getNearestIdleBuilder(Entity entity, double d)
    {
        double d1 = d * d;
        BLDREntityBuilder entitybuilder2 = null;
        List list = mod_Builders.builderList;
        for(int i = 0; i < list.size(); i++)
        {
        	BLDREntityBuilder eb = (BLDREntityBuilder)list.get(i);
            if(eb == entity.ridingEntity || eb == entity.riddenByEntity)
            {
                continue;
            }
            double d2 = eb.getDistanceSq(entity.posX, entity.posY, entity.posZ);
            if((d2 < d1) && eb.canEntityBeSeen(entity) && eb.currentAction == 0 && !(eb instanceof BLDREntityMayor))
            {
                d1 = d2;
                entitybuilder2 = eb;
            }
        }

        return entitybuilder2;
    }
    
    public BLDREntityBuilder getNearestIdleBuilder2(Entity entity, double d)
    {
        double d1 = d * d;
        BLDREntityBuilder entitybuilder2 = null;
        List list = mod_Builders.builderList;
        for(int i = 0; i < list.size(); i++)
        {
        	BLDREntityBuilder eb = (BLDREntityBuilder)list.get(i);
            if(eb == entity.ridingEntity || eb == entity.riddenByEntity)
            {
                continue;
            }
            double d2 = eb.getDistanceSq(entity.posX, entity.posY, entity.posZ);
            if((d2 < d1) && eb.canEntityBeSeen(entity) && eb.currentAction == 0  && !eb.noMove)
            {
                d1 = d2;
                entitybuilder2 = eb;
            }
        }

        return entitybuilder2;
    }
    
    public ItemStack getChestItem(){
    	return chestItems[rand.nextInt(chestItems.length)].copy();
    }
    
    protected float getBlockPathWeight(int i, int j, int k)
    {
    	if(currentAction == -2){
    		int d3 = xT - i;
            int d4 = yT - j;
            int d5 = zT - k;
            return -(float)MathHelper.sqrt_double(d3 * d3 + d4 * d4 + d5 * d5);
    	}
    	else
        	return super.getBlockPathWeight(i, j, k);
    }
    
    protected boolean canDespawn()
    {
        return super.canDespawn() && currentAction == 0;
    }
    
    protected boolean canTossMeat(){
    	return false;
    }
    
    protected void setTimers(short x){
    	if(mayorCounter < 9000)
    		mayorCounter = x;
    }
    
  //called when actionTimer = maxWait
    protected void selectIdleAction(){
    	heldObj = new ItemStack(mayorItems[rand.nextInt(mayorItems.length)], 1).copy();
    }
    
    protected ItemStack getHealingItem(){
    	return new ItemStack(Item.appleGold);
    }
    
    public int getMaxHp(){
    	return 35;
    }
    
    public int getClimbBlockID(){
    	return Block.glass.blockID;
    }
    
    protected String getActionDescrip(){
    	switch(currentAction){
    	case -2:
    		return "Managing town";
    	case -1:
    		return new StringBuilder("Building ").append(townRadius * 2 + 1).append(" x ").append(townRadius * 2 + 1).append(" town wall").toString();
    	case 0:
    		return new StringBuilder("Looking for location to build ").append(townRadius * 2 + 1).append(" x ").append(townRadius * 2 + 1).append(" town").toString();
    	default:
    		return super.getActionDescrip();
    	}
    }
    
    public static final Item[] mayorItems = new Item[]{
    	Item.pocketSundial, Item.compass, Item.reed, Item.book, Item.sign, Item.cake, Item.appleGold, Item.diamond, Item.ingotGold, Item.mapItem
    };
    public int builderCount; //Count of how many builders are assisting mayor
    public int mayorCounter; //mayor's specialized counter
    public int xDR; //X coordinate of Wall Door
    public int yDR; //Y coordinate of Wall Door
    public int zDR; //Z coordinate of Wall Door
    public int xM; //X coordinate of Mayor's current location pointer (starts at x + 7)
    public int yM; //Y coordinate of Mayor's current location pointer (starts at y + ?)
    public int zM; //Z coordinate of Mayor's current location pointer (starts at z + 7)
    public int xMO; // X offset of the Mayor's location pointer (changeable by builders)
    public int yMO; // Y offset of the Mayor's location pointer (changeable by builders)
    public int zMO; // Z offset of the Mayor's location pointer (changeable by builders)
    public int yMO2; //Additional Y offset for yMO.  Minimum of 0, maximum of 2.  Changeable by builders.
    public int traderMax; //used by other builders to determine position to build at.
    //public boolean followerMode; //if true, can gain followers; if false, cannot and trade mode.
    public int townRadius; //the radius of a town. Can be between 7 and 12. Town size is radius * 2 + 1 x radius * 2 + 1;
    static final String townNames1[] = new String[]{ // 8 letters maximum
    	"Grass", "Creature", "Luxury", "People", "Notch", "Peaceful", "Stone", "Stargaze", "Builder", "Simple", "Glory", "Dirt", "Gravy", "Mine"
    };
    static final String townNames2[] = new String[]{ //7 letters maximum
    	"Land", "County", "Place", "Town", "Ville", "Wall", "Skies", "Ocean", "Lake", "River", "Valley", "Sea", "Craftia", "Farm"
    };
    static final ItemStack[] chestItems = (new ItemStack[]{
        	new ItemStack(Item.book, 1), new ItemStack(Block.jukebox, 1), new ItemStack(Block.bookShelf, 1),
        	new ItemStack(Block.tnt, 1), new ItemStack(Block.rail, 1), new ItemStack(Item.bootsGold, 1),
        	new ItemStack(Item.redstone, 1), new ItemStack(Block.oreGold, 1), new ItemStack(Block.oreIron, 1),
        	new ItemStack(Item.dyePowder, 1, 4), new ItemStack(Item.compass, 1), new ItemStack(Item.pocketSundial, 1),
        	new ItemStack(Item.dyePowder, 1, 7), new ItemStack(Item.appleRed, 1), new ItemStack(Item.painting, 1),
        	new ItemStack(Item.dyePowder, 1, 12), new ItemStack(Item.legsDiamond, 1, Item.legsDiamond.getMaxDamage() / 2), new ItemStack(Item.plateLeather, 1),
        	new ItemStack(Item.appleGold, 1), new ItemStack(Item.book, 3), new ItemStack(Item.bootsDiamond, 1, 40),
        	new ItemStack(Item.ingotGold, 1), new ItemStack(Item.helmetDiamond, 1, Item.helmetDiamond.getMaxDamage() / 4), new ItemStack(Item.plateChain, 1, 50),
        	new ItemStack(Item.bucketEmpty, 1), new ItemStack(Block.plantYellow, 1), new ItemStack(Block.mushroomBrown, 1),
        	new ItemStack(Item.bread, 1)
        });
}
