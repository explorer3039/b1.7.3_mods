package net.minecraft.src;

import java.util.HashMap;

public class BLDREntityHomeSeeker extends BLDREntityBuilder{

	public BLDREntityHomeSeeker(World world) {
		super(world);
		if(BLDRBuilderConfig.homeStructureLimit != 0)
			buildCount = rand.nextInt(BLDRBuilderConfig.homeStructureLimit + 1);
		else
			buildCount = 0;
		int rrNum = rand.nextInt(4);
		if(rrNum == 0)
			texture = "/mob/HomeSeeker1.png";
		else if(rrNum == 1)
			texture = "/mob/HomeSeeker2.png";
		else if(rrNum == 2)
			texture = "/mob/HomeSeeker3.png";
		else
			texture = "/mob/HomeSeeker4.png";
			
		health = 20;
		maxWait = 145;
		if(rand.nextInt(10) < 9) //90% that HomeSeekers build single house with dirt
			buildBlock = BLDRBuilderConfig.homeCommonBlock;
		else //10% that HomeSeekers build single house with cloth
			buildBlock = BLDRBuilderConfig.homeRareBlock;
		//blueNum = rand.nextInt(Blueprints.numBlueprints - 1) + 1;
		blueNum = mod_Builders.homeSeekerHutIndex;

        tradeGiveNum = tradeGiveNum - rand.nextInt(5);
        tradeReceiveNum = rand.nextInt(2);
        tradeRatio = tradeRatio + rand.nextInt(15);
	}
	
	public void onDeath(Entity entity)
    {
        super.onDeath(entity);
    }
	
	public boolean getCanSpawnHere()
    {
		if(worldObj.isDaytime()){
			if(mod_Builders.countBuilders(this.getClass()) >= BLDRBuilderConfig.homeSpawnMaxDay)
				return false;
			else
				return rand.nextInt(100) < BLDRBuilderConfig.homeSpawnRateDay && super.getCanSpawnHere();
		}
		else{
			if(mod_Builders.countBuilders(this.getClass()) >= BLDRBuilderConfig.homeSpawnMaxNight)
				return false;
			else
				return rand.nextInt(100) < BLDRBuilderConfig.homeSpawnRateNight && super.getCanSpawnHere();
		}
    }
	
    public void writeEntityToNBT(NBTTagCompound nbttagcompound)
    {
        super.writeEntityToNBT(nbttagcompound);
    }

    public void readEntityFromNBT(NBTTagCompound nbttagcompound)
    {
        super.readEntityFromNBT(nbttagcompound);
    }
    
    public void onUpdate()
    {
    	if(currentAction == 0 && actionTimer == 15)
    		blueNum = mod_Builders.homeSeekerHutIndex;;
    	super.onUpdate();
	}
    
    public boolean interact(EntityPlayer entityplayer)
    {
    	if(currentAction == 0 || currentAction == 7){
    		ItemStack itemstack = entityplayer.inventory.getCurrentItem();
        	if(itemstack == null)
        	{
        		return super.interact(entityplayer);
        	}
        	else if(conversions.containsKey(itemstack.itemID)){
        		try {
					BLDREntityBuilder eb = (BLDREntityBuilder)conversions.get(itemstack.itemID).getConstructor(new Class[]{World.class}).newInstance(new Object[]{worldObj});
					eb.initConvert(itemstack.itemID, texture);
					eb.setPosition(posX, posY, posZ);
					eb.name = name;
	        		eb.builderFlags |= (1 << 2);
	        		if(!worldObj.entityJoinedWorld(eb))
	        			return false;
        		} catch (Exception e) {
					e.printStackTrace();
        		}
        	}
        	else
        		return super.interact(entityplayer);
        
       
        	if(itemstack.stackSize > 1)
        		itemstack.stackSize--;
        	else
        		entityplayer.destroyCurrentEquippedItem();
        	isDead = true;
        
        	return true;
    	}
    	else
    		return super.interact(entityplayer);
    }
    
    public ItemStack getChestItem(){
    	return chestItems[rand.nextInt(chestItems.length)].copy();
    }
    
    public boolean attackEntityFrom(Entity entity, int i)
    {
    	if((currentAction == 0 || currentAction >= 7 && currentAction <= 10 || currentAction >= 18 && currentAction <= 20) && entity instanceof EntityPlayer && rand.nextFloat() < 0.4F)
    		dropItem(Item.slimeBall.shiftedIndex, 1);
    	return super.attackEntityFrom(entity, i);
    }
    
    
    protected int getChunkOffsetX(){
    	return 2;
    }
    
    protected int getChunkOffsetZ(){
    	return -3;
    }
    
    protected ItemStack getThrownItem(){
    	return new ItemStack(Item.slimeBall);
    }
    
    protected ItemStack getHealingItem(){
    	return new ItemStack(Item.cookie);
    }
    
    public int getMaxHp(){
    	return 20;
    }
    
    protected boolean isAlwaysHappy(){
    	return true;
    }
    
    static final ItemStack[] chestItems = (new ItemStack[]{
        	new ItemStack(Block.dirt, 1), new ItemStack(Block.cloth, 1), new ItemStack(Item.stick, 1),
        	new ItemStack(Block.dirt, 1), new ItemStack(Block.gravel, 1), new ItemStack(Item.bone, 1),
        	new ItemStack(Item.leather, 1), new ItemStack(Item.bowlEmpty, 1), new ItemStack(Item.stick, 1),
        	new ItemStack(Item.seeds, 1), new ItemStack(Item.bootsLeather, 1), new ItemStack(Item.porkRaw, 1),
        	new ItemStack(Block.sand, 1), new ItemStack(Block.reed, 1), new ItemStack(Block.wood, 1),
        	new ItemStack(Block.dirt, 1), new ItemStack(Block.dirt, 1), new ItemStack(Item.stick, 1),
        	new ItemStack(Block.cloth, 1, 7), new ItemStack(Block.cloth, 1, 3), new ItemStack(Block.cloth, 12),
        	new ItemStack(Block.trapdoor, 1), new ItemStack(Block.sapling, 1, 2), new ItemStack(Item.egg, 3),
        	new ItemStack(Block.dirt, 1), new ItemStack(Block.gravel, 1), new ItemStack(Item.stick, 1),
        	new ItemStack(Item.slimeBall, 1)
        });

    private static final HashMap<Integer, Class> conversions;
    static{
    	conversions = new HashMap<Integer, Class>();
    	conversions.put(Block.brick.blockID, BLDREntityBrickBuilder.class);
    	conversions.put(Item.brick.shiftedIndex, BLDREntityBrickBuilder.class);
    	conversions.put(Block.cobblestone.blockID, BLDREntityCobbleBuilder.class);
    	conversions.put(Block.cobblestoneMossy.blockID, BLDREntityCobbleBuilder.class);
    	conversions.put(Block.torchWood.blockID, BLDREntityExplorer.class);
    	conversions.put(Item.swordWood.shiftedIndex, BLDREntityExplorer.class);
    	conversions.put(Block.workbench.blockID, BLDREntityMultiBuilder.class);
    	conversions.put(Block.ladder.blockID, BLDREntityMultiBuilder.class);
    	conversions.put(Block.sand.blockID, BLDREntitySandBuilder.class);
    	conversions.put(Block.sandStone.blockID, BLDREntitySandBuilder.class);
    	conversions.put(Item.book.shiftedIndex, BLDREntityMayor.class);
    	conversions.put(Block.bookShelf.blockID, BLDREntityMayor.class);
    	conversions.put(Item.ingotGold.shiftedIndex, BLDREntityTrader.class);
    	conversions.put(Item.diamond.shiftedIndex, BLDREntityTrader.class);
    	conversions.put(Item.bread.shiftedIndex, BLDREntityBaker.class);
    	conversions.put(Item.cookie.shiftedIndex, BLDREntityBaker.class);
    	conversions.put(Item.shovelWood.shiftedIndex, BLDREntityTreasureHunter.class);
    	conversions.put(Item.shovelGold.shiftedIndex, BLDREntityTreasureHunter.class);
    	conversions.put(Item.shovelStone.shiftedIndex, BLDREntityTreasureHunter.class);
    	conversions.put(Item.shovelSteel.shiftedIndex, BLDREntityTreasureHunter.class);
    	conversions.put(Item.shovelDiamond.shiftedIndex, BLDREntityTreasureHunter.class);
    }
}
