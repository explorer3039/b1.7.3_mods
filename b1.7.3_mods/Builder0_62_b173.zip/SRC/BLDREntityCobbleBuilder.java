package net.minecraft.src;

//CobbleBuilder: Places cobblestone; slow building speed; 15 hp; 250 blocks; day(common)/night(rare). Planned{Basic structures}

public class BLDREntityCobbleBuilder extends BLDREntityBuilder{

	public BLDREntityCobbleBuilder(World world) {
		super(world);
		buildCount = BLDRBuilderConfig.cobbleStructureLimit;
		health = 25;
		maxWait = 180;
		if(rand.nextInt(10) < 7) //70% chance of having cobblestone
			buildBlock = BLDRBuilderConfig.cobbleCommonBlock;
		else //30% chance of having regular stone
			buildBlock = BLDRBuilderConfig.cobbleRareBlock;
		int rrNum = rand.nextInt(3);
		if(rrNum == 0)
			texture = "/mob/CobbleBuilder1.png";
		else if(rrNum == 1)
			texture = "/mob/CobbleBuilder2.png";
		else{
			texture = "/mob/CobbleBuilder3.png";
			buildCount = buildCount * 2;
			maxWait = 140;
			health = 20;
			buildBlock = BLDRBuilderConfig.cobbleRareBlock;
		}
		if(BLDRBlueprints.singlePrints.size() > 0)
			blueNum = rand.nextInt(BLDRBlueprints.singlePrints.size());
		else
			blueNum = -1;
		while(BLDRBlueprints.singlePrints.size() > 2 && (blueNum == mod_Builders.explorerSingleBlockIndex || blueNum == mod_Builders.traderBakerShopIndex))
			blueNum = rand.nextInt(BLDRBlueprints.singlePrints.size());
        tradeGiveNum = tradeGiveNum + rand.nextInt(5);
        tradeReceiveNum = rand.nextInt(5);
        tradeRatio = tradeRatio - rand.nextInt(5);
        maxAir = 400;
	}
	
	protected void initConvert(int x, String s){
		if(x == Block.cobblestone.blockID){
			builderFlags |= (1 << 5); //pays rent three times as often
			moveSpeed += 0.15D;
			health += 5;
		}
		else if(x == Block.cobblestoneMossy.blockID){
			builderFlags |= (1 << 3); //trades twice as often
			builderFlags |= (1 << 4); //builds twice as fast
			buildBlock = Block.cobblestoneMossy.blockID; //builds with Mossy CobbleStone
			health += 10;
		}
    }
	
	public void onDeath(Entity entity)
    {
        super.onDeath(entity);
    }
	
	public boolean attackEntityFrom(Entity entity, int i)
    {
		return super.attackEntityFrom(entity, i);
    }
	
	public boolean getCanSpawnHere()
    {
		if(worldObj.isDaytime()){
			return mod_Builders.countBuilders(this.getClass()) < BLDRBuilderConfig.cobbleSpawnMaxDay && rand.nextInt(100) < BLDRBuilderConfig.cobbleSpawnRateDay && super.getCanSpawnHere();
		}
		else{
			return mod_Builders.countBuilders(this.getClass()) < BLDRBuilderConfig.cobbleSpawnMaxNight && rand.nextInt(100) < BLDRBuilderConfig.cobbleSpawnRateNight && super.getCanSpawnHere();
		}
    }
	
    public void writeEntityToNBT(NBTTagCompound nbttagcompound)
    {
        super.writeEntityToNBT(nbttagcompound);
    }

    public void readEntityFromNBT(NBTTagCompound nbttagcompound)
    {
        super.readEntityFromNBT(nbttagcompound);
    }
    
    public void onUpdate()
    {
    	if(currentAction >= 1 && currentAction <= 6 && actionTimer == 10099 && ((builderFlags >> 1) & 1) != 1){
    		if(BLDRBlueprints.singlePrints.size() > 0)
    			blueNum = rand.nextInt(BLDRBlueprints.singlePrints.size());
    		else
    			blueNum = -1;
    		while(BLDRBlueprints.singlePrints.size() > 2 && (blueNum == mod_Builders.explorerSingleBlockIndex || blueNum == mod_Builders.traderBakerShopIndex))
    			blueNum = rand.nextInt(BLDRBlueprints.singlePrints.size());
    	}
    	if(inWater) //CobbleBuilders can swim faster
    		if(rand.nextFloat() < 0.4F){
    			motionX *= 1.3D;
    			motionZ *= 1.3D;
    			motionY *= motionY > 0.0D ? 1.15D : 0.85D;
    		}
    	super.onUpdate();
	}
    
    public ItemStack getChestItem(){
    	return chestItems[rand.nextInt(chestItems.length)].copy();
    }
    
    public boolean canRenovateBuild(){
    	return true;
    }
    
    protected ItemStack getThrownItem(){
    	return new ItemStack(Item.fishRaw);
    }
    
    protected int getChunkOffsetX(){
    	return 4;
    }
    
    protected int getChunkOffsetZ(){
    	return -6;
    }
    
    protected ItemStack getHealingItem(){
    	return new ItemStack(Item.fishCooked);
    }

    public int getMaxHp(){
    	return 25;
    }
    
    static final ItemStack[] chestItems = (new ItemStack[]{
        	new ItemStack(Block.cobblestone, 1), new ItemStack(Block.cobblestone, 1), new ItemStack(Block.cobblestone, 1),
        	new ItemStack(Item.dyePowder, 1, 7), new ItemStack(Item.dyePowder, 1, 8), new ItemStack(Item.gunpowder, 1),
        	new ItemStack(Block.stone, 1), new ItemStack(Block.cobblestoneMossy, 1), new ItemStack(Item.coal, 1),
        	new ItemStack(Item.paper, 1), new ItemStack(Item.flint, 1), new ItemStack(Item.helmetLeather, 1),
        	new ItemStack(Item.bone, 1), new ItemStack(Item.pickaxeDiamond, 1, Item.pickaxeDiamond.getMaxDamage() - 35), new ItemStack(Item.flintAndSteel, 1, 14),
        	new ItemStack(Item.pickaxeWood, 1), new ItemStack(Item.pickaxeStone, 1), new ItemStack(Item.pickaxeSteel, 1, Item.pickaxeSteel.getMaxDamage() - 45),
        	new ItemStack(Item.pickaxeGold, 1, Item.pickaxeGold.getMaxDamage() / 2)
        });
}
