package net.minecraft.src;

/*
 * Unique Actions
 * -1: Shop Mode
 */
public class BLDREntityTrader extends BLDREntityBuilder{
	public BLDREntityTrader(World world) {
		super(world);
		buildCount = 1;
		health = 20;
		maxWait = 200;
		buildBlock = BLDRBuilderConfig.traderBlock; 
		int rrNum = rand.nextInt(3);
		if(rrNum == 0)
			texture = "/mob/Trader1.png";
		else if(rrNum == 1)
			texture = "/mob/Trader2.png";
		else{
			texture = "/mob/Trader3.png";
		}
        blueNum = mod_Builders.traderBakerShopIndex;
        shopX = 0;
        shopY = 0;
        shopZ = 0;
	}
	
	protected void initConvert(int x, String s){
		if(x == Item.ingotGold.shiftedIndex){
			builderFlags |= (1 << 3); //trades twice as often
			health += 2;
			buildBlock = Block.sandStone.blockID;
		}
		else if(x == Item.diamond.shiftedIndex){
			builderFlags |= (1 << 3); //trades twice as often
			builderFlags |= (1 << 5); //pays rent three times as often
			health += 8;
			buildBlock = Block.blockLapis.blockID; //valuable build block
		}
    }
	
	public void onDeath(Entity entity)
    {
        super.onDeath(entity);
    }
	
	public boolean getCanSpawnHere()
    {
		if(worldObj.isDaytime()){
			if(mod_Builders.countBuilders(this.getClass()) >= BLDRBuilderConfig.traderSpawnMaxDay)
				return false;
			else
				return rand.nextInt(100) < BLDRBuilderConfig.traderSpawnRateDay && super.getCanSpawnHere();
		}
		else{
			if(mod_Builders.countBuilders(this.getClass()) >= BLDRBuilderConfig.traderSpawnMaxNight)
				return false;
			else
				return rand.nextInt(100) < BLDRBuilderConfig.traderSpawnRateNight && super.getCanSpawnHere();
		}
    }
	
    public void writeEntityToNBT(NBTTagCompound nbttagcompound)
    {
        super.writeEntityToNBT(nbttagcompound);
        if(currentAction == -1){
        	nbttagcompound.setInteger("coalItemID", coalTradeItem.itemID);
        	nbttagcompound.setInteger("coalStackSize", coalTradeItem.stackSize);
        	nbttagcompound.setInteger("ironItemID", ironTradeItem.itemID);
        	nbttagcompound.setInteger("ironStackSize", ironTradeItem.stackSize);
        	nbttagcompound.setInteger("goldItemID", goldTradeItem.itemID);
        	nbttagcompound.setInteger("goldStackSize", goldTradeItem.stackSize);
        	nbttagcompound.setInteger("diamondItemID", diamondTradeItem.itemID);
        	nbttagcompound.setInteger("diamondStackSize", diamondTradeItem.stackSize);
        }
    }

    public void readEntityFromNBT(NBTTagCompound nbttagcompound)
    {
        super.readEntityFromNBT(nbttagcompound);
        if(currentAction == -1){
        	noMove = true;
        	int id1 = 0; //id number
        	int ss1 = 0; //stack size
        	//coal item
        	if(nbttagcompound.hasKey("coalItemID"))
        	{
            	id1 = nbttagcompound.getInteger("coalItemID");
        	}
        	if(nbttagcompound.hasKey("coalStackSize"))
        	{
        		ss1 = nbttagcompound.getInteger("coalStackSize");
        	}
        	if(id1 != 0 && ss1 != 0)
        		coalTradeItem = new ItemStack(id1, ss1, 0);
        	id1 = 0;
        	ss1 = 0;
        	//iron item
        	if(nbttagcompound.hasKey("ironItemID"))
        	{
            	id1 = nbttagcompound.getInteger("ironItemID");
        	}
        	if(nbttagcompound.hasKey("ironStackSize"))
        	{
        		ss1 = nbttagcompound.getInteger("ironStackSize");
        	}
        	if(id1 != 0 && ss1 != 0)
        		ironTradeItem = new ItemStack(id1, ss1, 0);
        	id1 = 0;
        	ss1 = 0;
        	//gold item
        	if(nbttagcompound.hasKey("goldItemID"))
        	{
            	id1 = nbttagcompound.getInteger("goldItemID");
        	}
        	if(nbttagcompound.hasKey("goldStackSize"))
        	{
        		ss1 = nbttagcompound.getInteger("goldStackSize");
        	}
        	if(id1 != 0 && ss1 != 0)
        		goldTradeItem = new ItemStack(id1, ss1, 0);
        	id1 = 0;
        	ss1 = 0;
        	//diamond item
        	if(nbttagcompound.hasKey("diamondItemID"))
        	{
            	id1 = nbttagcompound.getInteger("diamondItemID");
        	}
        	if(nbttagcompound.hasKey("diamondStackSize"))
        	{
        		ss1 = nbttagcompound.getInteger("diamondStackSize");
        	}
        	if(id1 != 0 && ss1 != 0)
        		diamondTradeItem = new ItemStack(id1, ss1, 0);
        	id1 = 0;
        	ss1 = 0;
        }
    }
    
    protected boolean canDespawn()
    {
        return super.canDespawn() && currentAction != -1;
    }
    
    public void onUpdate()
    {
    	super.onUpdate();
    	//Set trader's home location
    	if(currentAction == -1){
    		actionTimer = 0;
    	}
    	if(actionTimer == 14){
    		blueNum = mod_Builders.traderBakerShopIndex;
    	}
    	if(currentAction >= 1 && currentAction <= 6 && actionTimer == 10049 && jA == 0 && kA == 1 && BLDRBlueprints.singlePrints.get(blueNum).get(jA).get(iA).get(kA) == 0){
    		shopX = iA + iB;
    		shopY = jA + jB;
    		shopZ = kA + kB;
    	}
    	if(buildCount == 0 && currentAction != -1 && actionTimer == 0){
    		setupShop();
    	}
    	if(currentAction != -1)
    		return;
    	
    	if(handCounter > 0){
    		handCounter++;
    	}
    	EntityPlayer eP = ModLoader.getMinecraftInstance().thePlayer;
    	
		if(eP != null)
			this.faceBlock(eP.posX, eP.posY, eP.posZ, 12F);
    	if(handCounter > 4 && handCounter <= 12){
    		prevSwingProgress = (12 - handCounter) * 0.125F;
    		swingProgress = (12 - handCounter) * 0.125F;
    	}
    	else if(handCounter == 13){
    		heldObj = null;

        	if(itemToGive.getItem() instanceof ItemArmor || itemToGive.getItem() instanceof ItemTool || itemToGive.getItem() instanceof ItemSword)
        		itemToGive.damageItem(rand.nextInt(itemToGive.getMaxDamage() / 2), null); //damages item
        	worldObj.entityJoinedWorld(new EntityItem(worldObj, eP.posX, eP.posY + 0.2D, eP.posZ, itemToGive));
        	handCounter = 0;
    	}
	}
    
    public ItemStack getChestItem(){
    	if(rand.nextInt(20) > 0)
    		return chestItems[rand.nextInt(chestItems.length)].copy();
    	else{
    		int rNum1 = rand.nextInt(100);
    		if(rNum1 < 50)
    			return new ItemStack(coalItems[rand.nextInt(coalItems.length)].copy().itemID, 1, 0);
    		else if(rNum1 < 75)
    			return new ItemStack(ironItems[rand.nextInt(ironItems.length)].copy().itemID, 1, 0);
    		else if(rNum1 < 99)
    			return new ItemStack(goldItems[rand.nextInt(goldItems.length)].copy().itemID, 1, 0);
    		else
    			return new ItemStack(diamondItems[rand.nextInt(diamondItems.length)].copy().itemID, 1, 0);
    	}
    	//return null;
    }
    
    protected int getDropItemId()
    {
    	if(rand.nextInt(20) != 0)
    		return Item.paper.shiftedIndex;
    	else
    		return Item.ingotGold.shiftedIndex;
    }
    
    protected ItemStack getTradeItem(int i){
    	ItemStack iS;
    	if(i == 0){
    		iS = coalItems[rand.nextInt(coalItems.length)].copy();
    	}
    	else if(i == 1){
    		iS = ironItems[rand.nextInt(ironItems.length)].copy();
    	}
    	else if(i == 2){
    		iS = goldItems[rand.nextInt(goldItems.length)].copy();
    	}
    	else if(i == 3){
    		iS = diamondItems[rand.nextInt(diamondItems.length)].copy();
    	}
    	else
    		return null;
    	if(iS.getMaxStackSize() != 1)
    		iS.stackSize += rand.nextInt(5);
    	return iS;
    }
    
    public boolean interact(EntityPlayer entityplayer)
    {
		if(currentAction != -1 || entityplayer.inventory.getCurrentItem()== null)
			return super.interact(entityplayer);
		else if(handCounter > 0)
			return false;
		else{
			ItemStack itemstack = entityplayer.inventory.getCurrentItem();
			//prepare give item process
			if(itemstack.itemID == Item.coal.shiftedIndex)
        	{
        		heldObj = coalTradeItem.copy();
        		itemToGive = coalTradeItem.copy();
        		handCounter = 1;
        	}
			else if(itemstack.itemID == Item.ingotIron.shiftedIndex)
        	{
        		heldObj = ironTradeItem.copy();
        		itemToGive = ironTradeItem.copy();
        		handCounter = 1;
        	}
			else if(itemstack.itemID == Item.ingotGold.shiftedIndex)
        	{
        		heldObj = goldTradeItem.copy();
        		itemToGive = goldTradeItem.copy();
        		handCounter = 1;
        	}
			else if(itemstack.itemID == Item.diamond.shiftedIndex)
        	{
        		heldObj = diamondTradeItem.copy();
        		itemToGive = diamondTradeItem.copy();
        		handCounter = 1;
        	}
			else{
				return false;
			}
			//remove item
			ItemStack temp = entityplayer.inventory.getStackInSlot(entityplayer.inventory.currentItem);
        	if(temp.stackSize > 1)
        		temp.stackSize--;
        	else
        		entityplayer.destroyCurrentEquippedItem();
        	
        	return true;
		}
    }
    
    private void setupShop(){
    	currentAction = -1;
		//place trader in shop
		setPosition(shopX + 0.5, shopY, shopZ + 1);
		setPosition(posX, MathHelper.floor_double(boundingBox.minY), posZ);
		//set trade items
		coalTradeItem = getTradeItem(0);
		ironTradeItem = getTradeItem(1);
		goldTradeItem = getTradeItem(2);
		diamondTradeItem = getTradeItem(3);
		//place cloth underneath trader
		worldObj.setBlock(shopX, shopY - 1, shopZ, Block.cloth.blockID);
		worldObj.setBlock(shopX, shopY - 1, shopZ + 1, Block.cloth.blockID);
		//place and set title wall sign & torches.
		worldObj.setBlock(shopX + 2, shopY + 1, shopZ - 1, Block.torchWood.blockID);
		worldObj.setBlockAndMetadata(shopX + 2, shopY + 2, shopZ, Block.signWall.blockID, 0x5);
		worldObj.setBlockAndMetadata(shopX + 2, shopY + 2, shopZ + 1, Block.signWall.blockID, 0x5);
		worldObj.setBlock(shopX + 2, shopY + 1, shopZ + 2, Block.torchWood.blockID);
			//set Title Signs
		TileEntity tE = worldObj.getBlockTileEntity(shopX + 2, shopY + 2, shopZ + 1);
		TileEntitySign tES;
		if(tE != null){
			tES = (TileEntitySign) tE;
			if(tES != null)
				tES.signText = new String[]{"Welcome to", name.concat("'s"), "Trading Shop.", "Trade your"};
		}
		tE = worldObj.getBlockTileEntity(shopX + 2, shopY + 2, shopZ);
		if(tE != null){
			tES = (TileEntitySign) tE;
			if(tES != null)
				tES.signText = new String[]{"spare coal,", "iron, gold, and", "diamonds here.", "Enjoy!"};
		}
		//place trade wall signs on shop (try facing south)
		worldObj.setBlockAndMetadata(shopX + 2, shopY, shopZ - 1, Block.signWall.blockID, 0x5);
		worldObj.setBlockAndMetadata(shopX + 2, shopY, shopZ, Block.signWall.blockID, 0x5);
		worldObj.setBlockAndMetadata(shopX + 2, shopY, shopZ + 1, Block.signWall.blockID, 0x5);
		worldObj.setBlockAndMetadata(shopX + 2, shopY, shopZ + 2, Block.signWall.blockID, 0x5);
		//set Coal-Trade Sign
		String tItem = (new StringBuilder()).append("").append(StringTranslate.getInstance().translateNamedKey(coalTradeItem.getItemName())).toString().trim();
		if(tItem == null || tItem.length() > 15)
			tItem = "Mystery Item";
		tE = worldObj.getBlockTileEntity(shopX + 2, shopY, shopZ + 2);
		if(tE != null){
			tES = (TileEntitySign) tE;
			if(tES != null)//.split(".")[1] //check if substring function works correctly
				tES.signText = new String[]{"Trade 1 Coal", "for ".concat((new StringBuilder()).append(coalTradeItem.stackSize).toString()), tItem, ""};
		}
		//set Iron-Trade Sign
		tItem = (new StringBuilder()).append("").append(StringTranslate.getInstance().translateNamedKey(ironTradeItem.getItemName())).toString().trim();
		if(tItem == null || tItem.length() > 15)
			tItem = "Mystery Item";
		tE = worldObj.getBlockTileEntity(shopX + 2, shopY, shopZ + 1);
		if(tE != null){
			tES = (TileEntitySign) tE;
			if(tES != null)
				tES.signText = new String[]{"Trade 1 Iron", "Bar for ".concat((new StringBuilder()).append(ironTradeItem.stackSize).toString()), tItem, ""};
		}
		//set Gold-Trade Sign
		tItem = (new StringBuilder()).append("").append(StringTranslate.getInstance().translateNamedKey(goldTradeItem.getItemName())).toString().trim();
		if(tItem == null || tItem.length() > 15)
			tItem = "Mystery Item";
		tE = worldObj.getBlockTileEntity(shopX + 2, shopY, shopZ);
		if(tE != null){
			tES = (TileEntitySign) tE;
			if(tES != null)
				tES.signText = new String[]{"Trade 1 Gold", "Bar for ".concat((new StringBuilder()).append(goldTradeItem.stackSize).toString()), tItem, ""};
		}
		//set Diamond-Trade Sign
		tItem = (new StringBuilder()).append("").append(StringTranslate.getInstance().translateNamedKey(diamondTradeItem.getItemName())).toString().trim();
		if(tItem == null || tItem.length() > 15)
			tItem = "Mystery Item";
		tE = worldObj.getBlockTileEntity(shopX + 2, shopY, shopZ - 1);
		if(tE != null){
			tES = (TileEntitySign) tE;
			if(tES != null)
				tES.signText = new String[]{"Trade 1 Diamond", "for ".concat((new StringBuilder()).append(diamondTradeItem.stackSize).toString()), tItem, ""};
		}
		noMove = true;
    }

    protected boolean uniDirectionalStructures(){
    	return true;
    }
    
    protected boolean canTossMeat(){
    	return currentAction != -1;
    }
    
    protected boolean canBeHurt(){
    	return currentAction == -1 || super.canBeHurt();
    }
    
    
    protected int getChunkOffsetX(){
    	return -1;
    }
    
    protected int getChunkOffsetZ(){
    	return 4;
    }
    
    protected ItemStack getThrownItem(){
    	return new ItemStack(Item.bread);
    }
    
    protected ItemStack getHealingItem(){
    	return new ItemStack(Item.appleRed);
    }
    
    public int getMaxHp(){
    	return 20;
    }
    
    protected String getActionDescrip(){
    	switch(currentAction){
    	case -1:
    		return "Selling various goods";
    	default:
    		return super.getActionDescrip();
    	}
    }
    
    static final ItemStack[] chestItems = (new ItemStack[]{
        	new ItemStack(Item.leather, 1), new ItemStack(Item.leather, 1), new ItemStack(Item.leather, 1),
        	new ItemStack(Item.leather, 1), new ItemStack(Item.leather, 1), new ItemStack(Item.leather, 1),
        	new ItemStack(Item.leather, 1), new ItemStack(Item.coal, 1), new ItemStack(Item.leather, 1),
        	new ItemStack(Item.leather, 1), new ItemStack(Item.leather, 1), new ItemStack(Item.leather, 1),
        	new ItemStack(Item.axeGold, 1), new ItemStack(Item.gunpowder, 2), new ItemStack(Item.swordDiamond, 1, Item.swordDiamond.getMaxDamage() - 65),
        	new ItemStack(Item.leather, 1), new ItemStack(Item.leather, 1), new ItemStack(Item.leather, 1),
        	new ItemStack(Item.leather, 1), new ItemStack(Item.ingotGold, 1), new ItemStack(Item.coal, 1),
        	new ItemStack(Item.leather, 1), new ItemStack(Item.leather, 1), new ItemStack(Item.diamond, 1), new ItemStack(Item.ingotIron, 1)
        });
        
    
    static final ItemStack[] coalItems = new ItemStack[]{
    	new ItemStack(Block.cactus.blockID, 5, 0), new ItemStack(Block.cloth.blockID, 8, 0), new ItemStack(Block.plantRed.blockID, 4, 0),
    	new ItemStack(Block.plantYellow.blockID, 4, 0), new ItemStack(Block.mushroomBrown.blockID, 1, 0), new ItemStack(Block.mushroomRed.blockID, 1, 0),
    	new ItemStack(Block.wood.blockID, 4, 0), new ItemStack(Block.torchWood.blockID, 3, 0), new ItemStack(Block.rail.blockID, 2, 0),
    	new ItemStack(Block.sapling.blockID, 2, 0), new ItemStack(Block.pumpkin.blockID, 1, 0), new ItemStack(Block.ladder.blockID, 2, 0),
    	new ItemStack(Item.clay.shiftedIndex, 1, 0), new ItemStack(Item.wheat.shiftedIndex, 3, 0), new ItemStack(Item.gunpowder.shiftedIndex, 3, 0),
    	new ItemStack(Item.sugar.shiftedIndex, 6, 0), new ItemStack(Item.dyePowder.shiftedIndex, 3, 0), new ItemStack(Item.bone.shiftedIndex, 6, 0)
    };
    
    static final ItemStack[] ironItems = new ItemStack[]{
    	new ItemStack(Item.coal.shiftedIndex, 5, 0), new ItemStack(Item.wheat.shiftedIndex, 10, 0), new ItemStack(Item.gunpowder.shiftedIndex, 10, 0),
    	new ItemStack(Item.flint.shiftedIndex, 16, 0), new ItemStack(Item.leather.shiftedIndex, 10, 0), new ItemStack(Item.stick.shiftedIndex, 50, 0),
    	new ItemStack(Item.redstone.shiftedIndex, 1, 0), new ItemStack(Item.egg.shiftedIndex, 7, 0), new ItemStack(Item.feather.shiftedIndex, 20, 0),
    	new ItemStack(Item.reed.shiftedIndex, 8, 0), new ItemStack(Item.arrow.shiftedIndex, 30, 0), new ItemStack(Block.tnt.blockID, 3, 0),
    	new ItemStack(Item.bow.shiftedIndex, 1, 0), new ItemStack(Item.helmetChain.shiftedIndex, 1, 0), new ItemStack(Item.axeSteel.shiftedIndex, 1, 0),
    	new ItemStack(Item.fishCooked.shiftedIndex, 1, 0), new ItemStack(Block.musicBlock.blockID, 3, 0), new ItemStack(Block.sandStone.blockID, 35, 0)
    };
    
    static final ItemStack[] goldItems = new ItemStack[]{
    	new ItemStack(Item.bootsSteel.shiftedIndex, 1, 0), new ItemStack(Item.gunpowder.shiftedIndex, 23, 0), new ItemStack(Item.swordSteel.shiftedIndex, 1, 0),
    	new ItemStack(Item.shovelGold.shiftedIndex, 1, 0), new ItemStack(Item.ingotIron.shiftedIndex, 2, 0), new ItemStack(Item.coal.shiftedIndex, 15, 0),
    	new ItemStack(Item.bucketLava.shiftedIndex, 1, 0), new ItemStack(Item.hoeDiamond.shiftedIndex, 1, 0), new ItemStack(Item.legsSteel.shiftedIndex, 1, 0),
    	new ItemStack(Item.lightStoneDust.shiftedIndex, 1, 0), new ItemStack(Item.redstone.shiftedIndex, 10, 0), new ItemStack(Block.tnt.blockID, 8, 0),
    	new ItemStack(Block.oreIron, 4), new ItemStack(Block.rail.blockID, 30, 0), new ItemStack(Item.pickaxeSteel.shiftedIndex, 1, 0),
    	new ItemStack(Block.dispenser.blockID, 5, 0), new ItemStack(Block.oreLapis.blockID, 2, 0), 
    };
    
    static final ItemStack[] diamondItems = new ItemStack[]{
    	new ItemStack(Item.appleGold.shiftedIndex, 1, 0), new ItemStack(Item.axeDiamond.shiftedIndex, 1, 0), new ItemStack(Block.blockGold.blockID, 2, 0),
    	new ItemStack(Block.blockSteel, 5), new ItemStack(Item.swordDiamond.shiftedIndex, 1, 0), new ItemStack(Item.bootsDiamond.shiftedIndex, 1, 0),
    	new ItemStack(Item.helmetDiamond.shiftedIndex, 1, 0), new ItemStack(Block.netherrack.blockID, 20, 0), new ItemStack(Block.glowStone.blockID, 10, 0),
    	new ItemStack(Block.slowSand.blockID, 10, 0), new ItemStack(Block.tnt, 60), new ItemStack(Block.obsidian.blockID, 15, 0),
    	new ItemStack(Item.wheat.shiftedIndex, 60, 0), new ItemStack(Item.record13.shiftedIndex, 1, 0), new ItemStack(Item.recordCat.shiftedIndex, 1, 0),
    	new ItemStack(Block.blockLapis.blockID, 1, 0), 
    };
    
    public int shopX; //Xcoordinate of inside of shop
    public int shopY; //Ycoordinate of inside of shop
    public int shopZ; //Zcoordinate of inside of shop
    public ItemStack coalTradeItem; //coal trade item
    public ItemStack ironTradeItem; //iron trade item
    public ItemStack goldTradeItem; //gold trade item
    public ItemStack diamondTradeItem; //diamond trade item
    public ItemStack itemToGive; //item that is given to player
    protected short handCounter; //used for timing item throw properly
}
