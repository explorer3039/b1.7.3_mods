package net.minecraft.src;

import java.util.HashMap;

/*
 * Unique Actions
 * -1: Shop Mode
 */
public class BLDREntityBaker extends BLDREntityBuilder{
	public BLDREntityBaker(World world) {
		super(world);
		buildCount = 1;
		health = 20;
		maxWait = 200;
		buildBlock = BLDRBuilderConfig.bakerBlock; 
		int rrNum = rand.nextInt(3);
		if(rrNum == 0)
			texture = "/mob/Baker1.png";
		else if(rrNum == 1)
			texture = "/mob/Baker2.png";
		else{
			texture = "/mob/Baker3.png";
		}
        blueNum = mod_Builders.traderBakerShopIndex;
        shopX = 0;
        shopY = 0;
        shopZ = 0;
        breads = null;
	}
	
	protected void initConvert(int x, String s){
		if(x == Item.bread.shiftedIndex){
			builderFlags |= (1 << 5); //pays rent three times as often
			health = 30;
		}
		else if(x == Item.cookie.shiftedIndex){
			builderFlags |= (1 << 3); //trades twice as often
			health = 25;
		}
    }
	
	public void onDeath(Entity entity)
    {
		if(rand.nextFloat() < 0.08F){
			EntityItem entityitem = new EntityItem(worldObj, posX, posY + (double)0.1F, posZ, new ItemStack(Item.dyePowder.shiftedIndex, 2, 3));
	        entityitem.delayBeforeCanPickup = 10;
	        entityitem.motionY += 0.07F;
	        worldObj.entityJoinedWorld(entityitem);
		}
		super.onDeath(entity);
    }
	
	public boolean getCanSpawnHere()
    {
		if(worldObj.isDaytime()){
			if(mod_Builders.countBuilders(this.getClass()) >= BLDRBuilderConfig.bakerSpawnMaxDay)
				return false;
			else
				return rand.nextInt(100) < BLDRBuilderConfig.bakerSpawnRateDay && super.getCanSpawnHere();
		}
		else{
			if(mod_Builders.countBuilders(this.getClass()) >= BLDRBuilderConfig.bakerSpawnMaxNight)
				return false;
			else
				return rand.nextInt(100) < BLDRBuilderConfig.bakerSpawnRateNight && super.getCanSpawnHere();
		}
    }
	
    public void writeEntityToNBT(NBTTagCompound nbttagcompound)
    {
        super.writeEntityToNBT(nbttagcompound);
        if(currentAction == -1){
        	nbttagcompound.setInteger("woodItemID", woodTradeItem.itemID);
        	nbttagcompound.setInteger("woodStackSize", woodTradeItem.stackSize);
        	nbttagcompound.setInteger("leatherItemID", leatherTradeItem.itemID);
        	nbttagcompound.setInteger("leatherStackSize", leatherTradeItem.stackSize);
        	nbttagcompound.setInteger("redstoneItemID", redstoneTradeItem.itemID);
        	nbttagcompound.setInteger("redstoneStackSize", redstoneTradeItem.stackSize);
        	nbttagcompound.setInteger("lightdustItemID", lightdustTradeItem.itemID);
        	nbttagcompound.setInteger("lightdustStackSize", lightdustTradeItem.stackSize);
        }
    }

    public void readEntityFromNBT(NBTTagCompound nbttagcompound)
    {
        super.readEntityFromNBT(nbttagcompound);
        if(currentAction == -1){
        	noMove = true;
        	int id1 = 0; //id number
        	int ss1 = 0; //stack size
        	//wood item
        	if(nbttagcompound.hasKey("woodItemID"))
        	{
            	id1 = nbttagcompound.getInteger("woodItemID");
        	}
        	if(nbttagcompound.hasKey("woodStackSize"))
        	{
        		ss1 = nbttagcompound.getInteger("woodStackSize");
        	}
        	if(id1 != 0 && ss1 != 0)
        		woodTradeItem = new ItemStack(id1, ss1, id1 == Item.dyePowder.shiftedIndex ? 3 :0);
        	id1 = 0;
        	ss1 = 0;
        	//leather item
        	if(nbttagcompound.hasKey("leatherItemID"))
        	{
            	id1 = nbttagcompound.getInteger("leatherItemID");
        	}
        	if(nbttagcompound.hasKey("leatherStackSize"))
        	{
        		ss1 = nbttagcompound.getInteger("leatherStackSize");
        	}
        	if(id1 != 0 && ss1 != 0)
        		leatherTradeItem = new ItemStack(id1, ss1, 0);
        	id1 = 0;
        	ss1 = 0;
        	//redstone item
        	if(nbttagcompound.hasKey("redstoneItemID"))
        	{
            	id1 = nbttagcompound.getInteger("redstoneItemID");
        	}
        	if(nbttagcompound.hasKey("redstoneStackSize"))
        	{
        		ss1 = nbttagcompound.getInteger("redstoneStackSize");
        	}
        	if(id1 != 0 && ss1 != 0)
        		redstoneTradeItem = new ItemStack(id1, ss1, 0);
        	id1 = 0;
        	ss1 = 0;
        	//lightdust item
        	if(nbttagcompound.hasKey("lightdustItemID"))
        	{
            	id1 = nbttagcompound.getInteger("lightdustItemID");
        	}
        	if(nbttagcompound.hasKey("lightdustStackSize"))
        	{
        		ss1 = nbttagcompound.getInteger("lightdustStackSize");
        	}
        	if(id1 != 0 && ss1 != 0)
        		lightdustTradeItem = new ItemStack(id1, ss1, 0);
        	id1 = 0;
        	ss1 = 0;
        }
    }
    
    protected boolean canDespawn()
    {
        return super.canDespawn() && currentAction != -1;
    }
    
    public void onUpdate()
    {
    	super.onUpdate();
    	//Set baker's home location
    	if(currentAction == -1){
    		actionTimer = 0;
    	}
    	if(actionTimer == 14){
    		blueNum = mod_Builders.traderBakerShopIndex;
    	}
    	if(currentAction >= 1 && currentAction <= 6 && actionTimer == 10049 && jA == 0 && kA == 1 && BLDRBlueprints.singlePrints.get(blueNum).get(jA).get(iA).get(kA) == 0){
    		shopX = iA + iB;
    		shopY = jA + jB;
    		shopZ = kA + kB;
    	}
    	if(buildCount == 0 && currentAction != -1 && actionTimer == 0){
    		setupShop();
    	}

    	if(currentAction != -1)
    		return;
    	
    	if(handCounter > 0){
    		handCounter++;
    	}
    	EntityPlayer eP = ModLoader.getMinecraftInstance().thePlayer;
		if(eP != null)
			this.faceBlock(eP.posX, eP.posY, eP.posZ, 12F);
    	if(handCounter > 4 && handCounter <= 12){
    		prevSwingProgress = (12 - handCounter) * 0.125F;
    		swingProgress = (12 - handCounter) * 0.125F;
    	}
    	else if(handCounter == 13){
    		heldObj = null;

        	worldObj.entityJoinedWorld(new EntityItem(worldObj, eP.posX, eP.posY + 0.2D, eP.posZ, itemToGive));
        	handCounter = 0;
    	}
    	//if player nearby, spawn breads and smoked goods
    	if(eP.getDistanceToEntity(this) < 40){
    		spawnBreads();
    		makeBreadsSmoke();
    	}
    	//if player far, kill breads
    	else{
    		killBreads();
    	}
	}
    
    public ItemStack getChestItem(){
    	if(rand.nextInt(20) != 0)
    		return chestItems[rand.nextInt(chestItems.length)].copy();
    	else{
    		int rNum1 = rand.nextInt(100);
    		if(rNum1 < 50)
    			return new ItemStack(woodItems[rand.nextInt(woodItems.length)].copy().itemID, 1, 0);
    		else if(rNum1 < 75)
    			return new ItemStack(leatherItems[rand.nextInt(leatherItems.length)].copy().itemID, 1, 0);
    		else if(rNum1 < 99)
    			return new ItemStack(redstoneItems[rand.nextInt(redstoneItems.length)].copy().itemID, 1, 0);
    		else
    			return new ItemStack(lightdustItems[rand.nextInt(lightdustItems.length)].copy().itemID, 1, 0);
    	}
    	//return null;
    }
    
    protected int getDropItemId()
    {
    	return dropIDs.get(rand.nextInt(dropIDs.size()));
    }
    
    protected ItemStack getTradeItem(int i){
    	ItemStack iS;
    	if(i == 0){
    		iS = woodItems[rand.nextInt(woodItems.length)].copy();
    	}
    	else if(i == 1){
    		iS = leatherItems[rand.nextInt(leatherItems.length)].copy();
    	}
    	else if(i == 2){
    		iS = redstoneItems[rand.nextInt(redstoneItems.length)].copy();
    	}
    	else if(i == 3){
    		iS = lightdustItems[rand.nextInt(lightdustItems.length)].copy();
    	}
    	else
    		return null;
    	if(iS.getMaxStackSize() != 1)
    		iS.stackSize += rand.nextInt(5);
    	return iS;
    }
    
    public boolean interact(EntityPlayer entityplayer)
    {
		if(currentAction != -1 || entityplayer.inventory.getCurrentItem()== null)
			return super.interact(entityplayer);
		else if(handCounter > 0)
			return false;
		else{
			ItemStack itemstack = entityplayer.inventory.getCurrentItem();
			//prepare give item process
			if(itemstack.itemID == Block.wood.blockID)
        	{
        		heldObj = woodTradeItem.copy();
        		itemToGive = woodTradeItem.copy();
        		handCounter = 1;
        	}
			else if(itemstack.itemID == Item.leather.shiftedIndex)
        	{
        		heldObj = leatherTradeItem.copy();
        		itemToGive = leatherTradeItem.copy();
        		handCounter = 1;
        	}
			else if(itemstack.itemID == Item.redstone.shiftedIndex)
        	{
        		heldObj = redstoneTradeItem.copy();
        		itemToGive = redstoneTradeItem.copy();
        		handCounter = 1;
        	}
			else if(itemstack.itemID == Item.lightStoneDust.shiftedIndex)
        	{
        		heldObj = lightdustTradeItem.copy();
        		itemToGive = lightdustTradeItem.copy();
        		handCounter = 1;
        	}
			else{
				return false;
			}
			//remove item
			ItemStack temp = entityplayer.inventory.getStackInSlot(entityplayer.inventory.currentItem);
        	if(temp.stackSize > 1)
        		temp.stackSize--;
        	else
        		entityplayer.destroyCurrentEquippedItem();
        	
        	return true;
		}
    }
    
    private void setupShop(){
    	currentAction = -1;
		//place baker in shop
		setPosition(shopX + 0.5, shopY, shopZ + 1);
		posY = MathHelper.floor_double(boundingBox.minY);
		//set trade items
		woodTradeItem = getTradeItem(0);
		leatherTradeItem = getTradeItem(1);
		redstoneTradeItem = getTradeItem(2);
		lightdustTradeItem = getTradeItem(3);
		//place cloth underneath trader
		worldObj.setBlock(shopX, shopY - 1, shopZ, Block.cloth.blockID);
		worldObj.setBlock(shopX, shopY - 1, shopZ + 1, Block.cloth.blockID);
		//place and set title wall sign & torches.
		worldObj.setBlock(shopX + 2, shopY + 1, shopZ - 1, Block.torchWood.blockID);
		worldObj.setBlockAndMetadata(shopX + 2, shopY + 2, shopZ, Block.signWall.blockID, 0x5);
		worldObj.setBlockAndMetadata(shopX + 2, shopY + 2, shopZ + 1, Block.signWall.blockID, 0x5);
		worldObj.setBlock(shopX + 2, shopY + 1, shopZ + 2, Block.torchWood.blockID);
			//set Title Signs
		TileEntity tE = worldObj.getBlockTileEntity(shopX + 2, shopY + 2, shopZ + 1);
		TileEntitySign tES;
		if(tE != null){
			tES = (TileEntitySign) tE;
			if(tES != null)
				tES.signText = new String[]{"Welcome to", name.concat("'s"), "Bakery.", "Trade your"};
		}
		tE = worldObj.getBlockTileEntity(shopX + 2, shopY + 2, shopZ);
		if(tE != null){
			tES = (TileEntitySign) tE;
			if(tES != null)
				tES.signText = new String[]{"spare wood,", "leather, and", "dusts for food!", "Om nom nom!"};
		}
		//place trade wall signs on shop (try facing south)
		worldObj.setBlockAndMetadata(shopX + 2, shopY, shopZ - 1, Block.signWall.blockID, 0x5);
		worldObj.setBlockAndMetadata(shopX + 2, shopY, shopZ, Block.signWall.blockID, 0x5);
		worldObj.setBlockAndMetadata(shopX + 2, shopY, shopZ + 1, Block.signWall.blockID, 0x5);
		worldObj.setBlockAndMetadata(shopX + 2, shopY, shopZ + 2, Block.signWall.blockID, 0x5);
		//set wood-Trade Sign
		String tItem = (new StringBuilder()).append("").append(StringTranslate.getInstance().translateNamedKey(woodTradeItem.getItemName())).toString().trim();
		if(tItem == null || tItem.length() > 15)
			tItem = "Mystery Item";
		tE = worldObj.getBlockTileEntity(shopX + 2, shopY, shopZ + 2);
		if(tE != null){
			tES = (TileEntitySign) tE;
			if(tES != null)//.split(".")[1] //check if substring function works correctly
				tES.signText = new String[]{"Give 1 wood", "for ".concat((new StringBuilder()).append(woodTradeItem.stackSize).toString()), tItem, ""};
		}
		//set leather-Trade Sign
		tItem = (new StringBuilder()).append("").append(StringTranslate.getInstance().translateNamedKey(leatherTradeItem.getItemName())).toString().trim();
		if(tItem == null || tItem.length() > 15)
			tItem = "Mystery Item";
		tE = worldObj.getBlockTileEntity(shopX + 2, shopY, shopZ + 1);
		if(tE != null){
			tES = (TileEntitySign) tE;
			if(tES != null)
				tES.signText = new String[]{"Give 1 leather", "for ".concat((new StringBuilder()).append(leatherTradeItem.stackSize).toString()), tItem, ""};
		}
		//set redstone-Trade Sign
		tItem = (new StringBuilder()).append("").append(StringTranslate.getInstance().translateNamedKey(redstoneTradeItem.getItemName())).toString().trim();
		if(tItem == null || tItem.length() > 15)
			tItem = "Mystery Item";
		tE = worldObj.getBlockTileEntity(shopX + 2, shopY, shopZ);
		if(tE != null){
			tES = (TileEntitySign) tE;
			if(tES != null)
				tES.signText = new String[]{"Give 1 redstone", "dust for ".concat((new StringBuilder()).append(redstoneTradeItem.stackSize).toString()), tItem, ""};
		}
		//set lightdust-Trade Sign
		tItem = (new StringBuilder()).append("").append(StringTranslate.getInstance().translateNamedKey(lightdustTradeItem.getItemName())).toString().trim();
		if(tItem == null || tItem.length() > 15)
			tItem = "Mystery Item";
		tE = worldObj.getBlockTileEntity(shopX + 2, shopY, shopZ - 1);
		if(tE != null){
			tES = (TileEntitySign) tE;
			if(tES != null)
				tES.signText = new String[]{"Give 1 glowing", "dust for ".concat((new StringBuilder()).append(lightdustTradeItem.stackSize).toString()), tItem, ""};
		}
		noMove = true;
    }

    //spawn smoking goods if none on shelf
    private void spawnBreads(){
    	if(breads != null)
    		return;
    	
    	breads = new EntityItem[]{
    		new EntityItem(worldObj, posX + 1, posY + 1.3, posZ - 0.5, new ItemStack(rand.nextFloat() < 0.5 ? Item.cookie.shiftedIndex : Item.bread.shiftedIndex, 1, 0)), //cookie/bread 
    		new EntityItem(worldObj, posX + 1, posY + 1.3, posZ + 0.5, new ItemStack(rand.nextFloat() < 0.5 ? Item.cookie.shiftedIndex : Item.cake.shiftedIndex, 1, 0)) //cookie/cake
    	};
    	breads[0].age = 5980;
    	breads[1].age = 5980;
    	breads[0].delayBeforeCanPickup = 600;
    	breads[1].delayBeforeCanPickup = 600;
    	breads[0].setVelocity(0, 0, 0);
    	breads[1].setVelocity(0, 0, 0);
    	worldObj.entityJoinedWorld(breads[0]);
    	worldObj.entityJoinedWorld(breads[1]);
    }
    
    protected String getActionDescrip(){
    	switch(currentAction){
    	case -1:
    		return "Selling baked goods";
    	default:
    		return super.getActionDescrip();
    	}
    }
    
    //makes bread items smoke
    private void makeBreadsSmoke(){
    	if(breads == null)
    		return;
    	//makes breads unable to be picked up and unable to despawn
    	breads[0].age = 5980;
    	breads[1].age = 5980;
    	breads[0].delayBeforeCanPickup = 600;
    	breads[1].delayBeforeCanPickup = 600;
    	//cause breads to smoke
    	if(rand.nextFloat() < 0.05)
    		mod_Builders.spawnParticlesAtEntity(breads[0], "explode", 1);
    	if(rand.nextFloat() < 0.025)
    		mod_Builders.spawnParticlesAtEntity(breads[1], "explode", 1);
    }
    
    //removes smoking goods
    private void killBreads(){
    	if(breads == null)
    		return;
    	breads = null;
    }
    
    protected boolean uniDirectionalStructures(){
    	return true;
    }
    
    protected boolean canTossMeat(){
    	return currentAction != -1;
    }
    
    protected ItemStack getThrownItem(){
    	return new ItemStack(Item.cake);
    }
    
    protected boolean canBeHurt(){
    	return currentAction == -1 || super.canBeHurt();
    }
    
    
    protected int getChunkOffsetX(){
    	return -7;
    }
    
    protected int getChunkOffsetZ(){
    	return -7;
    }
    
    protected ItemStack getHealingItem(){
    	return new ItemStack(Item.bread);
    }
    
    public int getMaxHp(){
    	return 20;
    }
    
    static final ItemStack[] chestItems = (new ItemStack[]{
        	new ItemStack(Item.egg, 1), new ItemStack(Item.wheat.shiftedIndex, 1, 0), new ItemStack(Item.seeds.shiftedIndex, 1, 0),
        	new ItemStack(Item.bread, 1), new ItemStack(Item.wheat.shiftedIndex, 1, 0), new ItemStack(Item.wheat.shiftedIndex, 1, 0),
        	new ItemStack(Item.bread, 1), new ItemStack(Item.bone.shiftedIndex, 1, 0), new ItemStack(Item.cake.shiftedIndex, 1, 0),
        	new ItemStack(Item.bread, 1), new ItemStack(Item.wheat.shiftedIndex, 1, 0), new ItemStack(Item.wheat.shiftedIndex, 1, 0),
        	new ItemStack(Item.cookie, 5), new ItemStack(Item.cookie.shiftedIndex, 3, 0), new ItemStack(Item.dyePowder.shiftedIndex, 1, 3),
        	new ItemStack(Item.bucketMilk, 1), new ItemStack(Item.wheat.shiftedIndex, 1, 0), new ItemStack(Item.sugar.shiftedIndex, 1, 0)
        });
        
    
    static final ItemStack[] woodItems = new ItemStack[]{
    	new ItemStack(Item.seeds.shiftedIndex, 5, 0), new ItemStack(Item.dyePowder.shiftedIndex, 2, 3), new ItemStack(Item.egg.shiftedIndex, 1, 0), new ItemStack(Item.sugar.shiftedIndex, 2, 0), new ItemStack(Item.cookie.shiftedIndex, 1, 0)
    };
    
    static final ItemStack[] leatherItems = new ItemStack[]{
    	new ItemStack(Item.wheat.shiftedIndex, 1, 0), new ItemStack(Block.pumpkin, 1, 0), new ItemStack(Block.mushroomRed, 1, 0), new ItemStack(Block.mushroomBrown, 1, 0), new ItemStack(Item.cookie.shiftedIndex, 5, 0)
    };
    
    static final ItemStack[] redstoneItems = new ItemStack[]{
    	new ItemStack(Item.bread.shiftedIndex, 1, 0), new ItemStack(Item.wheat.shiftedIndex, 6, 0), new ItemStack(Item.appleRed.shiftedIndex, 1, 0) 
    };
    
    static final ItemStack[] lightdustItems = new ItemStack[]{
    	new ItemStack(Item.bread.shiftedIndex, 7, 0), new ItemStack(Item.wheat.shiftedIndex, 30, 0), new ItemStack(Item.bucketMilk.shiftedIndex, 3, 0), new ItemStack(Item.cake, 1, 0)
    };
    
    public int shopX; //Xcoordinate of inside of shop
    public int shopY; //Ycoordinate of inside of shop
    public int shopZ; //Zcoordinate of inside of shop
    public ItemStack woodTradeItem; //Wood trade item
    public ItemStack leatherTradeItem; //Leather trade item
    public ItemStack redstoneTradeItem; //Red Stone Dust trade item
    public ItemStack lightdustTradeItem; //Glow Stone Dust trade item
    public ItemStack itemToGive; //item that is given to player
    protected short handCounter; //used for timing item throw properly
    private EntityItem breads[]; // smoking goods on shelving
    private static final HashMap<Integer, Integer> dropIDs;
    static{
    	dropIDs = new HashMap<Integer, Integer>();
    	dropIDs.put(0, Item.bread.shiftedIndex);
    	dropIDs.put(1, Item.bread.shiftedIndex);
    	dropIDs.put(2, Item.bread.shiftedIndex);
    	dropIDs.put(3, Item.cookie.shiftedIndex);
    	dropIDs.put(4, Item.cookie.shiftedIndex);
    	dropIDs.put(5, Item.cookie.shiftedIndex);
    	dropIDs.put(6, Item.cookie.shiftedIndex);
    	dropIDs.put(7, Item.cookie.shiftedIndex);
    	dropIDs.put(8, Item.wheat.shiftedIndex);
    	dropIDs.put(9, Item.wheat.shiftedIndex);
    	dropIDs.put(10, Item.egg.shiftedIndex);
    	dropIDs.put(11, Item.cake.shiftedIndex);
    }
}

