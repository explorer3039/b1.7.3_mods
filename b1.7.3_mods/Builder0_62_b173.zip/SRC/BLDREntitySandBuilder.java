package net.minecraft.src;

import java.util.ArrayList;
import java.util.List;

/*
 * Actions exclusive to SandBuilder (not yet added)
 * -1: Digging up sand
 * -2: Cutting up cactuses
 * -3: Collecting nearby sand and cactus items
*/ 
public class BLDREntitySandBuilder extends BLDREntityBuilder{

	public BLDREntitySandBuilder(World world) {
		super(world);
		buildCount = BLDRBuilderConfig.sandStructureLimit;
		int rrNum = rand.nextInt(3);
		if(rrNum == 0)
			texture = "/mob/SandBuilder1.png";
		else if(rrNum == 1)
			texture = "/mob/SandBuilder2.png";
		else
			texture = "/mob/SandBuilder3.png";
		health = 15;
		maxWait = 285;	
		buildBlock = BLDRBuilderConfig.sandBlock;
		if(BLDRBlueprints.singlePrints.size() > 0)
			blueNum = rand.nextInt(BLDRBlueprints.singlePrints.size());
		else
			blueNum = -1;
		while(BLDRBlueprints.singlePrints.size() > 2 && (blueNum == mod_Builders.explorerSingleBlockIndex || blueNum == mod_Builders.traderBakerShopIndex))
			blueNum = rand.nextInt(BLDRBlueprints.singlePrints.size());

        tradeGiveNum = 1 + rand.nextInt(4);
        tradeReceiveNum = rand.nextInt(4);
        tradeRatio = 5 + rand.nextInt(12);
        randomStrafe = 0.0F;
        herd = new ArrayList<EntityAnimal>();
        flags = (byte) (rand.nextInt(256) - 128);
        
        randomStrafe = 0.0F;
        moveSpeed = 1.001F;
	}
	
	protected void initConvert(int x, String s){
		if(x == Block.sand.blockID){
			builderFlags |= (1 << 4); //builds twice as fast
			health += 3;
			flags = 63;
		}
		else if(x == Block.sandStone.blockID){
			builderFlags |= (1 << 4); //builds twice as fast
			health += 6;
			flags = -128;
		}
    }
	
	public void writeEntityToNBT(NBTTagCompound nbttagcompound)
    {
        super.writeEntityToNBT(nbttagcompound);
        nbttagcompound.setByte("Flags", flags);
    }

    public void readEntityFromNBT(NBTTagCompound nbttagcompound)
    {
        super.readEntityFromNBT(nbttagcompound);
        flags = nbttagcompound.getByte("Flags");
    }
	
	public boolean getCanSpawnHere()
    {
		BiomeGenBase biome = worldObj.getWorldChunkManager().getBiomeGenAt((int)posX, (int)posZ);
		if(biome.biomeName != "Desert") return false;
		if(worldObj.isDaytime()){
			if(mod_Builders.countBuilders(this.getClass()) >= BLDRBuilderConfig.sandSpawnMaxDay)
				return false;
			else
				return rand.nextInt(100) < BLDRBuilderConfig.sandSpawnRateDay && super.getCanSpawnHere();
		}
		else{
			if(mod_Builders.countBuilders(this.getClass()) >= BLDRBuilderConfig.sandSpawnMaxNight)
				return false;
			else
				return rand.nextInt(100) < BLDRBuilderConfig.sandSpawnRateNight && super.getCanSpawnHere();
		}
    }
	
	protected void updatePlayerActionState()
    {
		super.updatePlayerActionState();
		if((flags & 16) == 16 && !noMove){
			moveStrafing = randomStrafe;
    		randomStrafe *= 1.0F - rand.nextFloat() / 40.0F;
		}			
    }
	
    public void onUpdate()
    {

    	super.onUpdate();
    	if(currentAction >= 1 && currentAction <= 6 && actionTimer == 10099 && ((builderFlags >> 1) & 1) != 1){
    		if(BLDRBlueprints.singlePrints.size() > 0)
    			blueNum = rand.nextInt(BLDRBlueprints.singlePrints.size());
    		else
    			blueNum = -1;
    		while(BLDRBlueprints.singlePrints.size() > 2 && (blueNum == mod_Builders.explorerSingleBlockIndex || blueNum == mod_Builders.traderBakerShopIndex))
    			blueNum = rand.nextInt(BLDRBlueprints.singlePrints.size());
    	}
    	
    	if(!noMove){
    		//determine move speed based on block being stood on; Makes this mob also immune to speed changing effects
        	if(onGround && updateTimer % 40 == 0){
        		determineMoveSpeed();
        		setRandomStrafing();
        		gradualHeal();
        	}
    		
    		//imitates leader
    		if((flags & 64) == 64 && leader instanceof EntityLiving){
    			setEntityFlag(1, leader.isSneaking());
    			isJumping = ((EntityLiving) leader).isJumping;
    		}
    		
    	}
    	
    	if((flags & 15) > 0) handleHerd();
	}
    
    private void handleHerd(){
    	//if player cannot see this SandBuilder, spawn animals occasionally
		if(herd.size() < 5 && rand.nextFloat() < 0.02F && !canEntityBeSeen(worldObj.getClosestPlayerToEntity(this, -1))){
			EntityAnimal es = null;
			float f = rand.nextFloat();
			if((flags & 1) == 1 && f < 0.25F)
				es = new EntitySheep(worldObj);
			else if((flags & 2) == 2 && f < 0.5F)
				es = new EntityPig(worldObj);
			else if((flags & 4) == 4 && f < 0.75F)
				es = new EntityCow(worldObj);
			else if((flags & 8) == 8 && f < 1.0F)
				es = new EntityChicken(worldObj);
			
			if(es != null){
				es.setPosition(posX, posY, posZ);
				if(worldObj.entityJoinedWorld(es))
					herd.add(es);
			}
		}
		
		//gather any nearby animals within 8 blocks, but not if another herder within 16 blocks.
		double d = 16D;
		List list = worldObj.getEntitiesWithinAABBExcludingEntity(this, boundingBox.expand(d, d, d));
		ArrayList<EntityAnimal> animalList = new ArrayList<EntityAnimal>();
		boolean otherHerders = false;
		for(int i = 0; i < list.size(); i++)
        {
            Entity entity1 = (Entity)list.get(i);
            if(entity1 instanceof BLDREntitySandBuilder && (((BLDREntitySandBuilder) entity1).flags & 15) > 0){
            	otherHerders = true;
            	break;
            }
            if(!(entity1 instanceof EntityAnimal) || entity1 == ridingEntity || entity1 == riddenByEntity)
			{
				continue;
			}
            animalList.add((EntityAnimal) entity1);
        }
		
		if(otherHerders == false)
			for(int i = 0; i < animalList.size(); i++)
			{
				EntityAnimal entity1 = animalList.get(i);
				double d2 = entity1.getDistanceToEntity(this);
				boolean canGather = false;
				if((entity1 instanceof EntitySheep && (flags & 1) == 1)
						|| (entity1 instanceof EntityPig && (flags & 2) == 2)
						|| (entity1 instanceof EntityCow && (flags & 4) == 4)
						|| (entity1 instanceof EntityChicken && (flags & 8) == 8))
					canGather = true;
					
				if(canGather && (d2 < d / 2F) && entity1.canEntityBeSeen(this) && !herd.contains(entity1))
				{
					herd.add(entity1);
				}
			}
		
		//order herd animals to stay within 6 blocks of SandBuilder
		for(int i = 0; i < herd.size(); i++){
			EntityAnimal es = herd.get(i);
			//remove dead animals from herd
			if(es == null || es.isDead){
				herd.remove(i);
				i--;
				continue;
			}
			//manage animal movement
			float f = es.getDistanceToEntity(this);
			if(f < 6F && es.playerToAttack == this) //wander if close
				es.playerToAttack = null;
			else if(f > 6F && es.playerToAttack != this) //follow if far
				es.playerToAttack = this;
			else if(f > 16F){ //remove from herd if too far
				es.playerToAttack = null;
				herd.remove(i);
				i--;
				continue;
			}
			
			//if animal is idle, make it jump with random variance, change its speed, and make sound
			if(es.onGround && !es.isJumping && !es.hasPath()){
				es.jump();
				es.addVelocity(-0.2D + rand.nextDouble() / 2.5D, -0.1D + rand.nextDouble() / 5D, -0.2D + rand.nextDouble() / 2.5D);
				es.moveSpeed = 0.4F + rand.nextFloat() / 2F;
				es.playLivingSound();
				es.isJumping = true;
			}
		}
		
    }
    
    private void determineMoveSpeed(){
    	if((flags & 32) == 32){
    		int i = MathHelper.floor_double(posX);
    		int j = MathHelper.floor_double(boundingBox.minY);
    		int k = MathHelper.floor_double(posZ);
    		int bid = worldObj.getBlockId(i, j - 1, k);
    		if(bid == Block.sand.blockID || bid == Block.sandStone.blockID)
    			moveSpeed = 1.05F;
    		else
    			moveSpeed = 0.65F;
    	}
    }
    
    private void setRandomStrafing(){
    	if((flags & 16) == 16){
    		randomStrafe = rand.nextFloat() - rand.nextFloat();
    		if(moveSpeed > 1.0F)
    			randomStrafe *= 1.6F;
    	}
    }
    
    public ItemStack getChestItem(){
    	return chestItems[rand.nextInt(chestItems.length)].copy();
    }
    
    public boolean canRenovateBuild(){
    	return true;
    }
    
    protected ItemStack getThrownItem(){
    	return new ItemStack(Item.bowlEmpty);
    }
    
    private void gradualHeal(){
    	if(flags < 0 && rand.nextFloat() < 0.1F && health < getMaxHp()){
    		health++;
    	}
    }
    
    protected ItemStack getHealingItem(){
    	return new ItemStack(Item.fishRaw);
    }
    
    protected int getChunkOffsetX(){
    	return -2;
    }
    
    protected int getChunkOffsetZ(){
    	return 1;
    }
    
    public int getMaxHp(){
    	return 15;
    }
    
    /*private byte setAction(){
    	switch (currentAction){
    	case 0:
    		if(actionTimer < 200 + rand.nextInt(1000)) return 0;
    		else if(moveSpeed > 1.0F) return (byte) (rand.nextInt(2) + 1);
    	case 1:
    		if(actionTimer < 200 + rand.nextInt(1000)) return 0;
    		else return 3;
    	case 2:
    		if(actionTimer < 200 + rand.nextInt(1000)) return 0;
    		else return 3;
    	case 3:
    		return -((xDif - zDif) / 2F);
    	default:
    		return currentAction;
    	}
    }*/
	
    static final private ItemStack[] chestItems = (new ItemStack[]{
        	new ItemStack(Block.sand, 6), new ItemStack(Block.sand, 4), new ItemStack(Block.sand, 2),
        	new ItemStack(Block.blockClay, 1), new ItemStack(Item.clay, 1), new ItemStack(Item.bone, 1),
        	new ItemStack(Block.cloth, 2, 8), new ItemStack(Item.arrow, 2), new ItemStack(Item.bone, 2),
        	new ItemStack(Block.stoneOvenIdle, 1), new ItemStack(Item.pocketSundial, 1), new ItemStack(Item.stick, 3),
        	new ItemStack(Block.lever, 1), new ItemStack(Item.minecartEmpty, 1), new ItemStack(Item.coal, 3),
        	new ItemStack(Item.stick, 1), new ItemStack(Item.bucketWater, 1), new ItemStack(Item.swordGold, 1),
        	new ItemStack(Block.cactus, 1), new ItemStack(Block.sandStone, 3), new ItemStack(Block.stoneOvenIdle, 1),
        	new ItemStack(Block.sandStone, 3)
        });
    
    private float randomStrafe;
    protected ArrayList<EntityAnimal> herd;
    
    /** -flags-
     * bit 1: Herds Sheep
     * bit 2: Herds Pigs
     * bit 3: Herds Cows
     * bit 4: Herds Chickens
     * bit 5: Randomly strafes
     * bit 6: Changes speed based on terrain
     * bit 7: Imitates leader behavior
     * bit 8: Gradually heals
     */
    protected byte flags;
    
}
