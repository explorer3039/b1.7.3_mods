package net.minecraft.src;

/*
 * Class: BuilderSigns
 * Purpose: This class contains the coordinates and effects of signs specialized for Builders
 */

public class BLDRBuilderSigns {

	//Empty Constructor (used for getting saved signs)
	public BLDRBuilderSigns(){
	}

	/*
	 * Method: getDefaultRange
	 * Purpose: based on the sign's type, set the default range of that sign
	 */
	public int getDefaultRange(int type){
		if(type == 1) //For Rent Sign
			return 10;
		else if(type == 2 || type == 3) //Construction Zone / Private Property
			return 100;
		else
			return 0;
	}
	
	
	/*
	 * Method: signExists
	 * Purpose: returns true if the sign is still at the coordinates, false otherwise.
	 */
	public boolean signExists(){
		try{
			return world.getBlockId(xCoord, yCoord, zCoord) == Block.signPost.blockID || world.getBlockId(xCoord, yCoord, zCoord) == Block.signWall.blockID;
		}catch(Exception e){
			return false;
		}
	}
	
	/*
	 * Method: determineSignType
	 * Purpose: scans the text of a Sign, and determines the type of sign based on this text. If sign is invalid, returns 0.
	 */
	static public int determineSignType(TileEntitySign tes){
		String temp = new String(tes.signText[0].replace(" ", "")).concat(tes.signText[1].replace(" ", "")).toLowerCase();
		
		//determine if 1st 2 lines of sign's text contains valid text
		if(temp.contains("forrent")) //if "For Rent", return 1
			return 1;
		else if(temp.contains("constructionzone")) //if "Construction Zone", return 2
			return 2;
		else if(temp.contains("privateproperty")) //if "Private Property", return 3
			return 3;
		
		//if fails, return 0
		return 0;
	}
	
	/*
	 * Method: getThirdLineNumber
	 * Purpose: scans the text of a Sign, and determines the third number based on this text. If number is invalid, returns -1.
	 */
	static public int getThirdLineNumber(TileEntitySign tes){
		try{
			
			int r = Integer.valueOf(tes.signText[2].trim()).intValue();
			if(r <= 0 || r >= 30000)
				return -1;
			else
				return r;
		}catch(Exception e){
			return -1;
		}
	}
	
	public boolean createBuilderSign(TileEntitySign sign){
		   //get type of sign
		   this.type = determineSignType(sign);
		   
		   //if invalid sign, end
		   if(this.type == 0) return false;
		   
		   //set other attributes based on sign
		   this.world = sign.worldObj;
		   this.xCoord = sign.xCoord;
		   this.yCoord = sign.yCoord;
		   this.zCoord = sign.zCoord;
		   this.range = this.getDefaultRange(type);
		   this.num1 = -1;
		   this.num2 = -1;
		   
		   //attempt to get 3rd line's value (range)
		   int num = BLDRBuilderSigns.getThirdLineNumber(sign);
		   
		   //set appropriate number if 3rd line valid
		   if(num != -1){
			   if(this.type == 1)
				   this.num1 = num;
			   else if(this.type == 2 || this.type == 3)
				   this.range = num;
		   }
		   
		   //confirm sign was accepted
		   sign.signText[3] = "<Confirmed>";
		   return true;
	   }
	
	public void writeToNBT(NBTTagCompound nbttagcompound){
		nbttagcompound.setInteger("xCoord", xCoord);
		nbttagcompound.setInteger("yCoord", yCoord);
		nbttagcompound.setInteger("zCoord", zCoord);
		nbttagcompound.setInteger("type", type);
		nbttagcompound.setInteger("range", range);
		nbttagcompound.setInteger("num1", num1);
		nbttagcompound.setInteger("num2", num2);
	}
	
	public void readFromNBT(NBTTagCompound nbttagcompound){
		this.xCoord = nbttagcompound.getInteger("xCoord");
        this.yCoord = nbttagcompound.getInteger("yCoord");
        this.zCoord = nbttagcompound.getInteger("zCoord");
        this.type = nbttagcompound.getInteger("type");
        this.range = nbttagcompound.getInteger("range");
        this.num1 = nbttagcompound.getInteger("num1");
        this.num2 = nbttagcompound.getInteger("num2");
	}
	
	
	public World world;
	public int xCoord;
	public int yCoord;
	public int zCoord;
	
	/*
	 * Type of Signs:
	 * 1. For Rent Signs: 
	 * 		- A nearby builder sets the sign to his home location
	 * 		- After the builder does this, this sign will have its text be changed.
	 * 		- The Builder no longer despawns, except through death.  The builder stops building as well.
	 * 		- The instance of this class will no longer be necessary.  The sign can be destroyed, and the builder will still have that set as his home location.
	 * 	  Sign Text: "For Rent [Range]"  NOTE: Range must be alone on 3rd line
	 * 		Range (default 10) specifies how far the builder may wander away from sign before returning.
	 * 
	 *  2. Construction Zone Signs:
	 *  	-Nearby builders within the range of this sign build more frequently and have no buildLimit
	 *    Sign Text: "Construction Zone [Range]"  NOTE: Range must be alone on 3rd line
	 *      Range (default 100) specifies how far away a builder may be to still be affected by this sign
	 *      
	 *  3. Private Property Signs:
	 *  	-Nearby builders within the range of this sign will not build
	 *    Sign Text: "Private Property [Range]"  NOTE: Range must be alone on 3rd line
	 *      Range (default 100) specifies how far away a builder may be to still be affected by this sign
	 */
	public int type;
	public int range;
	public int num1; //misc. number that may or may not be used, depending on the sign
	public int num2; //misc. number that may or may not be used, depending on the sign
}
