package net.minecraft.src;

public class BLDRBuilderConfig {


	public static int getMaxTotalDayTime(){
		return brickSpawnMaxDay + cobbleSpawnMaxDay + explorerSpawnMaxDay + homeSpawnMaxDay +
		treasureSpawnMaxDay + mayorSpawnMaxDay + multiSpawnMaxDay + traderSpawnMaxDay + bakerSpawnMaxDay +
		sandSpawnMaxDay;
	}
	
	public static int getMaxTotalNightTime(){
		return brickSpawnMaxNight + cobbleSpawnMaxNight + explorerSpawnMaxNight + homeSpawnMaxNight +
		treasureSpawnMaxNight + mayorSpawnMaxNight + multiSpawnMaxNight + traderSpawnMaxNight + bakerSpawnMaxNight +
		sandSpawnMaxNight;
	}

			//Spawn stuff: If input is less than 0, set to 0; If more than 100, set to 100.
		
		//Spawn rates for each builder (0 - 100), 0 = never, 100 = always
		public static int brickSpawnRateDay; //BrickBuilder (Day)
		public static int brickSpawnRateNight; //BrickBuilder (Night)
		public static int cobbleSpawnRateDay; //CobbleBuilder (Day)
		public static int cobbleSpawnRateNight; //CobbleBuilder (Night)
		public static int explorerSpawnRateDay; //Explorer (Day)
		public static int explorerSpawnRateNight; //Explorer (Night)
		public static int homeSpawnRateDay; //Home Seeker (Day)
		public static int homeSpawnRateNight; //Home Seeker (Night)
		public static int treasureSpawnRateDay; //Treasure Hunter (Day)
		public static int treasureSpawnRateNight; //Treasure Hunter (Night)
		public static int mayorSpawnRateDay; //Mayor (Day)
		public static int mayorSpawnRateNight; //Mayor (Night)
		public static int multiSpawnRateDay; //MultiBuilder (Day)
		public static int multiSpawnRateNight; //MultiBuilder (Night)
		public static int traderSpawnRateDay; //Trader (Day)
		public static int traderSpawnRateNight; //Trader (Night)
		public static int bakerSpawnRateDay; //Baker (Day)
		public static int bakerSpawnRateNight; //Baker (Night)
		public static int sandSpawnRateDay; //SandBuilder (Day)
		public static int sandSpawnRateNight; //SandBuilder (Night)
		
		//Maximum spawn for each Builder (0 - 100), 0 = no regular spawns; only created via conversion
		public static int brickSpawnMaxDay; //BrickBuilder (Day)
		public static int brickSpawnMaxNight; //BrickBuilder (Night)
		public static int cobbleSpawnMaxDay; //CobbleBuilder (Day)
		public static int cobbleSpawnMaxNight; //CobbleBuilder (Night)
		public static int explorerSpawnMaxDay; //Explorer (Day)
		public static int explorerSpawnMaxNight; //Explorer (Night)
		public static int homeSpawnMaxDay; //Home Seeker (Day)
		public static int homeSpawnMaxNight; //Home Seeker (Night)
		public static int treasureSpawnMaxDay; //Treasure Hunter (Day)
		public static int treasureSpawnMaxNight; //Treasure Hunter (Night)
		public static int mayorSpawnMaxDay; //Mayor (Day)
		public static int mayorSpawnMaxNight; //Mayor (Night)
		public static int multiSpawnMaxDay; //MultiBuilder (Day)
		public static int multiSpawnMaxNight; //MultiBuilder (Night)
		public static int traderSpawnMaxDay; //Trader (Day)
		public static int traderSpawnMaxNight; //Trader (Night)
		public static int bakerSpawnMaxDay; //Baker (Day)
		public static int bakerSpawnMaxNight; //Baker (Night)
		public static int sandSpawnMaxDay; //SandBuilder (Day)
		public static int sandSpawnMaxNight; //SandBuilder (Night)
		
		//Structure Limits:  Builders may only build this # of complete structures
		public static int brickStructureLimit; //BrickBuilder's Structure Limit
		public static int cobbleStructureLimit; //CobbleBuilder's Structure Limit
		public static int explorerBlockLimit; //Explorer's Block Limit
		public static int homeStructureLimit; //HomeSeeker's Structure Limit
		public static int multiStructureLimit; //MultiBuilder's Structure Limit
		public static int sandStructureLimit; //SandBuilder's Structure Limit
				
		//Build Block IDs; glitches may occur if invalid blocks.
		public static int brickCommonBlock; //BrickBuilder's common block
		public static int brickRareBlock; //BrickBuilder's rare block
		public static int cobbleCommonBlock; //CobbleBuilder's common block
		public static int cobbleRareBlock; //CobbleBuilder's rare block
		public static int homeCommonBlock; //HomeSeeker's common block
		public static int homeRareBlock; //HomeSeeker's rare block
		public static int explorerBlock; //Explorer's block
		public static int explorerMBlock; //Explorer's mayor-support block
		public static int treasureMBlock; //Treasure Hunter's mayor-support block
		public static int traderBlock; //Trader's block
		public static int bakerBlock; //Baker's block
		public static int sandBlock; //SandBuilder's block
		
		//Misc.
		public static boolean buildAnywhere; //if true, builders will build over other blocks.
		public static boolean enableNames; //if true, builders have their name appear above their heads
		
		/**
		 * determines where builders naturally build.
		 * 0: No freelance building
		 * 1: Build anywhere
		 * 2: Build within 8x8 chunk regions
		 * 3: Build within 8x8 chunk regions with offset varying per builder type
		 */
		public static byte freeLanceStyle;

}
