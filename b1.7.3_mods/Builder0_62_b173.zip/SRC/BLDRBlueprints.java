package net.minecraft.src;

import java.util.ArrayList;
import java.util.List;

//This class holds multiple triple short arrays used for designating build coordinates.  Floors are shown from top view.

public class BLDRBlueprints {
	public static ArrayList<ArrayList<ArrayList<ArrayList<Short>>>> singlePrints;
	public static List<String> singlePrintNames;
}

