package net.minecraft.src;

/*
 * Unique Actions
 * 0: Idle / on Break
 * -1: Digging
 * -2: Placing Sign on Treasure Chest
 */
public class BLDREntityTreasureHunter extends BLDREntityBuilder{

	public BLDREntityTreasureHunter(World world) {
		super(world);
		buildCount = 0;
		health = 25;
		maxWait = 500;
		//buildBlock = Block.signPost.blockID;
		buildBlock = BLDRBuilderConfig.treasureMBlock;
		blueNum = 0;
		shovelType = 0;
		breakCounter = 0;
		destroyCounter = -31;
		blocksBroken = 0;
		texture = "/mob/TreasureHunter3.png";
        tradeGiveNum = tradeGiveNum + rand.nextInt(12);
        tradeReceiveNum = rand.nextInt(12);
        tradeRatio = tradeRatio + rand.nextInt(25);
	}

	protected void initConvert(int x, String s){

		if(x == Item.shovelWood.shiftedIndex)
			shovelType = 0;
		else if(x == Item.shovelGold.shiftedIndex)
			shovelType = 1;
		else if(x == Item.shovelStone.shiftedIndex)
			shovelType = 2;
		else if(x == Item.shovelSteel.shiftedIndex)
			shovelType = 3;
		else if(x == Item.shovelDiamond.shiftedIndex)
			shovelType = 4;
		health += 5;
		tradeGiveNum += 8;
		if(s == "/mob/HomeSeeker1.png" || s == "/mob/HomeSeeker4.png")
			texture = "/mob/TreasureHunter1.png";
		else if(s == "/mob/HomeSeeker2.png")
			texture = "/mob/TreasureHunter2.png";
    }

	public void onDeath(Entity entity)
    { 
		if(rand.nextInt(10) < 7)
			dropItem(Item.sign.shiftedIndex, 1); // 70%: Sign
		else
			dropItem(shovels[shovelType].itemID, 1); //30%: shovel that is being held
		super.onDeath(entity);
    }
	
	public boolean getCanSpawnHere()
    {
		if(worldObj.isDaytime()){
			if(mod_Builders.countBuilders(this.getClass()) >= BLDRBuilderConfig.treasureSpawnMaxDay)
				return false;
			else
				return rand.nextInt(100) < BLDRBuilderConfig.treasureSpawnRateDay && super.getCanSpawnHere();
		}
		else{
			if(mod_Builders.countBuilders(this.getClass()) >= BLDRBuilderConfig.treasureSpawnMaxNight)
				return false;
			else
				return rand.nextInt(100) < BLDRBuilderConfig.treasureSpawnRateNight && super.getCanSpawnHere();
		}
    }
	
    public void writeEntityToNBT(NBTTagCompound nbttagcompound)
    {
        super.writeEntityToNBT(nbttagcompound);
    }

    public void readEntityFromNBT(NBTTagCompound nbttagcompound)
    {
        super.readEntityFromNBT(nbttagcompound);
        if(currentAction < 0)
        	currentAction = 0;
    }
    
    public void onUpdate()
    {
    	super.onUpdate();
    
    	if(currentAction == 0 || currentAction == -2) breakCounter++;
    	if(currentAction == -1) destroyCounter++;
    	
    	if(breakCounter == breakTime[shovelType] && !onGround){
    		breakCounter -= 4;
    	}
    	else if(breakCounter == breakTime[shovelType] && onGround){ //when break over, switch to dig mode
			posY = MathHelper.floor_double(boundingBox.minY);
			if(worldObj.getBlockId(MathHelper.floor_double(posX), MathHelper.floor_double(boundingBox.minY) - 1, MathHelper.floor_double(posZ)) == 0)
				posY -= 1;
    		noMove = true;
    		heldObj = shovels[shovelType];
    		breakCounter = 0;
    		destroyCounter = 0;
    		currentAction = -1;
    		randomizeDigCoordinates();
    		xO = 0;
    		yO = 0;
    		zO = 0;
    	}
    	else if(destroyCounter == 1){ //check if chosen block can be dug
    		if(!canDigBlock(xD + xO, yD + yO, zD + zO)){ //if cannot, skip to next block
    			if(destroyCounter != -31){
        			destroyCounter = 0;
        			xO++;
        			if(xO > 3){
        				xO = 0;
        				zO++;
        				if(zO > 3){
        					zO = 0;
        					yO--;
        					if(yO < -3){
        						xO = 0;
        						zO = 0;
        						yO = 0;
        						destroyCounter = -31;
        						currentAction = 0;
        						blocksBroken = 0;
        			    		breakCounter = 0;
        			    		noMove = false;
        			    		heldObj = null;
        					}
        				}
        			}
    			}
    		}
    	}
    	else if(destroyCounter > 1 && destroyCounter <= blockDestroyTime[shovelType] + 1){ //animate arm movement and rotation
    		prevSwingProgress = ((float) destroyCounter - 1F) / ((float) blockDestroyTime[shovelType]);
    		swingProgress = ((float) destroyCounter - 1F) / ((float) blockDestroyTime[shovelType]);
    		faceBlock(xD + xO, yD + yO, zD + zO, 90F / ((float) blockDestroyTime[shovelType]));
    	}
    	else if(destroyCounter == blockDestroyTime[shovelType] + 2){ //once counter high enough, destroy block
    		//Create digging FX
    		//Tessellator tessellator = Tessellator.instance;
            //tessellator.startDrawingQuads();
    		/*EntityDiggingFX edFX[] = new EntityDiggingFX[8];
			for(int LL = 0; LL < 8; LL++){
				edFX[LL] = new EntityDiggingFX(worldObj, xD + xO, yD + yO, zD + zO, rand.nextDouble(), rand.nextDouble() + 1, rand.nextDouble(),
						Block.blocksList[worldObj.getBlockId(xD + xO, yD + yO, zD + zO)]).func_4041_a(xD + xO, yD + yO, zD + zO);
				
			//	edFX[LL].func_406_a(tessellator, rand.nextFloat(), rand.nextFloat(), rand.nextFloat(), rand.nextFloat(), rand.nextFloat(), rand.nextFloat());
			}*/
			//tessellator.draw();
			//Get type of block and replace with air
			int bID = worldObj.getBlockId(xD + xO, yD + yO, zD + zO);
			if(bID != 0){
				worldObj.playSoundAtEntity(this, Block.blocksList[bID].stepSound.func_1145_d(), getSoundVolume(), (rand.nextFloat() - rand.nextFloat()) * 0.2F + 1.0F);
			//Spawn correct kind of item at destroyed block
				int quantDrop = Block.blocksList[bID].quantityDropped(rand);
				int idDrop = Block.blocksList[bID].idDropped(0, rand);
				if(quantDrop > 0 && idDrop > 0){
					ItemStack blockDrop = new ItemStack(idDrop, quantDrop, 0);
					worldObj.setBlockWithNotify(xD + xO, yD + yO, zD + zO, 0);
					EntityItem entityitem;
					entityitem = new EntityItem(worldObj, xD + xO, yD + yO + 0.4, zD + zO, blockDrop);
					entityitem.delayBeforeCanPickup = 10;
					entityitem.age = 5400;
					worldObj.entityJoinedWorld(entityitem);
				}
				else
					worldObj.setBlockWithNotify(xD + xO, yD + yO, zD + zO, 0);
				
			}
        	//Add Digging FX to world
			/*for(int LL = 0; LL < 8; LL++)
				worldObj.entityJoinedWorld(edFX[LL]);
			*/
    		if(blocksBroken != maxBlockDestroy[shovelType] - 1){ //if enough blocks destroyed, stop automatically
    			//func_1186_a(int i, int j, int k)
    			if(rand.nextInt(100) < 10)
    				generateTreasure(xD + xO, yD + yO - 1, zD + zO);
    			if(currentAction != -2){
    				//if sand or gravel, set destroy counter
    				if(bID == Block.sand.blockID || bID == Block.gravel.blockID){
    					destroyCounter = -30;
    				}
    				else{
        				destroyCounter = 0;
        				xO++;
    				}
    				blocksBroken++;
    				if(xO > 4){
    					xO = 0;
    					zO++;
    					if(zO > 4){
    						zO = 0;
    						yO--;
    						if(yO < -3){
    							xO = 0;
    							zO = 0;
    							yO = 0;
    							destroyCounter = -31;
    							currentAction = 0;
    							blocksBroken = 0;
    							breakCounter = 0;
    							noMove = false;
    							heldObj = null;
    						}
    					}
    				}
    			}
    		}
    		else{
    			if(rand.nextInt(100) < 25)
    				generateTreasure(xD + xO, yD + yO - 1, zD + zO);
    			if(currentAction != -2){
    				xO = 0;
					zO = 0;
					yO = 0;
					destroyCounter = -31;
					currentAction = 0;
					blocksBroken = 0;
					breakCounter = 0;
					noMove = false;
					heldObj = null;
    			}
    		}
    	}
    	else if(currentAction == -2 && breakCounter == 1){ //if chest was found, prepare to place sign on top
    		heldObj = new ItemStack(Block.signPost.blockID, 1, 0);
    	}
    	else if(currentAction == -2 && breakCounter > 5 && breakCounter <= 13){
    		prevSwingProgress = ((float) breakCounter - 5F) / 8F;
    		swingProgress = ((float) breakCounter - 5F) / 8F;
    		faceBlock(xS, yS, zS, 90F / 8F);
    	}
    	else if(currentAction == -2 && breakCounter == 14){
    		//worldObj.setBlockWithNotify(xS, yS, zS, Block.signPost.blockID);
    		worldObj.setBlockAndMetadataWithNotify(xS, yS, zS, Block.signPost.blockID, MathHelper.floor_double((double)(((rotationYaw + 180F) * 16F) / 360F) + 0.5D) & 0xf);
    		worldObj.playSoundAtEntity(this, "random.pop", getSoundVolume(), (rand.nextFloat() - rand.nextFloat()) * 0.2F + 1.0F);
    		TileEntitySign tES = (TileEntitySign)worldObj.getBlockTileEntity(xS, yS, zS);
    		if(tES != null)
    			tES.signText = new String[]{"Hidden treasure", "found by your", "local treasure", "hunter. Enjoy!"};
    		heldObj = null;
    		noMove = false;
    		currentAction = 0;
    		xS = 0;
    		yS = 0;
    		zS = 0;
    	}
	}
    
    protected void generateTreasure(int i, int j, int k){
    	int rNum = rand.nextInt(300);
    	if(worldObj.getBlockId(i, j, k) == Block.stone.blockID){
    		int treasure;
    		if(rNum < 150) treasure = 0;
    		else if(rNum < 225) treasure = 1;
    		else if(rNum < 260) treasure = 2;
    		else if(rNum < 275) treasure = 3;
    		else if(rNum < 285) treasure = 4;
    		else if(rNum < 295) treasure = 5;
    		else if(rNum < 299) treasure = 6;
    		else treasure = 7;
    		worldObj.setBlockWithNotify(i, j, k, treasures[treasure]);
    		if(treasure == 5){
    			setRareTreasures(i, j, k);
    			currentAction = -2;
    			xS = i;
    			yS = j + 1;
    			zS = k;
    			xO = 0;
				zO = 0;
				yO = 0;
				destroyCounter = -31;
				blocksBroken = 0;
				breakCounter = 0;
				heldObj = null;
    		}
    	}
    	else{
    		if(rNum < 5){
    			worldObj.setBlockWithNotify(i, j, k, Block.chest.blockID);
    			setCommonTreasures(i, j, k);
    			currentAction = -2;
    			xS = i;
    			yS = j + 1;
    			zS = k;
    			xO = 0;
				zO = 0;
				yO = 0;
				destroyCounter = -31;
				blocksBroken = 0;
				breakCounter = 0;
				heldObj = null;
    		}
    	}
    }
    
    protected boolean canDigBlock(int i, int j, int k){
    	int bID = worldObj.getBlockId(i, j, k); //block id of block within designated spot
    	int bID2 = worldObj.getBlockId(i, j + 1, k); //block id of block above designated spot
    	if(!(bID2 == 0 || bID2 == Block.dirt.blockID || bID2 == Block.grass.blockID
    			|| bID2 == Block.tilledField.blockID || bID2 == Block.snow.blockID
    			|| bID2 == Block.sand.blockID || bID2 == Block.gravel.blockID || bID2 == Block.blockClay.blockID)){
    		destroyCounter = -31;
    		breakCounter = breakTime[shovelType] / 2;
    		noMove = false;
    		heldObj = null;
    		blocksBroken = 0;
    		currentAction = 0;
    		return false;
    	}
    	else return (bID == Block.dirt.blockID || bID == Block.grass.blockID
    			|| bID == Block.tilledField.blockID || bID == Block.snow.blockID
    			|| bID2 == Block.sand.blockID || bID2 == Block.gravel.blockID || bID2 == Block.blockClay.blockID);
    }
    
    protected void randomizeDigCoordinates(){
    	//randomly determine which nearby block to dig at
		int rand1 = rand.nextInt(3) - 1; 
		int rand2 = rand.nextInt(3) - 1;
		if(rand1 == -1 && rand2 == -1)
			rand1 = 1;
		else if(rand1 == -1 && rand2 == 0)
			rand2 = 1;
		else if(rand1 == 0 && rand2 == 11)
			rand2 = 1;
		else if(rand1 == 0 && rand2 == 0)
			rand1 = 1;
		
		//set dig coordinates
    	xD = MathHelper.floor_double(posX) + rand1;
		yD = MathHelper.floor_double(boundingBox.minY) - 1;
		zD = MathHelper.floor_double(posZ) + rand2;	
    }
    
    public boolean interact(EntityPlayer entityplayer)
    {
		if(breakCounter != -1) return super.interact(entityplayer);
		else return false;
    }
    
    protected void setCommonTreasures(int i, int j, int k){
    	TileEntityChest tEC = (TileEntityChest) worldObj.getBlockTileEntity(i, j, k);
    	if(tEC == null) return;
    	int numIts = rand.nextInt(27) + 1;
    	for(int n = 0; n < numIts; n++){
    		tEC.setInventorySlotContents(n, new ItemStack(cTreasures[rand.nextInt(cTreasures.length)], rand.nextInt(5) + 1));
    	}
    }
    
    protected void setRareTreasures(int i, int j, int k){
    	TileEntityChest tEC = (TileEntityChest) worldObj.getBlockTileEntity(i, j, k);
    	if(tEC == null) return;
    	int numIts = rand.nextInt(27) + 1;
    	for(int n = 0; n < numIts; n++){
    		tEC.setInventorySlotContents(n, rTreasures[rand.nextInt(rTreasures.length)]);
    	}
    }
    
    public ItemStack getChestItem(){
    	return chestItems[rand.nextInt(chestItems.length)].copy();
    }
    
    protected boolean canDespawn()
    {
        return false;
    }
    
    protected boolean canTossMeat(){
    	return currentAction == 0;
    }
    
    protected void setTimers(short x){
    	if(breakCounter != -1)
			breakCounter = x;
    }
    
    protected boolean canBeHurt(){
    	return currentAction == -1 || super.canBeHurt();
    }
    
  //called when actionTimer = maxWait
    protected void selectIdleAction(){
    }
    
    protected ItemStack getThrownItem(){
    	return new ItemStack(Item.bowlSoup);
    }
    
    protected ItemStack getHealingItem(){
    	return new ItemStack(Item.bowlSoup);
    }
    
    public int getMaxHp(){
    	return 25;
    }
    
    public int getClimbBlockID(){
    	return Block.sand.blockID;
    }
    
    protected String getActionDescrip(){
    	switch(currentAction){
    	case -2:
    		return "Placing Sign";
    	case -1:
    		return "Digging";
    	default:
    		return super.getActionDescrip();
    	}
    }
    
    public int shovelType;
    protected int destroyCounter; //counter for block destroying process
    protected int breakCounter; //counter for break times
    protected int blocksBroken; //counter for # of blocks dug up
    protected int xD; //Starting dig Xposition
    protected int yD; //Starting dig Yposition
    protected int zD; //Starting dig Zposition
    protected int xO; //X offset from starting dig Xposition
    protected int yO; //Y offset from starting dig Yposition
    protected int zO; //Z offset from starting dig Zposition
    protected int xS; //X position of sign to be placed
    protected int yS; //Y position of sign to be placed
    protected int zS; //Z position of sign to be placed
    //protected boolean chestSign; //if true, designates sign to be placed at xS, yS, zS
	
    static final ItemStack[] shovels = (new ItemStack[]{
        	new ItemStack(Item.shovelWood, 1), new ItemStack(Item.shovelGold, 1), new ItemStack(Item.shovelStone, 1),
        	new ItemStack(Item.shovelSteel, 1), new ItemStack(Item.shovelDiamond, 1)
        });
      	static final int[] maxBlockDestroy = new int[]{
        	10, 10, 20, 30, 50
        };
        static final int[] blockDestroyTime = new int[]{
        	16, 2, 12, 9, 4
        };
        static final int[] breakTime = new int[]{
        	320, 320, 240, 160, 100
        };
        static final int[] treasures = new int[]{
        	Block.oreCoal.blockID, Block.oreIron.blockID, Block.oreRedstone.blockID, Block.oreGold.blockID, 
        	Block.oreLapis.blockID, Block.obsidian.blockID,
        	Block.oreDiamond.blockID, Block.chest.blockID
        };
        static final Item[] cTreasures = new Item[]{
        	Item.coal, Item.arrow, Item.ingotIron, Item.ingotGold, Item.bowlSoup, Item.silk, Item.feather, Item.gunpowder, Item.seeds,
        	 Item.wheat, Item.flint, Item.redstone, Item.leather, Item.appleRed, Item.clay, Item.book, Item.slimeBall, Item.ingotGold,
        	 Item.cookie, Item.sugar, Item.paper, Item.stick, Item.fishRaw, Item.slimeBall, Item.bed, Item.painting, Item.saddle,
        	 Item.ingotGold, Item.ingotGold, Item.bone
        };
        static final ItemStack[] rTreasures = new ItemStack[]{
        	new ItemStack(Item.diamond, 1), new ItemStack(Block.blockDiamond.blockID, 1, 0), new ItemStack(Item.lightStoneDust, 5), 
        	new ItemStack(Item.lightStoneDust, 20), new ItemStack(Item.diamond, 2), new ItemStack(Item.bucketLava, 1), 
        	new ItemStack(Item.helmetDiamond, 1), new ItemStack(Item.plateDiamond, 1), new ItemStack(Item.legsDiamond, 1), 
        	new ItemStack(Item.bootsDiamond, 1), new ItemStack(Item.appleGold, 1), new ItemStack(Item.hoeDiamond, 1), 
        	new ItemStack(Item.axeDiamond, 1), new ItemStack(Item.pickaxeDiamond, 1), new ItemStack(Item.shovelDiamond, 1), 
        	new ItemStack(Item.swordDiamond, 1), new ItemStack(Item.arrow, 64), new ItemStack(Item.ingotIron, 16), 
        	new ItemStack(Item.slimeBall, 64), new ItemStack(Block.tnt, 20), new ItemStack(Item.record13, 1), 
        	new ItemStack(Item.legsGold, 1), new ItemStack(Item.gunpowder, 64), new ItemStack(Block.glowStone, 16), 
        	new ItemStack(Item.diamond, 3), new ItemStack(Block.rail.blockID, 64, 0)
        };
        
        static final ItemStack[] chestItems = (new ItemStack[]{
            	new ItemStack(Item.ingotGold, 1), new ItemStack(Item.clay, 1), new ItemStack(Block.oreGold, 1),
            	new ItemStack(Block.dirt, 1), new ItemStack(Item.sign, 1), new ItemStack(Block.chest, 1),
            	new ItemStack(Block.dirt, 1), new ItemStack(Item.silk, 1), new ItemStack(Block.sandStone, 1),
            	new ItemStack(Block.dirt, 1), new ItemStack(Item.redstone, 1), new ItemStack(Block.sand, 1),
            	new ItemStack(Block.cobblestoneMossy, 1), new ItemStack(Item.bone, 3), new ItemStack(Block.tnt, 2),
            	new ItemStack(Block.musicBlock, 1), new ItemStack(Item.lightStoneDust, 2), new ItemStack(Block.railPowered, 1),
            	new ItemStack(Item.feather, 1), new ItemStack(Item.bowlEmpty, 1), new ItemStack(Item.helmetLeather, 1), new ItemStack(Item.seeds, 1)
            });
}
