package net.minecraft.src;
// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

import java.io.BufferedReader;
import net.minecraft.client.Minecraft;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.jar.JarInputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class mod_Builders extends BaseMod
{

    public mod_Builders()
    {
    	builderCount = 0;
    	minecraft_b = ModLoader.getMinecraftInstance();
    	BLDRBlueprints.singlePrints = new ArrayList<ArrayList<ArrayList<ArrayList<Short>>>>();
    	builderList = new ArrayList<BLDREntityBuilder>();
    	BLDRBlueprints.singlePrintNames = new ArrayList<String>();
    	
    	ModLoader.SetInGameHook(this, true, true);
    	ModLoader.SetInGUIHook(this, true, true);
    	
		ModLoader.RegisterEntityID(BLDREntityBrickBuilder.class, "BrickBuilder", ModLoader.getUniqueEntityId());
        ModLoader.RegisterEntityID(BLDREntityCobbleBuilder.class, "CobbleBuilder", ModLoader.getUniqueEntityId());
        ModLoader.RegisterEntityID(BLDREntityExplorer.class, "Explorer", ModLoader.getUniqueEntityId());
        ModLoader.RegisterEntityID(BLDREntityHomeSeeker.class, "HomeSeeker", ModLoader.getUniqueEntityId());
        ModLoader.RegisterEntityID(BLDREntityTreasureHunter.class, "TreasureHunter", ModLoader.getUniqueEntityId());
        ModLoader.RegisterEntityID(BLDREntityMayor.class, "Mayor", ModLoader.getUniqueEntityId());
        ModLoader.RegisterEntityID(BLDREntityMultiBuilder.class, "MultiBuilder", ModLoader.getUniqueEntityId());
        ModLoader.RegisterEntityID(BLDREntityTrader.class, "Trader", ModLoader.getUniqueEntityId());
        ModLoader.RegisterEntityID(BLDREntityBaker.class, "Baker", ModLoader.getUniqueEntityId());
        ModLoader.RegisterEntityID(BLDREntitySandBuilder.class, "SandBuilder", ModLoader.getUniqueEntityId());
        
        /*ModLoader.AddSpawn(EntityBrickBuilder.class, 10, EnumCreatureType.creature);
        ModLoader.AddSpawn(EntityCobbleBuilder.class, 10, EnumCreatureType.creature);
        ModLoader.AddSpawn(EntityExplorer.class, 10, EnumCreatureType.creature);
        ModLoader.AddSpawn(EntityHomeSeeker.class, 10, EnumCreatureType.creature);
        ModLoader.AddSpawn(EntityTreasureHunter.class, 10, EnumCreatureType.creature);
        ModLoader.AddSpawn(EntityMayor.class, 10, EnumCreatureType.creature);
        ModLoader.AddSpawn(EntityMultiBuilder.class, 10, EnumCreatureType.creature);
        ModLoader.AddSpawn(EntityTrader.class, 10, EnumCreatureType.creature);
        ModLoader.AddSpawn(EntityBaker.class, 10, EnumCreatureType.creature);
        ModLoader.AddSpawn(EntitySandBuilder.class, 10, EnumCreatureType.creature, new BiomeGenBase[]{BiomeGenBase.desert});*/

        //if index nonexistant, will stay -1
        homeSeekerHutIndex = -1;
    	explorerSingleBlockIndex = -1;
    	explorerFancyBeaconIndex = -1;
    	traderBakerShopIndex = -1;
    	//setDefaultSettings();
        File f = null;
        File source = null;
        File srcDirectory;
        File srcDirectory2;
        File singlePrintsDirectory;
        folderDetected = false;
        try{
        	source = new File(mod_Builders.class.getProtectionDomain().getCodeSource().getLocation().toURI());
        	srcDirectory = source.getParentFile();
        	srcDirectory2 = new File(srcDirectory, "Builders");
        	if(srcDirectory2.exists() && srcDirectory2.isDirectory()){
            	folderDetected = true;
        		f = new File(srcDirectory2, "BuilderConfiguration.txt"); //load config file
        		singlePrintsDirectory = new File(srcDirectory2, "SinglePrints");
        		if(singlePrintsDirectory.exists() && singlePrintsDirectory.isDirectory())
        			loadAllSingleBlueprints(singlePrintsDirectory.listFiles());
        	}
        		
        	
        }catch(Exception e){
        	setDefaultSettings();
        }finally{
        //load configuration file
        if(f != null && f.exists())
        	setConfigurationSettings(f);
        else
        	setDefaultSettings();
        }
        
        signEdit = false;
        sign = null;
        saveSignList = false;
        loadSignList = false;
        world = null;
        

    }
    
   private void signsListLoad(){
	   //create fresh new signsList
       signsList = new ArrayList<BLDRBuilderSigns>();
	   try{
		   //open saved sign file; if does not exist, end method
		   File file1 = new File(Minecraft.getMinecraftDir(), "saves"); //saves directory
		   File file2 = new File(file1, world.getWorldInfo().getWorldName()); //world directory
		   File file3 = new File(file2, "builderSigns.dat"); //signs file
		   if(file3 == null || !file3.exists())
			   return;
		   
		   FileInputStream fileinputstream = new FileInputStream(file3);
           NBTTagCompound nbttagcompound = CompressedStreamTools.func_1138_a(fileinputstream);
           
           NBTTagList nbttaglist = nbttagcompound.getTagList("Signs");
		   //read data from file until at end of file
		   ////add Sign to list using coordinates, type, range, num1, and num2
           for(int i = 0; i < nbttaglist.tagCount(); i++)
           {
               NBTTagCompound nbttagcompound1 = (NBTTagCompound)nbttaglist.tagAt(i);
               BLDRBuilderSigns b = new BLDRBuilderSigns();
               b.readFromNBT(nbttagcompound1);
               signsList.add(b);
           }
	   }catch(Exception e){
		   e.printStackTrace();
	   }
   }
   
   private void signsListSave(){
	   //if signList empty or non-existent, exit
	   if(signsList == null || signsList.size() < 1)
		   return;
	   try{
		   //create or replace sign file
		   File file1 = new File(Minecraft.getMinecraftDir(), "saves"); //saves directory
		   File file2 = new File(file1, world.getWorldInfo().getWorldName()); //world directory
		   File file3 = new File(file2, "builderSigns.dat"); //signs file
		   if(file3.exists())
			   file3.delete();
		   FileOutputStream fileoutputstream = new FileOutputStream(file3);
	   
		   //copy data from each sign on the list into file, until end of list
		   ////save coordinates, type, range, num1, and num2 to file
		   NBTTagCompound nbttagcompound = new NBTTagCompound();
		   NBTTagList nbttaglist = new NBTTagList();
		   for(int i = 0; i < signsList.size(); i++)
		   {
			   BLDRBuilderSigns b = signsList.get(i);
			   if(b != null)
			   {
				   NBTTagCompound nbttagcompound1 = new NBTTagCompound();
				   b.writeToNBT(nbttagcompound1);
				   nbttaglist.setTag(nbttagcompound1);
			   }
		   }
		   nbttagcompound.setTag("Signs", nbttaglist);
		   CompressedStreamTools.writeGzippedCompoundToOutputStream(nbttagcompound, fileoutputstream);
	   }catch(Exception e){
		   e.printStackTrace();
	   }
   }
   

   public boolean OnTickInGUI(Minecraft game, GuiScreen gui)
   {
	   if(world != null && world.multiplayerWorld || game.thePlayer != null && game.thePlayer.dimension != 0) return true;
  		//Get Sign Edit Screen's SignTileEntity, if not already obtained
		if(signEdit == false && gui instanceof GuiEditSign){
			try {
				sign = (TileEntitySign) ModLoader.getPrivateValue(GuiEditSign.class, (GuiEditSign)gui, "i");
				signEdit = true;
			} catch (Throwable e) {
			}
		}
		//Save signsList variable when at menu screen
		else if(saveSignList == false && gui instanceof GuiIngameMenu){
			signsListSave();
			saveSignList = true;
		}

		return true;
   }
   
   public boolean OnTickInGame(Minecraft game)
   {
	   if(world != null && world.multiplayerWorld || game.thePlayer != null && game.thePlayer.dimension != 0) return true;
	   
	 //if world has just been loaded, or has changed, set world variable to that world
   	if(game.theWorld != world){
   		world = game.theWorld;
   		builderCount = 0;
   		builderList.clear();
   		signEdit = false;
           sign = null;
           saveSignList = false;
           loadSignList = false;
           if(folderDetected) game.ingameGUI.addChatMessage("Builders Mod: Mod properly installed and functioning.");
           else game.ingameGUI.addChatMessage("Builders Mod: <WARNING> Builders folder not detected in .minecraft/bin folder.  Mod will not function correctly without this folder.");
           
         //set minecraft instance if not already set
			if(mod_Builders.minecraft_b == null || mod_Builders.minecraft_b != game)
				mod_Builders.minecraft_b = game;
   	}
   	
  //After sign screen removed, check sign's text, and add to sign List if applicable
   	if(game.currentScreen == null){
	if(signEdit == true){
		BLDRBuilderSigns b = new BLDRBuilderSigns();
		if(b.createBuilderSign(sign))
			signsList.add(b);
		sign = null;
		signEdit = false;
	}
	
	//reset save variable
	else if(saveSignList == true)
		saveSignList = false;
	
	//if not loaded signs, load signs from file
	else if(loadSignList == false){
		signsListLoad();
		loadSignList = true;
	}
   	}
   	
   	if(world.getWorldTime() % 10 == 0){
		try {
			performBuilderSpawning(game);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
   	
   	if(builderCount != 0) refreshBuilderList();
   	builderCount = builderList.size();

	return true;
   }
   
 //refreshes the bat list
	private void refreshBuilderList(){
		builderList.clear();
		BLDREntityBuilder eb;
		for(int i = 0; i < world.loadedEntityList.size(); i++){
			if(world.loadedEntityList.get(i) instanceof BLDREntityBuilder){
				eb = (BLDREntityBuilder) world.loadedEntityList.get(i);
				if(((eb.builderFlags >> 2) & 1) != 1 && !eb.isDead) builderList.add(eb);
			}
		}
	}
   
   //adds all builder limits together
   private int addLimits(){
	   if(world.isDaytime()){
		   return BLDRBuilderConfig.getMaxTotalDayTime();
	   }
	   else{
		   return BLDRBuilderConfig.getMaxTotalNightTime();
	   }
   }
 //spawns builders into world
	private void performBuilderSpawning(Minecraft game) throws Exception{
		if(builderList.size() > addLimits() || game.thePlayer == null) return;
		
		int chunkX = MathHelper.floor_double(game.thePlayer.posX / 16.0D);
		int chunkZ = MathHelper.floor_double(game.thePlayer.posZ / 16.0D);
		
		//choose random chunk to spawn builders at
		chunkX += world.rand.nextInt(11) - 5;
		chunkZ += world.rand.nextInt(11) - 5;
		
		//choose random coordinates in chunk to spawn builders at
		int x = (chunkX * 16) + world.rand.nextInt(16);
		int y = world.rand.nextInt(63) + 64;
		int z = (chunkZ * 16) + world.rand.nextInt(16);
		while(game.thePlayer.getDistance(x, y, z) < 20D) //make builders spawn somewhat far from player
			x += 8 + world.rand.nextInt(10);
		while(world.isAirBlock(x, y - 1, z) && y > 10)
			y -= 5;
		BLDREntityBuilder eb;
		//spawn multiple builders near that location
		for(int i = 0; i < (BLDRBuilderConfig.freeLanceStyle > 1 ? 16 : 8); i++){
			eb = (BLDREntityBuilder) builderTypes[world.rand.nextInt(builderTypes.length)].getConstructor(World.class).newInstance(world);
			int xx = x + world.rand.nextInt(15) - 7;
			int yy = y + world.rand.nextInt(5) - 2;
			int zz = z + world.rand.nextInt(15) - 7;

			while(world.isAirBlock(xx, yy - 1, zz) && yy > 10)
				yy--;
			while(!world.isAirBlock(xx, yy, zz) && yy < 120)
				yy++;

			eb.setLocationAndAngles(xx, (double)yy + 1.3, zz, world.rand.nextFloat() * 360.0F, 0.0F);
			if(canBeSpawned(eb)){
				if(world.getWorldInfo().getWorldName() == "BuilderDebug"){
					String str = new StringBuilder("Builder spawned: ").append(xx).append(" ").append((double)yy + 1.3).append(" ").append(zz).toString();
					ModLoader.getMinecraftInstance().ingameGUI.addChatMessage(str);
				}
				builderList.add(eb);
				world.entityJoinedWorld(eb);
			}
		}
	}
	
	private boolean canBeSpawned(BLDREntityBuilder eb){
		return eb.getCanSpawnHere() && (BLDRBuilderConfig.freeLanceStyle != 2 || eb.withinBuildRegion((int) (eb.posX / 16), (int) (eb.posZ / 16))) && (BLDRBuilderConfig.freeLanceStyle != 3 || eb.withinBuildRegion((int) (eb.posX / 16) + eb.getChunkOffsetX(), (int) (eb.posZ / 16) + eb.getChunkOffsetZ()));
	}
	
	 public static int countBuilders(Class class1)
	    {
	        int i = 0;
	        for(int j = 0; j < builderList.size(); j++)
	        {
	            Entity entity = (Entity)builderList.get(j);
	            if(class1.isAssignableFrom(entity.getClass()))
	            {
	                i++;
	            }
	        }

	        return i;
	    }
    
    
    private void setConfigurationSettings(File f){
    	BufferedReader br = null;
    	try{
    		br = new BufferedReader(new FileReader(f));
    		String thisLine;
    		
    		//set each static value (see setDefaultSettings() for identifications)
    		//Spawn Rates
    		thisLine = br.readLine();
    		thisLine = br.readLine();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.brickSpawnRateDay = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.brickSpawnRateNight = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.cobbleSpawnRateDay = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.cobbleSpawnRateNight = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.explorerSpawnRateDay = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.explorerSpawnRateNight = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.homeSpawnRateDay = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.homeSpawnRateNight = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.treasureSpawnRateDay = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.treasureSpawnRateNight = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.mayorSpawnRateDay = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.mayorSpawnRateNight = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.multiSpawnRateDay = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.multiSpawnRateNight = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.traderSpawnRateDay = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.traderSpawnRateNight = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.bakerSpawnRateDay = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.bakerSpawnRateNight = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.sandSpawnRateDay = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.sandSpawnRateNight = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();

    		//Spawn Limits
    		thisLine = br.readLine();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.brickSpawnMaxDay = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.brickSpawnMaxNight = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.cobbleSpawnMaxDay = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.cobbleSpawnMaxNight = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.explorerSpawnMaxDay = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.explorerSpawnMaxNight = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.homeSpawnMaxDay = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.homeSpawnMaxNight = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.treasureSpawnMaxDay = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.treasureSpawnMaxNight = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.mayorSpawnMaxDay = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.mayorSpawnMaxNight = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.multiSpawnMaxDay = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.multiSpawnMaxNight = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.traderSpawnMaxDay = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.traderSpawnMaxNight = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.bakerSpawnMaxDay = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.bakerSpawnMaxNight = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.sandSpawnMaxDay = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.sandSpawnMaxNight = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		
    		//Structure Limits
    		thisLine = br.readLine();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.brickStructureLimit = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.cobbleStructureLimit = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.explorerBlockLimit = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.homeStructureLimit = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.multiStructureLimit = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.sandStructureLimit = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		
    		//Build Blocks
    		thisLine = br.readLine();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.brickCommonBlock = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.brickRareBlock = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.cobbleCommonBlock = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.cobbleRareBlock = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.homeCommonBlock = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.homeRareBlock = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.explorerBlock = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.explorerMBlock = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.treasureMBlock = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.traderBlock = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.bakerBlock = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		thisLine = br.readLine();
    		BLDRBuilderConfig.sandBlock = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
    		
    		//Misc
    		thisLine = br.readLine();
    		thisLine = br.readLine();
    		int temp1 = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
        	if(temp1 == 0)
        		BLDRBuilderConfig.buildAnywhere = false;
        	else
        		BLDRBuilderConfig.buildAnywhere = true;

        	thisLine = br.readLine();
    		temp1 = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
        	if(temp1 == 0)
        		BLDRBuilderConfig.enableNames = false;
        	else
        		BLDRBuilderConfig.enableNames = true;
        	
        	thisLine = br.readLine();
    		temp1 = Integer.valueOf(thisLine.split(":")[1].trim()).intValue();
        	if(temp1 < 0)
        		BLDRBuilderConfig.freeLanceStyle = 0;
        	else if(temp1 > 3)
        		BLDRBuilderConfig.freeLanceStyle = 3;
        	else
        		BLDRBuilderConfig.freeLanceStyle = (byte) temp1;
        	
    		
    		thisLine = br.readLine();
        	if(thisLine != null)
        		setDefaultSettings();

    		
    		
    	}catch(FileNotFoundException e) {
    		setDefaultSettings();
    		if (br != null)
    			try {
    				br.close();
    			}
    			catch (IOException localIOException2)
    			{
    			}
    	}catch (IOException e)
    	{
    		setDefaultSettings();
    		if (br != null)
    		try {
    			br.close();
    		}
    		catch (IOException localIOException3)
    		{
    		}
    	}
    	finally
    	{
    		if (br != null)
    		try {
    			br.close();
    		} catch (IOException localIOException4) {
    		}
    	}
    }
    
    private void setDefaultSettings(){
        	//Spawn stuff
		
		//Spawn rates for each builder (0 - 100), 0 = never, 100 = always
        BLDRBuilderConfig.brickSpawnRateDay = 75; //BrickBuilder (Day)
		BLDRBuilderConfig.brickSpawnRateNight = 0; //BrickBuilder (Night)
		BLDRBuilderConfig.cobbleSpawnRateDay = 90; //CobbleBuilder (Day)
		BLDRBuilderConfig.cobbleSpawnRateNight = 20; //CobbleBuilder (Night)
		BLDRBuilderConfig.explorerSpawnRateDay = 10; //Explorer (Day)
		BLDRBuilderConfig.explorerSpawnRateNight = 90; //Explorer (Night)
		BLDRBuilderConfig.homeSpawnRateDay = 60; //Home Seeker (Day)
		BLDRBuilderConfig.homeSpawnRateNight = 10; //Home Seeker (Night)
		BLDRBuilderConfig.treasureSpawnRateDay = 0; //Treasure Hunter (Day)
		BLDRBuilderConfig.treasureSpawnRateNight = 0; //Treasure Hunter (Night)
		BLDRBuilderConfig.mayorSpawnRateDay = 50; //Mayor (Day)
		BLDRBuilderConfig.mayorSpawnRateNight = 10; //Mayor (Night)
		BLDRBuilderConfig.multiSpawnRateDay = 75; //MultiBuilder (Day)
		BLDRBuilderConfig.multiSpawnRateNight = 40; //MultiBuilder (Night)
		BLDRBuilderConfig.traderSpawnRateDay = 0; //Trader (Day)
		BLDRBuilderConfig.traderSpawnRateNight = 0; //Trader (Night)
		BLDRBuilderConfig.bakerSpawnRateDay = 0; //Baker (Day)
		BLDRBuilderConfig.bakerSpawnRateNight = 0; //Baker (Night)
		BLDRBuilderConfig.sandSpawnRateDay = 75; //SandBuilder (Day)
		BLDRBuilderConfig.sandSpawnRateNight = 75; //SandBuilder (Night)
		
		//Maximum spawn for each Builder (0 - 100), 0 = no regular spawns; only created via conversion
		BLDRBuilderConfig.brickSpawnMaxDay = 3; //BrickBuilder (Day)
		BLDRBuilderConfig.brickSpawnMaxNight = 0; //BrickBuilder (Night)
		BLDRBuilderConfig.cobbleSpawnMaxDay = 3; //CobbleBuilder (Day)
		BLDRBuilderConfig.cobbleSpawnMaxNight = 3; //CobbleBuilder (Night)
		BLDRBuilderConfig.explorerSpawnMaxDay = 3; //Explorer (Day)
		BLDRBuilderConfig.explorerSpawnMaxNight = 6; //Explorer (Night)
		BLDRBuilderConfig.homeSpawnMaxDay = 4; //Home Seeker (Day)
		BLDRBuilderConfig.homeSpawnMaxNight = 4; //Home Seeker (Night)
		BLDRBuilderConfig.treasureSpawnMaxDay = 0; //Treasure Hunter (Day)
		BLDRBuilderConfig.treasureSpawnMaxNight = 0; //Treasure Hunter (Night)
		BLDRBuilderConfig.mayorSpawnMaxDay = 1; //Mayor (Day)
		BLDRBuilderConfig.mayorSpawnMaxNight = 1; //Mayor (Night)
		BLDRBuilderConfig.multiSpawnMaxDay = 3; //MultiBuilder (Day)
		BLDRBuilderConfig.multiSpawnMaxNight = 3; //MultiBuilder (Night)
		BLDRBuilderConfig.traderSpawnMaxDay = 0; //Trader (Day)
		BLDRBuilderConfig.traderSpawnMaxNight = 0; //Trader (Night)
		BLDRBuilderConfig.bakerSpawnMaxDay = 0; //Baker (Day)
		BLDRBuilderConfig.bakerSpawnMaxNight = 0; //Baker (Night)
		BLDRBuilderConfig.sandSpawnMaxDay = 5; //SandBuilder (Day)
		BLDRBuilderConfig.sandSpawnMaxNight = 5; //SandBuilder (Night)
		
		//Structure Limits for each Builder
		BLDRBuilderConfig.brickStructureLimit = 4; //BrickBuilder Structure Limit
		BLDRBuilderConfig.cobbleStructureLimit = 2; //CobbleBuilder Structure Limit
		BLDRBuilderConfig.explorerBlockLimit = 16; //Explorer Structure Limit
		BLDRBuilderConfig.homeStructureLimit = 2; //Home Seeker Structure Limit
		BLDRBuilderConfig.multiStructureLimit = 3; //MultiBuilder Structure Limit
		BLDRBuilderConfig.sandStructureLimit = 3; //MultiBuilder Structure Limit
		
		//Build Block for each Builder (Block ID; glitches may occur if invalid block)
		BLDRBuilderConfig.brickCommonBlock = 45; //BrickBuilder Common Block
		BLDRBuilderConfig.brickRareBlock = 5; //BrickBuilder Rare Block
		BLDRBuilderConfig.cobbleCommonBlock = 4; //CobbleBuilder Common Block
		BLDRBuilderConfig.cobbleRareBlock = 1; //CobbleBuilder Rare Block
		BLDRBuilderConfig.homeCommonBlock = 3; //Home Seeker Common Block
		BLDRBuilderConfig.homeRareBlock = 35; //Home Seeker Rare Block
		BLDRBuilderConfig.explorerBlock = 50; //Explorer Block
		BLDRBuilderConfig.explorerMBlock = 24; //Explorer Mayor-Aid Block
		BLDRBuilderConfig.treasureMBlock = 5; //Treasure Hunter Mayor-Aid Block
		BLDRBuilderConfig.traderBlock = 1; //Trader Build Block
		BLDRBuilderConfig.bakerBlock = 1; //Baker Build Block
		BLDRBuilderConfig.sandBlock = 24; //SandBuilder Build Block
		
		//Misc.
		BLDRBuilderConfig.buildAnywhere = false; //Determines whether builders build over other terrain
		BLDRBuilderConfig.enableNames = true; //Determines whether Names appear above Builders
		BLDRBuilderConfig.freeLanceStyle = 1; //determines build style

    }


    public void AddRenderer(Map map)
    {
        map.put(BLDREntityBrickBuilder.class, new BLDRRenderBuilder(new ModelBiped(), 0.5F));
        map.put(BLDREntityCobbleBuilder.class, new BLDRRenderBuilder(new ModelBiped(), 0.5F));
        map.put(BLDREntityExplorer.class, new BLDRRenderBuilder(new ModelBiped(), 0.5F));
        map.put(BLDREntityHomeSeeker.class, new BLDRRenderBuilder(new ModelBiped(), 0.5F));
        map.put(BLDREntityTreasureHunter.class, new BLDRRenderBuilder(new ModelBiped(), 0.5F));
        map.put(BLDREntityMayor.class, new BLDRRenderBuilder(new ModelBiped(), 0.5F));
        map.put(BLDREntityMultiBuilder.class, new BLDRRenderBuilder(new ModelBiped(), 0.5F));
        map.put(BLDREntityTrader.class, new BLDRRenderBuilder(new ModelBiped(), 0.5F));
        map.put(BLDREntityBaker.class, new BLDRRenderBuilder(new ModelBiped(), 0.5F));
        map.put(BLDREntitySandBuilder.class, new BLDRRenderBuilder(new ModelBiped(), 0.5F));
    }
    
    public String Version() {
        return "0.61 Beta 1.6_06";
      }
    
    public void ModsLoaded()
    {
    	  //If MineColony found, adapt mod accordingly
        checkForMineColony();
        
        //If Humans+ found, adapt mod accordingly
        //checkForHumansPlus();
    }
    
    public void checkForMineColony(){
    	try {
			Class.forName("mod_MineColony");
			colonyWorker = Class.forName("EntityWorker");
			mineColonyDetected = true;
		} catch (Throwable e) {
			mineColonyDetected = false;
		}
    }
    
   /* private void checkForHumansPlus(){
    	try {
			Class.forName("mod_HumansPlus");
			humanSettler = Class.forName("EntitySettler").asSubclass(EntityLiving.class);
			humanWanderer = Class.forName("EntityWanderer").asSubclass(EntityLiving.class);
			humansPlusDetected = true;
		} catch (Throwable e) {
			humansPlusDetected = false;
		}
    }*/

    //load all txt files and schematic files to singlePrints array
    private void loadAllSingleBlueprints(File[] files){
    	//load all single blueprints
    	File results = new File(files[0].getParentFile().getParentFile(), "results.txt");
    	FileWriter output = null;
    	if(results.exists()) results.delete();
    	try {
			results.createNewFile();
			output = new FileWriter(results);
			output.write("Results.txt file created!\n");
		} catch (IOException e) {
			e.printStackTrace();
		}
		//input each file
    	for(int i = 0; i < files.length; i++){
    		if(!files[i].isFile()) continue; //skip nonFiles
    		else if (files[i].getName().toLowerCase().contains(".txt")) loadBlueprint(output, files[i], 0);
    		else if (files[i].getName().toLowerCase().contains(".schematic")) loadSchematic(output, files[i], 0);
    		else continue;
    	}
    	//when complete verify success in results.txt
    	try {
    		output.write("All txt files & schematic files scanned.\n");
    		output.close();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
    }
    
    //this method loads a blueprint from a .txt file (name, then coordinates), and adds it to an array based on type
    private void loadBlueprint(FileWriter results, File input, int type){
    	int test = 0;
    	BufferedReader br = null;
    	boolean hasName = false;
    	boolean inLayer = false;
    	String name = "";
    	ArrayList<ArrayList<ArrayList<Short>>> blueprintYXZ = new ArrayList<ArrayList<ArrayList<Short>>>();
    	ArrayList<ArrayList<Short>> blueprintXZ = new ArrayList<ArrayList<Short>>();
    	ArrayList<Short> blueprintZ = new ArrayList<Short>();
    	try {
    		test = -1;
			br = new BufferedReader(new FileReader(input));
    		String thisLine;
    		test = 0;
    		thisLine = br.readLine();
    		while(thisLine != null){
    			test++;
    	    	//skip all lines beginning with "//"
    			if(thisLine.startsWith("//")){
    				thisLine = br.readLine();
    				continue;
    			}
 
    			else if(thisLine.startsWith("##")){
    				String text = thisLine.substring(2).toLowerCase();
    				//if line begins with ##, and it is first instance of this, set text after that to name
    				if(!hasName){
    					hasName = true;
    					name = text;
    				}
    				//if line begins with ##Layer, on next line start loading coordinates
    				else if(!inLayer && text.startsWith("layer")){
    					inLayer = true;
    				}
    				//if line begins with  ##End Layer, stop loading coordinates for this layer, else continue
    				else if(inLayer && text.startsWith("end layer")){
    					inLayer = false;
    					blueprintYXZ.add(blueprintXZ);
    					blueprintXZ = new ArrayList<ArrayList<Short>>();
    				}
    				else{
    					throw new Exception();
    				}
    				thisLine = br.readLine();
    				continue;
    			}
    			//if line begins with neither of above, check if in layer, trim spaces at end of line, and add numericals to list, else error
        		//if text split on spaces does not contain all numericals(Short), then error
    			else if(inLayer){
    				String nums[] = thisLine.trim().split(" ");
    				for(int i = 0; i < nums.length; i++){
    					String dat[] = nums[i].split(":");
    					short id = (short) (dat.length > 1 ? Short.valueOf(dat[0]) + ((Short.valueOf(dat[1]) & 15) << 10) : Short.valueOf(dat[0]));
    					blueprintZ.add(id);
    				}

					blueprintXZ.add(blueprintZ);
					blueprintZ = new ArrayList<Short>();
					thisLine = br.readLine();
    			}
    			//If any invalid input or improper structure, output failure to results file in super Directory
    			else{
    				throw new Exception();
    			}
    		}
    		test = -5;
    		br.close();
    		//If file ends and it succeeds, add new list<list<list<short>>>> to proper list(based on type) and output success to results file
    		try {
    			if(type == 0){
    				BLDRBlueprints.singlePrintNames.add(name);
    				BLDRBlueprints.singlePrints.add(blueprintYXZ);
    				//check Blueprints for builder-specific blueprints
    				assignSpecialPrint(name.toLowerCase(), BLDRBlueprints.singlePrintNames.size() - 1, results);
    			}
				results.write(input.getName().concat(" was added!\r"));
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		} catch (Exception e) {
			try {
				if(test > 0)
					results.write(input.getName().concat(" was not read properly. Line ").concat(String.valueOf(test)).concat("\r"));
				else 
					results.write(input.getName().concat(" was not read properly. Failure Case ").concat(String.valueOf(test)).concat("\r"));
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
    	
    }
    
    //this method loads a blueprint from a .schematic file (coordinates only; name = filename(replace all _ with space)), and adds it to an array based on type
    private void loadSchematic(FileWriter results, File input, int type){
    	int test = 0;
    	String name = "";
    	ArrayList<ArrayList<ArrayList<Short>>> blueprintYXZ = new ArrayList<ArrayList<ArrayList<Short>>>();
    	ArrayList<ArrayList<Short>> blueprintXZ = new ArrayList<ArrayList<Short>>();
    	ArrayList<Short> blueprintZ = new ArrayList<Short>();
 	   try{
 		    test = -1;
 		    FileInputStream fileinputstream = new FileInputStream(input);
 		    test = -2;
            NBTTagCompound nbttagcompound = CompressedStreamTools.func_1138_a(fileinputstream);
            test = -3;
            if(nbttagcompound.hasKey("Schematic"))
            	nbttagcompound = nbttagcompound.getCompoundTag("Schematic");
            //make name same as file name without extension
            test = -4;
            String fileName = input.getName();
            test = -5;
            fileName = fileName.replace("_", " ");
            test = -6;
            name = fileName.substring(0, fileName.length() - 10);
            test = -7;
            //get tag list of block array and measurements
            byte blockids[] = nbttagcompound.getByteArray("Blocks");
            test = -8;
            byte blockdata[] = nbttagcompound.getByteArray("Data");
            test = -81;
            short width = nbttagcompound.getShort("Width");
            test = -9;
            short length = nbttagcompound.getShort("Length");
            test = -10;
            short height = nbttagcompound.getShort("Height");
            test = 0;
            int bSize = length * width * height;
            //read data from byte array into arraylists
            for(short y = 0; y < height; y++){
            	for(short z = 0; z < length; z++){
            		for(short x = 0; x < width; x++){
            			test++;
            			blueprintZ.add((short) (blockids[x + (y * length + z) * width] + ((blockdata[x + (y * length + z) * width] & 15) << 10)));
            		}
            		blueprintXZ.add(blueprintZ);
            		blueprintZ = new ArrayList<Short>();
            	}
        		blueprintYXZ.add(blueprintXZ);
        		blueprintXZ = new ArrayList<ArrayList<Short>>();
            }
            test = -11;
          //If file ends and it succeeds, add new list<list<list<short>>>> to proper list(based on type) and output success to results file
    		try {
    			if(type == 0){
    				BLDRBlueprints.singlePrintNames.add(name);
    				BLDRBlueprints.singlePrints.add(blueprintYXZ);
    			}
				results.write(input.getName().concat(" was added! ").concat(String.valueOf(bSize)).concat(" Blocks!\r"));
			} catch (IOException e1) {
				e1.printStackTrace();
			}
            
 	   }catch(Exception e){
 		  try {
 			 if(test < 0)
 				results.write(input.getName().concat(" was not formatted correctly. Fail Case ").concat(String.valueOf(test)).concat("\r"));
 			 else
 				results.write(input.getName().concat(" did not contain a properly formatted byte array. Failed at byte ").concat(String.valueOf(test)).concat("\r"));
			} catch (IOException e1) {
				e1.printStackTrace();
			}
 	   }
    }
    
    //finds and assigns index of specific blueprints used by some builders
    private void assignSpecialPrint(String txt, int index, FileWriter results){
    	boolean success = false;
    	if(txt.equals("hut")){
    		homeSeekerHutIndex = (short) index;
    		success = true;
    	}
    	else if(txt.equals("single block")){
    		explorerSingleBlockIndex = (short) index;
    		success = true;
    	}
    	else if(txt.equals("fancy beacon")){
    		explorerFancyBeaconIndex = (short) index;
    		success = true;
    	}
    	else if(txt.equals("small shop")){
    		traderBakerShopIndex = (short) index;
    		success = true;
    	}
    	
    	if(success == false) return;
    	
    	try {
			 results.write(txt.concat(" was assigned index value ").concat(String.valueOf(index)).concat(".\r"));
			} catch (IOException e1) {
				e1.printStackTrace();
			}
    }
    //Static Methods
    
    /**
     *  Name: dropChestItem()
     * Parameters: EntityBuilder [builder who will drop an item]
     * Spawns an item near the specified builder; The item spawned is one of the builder's trade chest items
     * Returns true if the item successfully joined the world; false otherwise 
     */
    public static boolean dropChestItem(BLDREntityBuilder eB){
    	ItemStack itemstack = eB.getChestItem();
    	EntityItem entityitem = new EntityItem(eB.worldObj, eB.posX, eB.posY + 0.2F, eB.posZ, itemstack);
        entityitem.delayBeforeCanPickup = 10;
        entityitem.age = 4800; //set to despawn after a minute
        return eB.worldObj.entityJoinedWorld(entityitem);
    }
    
    //makes a living entity dodge a entity
    public static boolean dodgeAttack(Entity entityToDodge, EntityLiving dodger, int i){
    	double d = entityToDodge.posX - dodger.posX;
        double d1;
        for(d1 = entityToDodge.posZ - dodger.posZ; d * d + d1 * d1 < 0.0001D; d1 = (Math.random() - Math.random()) * 0.01D)
        {
            d = (Math.random() - Math.random()) * 0.01D;
        }
        dodger.knockBack(entityToDodge, i, -d1, d);
    	if(dodger.motionY > 0.3D)
    		dodger.motionY = 0.3D;
    	return true;
    }
    
    //Spawns particles at an entity
    //Available particles: bubble, smoke, note, portal, explode, flame, lava, splash, largesmoke, reddust, snowballpoof, slime
    public static boolean spawnParticlesAtEntity(Entity entity, String particle, int numParticles){
    	for(int j = 0; j < numParticles; j++)
        {
            double d = entity.rand.nextGaussian() * 0.02D;
            double d1 = entity.rand.nextGaussian() * 0.02D;
            double d2 = entity.rand.nextGaussian() * 0.02D;
            entity.worldObj.spawnParticle(particle, (entity.posX + (double)(entity.rand.nextFloat() * entity.width * 2.0F)) - (double)entity.width, entity.posY + (double)(entity.rand.nextFloat() * entity.height), (entity.posZ + (double)(entity.rand.nextFloat() * entity.width * 2.0F)) - (double)entity.width, d, d1, d2);
        }
    	return true;
    }
    
    //mineColony variables
    public static boolean mineColonyDetected; //true if mineColony detected
    public static Class colonyWorker; //mineColony worker, including Lumberjack, Miner, etc.
    
    //Humans+ variables
    /*public static boolean humansPlusDetected; //true if Humans+ detected
    public static Class humanSettler; //settlers
    public static Class humanWanderer; //wanderers*/
    
    public static Minecraft minecraft_b;
    //Minecraft.isWorldLoaded
    //Minecraft.currentScreen
    //Minecraft.objectMouseOver.blockX,Y,Z
    
    //lists that hold indexes of available blueprints
    public static short homeSeekerHutIndex;
    public static short explorerSingleBlockIndex;
    public static short explorerFancyBeaconIndex;
    public static short traderBakerShopIndex;
    
    
    public static boolean signEdit;
    public static TileEntitySign sign;
    public static boolean saveSignList;
    public static boolean loadSignList;
    public static World world;
    public static List<BLDRBuilderSigns> signsList;
    public static boolean folderDetected;
    public static List<BLDREntityBuilder> builderList;
    public static int builderCount;
    public static final Class builderTypes[] = {
    	BLDREntityBaker.class, BLDREntityTrader.class, BLDREntityBrickBuilder.class, BLDREntityCobbleBuilder.class, 
    	BLDREntitySandBuilder.class, BLDREntityMultiBuilder.class, BLDREntityHomeSeeker.class, BLDREntityMayor.class, 
    	BLDREntityExplorer.class, BLDREntityTreasureHunter.class
    };
}

