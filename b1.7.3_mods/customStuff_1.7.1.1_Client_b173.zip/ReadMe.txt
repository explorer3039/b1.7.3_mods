Custom Recipes:
Create a file with an ending of ".recipe" in the folder "config\customRecipes".
Syntax: result count width height item IDs left to right ,up to down
ex:35-15 23 2 2 3 3 3 3
With this recipe you can make 23 black wool out of 4 dirt.

You can write multiple recipes in one file. (one recipe per line)

			
Custom Fuels:
Create a file with an ending of ".fuel" in the folder "config\customFuels".
Syntax: item duration
durations: One Item needs 200 to smelt
durations from Minecraft:
Wood: 300
Coal: 1600
Lava: 20000

ex: 3 1000
Dirt burns now 5 items long in the furnace
Damage values only for singleplayer: ex: 35-1 1000
You can write multiple fuels in one file. (one fuel per line)
			
			
Custom Smelting Recipes:
Create a file with an ending of ".srecipe" in the folder "config\customSmeltingRecipes".
Syntax: input output count
ex: 3 35-14 2
This smelting recipes let you smelt 2 red wool out of a dirt block
Subitems only works for output

You can write multiple smelting recipes in one file. (one smelting recipe per line)


Custom Ore Generation:
Create a file with an ending of ".oregen" in the folder "config\customOreGeneration".
id               - The id of the block which is generated
damage           - The damage value of the block which is generated.
type             - The type of the generation (normal, flower)
size             - How many blocks are created at maximum at one place
generationblocks - Next to which blocks the block is generated. Devide multiple blocks with a ",".
heightmin        - The lowest height where the block is generated
heightmax        - The highest height where the block is generated
rate             - How many times a depot of blocks per chunk is generated

ex:
id=35
damage=10
type=normal
size=10
rate=10
generationblocks=1
heightmin=0
heightmax=128



Custom Items:
Create a file with an ending of ".item" in the folder "config\customItems".

The file MUST include 3 things:

name           - Name of the item
id             - Id of the item. Must be higher than 512.
iconfile       - The name of the file for the icon. The file must be put into minecraft.jar or into the customStuff zip.

And then you can add optional things:

type              - type of the item. Possible types are normal, food, helmet, body, legs, boots, grenade. (Default is normal)
iconindex         - Used to use minecraft textures.
iddoor            - id of your door. Required for type door.
maxstack          - maximum stack size in inventory [1 ... 64]. (Default is 1)
healamount        - How many half hearts the food is healing. (Default is 1)
saturation        - Value for the saturation. (Default is 0.6)
efficiency        - How fast a tool mines. (ex: wood is 2, diamond is 8; Default is 4)
damage            - How many damage the item deals to a mob. (ex: wood is 0, diamond is 3; Default is 1)
maxuses           - How many uses has a normal item. Increase damage with damageitem function. (Default: armor: 16, food: 1, all other :64)
harvestblocks     - Which blocks the item can mine. Possible values are all, pickaxewood, pickaxestone, pickaxeiron, pickaxediamond, default and any blockid. Use multiple values by devide them with a ",".
efficiencyblocks  - Which blocks can the item mine fast. The given values have also to be in harvestblocks. Possible values are all, none, pickaxe, axe, shovel and any blockid. Use multiple values by devide them with a ",".
armorname         - The name of armortexturefiles (ex: obsidian, the texturefiles are then obsidian_1.png and obsidian_2.png)
infiniteair       - For armor. If true you will have infinite air under water. (Only Singleplayer)
nofalldamage      - For armor. If true you will get no falldamage. (Only Singleplayer)
noburning         - For armor. If true you will never be on fire. (Only Singleplayer)
grenadetime       - Time until grenade explode. (Default is 50)
grenadethrowforce - How far you throw the grenade. (Default is 1.0)
rightclick        - Functions, which are called when you rightclick a block with the item.
blockdestroyed    - Functions, which are called when you destroy a block with the item. 
hitmob            - Functions, which are called when you hit a mob or a player.
explode           - Functions, which are called when the grenade explodes. If you don't set this the grenade will only disappear without doing something. 


			
			
If you want to have more functions in one event you can devide the functions with an semicolon (;)
To make a recipe, your item a fuel, or part of a smelting recipes, you have to write the code into customRecipes.txt, customFuel.txt and customSmeltingRecipes.txt

Example:

name=Obsidian Pickaxe
id=2345
iconfile=ObsidianPickaxe.png
type=normal
maxuses=5000
harvestblocks=pickaxediamond
efficiencyblocks=pickaxe
efficiency=9
damage=5
rightclick=setblock(0,1,0,5,0);setblock(0,2,0,5,0);dropitem(1,55,0)
blockdestroyed=damageitem(1)



custom Blocks:
Create a file with an ending of ".block" in the folder "config\customBlock".

The file MUST include 3 things:

name              - Name of the block. 
id                - Id of the Block [97 ... 255]. 
texturefile       - The name of the file for the texture of the block. Also the bottom texture if you use more textures per block. If your block is a door, then this is the upper texture. The file must be put into minecraft.jar or into the customStuff zip.

And then you can add optional things:

type              - The type of the block (normal,fence,stairs,door,slab,crosstexture,torch,pressureplate,chest,pane). Default is normal.
textureindex      - Used to use minecraft textures. Also the bottom texture if you use more textures per block.
textureindex1     - textureindex1 to textureindex15. textureindex for damage values. Same with the other texture properties.
texturefiletop    - Top texture of the block.
texturefileeast   - East texture of the block.
texturefilewest   - West texture of the block.
texturefilenorth  - North texture of the block.
texturefilesouth  - South texture of the block.
textureindextop   - Top texture of the block.
textureindexeast  - East texture of the block.
textureindexwest  - West texture of the block.
textureindexnorth - North texture of the block.
textureindexsouth - South texture of the block.
chesttexturefile1 - chesttexturefile1 to chesttexturefile7. The textures for the chest. See chesttextures.png in the archiv for which number belongs to which texture.
chesttextureindex1 - chesttextureindex1 to chesttextureindex7. The textures for the chest. See chesttextures.png in the archiv for which number belongs to which texture.
material          - Material of the block. Possible materials are grass, ground, wood, rock, iron, cloth, sand, glass. (Default is rock)
damagevalues      - Number of damage values the block has [1 ... 15] (Default is 0). Only for type normal, fence and crosstexture.
name1             - Name of the block with damage:1. Use name1 to name15 for the other damage values.
redstoneonly      - Set to true if the door can only be opened by redstone. Only for doors. (Default is false)
texturefilebottom - The bottom texture of the door. Required for doors.
doubleslabid      - The id of the block, which is produced when you place the slab above another. If this isnt set up you cant place the slab above another. Only for slabs.
stepsound         - The step sound of the block. This is also the sound when you place or destroy the block. Possible step sounds are wood, gravel, grass, stone, metal, cloth, glass. (Default is stone)
hardness          - How long it takes to harvest the block. (ex: obsidian is 10, dirt is 0.5; Default is 1)
resistance        - Resistance against explosions. (ex: obisidian is 2000, stone is 10; Default is 0)
light             - How many light the block emits [0.0 ... 1.0]. (ex: glowstone is 1, torch is 0.9375; Default is 0)
opacity           - how many light goes through the block [0 ... 255]. (ex: 255=no light goes through the block, 0=all light goes through the block; Default is 255)
iddropped         - The block/item, which is dropped from the block. (Default is the same block)
iddropped1        - iddropped1 to iddropped15. iddropped for damage values. (Default is iddropped)
quantitydropped   - How many blocks/items the block drops when destroyed. You can also set a random value, ex:3-6 (Default is 1)
damagedropped     - Which damage value the block drops. (Default is 0)
damagedropped1    - damagedropped1 to damagedropped15. damagedropped for damage values. (Default is the damage the block has)
transparent       - Set to true if your block has transparent textures. (Default is false)
speed             - How fast you walk on the block. (Default is 0.6)
gravity           - If set to true the block has gravity like sand and gravel (Default is false).
collision         - If set to false you can walk through the block (Default is true)
movebypiston      - If set to false the block can't be pushed by a piston.
pressureplatetrigger - Which object can activate the pressureplate. Possible values are all, player, monster, animal, creature, item, noplayer, nomonster, noanimal, nocreature and noitem. You can't use multiple values.
destroyed         - Functions, which are called when the block is destroyed by a player.
destroyed1        - destroyed1 to destroyed15. destroyed for damage values. Same with clicked, added etc.
clicked           - Functions, which are called when you click the block.
neighborchanged   - Functions, which are called when a block next to the block is changing.
added             - Functions, which are called when the block is placed.
activated         - Functions, which are called when the block is powered with redstone.
deactivated       - Functions, which are called when the block changes from powered to unpowered.
rigthclicked      - Functions, which are called when you rightclick the block.

			

To make a recipe, your item a fuel, or part of a smelting recipes, you have to write the code into customRecipes.txt, customFuel.txt and customSmeltingRecipes.txt
		
Example:

name=Wood Generator
id=170
texturefile=WoodGenerator.png
material=iron
stepsound=metal
hardness=2
resistance=5
light=0.5
opacity=255
activated=setblock(0,1,0,17,0)


If you want to have more functions in one event you can devide the functions with an semicolon (;)	
You can find which functions can be used in which even (clicked, added, etc) in Functions.htm in the archiv.

	testfile.func
		Loads a function from a file in customStuffFunctions folder. The file need an extension of .func
		In this file you have one function per line.
	setblock(offsetX,offsetY,offsetZ,id,damage) 
		Set a block with the offset from the block you clicked.
		ex: setblock(0,-1,0,35,14)
			This will set the block below the one, which is rigthclicked/destroyed to red wool.
	setblocks(offsetX,offsetY,offsetZ,offsetX1,offsetY1,offsetZ1,id,damage) 
		Set the block within a cube.
		ex: setblocks(0,0,0,1,1,1,35,14)
			This will set a 2x2 cube to red wool. 	
	harvestblock(offsetX,offsetY,offsetZ)
		Harvests a block. Drop the blocks item and play the destroyed sound.
		ex: harvestblock(0,0,0)
	dropitem(id,quantity,damage)
		Creates items next to the player.
		ex: dropitem(35,4,15)
			This will creates 4 black wool.
	drop(offsetX,offsetY,offsetZ,id,quantity,damage)
		Drops an item at the offset from the block you clicked.
		ex: drop(0,1,0,35,4,15)
			This will creates 4 black wool one block above the one who is clicked.
	explode(offsetX,offsetY,offsetZ,strength)
		Creates a explosion
		ex: explode(0,0,0,4)
			This will create a explosion like a TNT explosion. (Strength: TNT is 4, Creeper is 3)
	settime(time)
		Set the time. 0 and 24000 is start of the day. 12000 is start of the night.
	thunderbolt(offsetX,offsetY,offsetZ)
		Spawn a thunderbolt.
	hoe()
		The hoe function. Makes grass to farmland.
	fillchest(offsetX,offsetY,offsetZ,id,damage)
		Fill the chest (not doublechest). Doesn't replace existing items.
	clearchest(offsetX,offsetY,offsetZ)
		Clear the chest (not doublechest).
	addtochest(offsetX,offsetY,offsetZ,id,quantity,damage)
		Add items to a chest (not doublechest)
	removefromchest(offsetX,offsetY,offsetZ,id,quantity,damage)
		Remove items from a chest (not doublechest)
	wait(milliseconds)
		Wait the given time. 1000 is one second
	spawn(mobtype,count)
		Spawns the given count of mobs.
		ex: spawn(Creeper,5)
			This will spawn 5 creepers. (MobTypes: Creeper, Skeleton, Spider, Zombie, Slime, Ghast, PigZombie, Pig, Sheep, Cow, Chicken, Squid, Wolf, Enderman, Sliverfish)
	killitem()
		Destroyes the item.
	weather(weather,time)
		Set the weather for the given time. 
		ex: weather(rain,60)
			It will rain for 60 seconds. (Possible weathertypes: rain, thundering, none (you have to set the time, too))
	addvelo(x,y,z)
		Add velocity to the mob you hit.
		ex: addvelo(0.0,1.0,0.0)
			This will throw the mob you hit in the air.
	burn()
		Set the mob you hit on fire.
	transform(mobtype)
		Transform the mob you hit into the one you coose. Only Singleplayer
			ex: transform(Creeper)
		MobTypes: Creeper, Skeleton, Spider, Zombie, Slime, Ghast, PigZombie, Pig, Sheep, Cow, Chicken, Squid, Wolf, Enderman, Sliverfish
	dropmobitem(id,quantity,damage)
		Drops an item from the mob you hit.
		    ex: dropmobitem(5,1,0)
	damageitem(count)
		damage the item by the given value
			ex: damageitem(1)
	burnplayer()
		set the player on fire.
	fillair()
		fill your air for underwater
	sethealth(value)
		set the player's health (1 is one halfheart)
	heal(value)
		heal the player by the given value (1 is one halfheart)

		
	if functions:
		Syntax: if functions:then functions:else functions
			ex: getblockid(0,0,0,1):setblock(0,1,0,1):setblock(0,1,0,5)
			Devide if then or else functions with &
			ex: getblockid(0,0,0,1)&getblockid(0,1,0,1):setblock(0,0,0,5)&setblock(0,1,0,5)
		To check if the value is NOT the result you use a "!"
		    ex: getblockid(0,0,0,!1):setblock(0,0,0,5)
				This will only set the block to wooden planks if the checking block is not stone.
			
		getblockid(offsetX,offsetY,offsetZ,id)
			checks if the block has the same id as given.
		getblockdamage(offsetX,offsetY,offsetZ,damage)
			checks if the block has the same damage value as given.
		getblockiddamage(offsetX,offsetY,offsetZ,id,damage)
			checks if the block has the same id and damage value as given.
		getblockheight(offsetX,offsetY,offsetZ,height)
			checks if the block is at the given height.
		getmob(mobtype)
			checks if the mob you hit has the given type. (MobTypes: Creeper, Skeleton, Spider, Zombie, Slime, Ghast, PigZombie, Pig, Sheep, Cow, Chicken, Squid, Wolf, Enderman, Sliverfish)
		getmobhp(health)
			checks if the mob you hit has the given health value.
		getitemdamage(damage)
			checks if the item has the given damage value.
		getweather(weathertype)
			checks if the current weather is the given weather. (WeahterTypes: rain, none)