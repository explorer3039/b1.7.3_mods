// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;

import net.minecraft.client.Minecraft;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

// Referenced classes of package net.minecraft.src:
//            GuiContainer, CraftingInventoryRecipeBookCB, InventoryRecipeBook, FontRenderer, 
//            RenderEngine

public class GuiRecipeBook extends GuiContainer
{

    private static InventoryRecipeBook a;
    private static IInventory inventory;
	private static CraftingInventoryRecipeBookCB container;
	public GuiRecipeBook(IInventory iinventory, ItemStack itemstack)
    {
        super(container = new CraftingInventoryRecipeBookCB(a = new InventoryRecipeBook(itemstack)));
        inv = a;
        inventory = iinventory;
        xSize = 242;
        ySize = 173;
        recipes = inv;
        itemStack = itemstack;
       
    }
	
	public void onGuiClosed()
    {
        super.onGuiClosed();
        mod_UltimateRecipeBook.sendBookDamageToServer(mc.thePlayer, recipes.getIndex(), false);
    }

    protected void drawGuiContainerForegroundLayer()
    {
        fontRenderer.drawString(inv.getInvName(), xSize - 172, 6+3, 0x404040);
    }
    
    public void initGui() {
        int i = width - xSize +66>> 1;
        int j = height - ySize +7>> 1;
        controlList.clear();
        controlList.add(new GuiSmallButton(1, i + 110, j -21, 20, 20, "<"));
        controlList.add(new GuiSmallButton(2, i + 130, j -21, 20, 20, ">"));
        controlList.add(new GuiSmallButton(3, i + 150, j -21, 20, 20, "..."));
        super.initGui();
    }
    
    protected void actionPerformed(GuiButton guibutton)
    {
    	if(guibutton.id == 1)
        {
    		
    		recipes.decIndex();
        } else
        if(guibutton.id == 2)
        {
        	recipes.incIndex();
        }
        if(guibutton.id == 3)
        {
        	itemStack.setItemDamage(0);
        	
        	ModLoader.OpenGUI(mc.thePlayer, new GuiRecipesCraft(inventory, itemStack));
        	mod_UltimateRecipeBook.sendBookDamageToServer(mc.thePlayer, 0, true);
        	//ItemBookCraft.openCrafter(mc.thePlayer, inventory, itemStack);
        	//ModLoader.OpenGUI(mc.thePlayer, new GuiRecipesCraft(inventory, itemStack));
        }
    }

    public void handleMouseInput()
    {
        int i = Mouse.getEventDWheel();
        if(i > 0)
        {
            recipes.incIndex();
        }
        if(i < 0)
        {
            recipes.decIndex();
        }
        super.handleMouseInput();
    }

    protected void mouseClicked(int i, int j, int k)
    {
    	Boolean buttonClicked = false;
        if(k == 0)
        {
            for(int l = 0; l < controlList.size(); l++)
            {
                GuiButton guibutton = (GuiButton)controlList.get(l);
                if(guibutton.mousePressed(mc, i, j))
                {
                    mc.sndManager.playSoundFX("random.click", 1.0F, 1.0F);
                    actionPerformed(guibutton);
                    buttonClicked = true;
                }
            }

        }
        if(!buttonClicked) {
        	if(Mouse.isButtonDown(0))
            {
                recipes.incIndex();
            } else
            if(Mouse.isButtonDown(1))
            {
                recipes.decIndex();
            }
        }
    }
   

    protected void drawGuiContainerBackgroundLayer(float f)
    {
    	drawDefaultBackground();
        int i = mc.renderEngine.getTexture("/gui/crafting.png");
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        mc.renderEngine.bindTexture(i);
        int j = width - xSize >> 1;
        int k = height - ySize >> 1;
        int l = (xSize - 8) / 2;
        for(int i1 = 0; i1 < 2; i1++)
        {
            drawTexturedModalRect(j + 4 + i1 * l, k+3, 4, 0, l, 4);
            drawTexturedModalRect(j + 4 + i1 * l, (k + ySize) - 4+3, 4, 162, l, 4);
        }

        int j1 = (ySize - 8) / 3;
        for(int k1 = 0; k1 < 3; k1++)
        {
            drawTexturedModalRect(j, k + 4 + k1 * j1+3, 0, 4, 4, j1);
            drawTexturedModalRect((j + xSize) - 4, k + 4 + k1 * j1+3, 172, 4, 4, j1);
        }

        drawTexturedModalRect(j, k+3, 0, 0, 4, 4);
        drawTexturedModalRect(j + 238, k+3, 172, 0, 4, 4);
        drawTexturedModalRect(j, (k + ySize) - 4+3, 0, 162, 4, 4);
        
        drawTexturedModalRect((j + xSize) - 4, (k + ySize) - 4+3, 172, 162, 4, 4);
        for(int l1 = 0; l1 < 2; l1++)
        {
            for(int i2 = 0; i2 < 3; i2++)
            {
                drawTexturedModalRect(j + 4 + l1 * 117, k + 4 + i2 * 55+3, 29, 15, 117, 55);
            }

        }

    }

    public boolean doesGuiPauseGame()
    {
        return false;
    }

    protected void keyTyped(char c, int i)
    {
        //super.keyTyped(c, i);
    	if (i ==mc.gameSettings.keyBindInventory.keyCode) {
    		
    		mc.thePlayer.closeScreen();
    	}
        switch(i)
        {
        case 1:
        	mc.thePlayer.closeScreen();
        	break;
        
        case 205: 
            recipes.incIndex();
            break;

        case 203: 
            recipes.decIndex();
            break;
        }
    }

    private ItemStack itemStack;
    private InventoryRecipeBook recipes;
    public static final int BORDER = 4;
    public static final int ROWS = 3;
    public static final int COLUMNS = 2;
    public static final int ENTRIES = 6;
    public static final int GRIDX = 5;
    public static final int GRIDY = 6;
    public static final int CRAFTX = 99;
    public static final int CRAFTY = 24;
    public static final int IMGWIDTH = 176;
    public static final int IMGHEIGHT = 166;
    public static final int IMGMIDX = 29;
    public static final int IMGMIDY = 15;
    public static final int MIDWIDTH = 117;
    public static final int MIDHEIGHT = 55;
    private final InventoryRecipeBook inv;
}
