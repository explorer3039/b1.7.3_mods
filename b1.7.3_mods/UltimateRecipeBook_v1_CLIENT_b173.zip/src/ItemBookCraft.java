// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;


// Referenced classes of package net.minecraft.src:
//            Item, ModLoader, GuiRecipesCraft, EntityPlayer, 
//            ItemStack, World

public class ItemBookCraft extends Item
{

    protected ItemBookCraft(int i)
    {
        super(i);
        setItemName(getClass().getName());
        setIconCoord(11, 3);
        maxStackSize = 1;
        ModLoader.AddName(this, "Recipe Book");
    }

    public int getColorFromDamage(int i)
    {
    	if (i == 0) {
    		return 0xffa0a0;
    	}
    	return 0x4182F0;
    }

    public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer entityplayer)
    {
    	if (itemstack.getItemDamage() == 0) {
        ModLoader.OpenGUI(entityplayer, new GuiRecipesCraft(entityplayer.inventory, itemstack));
    	}
    	else {
    		ModLoader.OpenGUI(entityplayer, new GuiRecipeBook(entityplayer.inventory, itemstack));
    	}
    		
        return itemstack;
    }

	public static void openCrafter(EntityPlayerSP thePlayer, IInventory inventory, ItemStack itemStack) {
		itemStack.setItemDamage(0);
		ModLoader.OpenGUI(thePlayer, new GuiRecipesCraft(inventory, itemStack));
		
	}
	
	public static void openRecipe(EntityPlayerSP thePlayer, IInventory inventory, ItemStack itemStack) {
		itemStack.setItemDamage(1);
		ModLoader.OpenGUI(thePlayer, new GuiRecipeBook(inventory, itemStack));
		
	}
}
