// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;

import java.util.List;
import java.util.logging.Logger;

// Referenced classes of package net.minecraft.src:
//            IInventory, CraftingManager, ModLoader, ItemStack, 
//            IRecipe, ShapedRecipes, ShapelessRecipes, EntityPlayer

public class InventoryRecipeBook
    implements IInventory
{

    public InventoryRecipeBook(ItemStack itemstack)
    {
        index = -1;
        items = new ItemStack[6][];
        if(recipes == null)
        {
            try
            {
                recipes = (List)ModLoader.getPrivateValue(net.minecraft.src.CraftingManager.class, CraftingManager.getInstance(), 1);
            }
            catch(Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
        book = itemstack;
        index = setIndex(book.getItemDamage()) + 1;
    }

    public void decIndex()
    {
        index = setIndex(index - 6);
    }

    public void incIndex()
    {
        index = setIndex(index + 6);
    }
    
    public int getIndex() {
    	return index - 1;
    }

    public int setIndex(int i)
    {
        if(index == i)
        {
            return i;
        }
        if(i < 0)
        {
            i = recipes.size() - 1;
        } else
        if(i >= recipes.size())
        {
            i = 0;
        }
        items = new ItemStack[6][];
        for(int j = 0; j < 6; j++)
        {
            items[j] = new ItemStack[10];
            int k = i + j;
            if(k < recipes.size())
            {
                IRecipe irecipe = (IRecipe)recipes.get(k);
                try
                {
                    if(irecipe instanceof ShapedRecipes)
                    {
                        int l = ((Integer)ModLoader.getPrivateValue(net.minecraft.src.ShapedRecipes.class, (ShapedRecipes)irecipe, 0)).intValue();
                        int i1 = ((Integer)ModLoader.getPrivateValue(net.minecraft.src.ShapedRecipes.class, (ShapedRecipes)irecipe, 1)).intValue();
                        if(l * i1 > 9)
                        {
                            return setIndex(i + 1);
                        }
                        ItemStack aitemstack[] = (ItemStack[])ModLoader.getPrivateValue(net.minecraft.src.ShapedRecipes.class, (ShapedRecipes)irecipe, 2);
                        items[j][0] = (ItemStack)ModLoader.getPrivateValue(net.minecraft.src.ShapedRecipes.class, (ShapedRecipes)irecipe, 3);
                        for(int k1 = 0; k1 < aitemstack.length; k1++)
                        {
                            int l1 = k1 % l;
                            int i2 = k1 / l;
                            items[j][l1 + i2 * 3 + 1] = aitemstack[k1];
                        }

                    } else
                    if(irecipe instanceof ShapelessRecipes)
                    {
                        List list = (List)ModLoader.getPrivateValue(net.minecraft.src.ShapelessRecipes.class, (ShapelessRecipes)irecipe, 1);
                        if(list.size() > 9)
                        {
                            return setIndex(i + 1);
                        }
                        items[j][0] = (ItemStack)ModLoader.getPrivateValue(net.minecraft.src.ShapelessRecipes.class, (ShapelessRecipes)irecipe, 0);
                        for(int j1 = 0; j1 < list.size(); j1++)
                        {
                            items[j][j1 + 1] = (ItemStack)list.get(j1);
                        }

                    }
                }
                catch(Throwable throwable)
                {
                    ModLoader.getLogger().throwing("RecipeInventory", "setIndex", throwable);
                    ModLoader.ThrowException("Exception in RecipeInventory", throwable);
                }
            }
        }

        
        book.setItemDamage(i+1);
        
        return i;
    }

    public int getSizeInventory()
    {
        return 60;
    }

    public ItemStack decrStackSize(int i, int j)
    {
        return null;
    }

    public void setInventorySlotContents(int i, ItemStack itemstack)
    {
        items[i / 10][i % 10] = itemstack;
    }

    public boolean canInteractWith(EntityPlayer entityplayer)
    {
        return true;
    }

    public String getInvName()
    {
        return String.format("%d / %d", new Object[] {
            Integer.valueOf(index / 6) + 1, Integer.valueOf((recipes.size() - 1) / 6) + 1
        });
    }

    public ItemStack getStackInSlot(int i)
    {
        return items[i / 10][i % 10];
    }

    public int getInventoryStackLimit()
    {
        return 64;
    }

    public void onInventoryChanged()
    {
    }

    private static List recipes = null;
    private final ItemStack book;
    private int index;
    public ItemStack items[][];

}
