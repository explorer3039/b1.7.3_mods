package net.minecraft.src;

public class mod_UltimateRecipeBookPacket extends BaseModMp {

	@Override
	public String Version() {
		return "v1";
	}
	
	public void sendBookDamageToServer(EntityPlayer entityPlayer, int newDamageValue, Boolean newCraftGui) {
    	int[] dataInt = new int[2];
    	dataInt[0] = newDamageValue;
    	if (newCraftGui) 
    		dataInt[1] = 1;
    	else dataInt[1] = 0;
    	Packet230ModLoader packet = new Packet230ModLoader();
    	packet.dataInt = dataInt;
    	ModLoaderMp.SendPacket(this, packet);
    }

}
