// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;

import java.util.List;
import net.minecraft.client.Minecraft;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

// Referenced classes of package net.minecraft.src:
//            GuiContainer, GuiSrvRecipesCraft, mod_CraftingBook, InventoryRecipesCraft, 
//            Container, FontRenderer, RenderEngine, GuiSmallButton, 
//            GuiButton, IInventory

public class GuiRecipesCraft extends GuiContainer
{
	 private static IInventory inventory;
    public GuiRecipesCraft(IInventory iinventory, ItemStack inv)
    {
    	
        super(container = new GuiSrvRecipesCraft(iinventory));
        inv.setItemDamage(0);
        mod_UltimateRecipeBook.recCraft.getRecipes();
        height = 166;
        allowUserInput = false;
        book = inv;
        inventory = iinventory;
        
    }

    public void onGuiClosed()
    {
        super.onGuiClosed();
        inventorySlots.onCraftGuiClosed(mc.thePlayer);
        //mod_UltimateRecipeBook.sendBookDamageToServer(mc.thePlayer, 0, false);
    }

    protected void drawGuiContainerForegroundLayer()
    {
        int i = mod_UltimateRecipeBook.recCraft.getRecipeNum();
        
        fontRenderer.drawString((new StringBuilder(String.valueOf(mod_UltimateRecipeBook.recCraft.getRecipeIndex())).append(" / ").append(String.valueOf(i))).toString(), 37, 6, 0x404040);
      
        }
    
    public boolean doesGuiPauseGame()
    {
        return false;
    }

    protected void drawGuiContainerBackgroundLayer(float f)
    {
        drawDefaultBackground();
        int i = width - xSize >> 1;
        int j = height - ySize >> 1;
        int x = mc.renderEngine.getTexture("/Shockah/CraftingBook/guiRecipeCraft.png");
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        mc.renderEngine.bindTexture(x);
        drawTexturedModalRect(i, j, 0, 0, xSize, ySize);
    }

    

    public void initGui()
    {
        int i = width - xSize >> 1;
        int j = height - ySize >> 1;
        controlList.clear();
        controlList.add(new GuiSmallButton(1, i + 110, j -21, 20, 20, "<"));
        controlList.add(new GuiSmallButton(2, i + 130, j -21, 20, 20, ">"));
        controlList.add(new GuiSmallButton(3, i + 150, j -21, 20, 20, "..."));
        super.initGui();
    }
    
    public void handleMouseInput()
    {
        int i = Mouse.getEventDWheel();
        if(i > 0)
        {
        	mod_UltimateRecipeBook.recCraft.recipeNext();
        }
        if(i < 0)
        {
        	mod_UltimateRecipeBook.recCraft.recipePrev();
        }
        super.handleMouseInput();
    }
    
    protected void keyTyped(char c, int i)
    {
        //super.keyTyped(c, i);
    	if (i ==mc.gameSettings.keyBindInventory.keyCode) {
    		mc.thePlayer.closeScreen();
    	}
        switch(i)
        {
        case 1:
        	mc.thePlayer.closeScreen();
        	break;
        
        case 205: 
        	mod_UltimateRecipeBook.recCraft.recipeNext();
            break;

        case 203: 
        	mod_UltimateRecipeBook.recCraft.recipePrev();
            break;
        }
    }
    
    public void onCraftGuiClosed(EntityPlayer entityplayer)
    {
    	
    	//mod_UltimateRecipeBook.sendBookDamageToServer(entityplayer, entityplayer.inventory.getCurrentItem().getItemDamage(), false);
       
    }
    
    

    protected void actionPerformed(GuiButton guibutton)
    {
        if(guibutton.id == 1)
        {
        	mod_UltimateRecipeBook.recCraft.recipePrev();
        } else
        if(guibutton.id == 2)
        {
        	mod_UltimateRecipeBook.recCraft.recipeNext();
        }
        if(guibutton.id == 3)
        {
        	//ItemBookCraft.openRecipe(mc.thePlayer, inventory, book);
        	//ModLoader.OpenGUI(mc.thePlayer, new GuiRecipeBook(inventory, book));
        	book.setItemDamage(1);
        	
                int i = Mouse.getEventX();
                int k = Mouse.getEventY();
                mc.thePlayer.closeScreen();
                
        
        	ModLoader.OpenGUI(mc.thePlayer, new GuiRecipeBook(inventory, book));
        	Mouse.setCursorPosition(i , k);
        	mod_UltimateRecipeBook.sendBookDamageToServer(mc.thePlayer, 1, false);
        }
        super.actionPerformed(guibutton);
    }
    
    protected void mouseClicked(int i, int j, int k)
    {
    	Boolean buttonClicked = false;
    	if(k == 0 || k == 1)
        {
    		if(k == 0) {
            for(int l = 0; l < controlList.size(); l++)
            {
                GuiButton guibutton = (GuiButton)controlList.get(l);
                if(guibutton.mousePressed(mc, i, j))
                {
                    mc.sndManager.playSoundFX("random.click", 1.0F, 1.0F);
                    actionPerformed(guibutton);
                    buttonClicked = true;
                }
            }
    		}
            if(!buttonClicked) {
                
            Slot slot = getSlotAtPosition(i, j);
   
            	if(slot != null)
            	{
            	
            		if (slot.getHasStack() && slot.getStack().isItemEqual(book)) {
            			
            		}
            		else super.mouseClicked(i, j, k);
            	
            	}
            
            }
        }
    	
    	
    }
    
    private Slot getSlotAtPosition(int i, int j)
    {
        for(int k = 0; k < inventorySlots.slots.size(); k++)
        {
            Slot slot = (Slot)inventorySlots.slots.get(k);
            if(getIsMouseOverSlot(slot, i, j))
            {
            	slot.getBackgroundIconIndex();
                return slot;
            }
        }

        return null;
    }
    private boolean getIsMouseOverSlot(Slot slot, int i, int j)
    {
        int k = (width - xSize) / 2;
        int l = (height - ySize) / 2;
        i -= k;
        j -= l;
        return i >= slot.xDisplayPosition - 1 && i < slot.xDisplayPosition + 16 + 1 && j >= slot.yDisplayPosition - 1 && j < slot.yDisplayPosition + 16 + 1;
    }
    private static GuiSrvRecipesCraft container;
    private final ItemStack book;
}
