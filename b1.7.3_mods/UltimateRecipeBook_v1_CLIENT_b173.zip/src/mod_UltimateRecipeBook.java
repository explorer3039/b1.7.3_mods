// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;


// Referenced classes of package net.minecraft.src:
//            BaseMod, ItemRecipeBook, Item, ModLoader, 
//            ItemStack

public class mod_UltimateRecipeBook extends BaseModMp
{

    public mod_UltimateRecipeBook()
    {
        book = (new ItemBookCraft(RecipeBookID - 256)).setIconIndex(Item.book.iconIndex).setItemName("recipeBook");
        ModLoader.AddName(book, "Recipe Book");
        ModLoader.AddShapelessRecipe(new ItemStack(book, 1, 0), new Object[] {
        	Block.workbench, Item.book, new ItemStack(Item.dyePowder, 1, 0)
        });
        ModLoader.AddShapelessRecipe(new ItemStack(book, 1, 1), new Object[] {
        		new ItemStack(book, 1, 0)
        });
       
        	ModLoader.AddShapelessRecipe(new ItemStack(book, 1, 0), new Object[] {
            		new ItemStack(book, 1, -1)
        	});
        	ModLoaderMp.RegisterGUI(this, 15);
        	ModLoaderMp.RegisterGUI(this, 16);
        //}
        //ModLoader.AddShapelessRecipe(new ItemStack(book, 1, 0), new Object[] {
        //		new ItemStack(book, 1)
        //        //Block.workbench, Item.book, new ItemStack(Item.dyePowder, 1, 0)
        //});
    }
    
    public GuiScreen HandleGUI(int inventoryType)
	{
		if(inventoryType == 15)
			return new GuiRecipesCraft(ModLoader.getMinecraftInstance().thePlayer.inventory, ModLoader.getMinecraftInstance().thePlayer.inventory.getCurrentItem());
		else  if(inventoryType == 16)
			return new GuiRecipeBook(ModLoader.getMinecraftInstance().thePlayer.inventory, ModLoader.getMinecraftInstance().thePlayer.inventory.getCurrentItem());
		
		else return null;
	}

    public String Version()
    {
        return "v1";
    }
    
    public static void sendBookDamageToServer(EntityPlayer entityPlayer, int newDamageValue, Boolean newCraftGui) {
    	mod_UltimateRecipeBookPacket x = new mod_UltimateRecipeBookPacket();
    	x.sendBookDamageToServer(entityPlayer, newDamageValue, newCraftGui);
    	
    	/*System.out.println("PING");
    	int[] dataInt = new int[1];
    	dataInt[0] = newDamageValue;
    	Packet230ModLoader packet = new Packet230ModLoader();
    	packet.dataInt = dataInt;
    	ModLoaderMp.SendPacket(this, packet);*/
    }

    public static Item book;
    public static int RecipeBookID = 397;
    public static InventoryRecipesCraft recCraft = new InventoryRecipesCraft();

}
