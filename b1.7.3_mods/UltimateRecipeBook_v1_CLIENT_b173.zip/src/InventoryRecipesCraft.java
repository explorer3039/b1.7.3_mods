// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;

import java.util.*;

// Referenced classes of package net.minecraft.src:
//            IInventory, ItemStack, IRecipe, ShapedRecipes, 
//            ModLoader, ShapelessRecipes, CraftingManager, EntityPlayer

public class InventoryRecipesCraft
    implements IInventory
{

    public InventoryRecipesCraft()
    {
        currentRecipes = new ArrayList();
        items = new ItemStack[11];
        index = 0;
    }

    public String getInvName()
    {
        return "Craftables";
    }

    public int getSizeInventory()
    {
        return items.length;
    }

    public int getInventoryStackLimit()
    {
        return 64;
    }

    public void setInventorySlotContents(int i, ItemStack itemstack)
    {
        items[i] = itemstack;
        if(itemstack != null && itemstack.stackSize > getInventoryStackLimit())
        {
            itemstack.stackSize = getInventoryStackLimit();
        }
        onInventoryChanged();
    }

    public ItemStack getStackInSlot(int i)
    {
        return items[i];
    }

    public ItemStack decrStackSize(int i, int j)
    {
        if(items[i] != null)
        {
            if(items[i].stackSize <= j)
            {
                ItemStack itemstack = items[i];
                items[i] = null;
                onInventoryChanged();
                return itemstack;
            }
            ItemStack itemstack1 = items[i].splitStack(j);
            if(items[i].stackSize == 0)
            {
                items[i] = null;
            }
            onInventoryChanged();
            return itemstack1;
        } else
        {
            return null;
        }
    }

    public boolean canInteractWith(EntityPlayer entityplayer)
    {
        return true;
    }

    public void onInventoryChanged()
    {
    }

    public void clearItems()
    {
        for(int i = 0; i < getSizeInventory(); i++)
        {
            items[i] = null;
        }

        currentRecipes.clear();
    }

    public void updateItems()
    {
        currentRecipes = getMatchingRecipes(items[10]);
        setRecipe(0);
    }

    public void recipeNext()
    {
        if(getRecipeNum() == 0)
        {
            index = 0;
            return;
        }
        index++;
        if(index > currentRecipes.size() - 1)
        {
            index = 0;
        }
        setRecipe(index);
    }

    public void recipePrev()
    {
        if(getRecipeNum() == 0)
        {
            index = 0;
            return;
        }
        index--;
        if(index < 0)
        {
            index = currentRecipes.size() - 1;
        }
        setRecipe(index);
    }

    public void setRecipe(int i)
    {
        index = i;
        for(int j = 0; j < 10; j++)
        {
            items[j] = null;
        }

        if(currentRecipes.isEmpty())
        {
            return;
        }
        IRecipe irecipe = (IRecipe)currentRecipes.get(i);
        items[0] = new ItemStack(irecipe.getRecipeOutput().itemID, irecipe.getRecipeOutput().stackSize, irecipe.getRecipeOutput().getItemDamage());
        if(irecipe instanceof ShapedRecipes)
        {
            ShapedRecipes shapedrecipes = (ShapedRecipes)irecipe;
            try
            {
                int k = 0;
                int l = 0;
                int j1 = ((Integer)ModLoader.getPrivateValue(net.minecraft.src.ShapedRecipes.class, shapedrecipes, "b")).intValue();
                ItemStack aitemstack[] = (ItemStack[])ModLoader.getPrivateValue(net.minecraft.src.ShapedRecipes.class, shapedrecipes, "d");
                for(int k1 = 0; k1 < shapedrecipes.getRecipeSize(); k1++)
                {
                    ItemStack itemstack1 = aitemstack[k1];
                    if(itemstack1 != null)
                    {
                        items[1 + (l * 3 + k)] = new ItemStack(itemstack1.itemID, 1, itemstack1.getItemDamage());
                    }
                    if(++k >= j1)
                    {
                        k = 0;
                        l++;
                    }
                }

            }
            catch(Exception exception1)
            {
            	try
                {
                    int k = 0;
                    int l = 0;
                    int j1 = ((Integer)ModLoader.getPrivateValue(net.minecraft.src.ShapedRecipes.class, shapedrecipes, "recipeWidth")).intValue();
                    ItemStack aitemstack[] = (ItemStack[])ModLoader.getPrivateValue(net.minecraft.src.ShapedRecipes.class, shapedrecipes, "recipeItems");
                    for(int k1 = 0; k1 < shapedrecipes.getRecipeSize(); k1++)
                    {
                        ItemStack itemstack1 = aitemstack[k1];
                        if(itemstack1 != null)
                        {
                            items[1 + (l * 3 + k)] = new ItemStack(itemstack1.itemID, 1, itemstack1.getItemDamage());
                        }
                        if(++k >= j1)
                        {
                            k = 0;
                            l++;
                        }
                    }

                }
                catch(Exception exception2)
                {
                	exception1.printStackTrace();
                    exception2.printStackTrace();
                }
            }
        } else
        if(irecipe instanceof ShapelessRecipes)
        {
            ShapelessRecipes shapelessrecipes = (ShapelessRecipes)irecipe;
            try
            {
                List list = (List)ModLoader.getPrivateValue(net.minecraft.src.ShapelessRecipes.class, shapelessrecipes, "b");
                for(int i1 = 0; i1 < list.size(); i1++)
                {
                    ItemStack itemstack = (ItemStack)list.get(i1);
                    items[i1 + 1] = new ItemStack(itemstack.itemID, 1, itemstack.getItemDamage());
                }

            }
            catch(Exception exception1)
            {
            	try
                {
                    List list = (List)ModLoader.getPrivateValue(net.minecraft.src.ShapelessRecipes.class, shapelessrecipes, "recipeItems");
                    for(int i1 = 0; i1 < list.size(); i1++)
                    {
                        ItemStack itemstack = (ItemStack)list.get(i1);
                        items[i1 + 1] = new ItemStack(itemstack.itemID, 1, itemstack.getItemDamage());
                    }

                }
                catch(Exception exception2)
                {
                	exception1.printStackTrace();
                    exception2.printStackTrace();
                }
            }
        }
    }

    public void getRecipes()
    {
        if(recipes == null)
        {
            try
            {
                recipes = (List)ModLoader.getPrivateValue(net.minecraft.src.CraftingManager.class, CraftingManager.getInstance(), "b");
            }
            catch(Exception exception1)
            {
                //exception.printStackTrace();
                try
                {
                    recipes = (List)ModLoader.getPrivateValue(net.minecraft.src.CraftingManager.class, CraftingManager.getInstance(), "recipes");
                }
                catch(Exception exception2)
                {
                	exception1.printStackTrace();
                    exception2.printStackTrace();
                }
            }
        }
    }

    public int getRecipeNum()
    {
        if(currentRecipes == null)
        {
            return 0;
        } else
        {
            return currentRecipes.size();
        }
    }
    
    public int getRecipeIndex()
    {
    	if(currentRecipes.size() == 0) {
    		return 0;
    	}
    	else {
    		 return index+1;
    	}
           
        
    }

    public ArrayList getMatchingRecipes(ItemStack itemstack)
    {
        ArrayList arraylist = new ArrayList();
        if(itemstack == null)
        {
            return arraylist;
        }
        for(Iterator iterator = recipes.iterator();
        		iterator.hasNext();)
        {
            IRecipe irecipe = (IRecipe)iterator.next();
           //if(itemstack.itemID == irecipe.getRecipeOutput().itemID && (irecipe.getRecipeOutput().getItemDamage() == itemstack.getItemDamage() || irecipe.getRecipeOutput().getItemDamage() < 0))
            if(itemstack.itemID == irecipe.getRecipeOutput().itemID || irecipe.getRecipeOutput().getItemDamage() < 0)
            {
                arraylist.add(irecipe);
            } else
            if(irecipe instanceof ShapedRecipes)
            {
                ShapedRecipes shapedrecipes = (ShapedRecipes)irecipe;
                try
                {
                    ItemStack aitemstack[] = (ItemStack[])ModLoader.getPrivateValue(net.minecraft.src.ShapedRecipes.class, shapedrecipes, "d");
                    ItemStack aitemstack1[];
                    int j = (aitemstack1 = aitemstack).length;
                    for(int i = 0; i < j; i++)
                    {
                        ItemStack itemstack1 = aitemstack1[i];
                        if(itemstack1 == null || itemstack.itemID != itemstack1.itemID || itemstack1.getItemDamage() != itemstack.getItemDamage() && itemstack1.getItemDamage() >= 0)
                        {
                            continue;
                        }
                        arraylist.add(irecipe);
                        break;
                    }

                }
                catch(Exception exception1)
                {
                	try
                    {
                        ItemStack aitemstack[] = (ItemStack[])ModLoader.getPrivateValue(net.minecraft.src.ShapedRecipes.class, shapedrecipes, "recipeItems");
                        ItemStack aitemstack1[];
                        int j = (aitemstack1 = aitemstack).length;
                        for(int i = 0; i < j; i++)
                        {
                            ItemStack itemstack1 = aitemstack1[i];
                            if(itemstack1 == null || itemstack.itemID != itemstack1.itemID || itemstack1.getItemDamage() != itemstack.getItemDamage() && itemstack1.getItemDamage() >= 0)
                            {
                                continue;
                            }
                            arraylist.add(irecipe);
                            break;
                        }

                    }
                    catch(Exception exception2)
                    {
                        exception1.printStackTrace();
                        exception2.printStackTrace();
                    }
                }
            } else
            if(irecipe instanceof ShapelessRecipes)
            {
                ShapelessRecipes shapelessrecipes = (ShapelessRecipes)irecipe;
                try
                {
                    List list = (List)ModLoader.getPrivateValue(net.minecraft.src.ShapelessRecipes.class, shapelessrecipes, "b");
                    for(Iterator iterator1 = list.iterator(); iterator1.hasNext();)
                    {
                        Object obj = iterator1.next();
                        ItemStack itemstack2 = (ItemStack)obj;
                        if(itemstack.itemID == itemstack2.itemID && (itemstack2.getItemDamage() == itemstack.getItemDamage() || itemstack2.getItemDamage() < 0))
                        {
                            arraylist.add(irecipe);
                            break;
                        }
                    }

                }
                catch(Exception exception1)
                {
                	try
                    {
                        List list = (List)ModLoader.getPrivateValue(net.minecraft.src.ShapelessRecipes.class, shapelessrecipes, "recipeItems");
                        for(Iterator iterator1 = list.iterator(); iterator1.hasNext();)
                        {
                            Object obj = iterator1.next();
                            ItemStack itemstack2 = (ItemStack)obj;
                            if(itemstack.itemID == itemstack2.itemID && (itemstack2.getItemDamage() == itemstack.getItemDamage() || itemstack2.getItemDamage() < 0))
                            {
                                arraylist.add(irecipe);
                                break;
                            }
                        }

                    }
                    catch(Exception exception2)
                    {
                        exception1.printStackTrace();
                        exception2.printStackTrace();
                    }
                }
            }
        }
      

        return arraylist;
    }

    private static List recipes = null;
    private ArrayList currentRecipes;
    private ItemStack items[];
    private int index;

}
