===INSTALLATION===

Step 1: Copy Beta 1.7.3 jar into your (minecraftdir)/versions/b1.7.3_anvil folder and rename it b1.7.3_anvil.jar
Step 2: Copy files in "files" into b1.7.3_anvil.jar using 7-Zip, WinRar or your preferred program and delete META-INF
Step 3: Copy b1.7.3_anvil.json into the (minecraftdir)/versions/b1.7.3_anvil folder
Step 4: Start b1.7.3_anvil in launcher
