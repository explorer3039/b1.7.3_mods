K1K Good Old Days Mod V0.1
(Compatible with Minecrat Version 1.7.3)

[*** COPYRIGHT NOTICE ***]
 This document is Copyright �(2011) and is the intellectual property of the author. It may be not be reproduced under any circumstances except for personal, private use as long as it remains in its unaltered, unedited form. It may not be placed on any web site or otherwise distributed publicly without advance written permission. Use of this mod on any other website is strictly prohibited, and a violation of copyright.

****** Installation Instructions ******

1) Make sure minecraft is not running.
2) Install Risugami's ModLoader
3) Open your minecraft.jar with Winrar or other program
4) Delete the META-INF folder in minecraft.jar (you should have already done this when you installed ModLoader)
5) Copy the files in the In the "Good Old Days" into your jar
6) Enjoy
