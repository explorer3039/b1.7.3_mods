Original mod created by Ethereal in beta 1.2
[V1.7.3] Elevator (v1.6)

Install Instructions:

Copy the class files into your minecraft.jar then copy the elevatorOptions.txt file into your .minecraft folder where you will be able to change the block ID if you choose, by default I have set the block ID to 254 for the elevator and 255 is for the top half of which you should never have in your inventory. If you forget to place the elevatorOptions.txt file into your .minecraft folder one will be created for you when you run the game for the first time.

enjoy