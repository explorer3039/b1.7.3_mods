// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 


public class mod_ArmorRepair extends BaseMod
{

    public String Version()
    {
        return "BETA v1.7.2";
    }

    protected mod_ArmorRepair()
    {
        __helmetLeather = new iz(gm.T, 1, -1);
        __plateLeather = new iz(gm.U, 1, -1);
        __legsLeather = new iz(gm.V, 1, -1);
        __bootsLeather = new iz(gm.W, 1, -1);
        __helmetSteel = new iz(gm.ab, 1, -1);
        __plateSteel = new iz(gm.ac, 1, -1);
        __legsSteel = new iz(gm.ad, 1, -1);
        __bootsSteel = new iz(gm.ae, 1, -1);
        __helmetGold = new iz(gm.aj, 1, -1);
        __plateGold = new iz(gm.ak, 1, -1);
        __legsGold = new iz(gm.al, 1, -1);
        __bootsGold = new iz(gm.am, 1, -1);
        __helmetDiamond = new iz(gm.af, 1, -1);
        __plateDiamond = new iz(gm.ag, 1, -1);
        __legsDiamond = new iz(gm.ah, 1, -1);
        __bootsDiamond = new iz(gm.ai, 1, -1);
        __diamond = gm.l;
        __gold = gm.n;
        __iron = gm.m;
        __leather = gm.aD;
        ModLoader.AddRecipe(new iz(gm.T, 1), new Object[] {
            "OAO", Character.valueOf('O'), __leather, Character.valueOf('A'), __helmetLeather
        });
        ModLoader.AddRecipe(new iz(gm.T, 1), new Object[] {
            "A A", Character.valueOf('O'), __leather, Character.valueOf('A'), __helmetLeather
        });
        ModLoader.AddRecipe(new iz(gm.U, 1), new Object[] {
            "OAO", Character.valueOf('O'), __leather, Character.valueOf('A'), __plateLeather
        });
        ModLoader.AddRecipe(new iz(gm.U, 1), new Object[] {
            "A A", Character.valueOf('O'), __leather, Character.valueOf('A'), __plateLeather
        });
        ModLoader.AddRecipe(new iz(gm.V, 1), new Object[] {
            "OAO", Character.valueOf('O'), __leather, Character.valueOf('A'), __legsLeather
        });
        ModLoader.AddRecipe(new iz(gm.V, 1), new Object[] {
            "A A", Character.valueOf('O'), __leather, Character.valueOf('A'), __legsLeather
        });
        ModLoader.AddRecipe(new iz(gm.W, 1), new Object[] {
            "OAO", Character.valueOf('O'), __leather, Character.valueOf('A'), __bootsLeather
        });
        ModLoader.AddRecipe(new iz(gm.W, 1), new Object[] {
            "A A", Character.valueOf('O'), __leather, Character.valueOf('A'), __bootsLeather
        });
        ModLoader.AddRecipe(new iz(gm.ab, 1), new Object[] {
            "OAO", Character.valueOf('O'), __iron, Character.valueOf('A'), __helmetSteel
        });
        ModLoader.AddRecipe(new iz(gm.ab, 1), new Object[] {
            "A A", Character.valueOf('O'), __iron, Character.valueOf('A'), __helmetSteel
        });
        ModLoader.AddRecipe(new iz(gm.ac, 1), new Object[] {
            "OAO", Character.valueOf('O'), __iron, Character.valueOf('A'), __plateSteel
        });
        ModLoader.AddRecipe(new iz(gm.ac, 1), new Object[] {
            "A A", Character.valueOf('O'), __iron, Character.valueOf('A'), __plateSteel
        });
        ModLoader.AddRecipe(new iz(gm.ad, 1), new Object[] {
            "OAO", Character.valueOf('O'), __iron, Character.valueOf('A'), __legsSteel
        });
        ModLoader.AddRecipe(new iz(gm.ad, 1), new Object[] {
            "A A", Character.valueOf('O'), __iron, Character.valueOf('A'), __legsSteel
        });
        ModLoader.AddRecipe(new iz(gm.ae, 1), new Object[] {
            "OAO", Character.valueOf('O'), __iron, Character.valueOf('A'), __bootsSteel
        });
        ModLoader.AddRecipe(new iz(gm.ae, 1), new Object[] {
            "A A", Character.valueOf('O'), __iron, Character.valueOf('A'), __bootsSteel
        });
        ModLoader.AddRecipe(new iz(gm.aj, 1), new Object[] {
            "OAO", Character.valueOf('O'), __gold, Character.valueOf('A'), __helmetGold
        });
        ModLoader.AddRecipe(new iz(gm.aj, 1), new Object[] {
            "A A", Character.valueOf('O'), __gold, Character.valueOf('A'), __helmetGold
        });
        ModLoader.AddRecipe(new iz(gm.ak, 1), new Object[] {
            "OAO", Character.valueOf('O'), __gold, Character.valueOf('A'), __plateGold
        });
        ModLoader.AddRecipe(new iz(gm.ak, 1), new Object[] {
            "A A", Character.valueOf('O'), __gold, Character.valueOf('A'), __plateGold
        });
        ModLoader.AddRecipe(new iz(gm.al, 1), new Object[] {
            "OAO", Character.valueOf('O'), __gold, Character.valueOf('A'), __legsGold
        });
        ModLoader.AddRecipe(new iz(gm.al, 1), new Object[] {
            "A A", Character.valueOf('O'), __gold, Character.valueOf('A'), __legsGold
        });
        ModLoader.AddRecipe(new iz(gm.am, 1), new Object[] {
            "OAO", Character.valueOf('O'), __gold, Character.valueOf('A'), __bootsGold
        });
        ModLoader.AddRecipe(new iz(gm.am, 1), new Object[] {
            "A A", Character.valueOf('O'), __gold, Character.valueOf('A'), __bootsGold
        });
        ModLoader.AddRecipe(new iz(gm.af, 1), new Object[] {
            "OAO", Character.valueOf('O'), __diamond, Character.valueOf('A'), __helmetDiamond
        });
        ModLoader.AddRecipe(new iz(gm.af, 1), new Object[] {
            "A A", Character.valueOf('O'), __diamond, Character.valueOf('A'), __helmetDiamond
        });
        ModLoader.AddRecipe(new iz(gm.ag, 1), new Object[] {
            "OAO", Character.valueOf('O'), __diamond, Character.valueOf('A'), __plateDiamond
        });
        ModLoader.AddRecipe(new iz(gm.ag, 1), new Object[] {
            "A A", Character.valueOf('O'), __diamond, Character.valueOf('A'), __plateDiamond
        });
        ModLoader.AddRecipe(new iz(gm.ah, 1), new Object[] {
            "OAO", Character.valueOf('O'), __diamond, Character.valueOf('A'), __legsDiamond
        });
        ModLoader.AddRecipe(new iz(gm.ah, 1), new Object[] {
            "A A", Character.valueOf('O'), __diamond, Character.valueOf('A'), __legsDiamond
        });
        ModLoader.AddRecipe(new iz(gm.ai, 1), new Object[] {
            "OAO", Character.valueOf('O'), __diamond, Character.valueOf('A'), __bootsDiamond
        });
        ModLoader.AddRecipe(new iz(gm.ai, 1), new Object[] {
            "A A", Character.valueOf('O'), __diamond, Character.valueOf('A'), __bootsDiamond
        });
    }

    iz __helmetLeather;
    iz __plateLeather;
    iz __legsLeather;
    iz __bootsLeather;
    iz __helmetSteel;
    iz __plateSteel;
    iz __legsSteel;
    iz __bootsSteel;
    iz __helmetGold;
    iz __plateGold;
    iz __legsGold;
    iz __bootsGold;
    iz __helmetDiamond;
    iz __plateDiamond;
    iz __legsDiamond;
    iz __bootsDiamond;
	
    gm __diamond;
    gm __gold;
    gm __iron;
    gm __leather;
}
