# Minecraft mods
A collection of mods for old versions of Minecraft.

Some mods by me, some by various authors. Credits to them and Mojang. I don't own Minecraft. I'm not responsible if your world saves become corrupted, blah blah. I won't support you and neither will Mojang. Don't sue me.

You need to purchase Minecraft to use these mods. If you don't have a copy of the game, this repo isn't for you.

## Installation

Take a look at the [wiki](http://github.com/SnowshoeIceboot/mcmods/wiki).
