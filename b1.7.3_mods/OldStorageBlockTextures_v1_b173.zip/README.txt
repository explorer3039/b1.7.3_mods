This is OldStorageBlockTextures v1 for Minecraft Beta 1.7.3 Client

INTRO
This mod changes the textures of iron, gold and diamond blocks to their old ones from the indev versions
You can disable it in .minecraft/config/ModLoader.cfg
If you want to change the textures you can modify the files in minecraft.jar/oldStorageBlocks

INSTALL
1. Install Modloader
2. Insert the files from this .zip into the minecraft.jar
3. Delete META-INF from the minecraft.jar
4. ???
5. Sucess!

CREDIT
Mod creator - me, rek
Idea and inability to use MultiMC - LowMango

COMPATIBILITY
This mod is incompatible with any mod that changes l.class (BlockOreStorage.java)