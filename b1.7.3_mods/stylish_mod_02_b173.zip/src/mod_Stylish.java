package net.minecraft.src;
import java.io.*;
import java.util.*;

public class mod_Stylish extends BaseMod

{

public static final Item styler;

public static final BlockCustom cobblestone;
public static final BlockCustom planks, glass, stairDouble, stairSingle;

public String Version()
        {
                return "1.7.3";
        }

        static
        {
			// <@Risugami> Zaratustra set reference in the block array to null, and create your block, then use setPrivateValue to reassign the field
			System.err.println("Going through this once");

			styler = new ItemStyler(3000);

			((ItemStyler)styler).idsEffectiveAgainst=new int[] {4, 5, 20, 43, 44};

			Block.blocksList[4]=null;
			Block.blocksList[5]=null;
			Block.blocksList[20]=null;
			Block.blocksList[43]=null;
			Block.blocksList[44]=null;
			Item.itemsList[4]=null;
			Item.itemsList[5]=null;
			Item.itemsList[20]=null;
			Item.itemsList[43]=null;
			Item.itemsList[44]=null;

			cobblestone = (BlockCustom)(new BlockCustom(4, 16, Material.rock)).setHardness(2.0F).setResistance(10F).setStepSound(Block.soundStoneFootstep).setBlockName("stonebrick").disableNeighborNotifyOnMetadataChange();
			planks = (BlockCustom)(new BlockCustom(5, 4, Material.wood)).setHardness(2.0F).setResistance(5F).setStepSound(Block.soundWoodFootstep).setBlockName("wood").disableNeighborNotifyOnMetadataChange();
			glass = (BlockCustom)(new BlockCustomGlass(20, 49, Material.glass, false)).setHardness(0.3F).setStepSound(Block.soundGlassFootstep).setBlockName("glass").disableNeighborNotifyOnMetadataChange();
	        stairDouble = (BlockCustom)(new BlockCustomStep(43, 0)).setHardness(2.0F).setResistance(10F).setStepSound(Block.soundStoneFootstep).setBlockName("stoneSlab").disableNeighborNotifyOnMetadataChange();
	        stairSingle = (BlockCustom)(new BlockCustomStep(44, 1)).setHardness(2.0F).setResistance(10F).setStepSound(Block.soundStoneFootstep).setBlockName("stoneSlab").disableNeighborNotifyOnMetadataChange();

		}


		public int getOverride(String file)
		{
			try
			{
				int n=Integer.parseInt( file );
				return n;
			}
			catch (NumberFormatException e )
			{
				return ModLoader.addOverride("/terrain.png", "/stylish/"+file);
			}
		}

		public void setCustomIndexSide(BlockCustom bc, int index, String side, int n)
		{
			bc.setCustomIndexSide(index, n, side);
		}

        public mod_Stylish()
        {


			ModLoader.RegisterBlock(cobblestone, ItemCustom.class);
			ModLoader.RegisterBlock(planks, ItemCustom.class);
			ModLoader.RegisterBlock(glass, ItemCustom.class);
			ModLoader.RegisterBlock(stairDouble, ItemCustom.class);
			ModLoader.RegisterBlock(stairSingle, ItemCustom.class);

			styler.setIconCoord(ModLoader.addOverride("/gui/items.png", "/stylish/styler.png"), 0).setItemName("styler");

			try
			{
				InputStream in = mod_Stylish.class.getResourceAsStream("/stylish/config.txt");
				if (in==null) 			System.err.println("Error: java sucks");
				BufferedReader br = new BufferedReader(new InputStreamReader(in));
				String strLine;
				strLine = br.readLine();
				while ((strLine = br.readLine()) != null)
				{
					String[] arrConfig = strLine.split("\t");
					BlockCustom bc;

					int index = Integer.parseInt(arrConfig[1]);
					String side = arrConfig[2];
					int n = getOverride(arrConfig[3]);

					if (arrConfig[0].equals("cobble")) 		cobblestone.setCustomIndexSide(index, n, side);
					else if (arrConfig[0].equals("planks")) planks.setCustomIndexSide(index, n, side);
					else if (arrConfig[0].equals("glass"))  glass.setCustomIndexSide(index, n, side);
					else if (arrConfig[0].equals("slab"))
					{
						stairDouble.setCustomIndexSide(index, n, side);
						stairSingle.setCustomIndexSide(index, n, side);
					}
					else continue;
					System.err.println("hok");

				}
				in.close();
			}
			catch (Exception e)
			{
			System.err.println("Error: " + e.getMessage());
			}


			ModLoader.AddLocalization("item.styler.name", "Styler");
			ModLoader.AddLocalization("item.styler.0.name", "Styler #0");
			ModLoader.AddLocalization("item.styler.1.name", "Styler #1");
			ModLoader.AddLocalization("item.styler.2.name", "Styler #2");
			ModLoader.AddLocalization("item.styler.3.name", "Styler #3");
			ModLoader.AddLocalization("item.styler.4.name", "Styler #4");
			ModLoader.AddLocalization("item.styler.5.name", "Styler #5");
			ModLoader.AddLocalization("item.styler.6.name", "Styler #6");
			ModLoader.AddLocalization("item.styler.7.name", "Styler #7");
			ModLoader.AddLocalization("item.styler.8.name", "Styler #8");
			ModLoader.AddLocalization("item.styler.9.name", "Styler #9");
			ModLoader.AddLocalization("item.styler.10.name", "Styler #10");
			ModLoader.AddLocalization("item.styler.11.name", "Styler #11");
			ModLoader.AddLocalization("item.styler.12.name", "Styler #12");
			ModLoader.AddLocalization("item.styler.13.name", "Styler #13");
			ModLoader.AddLocalization("item.styler.14.name", "Styler #14");
			ModLoader.AddLocalization("item.styler.15.name", "Styler #15");

        	ModLoader.AddRecipe(new ItemStack(styler, 1, 0 ), new Object[] { "X", "#", Character.valueOf('#'), Block.planks, Character.valueOf('X'), Item.stick });
        	ModLoader.AddRecipe(new ItemStack(styler, 1, 1 ), new Object[] { "X ", " #", Character.valueOf('#'), Block.planks, Character.valueOf('X'), Item.stick });
        	ModLoader.AddRecipe(new ItemStack(styler, 1, 2 ), new Object[] { "X#", Character.valueOf('#'), Block.planks, Character.valueOf('X'), Item.stick });
			ModLoader.AddRecipe(new ItemStack(styler, 1, 3 ), new Object[] { " #", "X ", Character.valueOf('#'), Block.planks, Character.valueOf('X'), Item.stick });
        	ModLoader.AddRecipe(new ItemStack(styler, 1, 4 ), new Object[] { "#", "X", Character.valueOf('#'), Block.planks, Character.valueOf('X'), Item.stick });
        	ModLoader.AddRecipe(new ItemStack(styler, 1, 5 ), new Object[] { "X", " ", "#", Character.valueOf('#'), Block.planks, Character.valueOf('X'), Item.stick });
			ModLoader.AddRecipe(new ItemStack(styler, 1, 6 ), new Object[] { "X ", "  ", " #", Character.valueOf('#'), Block.planks, Character.valueOf('X'), Item.stick });
			ModLoader.AddRecipe(new ItemStack(styler, 1, 7 ), new Object[] { "X  ", "   ", "  #", Character.valueOf('#'), Block.planks, Character.valueOf('X'), Item.stick });
			ModLoader.AddRecipe(new ItemStack(styler, 1, 8 ), new Object[] { "X  ", "  #", Character.valueOf('#'), Block.planks, Character.valueOf('X'), Item.stick });
        	ModLoader.AddRecipe(new ItemStack(styler, 1, 9 ), new Object[] { "X #", Character.valueOf('#'), Block.planks, Character.valueOf('X'), Item.stick });
			ModLoader.AddRecipe(new ItemStack(styler, 1, 10), new Object[] { "#  ", "  X", Character.valueOf('#'), Block.planks, Character.valueOf('X'), Item.stick });
			ModLoader.AddRecipe(new ItemStack(styler, 1, 11), new Object[] { "#  ", "   ", "  X", Character.valueOf('#'), Block.planks, Character.valueOf('X'), Item.stick });
			ModLoader.AddRecipe(new ItemStack(styler, 1, 12), new Object[] { "# ", "  ", " X", Character.valueOf('#'), Block.planks, Character.valueOf('X'), Item.stick });
        	ModLoader.AddRecipe(new ItemStack(styler, 1, 13), new Object[] { "#", " ", "X", Character.valueOf('#'), Block.planks, Character.valueOf('X'), Item.stick });
        	ModLoader.AddRecipe(new ItemStack(styler, 1, 14), new Object[] { "#X", " #", Character.valueOf('#'), Block.planks, Character.valueOf('X'), Item.stick });
        	ModLoader.AddRecipe(new ItemStack(styler, 1, 15), new Object[] { " #", "#X", Character.valueOf('#'), Block.planks, Character.valueOf('X'), Item.stick });


			// custom slabs
        	ModLoader.AddRecipe(new ItemStack(stairSingle, 3, 8 ), new Object[] { "XXX", Character.valueOf('X'), Block.brick });
        	ModLoader.AddRecipe(new ItemStack(stairSingle, 3, 9 ), new Object[] { "XXX", Character.valueOf('X'), Block.wood });
        	ModLoader.AddRecipe(new ItemStack(stairSingle, 3, 10), new Object[] { "XXX", Character.valueOf('X'), Block.blockSteel });
        	ModLoader.AddRecipe(new ItemStack(stairSingle, 3, 11), new Object[] { "XXX", Character.valueOf('X'), Block.blockGold });
        	ModLoader.AddRecipe(new ItemStack(stairSingle, 3, 12), new Object[] { "XXX", Character.valueOf('X'), Block.bookShelf });
        	ModLoader.AddRecipe(new ItemStack(stairSingle, 3, 13), new Object[] { "XXX", Character.valueOf('X'), Block.cloth });
        	ModLoader.AddRecipe(new ItemStack(stairSingle, 3, 14), new Object[] { "XXX", Character.valueOf('X'), Block.blockSnow });
        	ModLoader.AddRecipe(new ItemStack(stairSingle, 3, 15), new Object[] { "XXX", Character.valueOf('X'), Block.obsidian });
        }
}
