// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode

package net.minecraft.src;


// Referenced classes of package net.minecraft.src:
//            Item, EnumToolMaterial, World, Block,
//            BlockGrass, StepSound, ItemStack, EntityPlayer

public class ItemStyler extends Item
{

    public ItemStyler(int i)
    {
        super(i);
        maxStackSize = 1;
        setHasSubtypes(true);
        setMaxDamage(0);
    }

    public String getItemNameIS(ItemStack itemstack)
    {
        return (new StringBuilder()).append(super.getItemName()).append(".").append(itemstack.getItemDamage()).toString();
    }

    public boolean onItemUse(ItemStack itemstack, EntityPlayer entityplayer, World world, int i, int j, int k, int l)
    {
        int i1 = world.getBlockId(i, j, k);
		System.err.println("style block id "+String.valueOf(i1));

        for(int ii = 0; ii < idsEffectiveAgainst.length; ii++)
        if(idsEffectiveAgainst[ii] == i1)
        {
			world.setBlockMetadataWithNotify(i, j, k, itemstack.getItemDamage());
			System.err.println("block metadata is now "+String.valueOf(world.getBlockMetadata(i, j, k)));
            return true;
        }

        return false;
    }

    public boolean isFull3D()
    {
        return true;
    }

    public int[] idsEffectiveAgainst;
}
        //styler = (new ItemStyler(34, EnumToolMaterial.IRON)).setIconCoord(9, 8).setItemName("styler");