// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode

package net.minecraft.src;
import java.util.Random;
// Referenced classes of package net.minecraft.src:
//            Block, Material

public class BlockCustom extends Block
{
	int customIndex[][];

    public BlockCustom(int i, int j, Material material)
    {
        super(i, j, material);
        customIndex=new int[16][];
        for (int i1=0; i1<16; i1++)
        {
			customIndex[i1]=new int[6];
    	    for (int i2=0; i2<6; i2++)
				customIndex[i1][i2]=blockIndexInTexture;
		}
    }

    public void setCustomIndexSide(int index, int block, String side)
    {
		System.err.println("setting index "+String.valueOf(index)+", side "+side+" to "+String.valueOf(block));
		if (side.equals("top")   || side.equals("all")) customIndex[index][0]=block;
		if (side.equals("top")   || side.equals("all")) customIndex[index][1]=block;
		if (side.equals("sides") || side.equals("all")) customIndex[index][2]=block;
		if (side.equals("sides") || side.equals("all")) customIndex[index][3]=block;
		if (side.equals("sides") || side.equals("all")) customIndex[index][4]=block;
		if (side.equals("sides") || side.equals("all")) customIndex[index][5]=block;
	}

	// 0 bottom 1 top 2 east 3 west 4 north 5 south
    public int getBlockTextureFromSideAndMetadata(int i, int j)
    {
		return customIndex[j][i];
    }

    protected int damageDropped(int i)
    {
        return i;
    }

    public int quantityDropped(Random random)
    {
       	return 1;
    }

}
