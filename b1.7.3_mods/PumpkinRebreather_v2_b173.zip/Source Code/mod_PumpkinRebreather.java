package net.minecraft.src;

import net.minecraft.client.Minecraft;

public class mod_PumpkinRebreather extends BaseMod {

	@Override
	public String Version() {
		return "Beta v1.7.3";
	}

	protected mod_PumpkinRebreather() {
		ModLoader.SetInGameHook(this, true, true);
	}

	@Override
	public boolean OnTickInGame(Minecraft minecraft) {
		if( minecraft.theWorld.multiplayerWorld ) {
			return true;
		}
		if(minecraft.thePlayer.isDead) return true;

		//only refills air meter at last second (no waste)
		if(minecraft.thePlayer.air > -10) return true;
		
		//check if we have charcoal readily available (in hotbar)
		ItemStack filter = null;
		int loop;
		for( loop = 0; loop < 10; ++loop ){
			if( loop == 9 ) {
				filter = null;
				continue;
			}
			filter = minecraft.thePlayer.inventory.mainInventory[loop];
			if( filter == null || filter.itemID != Item.coal.shiftedIndex || filter.getItemDamage() == 0 ) continue;
			
			//we found charcoal
			break;
		}

		//only works if we're wearing pumpkin helmet
		ItemStack helmet = minecraft.thePlayer.inventory.armorItemInSlot(3);
		if(helmet == null) return true;
		if(helmet.itemID != Block.pumpkin.blockID)return true;

		
		if( filter == null ) {
			int newAir = minecraft.thePlayer.maxAir * minecraft.thePlayer.health / 20;
			minecraft.thePlayer.air = newAir;
			minecraft.thePlayer.attackEntityFrom(null, 1);
		} else {
			minecraft.thePlayer.air = minecraft.thePlayer.maxAir*1;
			filter.stackSize--;
			if( filter.stackSize == 0 ){
				minecraft.thePlayer.inventory.mainInventory[loop] = null;
			}
		}
		return true;
	}

}
