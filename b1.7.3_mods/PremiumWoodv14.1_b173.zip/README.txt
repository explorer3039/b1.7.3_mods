===Installation Instructions===
-Locate your minecraft.jar file. For windows vista/7:
    "C:\Users\[username]\AppData\Roaming\.minecraft\bin"
-Use winrar or 7zip or any other archiver to open said file
-Place the class files in the "add-to-minecraft-jar" folder into the .jar file
-OPTIONAL: Copy the class files in the "optional" folder into the .jar file
--- yh.class will edit fire so that it will burn the new leaves added in this mod
-DELETE THE META-INF FOLDER FROM THE .JAR FILE!
-Play

===Changing Block IDs===
-Locate the "config" folder. For windows vista/7:
    "C:\Users\[username]\AppData\Roaming\.minecraft\config"
-Go to "mod_BetterWood.cfg"
-To open:
	-Double click
	-If this does not work, see "Alternate Method" below
-Change the numbers of the block ID you would like changed in the lower section of the file (below all of the '#' symbols).
-Save and close
-Play

===Alternate Method===
If double clicking the "mod_BetterWood.cfg" file does not open it, try this:
-Right click the file
-Hover over "Open With"
-Select "Notepad"
-Refer back to "Changing Block IDs" for further instructions
==If this still does not work, search "how to open a cfg file" on Google