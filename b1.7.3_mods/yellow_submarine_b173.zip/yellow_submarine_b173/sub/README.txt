Yellow Submarine Mod V.0.8
copyright 2011 Burnner

This mod gives you a snorkle and a yellow submarine!
The snorkle allows you to breath underwater.
Expolore the deep ocean!


To install: 
please install Modloader FIRST!!!! and then:

1. Make a backup of your minecraft.jar file
2. locate your .minecraft folder
3. unzip the sub files inside that folder
5. go dive!


ChangeLog
22.07.2011 The player is now in the submarine
21.07.2011 Added a submarine model


Last motified
22.07.2011


