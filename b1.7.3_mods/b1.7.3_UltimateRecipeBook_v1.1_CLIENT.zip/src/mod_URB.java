// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;


// Referenced classes of package net.minecraft.src:
//            BaseMod, ItemRecipeBook, Item, ModLoader, 
//            ItemStack

public class mod_URB extends BaseModMp
{

    public mod_URB()
    {
        book = (new ItemURB(RecipeBookID - 256)).setIconIndex(Item.book.iconIndex).setItemName("recipeBook");
        ModLoader.AddName(book, "Recipe Book");
        ModLoader.AddShapelessRecipe(new ItemStack(book, 1, 0), new Object[] {
        	Block.workbench, Item.book, new ItemStack(Item.dyePowder, 1, 0) });
        ModLoader.AddShapelessRecipe(new ItemStack(book, 1, 1), new Object[] {new ItemStack(book, 1, 0)});
        ModLoader.AddShapelessRecipe(new ItemStack(book, 1, 0), new Object[] {new ItemStack(book, 1, -1) });
        ModLoaderMp.RegisterGUI(this, 15);
        ModLoaderMp.RegisterGUI(this, 16);
    }
    
    public GuiScreen HandleGUI(int inventoryType)
	{
		if(inventoryType == 15)
			return new GuiURBFiltered(ModLoader.getMinecraftInstance().thePlayer.inventory, ModLoader.getMinecraftInstance().thePlayer.inventory.getCurrentItem());
		else  if(inventoryType == 16)
			return new GuiURBComplete(ModLoader.getMinecraftInstance().thePlayer.inventory, ModLoader.getMinecraftInstance().thePlayer.inventory.getCurrentItem(), null);
		
		else return null;
	}

    public String Version()
    {
        return "v1.1";
    }
    
    public static void sendBookDamageToServer(EntityPlayer entityPlayer, int newDamageValue, Boolean newCraftGui, int windowId) {
    	
    	//i += 1;
    	//System.out.println("PING " + i + ": DAMAGE/ID = "+newDamageValue);
    	
    	int[] dataInt = new int[3];
    	dataInt[0] = newDamageValue;
    	if (newCraftGui) {
    		dataInt[1] = 1;
    		dataInt[2] = windowId; }
    	else dataInt[1] = 0;
    	Packet230ModLoader packet = new Packet230ModLoader();
    	packet.dataInt = dataInt;
    	ModLoaderMp.SendPacket(ModLoaderMp.GetModInstance(mod_URB.class), packet);
    }

  
    //private static int i = 0;
	public static Item book;
    public static int RecipeBookID = 398;
    public static InventoryURBFiltered recCraft = new InventoryURBFiltered();

}
