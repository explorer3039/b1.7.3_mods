// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;


// Referenced classes of package net.minecraft.src:
//            Item, ModLoader, GuiRecipesCraft, EntityPlayer, 
//            ItemStack, World

public class ItemURB extends Item
{

    protected ItemURB(int i)
    {
        super(i);
        setItemName(getClass().getName());
        setIconCoord(11, 3);
        maxStackSize = 1;
        ModLoader.AddName(this, "Recipe Book");
    }

    public int getColorFromDamage(int i)
    {
    	if (i == 0) {
    		return 0x4182F0;
    	}
    	return 0xffa0a0;
    }

    public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer entityplayer)
    {
    	if (itemstack.getItemDamage() == 0) {
        ModLoader.OpenGUI(entityplayer, new GuiURBFiltered(entityplayer.inventory, itemstack));
    	}
    	else {
    		ModLoader.OpenGUI(entityplayer, new GuiURBComplete(entityplayer.inventory, itemstack, null));
    	}
    		
        return itemstack;
    }

	
}
