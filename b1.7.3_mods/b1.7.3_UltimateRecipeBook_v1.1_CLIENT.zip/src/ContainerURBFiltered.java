// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;


// Referenced classes of package net.minecraft.src:
//            Container, IInventory, SlotRecipeBookShow, mod_CraftingBook, 
//            SlotRecipeBookInput, Slot, InventoryRecipesCraft, EntityPlayer

public class ContainerURBFiltered extends Container
{

    public ContainerURBFiltered(IInventory iinventory)
    {
        byte byte0 = 3;
        int i = (byte0 - 4) * 18;
        for(int j = 0; j < 3; j++)
        {
            for(int i1 = 0; i1 < 3; i1++)
            {
                addSlot(new SlotURBOutput(mod_URB.recCraft, i1 + j * 3 + 1, 54 + i1 * 18, 17 + j * 18));
            }

        }

        addSlot(new SlotURBOutput(mod_URB.recCraft, 0, 148, 35));
        addSlot(new SlotURBInput(mod_URB.recCraft, 10, 12, 35));
        for(int k = 0; k < 3; k++)
        {
            for(int j1 = 0; j1 < 9; j1++)
            {
                addSlot(new Slot(iinventory, j1 + k * 9 + 9, 8 + j1 * 18, 102 + k * 18 + i));
            }

        }

        for(int l = 0; l < 9; l++)
        {
            addSlot(new Slot(iinventory, l, 8 + l * 18, 160 + i));
        }

    }
    
   
    public void onCraftGuiClosed(EntityPlayer entityplayer)
    {
        if(mod_URB.recCraft.getStackInSlot(10) != null)
        {
            entityplayer.dropPlayerItem(mod_URB.recCraft.getStackInSlot(10));
        }
        mod_URB.recCraft.clearItems();
        super.onCraftGuiClosed(entityplayer);
    }

    public boolean isUsableByPlayer(EntityPlayer entityplayer)
    {
        return mod_URB.recCraft.canInteractWith(entityplayer);
    }
}
