// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;


// Referenced classes of package net.minecraft.src:
//            Container, IInventory, Slot, EntityPlayer, 
//            ItemStack

public class ContainerURBComplete extends Container
{

    public ContainerURBComplete(IInventory iinventory)
    {
        inv = iinventory;
        int i = 0;
        for(int j = 0; j < 3; j++)
        {
            for(int k = 0; k < 2; k++)
            {
                addSlot(new Slot(iinventory, i++, 99 + k * 117, 24 + j * 55+3));
                for(int l = 0; l < 3; l++)
                {
                    for(int i1 = 0; i1 < 3; i1++)
                    {
                        addSlot(new Slot(iinventory, i++, 5 + i1 * 18 + k * 117, 6 + l * 18 + j * 55+3));
                    }

                }

            }

        }

    }
   
    
 

    public boolean isUsableByPlayer(EntityPlayer entityplayer)
    {
        return inv.canInteractWith(entityplayer);
    }

    public ItemStack getStackInSlot(int i)
    {
        return null;
    }

    private IInventory inv;
}
