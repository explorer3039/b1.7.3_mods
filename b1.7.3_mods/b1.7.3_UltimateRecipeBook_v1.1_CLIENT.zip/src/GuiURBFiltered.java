// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;

import java.util.List;
import net.minecraft.client.Minecraft;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

// Referenced classes of package net.minecraft.src:
//            GuiContainer, GuiSrvRecipesCraft, mod_CraftingBook, InventoryRecipesCraft, 
//            Container, FontRenderer, RenderEngine, GuiSmallButton, 
//            GuiButton, IInventory

public class GuiURBFiltered extends GuiContainer
{
	 private static IInventory inventory;
    public GuiURBFiltered(IInventory iinventory, ItemStack inv)
    {
    	
        super(container = new ContainerURBFiltered(iinventory));
        mod_URB.recCraft.getRecipes();
        height = 166;
        allowUserInput = false;
        book = inv;
        inventory = iinventory;
        
    }

    public void onGuiClosed()
    {
        super.onGuiClosed();
        inventorySlots.onCraftGuiClosed(mc.thePlayer);
    }

    protected void drawGuiContainerForegroundLayer()
    {
        int i = mod_URB.recCraft.getRecipeNum();
        
        fontRenderer.drawString((new StringBuilder(String.valueOf(mod_URB.recCraft.getRecipeIndex())).append(" / ").append(String.valueOf(i))).toString(), 37, 6, 0x404040);
      
        }
    
    public boolean doesGuiPauseGame()
    {
        return false;
    }

    protected void drawGuiContainerBackgroundLayer(float f)
    {
        drawDefaultBackground();
        int i = width - xSize >> 1;
        int j = height - ySize >> 1;
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        mc.renderEngine.bindTexture(mc.renderEngine.getTexture("/gui/crafting.png"));
        drawTexturedModalRect(i, j, 0, 0, xSize, ySize);
        drawTexturedModalRect(i+28, j+16, 3, 16, 26, 54);
        drawTexturedModalRect(i+53, j+16, 29, 16, 116, 54);
        drawTexturedModalRect(i+7, j+30, 119, 30, 26, 26);
        
        for (int z = 0; z < 9; z++) {
        	Slot slot = (Slot)inventorySlots.slots.get(38 + z);
        	if (mc.thePlayer.inventory.currentItem == slot.slotNumber - 38) {
        		GL11.glPushMatrix();
        		GL11.glScalef(0.5F, 0.5F, 1.0F);
        		mc.renderEngine.bindTexture(mc.renderEngine.getTexture("/gui/slot.png"));
        		drawTexturedModalRect(width + z*36 - xSize + 14, height + ySize - 51, 0, 36, 36, 36);
        		GL11.glPopMatrix();
    		}
        }
    }

    

    public void initGui()
    {
        int i = width - xSize >> 1;
        int j = height - ySize >> 1;
        controlList.clear();
        controlList.add(new GuiSmallButton(1, i + 110, j -21, 20, 20, "<"));
        controlList.add(new GuiSmallButton(2, i + 130, j -21, 20, 20, ">"));
        controlList.add(new GuiSmallButton(3, i + 150, j -21, 20, 20, "..."));
        super.initGui();
    }
    
    public void handleMouseInput()
    {
        int i = Mouse.getEventDWheel();
        if(i > 0)
        {
        	mod_URB.recCraft.recipeNext();
        }
        if(i < 0)
        {
        	mod_URB.recCraft.recipePrev();
        }
        super.handleMouseInput();
    }
    
    protected void keyTyped(char c, int i)
    {
        //super.keyTyped(c, i);
    	if (i ==mc.gameSettings.keyBindInventory.keyCode) {
    		mc.thePlayer.closeScreen();
    	}
        switch(i)
        {
        case 1:
        	mc.thePlayer.closeScreen();
        	break;
        
        case 205: 
        	mod_URB.recCraft.recipeNext();
            break;

        case 203: 
        	mod_URB.recCraft.recipePrev();
            break;
        }
    }
    

    
    

    protected void actionPerformed(GuiButton guibutton)
    {
        if(guibutton.id == 1)
        {
        	mod_URB.recCraft.recipePrev();
        } else
        if(guibutton.id == 2)
        {
        	mod_URB.recCraft.recipeNext();
        }
        if(guibutton.id == 3)
        {
        	//ItemBookCraft.openRecipe(mc.thePlayer, inventory, book);
        	//ModLoader.OpenGUI(mc.thePlayer, new GuiRecipeBook(inventory, book));
        	book.setItemDamage(1);
        	//mod_UltimateRecipeBook.sendBookDamageToServer(mc.thePlayer, 1, false, -1);
        	
                //int i = Mouse.getEventX();
                //int k = Mouse.getEventY();
               // mc.thePlayer.closeScreen();
                
        
        	//ModLoader.OpenGUI(mc.thePlayer, new GuiURBComplete(inventory, book, this));
        	//Mouse.setCursorPosition(i , k);
                
                ScaledResolution scaledresolution = new ScaledResolution(mc.gameSettings, mc.displayWidth, mc.displayHeight);
                int i = scaledresolution.getScaledWidth();
                int j = scaledresolution.getScaledHeight();
                GuiScreen x = new GuiURBComplete(inventory, book, this);
                mc.currentScreen = x;
               x.setWorldAndResolution(mc, i, j);
               mc.skipRenderWorld = false;
        }
        super.actionPerformed(guibutton);
    }
    
    protected void mouseClicked(int i, int j, int k)
    {
    	Boolean buttonClicked = false;
    	if(k == 0 || k == 1)
        {
    		if(k == 0) {
            for(int l = 0; l < controlList.size(); l++)
            {
                GuiButton guibutton = (GuiButton)controlList.get(l);
                if(guibutton.mousePressed(mc, i, j))
                {
                    mc.sndManager.playSoundFX("random.click", 1.0F, 1.0F);
                    actionPerformed(guibutton);
                    buttonClicked = true;
                }
            }
    		}
            if(!buttonClicked) {
                
            Slot slot = getSlotAtPosition(i, j);
   
            	if(slot != null)
            	{
            	
            		
            		if (slot.getHasStack() && mc.thePlayer.inventory.currentItem == slot.slotNumber - 38) {
            			return;
            		}
            	
            	}
            	super.mouseClicked(i, j, k);
            }
        }
    	
    	
    }
    
    private Slot getSlotAtPosition(int i, int j)
    {
        for(int k = 0; k < inventorySlots.slots.size(); k++)
        {
            Slot slot = (Slot)inventorySlots.slots.get(k);
            if(getIsMouseOverSlot(slot, i, j))
            {
            	slot.getBackgroundIconIndex();
                return slot;
            }
        }

        return null;
    }
    private boolean getIsMouseOverSlot(Slot slot, int i, int j)
    {
        int k = (width - xSize) / 2;
        int l = (height - ySize) / 2;
        i -= k;
        j -= l;
        return i >= slot.xDisplayPosition - 1 && i < slot.xDisplayPosition + 16 + 1 && j >= slot.yDisplayPosition - 1 && j < slot.yDisplayPosition + 16 + 1;
    }
    public static ContainerURBFiltered container;
    private final ItemStack book;
}
