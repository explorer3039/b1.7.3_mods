#####################################
## CrystalCraft v1.41 by ALP_Squid ##

##########################################
##					##
#            Installation		 #
##					##
##########################################

1. Install ModLoader and AudioMod (Copy all the files provided into your minecraft.jar)
2. Open the Crystalcraft zip
3. Copy everything from inside the 'for .jar' folder into your minecraft.jar
4. Copy the 'mod' folder from inside the 'for resources folder' into your resources folder located in your    .minecraft folder in AppData
5. Run the game and enjoy CrystalCraft!

##########################################
##					##
# About the .properties file [Important] #
##					##
##########################################

Block ID 97, and Item ID's 2002, 2015, 2021, 2029 and 2030 are taken and so are un useable 
(Crystal Ore, Crystal Item, Crystal Shard, Crystal Arrow, Sea Crown, Flaming Crown and climbing boots)

Other than that you can change the IDs for everything else

WARNING: Changing the IDs will cause the item you changed to disappear from your inventory. I recommend 	 changing the needed IDs and then starting a new save! Otherwise you will loose things



CrystalCraft.properties (found in your .minecraft folder)

Remember, Item ID's have 256 added to them so 2000 becomes 2256 in game
Block ID's cannot go above 255 and Item IDs cannot be above 32000

Item ids and their resprective items:

idCrystalMultitool=2003	(Crystal Multitool)
idbluecrystals=99	(Blue crystal Display)
idcrystalAxe=2006	(Crystal Axe)
idcrystalBlock=106	(Crystal Block) - not ore
idcrystalBoots=2013	(Crystal Boots)
idcrystalBow=2020	(Crystal Bow)
idcrystalChest=2011	(Crystal Chestplate)
idcrystalCrown=2014	(Crystal Crown)
idcrystalHelm=2010	(Crystal Helmet)
idcrystalHoe=2007	(Crystal Hoe)
idcrystalLegs=2012	(Crystal Leggings)
idcrystalPick=2004	(Crystal Pickaxe)
idcrystalPotion=2017	(Crystal Potion)
idcrystalPowder=2019	(Crystal Powder)
idcrystalShovel=2005	(Crystal Shovel)
idcrystalSword=2008	(Crystal Sword)
idcrystalglass=107	(Crystal Glass)
idcrystals=98		(Crystal - the Item)
idcrystaltrap=108	(Crystal Trap)
idcrystaltrident=2026	(Crystal Trident)
iddagger=2024		(Crystal Dagger)
idflametrident=2028	(Flaming Trident)
idfulltrident=2027	(Sea Trident)
idglassbottle=2016	(Glass Bottle)
idgreencrystals=103	(Green Crystal Display)
idgrinder=2018		(Stone Grinder)
idorangecrystals=101	(Orange Crystal Display)
idpinkcrystals=105	(Pink Crystal Display)
idpoison=2023		(Poison)
idpoisonDagger=2025	(Poisoned Crystal Dagger)
idpurplecrystals=104	(Purple Crystal DIsplay)
idredcrystals=100	(Red Crystal Display)
idyellowcrystals=102	(Yellow Crystal Display)


