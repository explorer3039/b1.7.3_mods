1) Download Biosphere from http://www.minecraftforum.net/topic/75440-v173-risugamis-mods-recipe-book-updated/
2) Add Biosphere.txt to Biosphere.zip
3) Delete xa.class from Biosphere.zip
4) Install Biosphere.zip like any other world generator

All credits for Biosphere go to Risugami