--------------------------------------
    Mystic Ruins mod version:  0.3
--------------------------------------


DISCLAIMER:
--------------------------------------
The Mystic Ruins mod was created by Axebane.  You MAY NOT release my mod within a "Compilation Mod Pack" or "Community Mod Pack" without my express permission.  To contact me, send a private message on the Minecraft Forums to: Axebane

The Mystic Ruins mod requires adding files to your minecraft.jar file, therefore SMP may not work with the mod installed.  There are also many new blocks and items, and you CANNOT load a save game without the mod installed if it has any of these new blocks/items.  I am not responsible for any
damage done to your computer, worlds, or your copy of Minecraft.

Please make sure to save a BACKUP COPY OF YOUR MINECRAFT.JAR and SAVES folder BEFORE USING THIS MOD.


REQUIREMENTS:
--------------------------------------
ModLoader for Beta 1.7.3
WinRAR or 7zip.


INCOMPATIBILIES:
--------------------------------------
This mod IS NOT compatible with the following mods:
Nethercraft
Any mod that adds new material types for Tools. (This mod is not Tools Utils compatible yet unfortunately)


INSTALLATION:
--------------------------------------
1. Save a backup copy of your minecraft.jar.
2. Install the LATEST Risugami's ModLoader
2. Right-Click your minecraft.jar and select "Open with WinRAR/7zip."
3. Delete the META-INF folder inside the minecraft.jar.
4. Drag all the files in the "Place in Minecraft JAR" folder into the WinRAR window and then click OK.
5. Close the WinRAR window and then load the game.

NOTE: if you have trouble copying the files into the minecraft.jar, make sure Minecraft is not allready running! If you get a blackscreen, re-open minecraft.jar with WinRAR and make sure you deleted the META-INF folder!


MYSTIC RUINS FEATURES:
--------------------------------------
NEW FEATURE: Randomly generated dungeons, with multiple corridors and rooms. Hidden tombs can be found in some of these dungeons. Most of the time, the tomb will have been allready looted, but intact tombs can be found also. There are even "secret" rooms hidden near dungeons! You will know if you found a "secret" room because it has a floor made of Lapis Blocks, and a Golden Treasure Chest!

Randomly generated ruins made of cobblestone and mossy cobblestone. The ruins are very rare. There will be at least 1 treasure chest buried in the ground under the ruins at each ruin site. Iron treasure chests contain less valuable items than Gold treasure chests.

New Vine block, that can be planted, and grows downward. Generates randomly in the world, hanging from trees, under overhangs and inside caves. Breaking vines sometimes yields seeds, sticks, or Strands of Vine. The Strands of Vine can be used to craft string, paper, leaf blocks and soup, and has one other special property when right clicking on a certain type of block.


BLOCK IDs and ITEM IDs used:
--------------------------------------
Block IDs 202 - 204.
Item IDs 17998 - 17999


VERSION INFO:
--------------------------------------
v0.3 -- Updated to support Beta 1.7.3
	NEW! Randomly generated dungeons with multiple corridors and rooms.
	Secret rooms hidden near dungeons that contain a Gold Treasure Chest and a floor made of Lapis Blocks.
	Made surface ruins a little more common, and they sometimes have Vines hanging from them.
	Vines will no longer drop seeds, only Strands of Vine, Sticks, or nothing.
	Vines are now more common, and can spawn in larger groups.
	Iron and Gold Treasure chests don't drop as many items.
v0.2 -- Updated to support Beta 1.7.3
	Made the Ruins slightly less rare.
	Most Ruin "pieces" are now a little taller.
	Reduced the chance for Vines to drop items.
v0.1 -- Initial release.