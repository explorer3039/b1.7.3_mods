package net.minecraft.src;

import java.lang.reflect.Method;
import java.util.Map;

public class mod_Bull extends BaseMod
{
        
  public String Version()
    {
//not sure exactly what this does, but I know that you can write pretty much anything you want in there.
        return "mod_Bull version 1.0.2";
    }
         public mod_Bull()
    {
        ModLoader.RegisterEntityID(EntityBull.class, "Bull", ModLoader.getUniqueEntityId());
        ModLoader.AddSpawn(EntityBull.class, 8, EnumCreatureType.creature);//not sure what the 8 does, play around with it if you want
}
//this part gives your mob a human model. This part is necessary if you want your mob to be able to carry stuff.
          public void AddRenderer(Map map)
    {
        map.put(EntityBull.class, new RenderBull(new ModelBull(), 0.5F));
    }
}