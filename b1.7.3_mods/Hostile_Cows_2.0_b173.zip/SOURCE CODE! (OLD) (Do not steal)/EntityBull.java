package net.minecraft.src;

public class EntityBull extends EntityMob
{

	public EntityBull(World world)
	{
		super(world);
		//This is the texture for your mob
		texture = "/mob/Bull.png";
	}

	protected int getDropItemId()
	{
		//This is the item your mob will drop
		return Item.porkCooked.shiftedIndex;
	}
}