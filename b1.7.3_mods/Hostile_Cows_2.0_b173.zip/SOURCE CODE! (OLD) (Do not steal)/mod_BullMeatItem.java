package net.minecraft.src;

	
public class mod_BullMeatItem extends BaseMod{
	


public mod_BullMeatItem()
   {
    ModLoader.AddName(BullMeatItem, "BullMeat");        
   } 
    public static final Item BullMeatItem;
 
    static
    {
      BullMeatItem = (new ItemBullMeat(4001, 11)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/gui/BullMeat.png")).setItemName("BullMeatItem");
         }
         public String Version()
    {
      return "1.6.6";
    }
    public void AddRecipes(CraftingManager craftingmanager)
   {
      craftingmanager.addRecipe(new ItemStack(BullMeatItem), new Object[]{
         " X ", "###", Character.valueOf('#'), Item.stick, Character.valueOf('X'), Item.porkCooked
      });
    }
} 