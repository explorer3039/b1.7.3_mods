// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;


// Referenced classes of package net.minecraft.src:
//            RenderLiving, EntityBull, ModelBase, EntityLiving, 
//            Entity

public class RenderBull extends RenderLiving
{

    public RenderBull(ModelBase modelbase, float f)
    {
        super(modelbase, f);
    }

    public void renderBull(EntityBull entityBull, double d, double d1, double d2, 
            float f, float f1)
    {
        super.doRenderLiving(entityBull, d, d1, d2, f, f1);
    }

    public void doRenderLiving(EntityLiving entityliving, double d, double d1, double d2, 
            float f, float f1)
    {
        renderBull((EntityBull)entityliving, d, d1, d2, f, f1);
    }

    public void doRender(Entity entity, double d, double d1, double d2, 
            float f, float f1)
    {
        renderBull((EntityBull)entity, d, d1, d2, f, f1);
    }
}
