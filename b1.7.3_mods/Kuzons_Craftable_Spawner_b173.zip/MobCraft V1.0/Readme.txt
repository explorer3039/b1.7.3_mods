1. Place all the file in "Files to place in Jar" into your minecraft.jar

2. Delete Meta Inf

3. Craft Mob Spawners!