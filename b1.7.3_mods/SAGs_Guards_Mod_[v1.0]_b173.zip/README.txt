SAG(SomeAwesomeGuy)'s Guards Mod, 1.7.3, v1.0

--INSTALLATION--
This is a modloader mod, download it if you haven't yet.
Rename your minecraft.jar to minecraft.zip and...
1)Copy all Files except this one to your minecraft.jar
2)Add the modloader files if you haven't already
3)Delete META-INF
4)Turn back to a .jar and play!
----------------

--Compatability(or however you spell it)--
This edits EntityPlayer and EntityPlayerSP classes in order
to display GUI.
Also, the whistle and spawner take up ID's 160 & 161.
------------------------------------------

--Mod Overview--
This is basically a mod that adds guards to the game-
since wolves are far too weak.
Guards have 25 Hearts of health, a backpack
and do 4 hearts of damage.
They will hunt hostile mobs, even creepers.
----------------

--Recipes--
To get a guard, you have to make a guard spawner

RSR
sIC
RIR

R-redstone dust
S-soul sand
s-stone sword
I-iron ingot
c-Chest

Whistle

SSS
SN_
SSS

S-Stone (not cobble) block
N-Note block
_-Empty space

This will teleport it to you and
reset its target.
----------------------------------------

--GUI and interaction--
Interact with the guard by right clicking on him.
You can see his health, in hearts, when you open the GUI.
By default he will follow you.
To change this, click on "Guard Behaviour" and choose "Stay".

You can store Items in the guard's chest by
right-clicking on him and clicking the second button.

You can heal it by right-clicking with any piece of food or cake.
Food will heal twice the amount it does for a player, and cake
will heal 20 hearts.

If you need it to guard a certain spot, right-click on it
and click the first button, and select "Stay".

---IMPORTANT----
I am aware of a certain annoying bug which means
he will look strange and buggy, just click "Follow" and then "Stay"
until it fixes.
Hopefully i will have this fixed in v1.1 .
----------------

Once in the "Stay" behaviour he will chase and attack any enemies
that get too close, and will then return to its post.

If you want it following you, he will act like a wolf
and will teleport if you get too far away.
However, their attention can wander often,
so you may want to make a whistle to teleport them quickly.
---------------------

--Development--
This mod isn't QUITE finished, if you know what i mean.
I still plan to add tons of things, like archers, TNT-guys,
and more.
I just wanted to see whether it would be worth my time,
seeing as it would take ages, much longer than it has taken me
already.
The reason I made this mod is because it was the one area I had not
seen already improved by mods.
I think if I can get this mod to multiplayer it will change
PvP forever.
If you have any suggestions or ideas, just send me a private
message.
---------------
