Drag all files inside into your Minecraft.jar file, and delete the MetaINF folder.


**Created by Death of LifeAndDeathGaming**
			
**Raldo100**