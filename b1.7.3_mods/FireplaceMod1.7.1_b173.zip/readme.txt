##############
#FIREPLACEMOD#
##############


This mod adds brick fireplaces and chimney blocks for smoke effects.
Scroll down to Usage for crafting recipes and instructions.
Important notes: ===<text>===


-Installation
    1. Ensure that you have ===INSTALLED MODLOADER AND MINECRAFT FORGE=== and ===DELETED META-INF===

    2. Drop the FireplaceMod zip file into ".minecraft/mods". Make sure you delete any older versions first.

    3. If you want to change block ids or get a blackscreen when starting up

	-Startup minecraft, a default configuartion will be created in .minecraft/config/mod_Fireplace.cfg (Open with any text editor)
	-Change the ids inside the file if desired
	-Give me an error log if 2 or 3 id changes doesn't work
	-===ERROR LOG=== can be found in ===.MINECRAFT/MODLOADER.TXT===


-Usage
    -Materials (Replace brick with this to get another fireplace)
	Cobblestone
	Moss Stone
	Brick (item)
	Netherrack
	Obsidian
	Diamond
	Gold ingot
	Iron ingot
	Lapis Dye
	Sandstone
	Stone Brick

    -Recipes

	###########
	#Fireplace#
	###########
	
	[Mat] [Mat]    [Mat]
	[Mat] [Planks] [Mat]
	[Mat] [Mat]    [Mat]

	*Replace "Mat" with anything in the material list


	#########
	#Chimney#
	#########
	
	[Mat] [Air] [Mat]
	[Mat] [Air] [Mat]
	[Mat] [Air] [Mat]



	#########
	#Firepit#
	#########
	
	[Air]   [Iron Ingot] [Air]
	[Brick] [Planks]     [Brick]
	[Brick] [Brick]      [Brick]


	##########
	#Firering#
	##########
	
	[Air] [Mat]    [Air]
	[Mat] [Planks] [Mat]
	[Air] [Mat]    [Air]



	#########
	#Grill#
	#########
	
	[Mat] [(Char)Coal] [Mat]
	[Mat] [Mat]        [Mat]
	[Air] [Mat]        [Air]



    -How to Use/Facts
	
	#################################
	#Fireplace / Firepit / Firering #
	#################################
	
	1. Right click it with a Flint and Steel to ignite it
	2. Punch the block to extinguish it
	
	#########
	#Chimney#
	#########
	
	1. The chimney tower cannot have holes and must start directly on the fireplace

	#######
	#Grill#
	#######
	
	1. Light it up and place raw fish, porkchops, beef, or chicken on it.