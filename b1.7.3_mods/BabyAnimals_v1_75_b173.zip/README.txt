---------------------------------------------
|Baby Animals v1.7.5 for Minecraft Beta 1.7.3|
---------------------------------------------

Other required mods (thanks to Risugami and 303): 
- AudioMod
- ModLoader

Installation
------------
1.Back up your minecraft.jar! It wouldn't hurt to back up your world save too.
2.Add ModLoader following it's instructions.
3.Add AudioMod following it's instructions.
4.Drop the resources folder into the .minecraft folder
5.Put the whole zip into .minecraft\mods
6.A properties file will be generated in .minecraft\mods\BabyAnimals when you run the game for the first time after installing the mod. You can customize item/block ids, whether or not the naturally occurring babies spawn (You can still summon them with SSP Commands if you wish), and some other things.
**If you are getting a black screen after login please post the modloader.txt 
file that can be found directly in the .minecraft folder. If it is some other 
kind of issue related to this mod then please give details on how to reproduce it.


Changelog
---------
-v1.7.5
      -Updated for Minecraft 1.7.3
-v1.7.4
      -Update for Minecraft 1.7.2
      -Updated sheep to use new shears
      -Phasing out old sheep shears, they will be replaced with the new shears when used on a sheep
-v1.7.3
      -Fixed chickens not laying any white eggs
      -Fixed properties so that item/block IDs can be adjusted
      -Miracle potion + white egg will give you a fertile egg
-v1.7.2
      -Fixed wonky wolf pups
      -Fixed numerous crash bugs: 
       *thrown tame and squicken eggs
       *interacting with tame cows
       *babies turning into infinite adults when fed cake
-v1.7.1
      -Updated for Minecraft v1.6.6
      -Wolf pups attack on command/when you are attacked again
      -General minor bug fixes
-v1.7
      -Added PReader to create properties file (thanks Roundaround and smith_61)
      -Fixed compatibility with Wolves Extended
      -Babies no longer trample crops
      -Added hay bales and fertile eggs
      -Created recipe to turn a white wool block into 9 string
      -Any egg type can be used to make cake
-v1.6
      -Updated for Minecraft Beta 1.5_01. 
      -Added lasso to get animals to follow more closely when desired. 
      -Cactus blocks can be used to un-tame babies along with green dye. 
      -Added Squickens. 
      -Tame puppies and tame blue-collared wolves will not attack you, ever. 
      -Added miracle potion and sheep shears.
-v1.5 
      -Added wolf puppies
      -updated animal following AI based on the wolf AI.
-v1.4.2 
      -Updated for Minecraft v1.4_01.
      -animals take cake blocks now in addition to the item.
      -added ability to use wheat to heal animals 2 HP each.
      -added compatibility with Plastic Craft buckets.
-v1.4.1 
      -Added using lightstone dust as 'medicine'
      -Eggs only spawn chicks.
      -babies are born tamed.
-v1.4 
      -Fixed not despawning issue.
      -added ability to make babies into adults and have more babies.
_v1.3.1 
      -Fixed bodies staying behind after animals die
      -re-added audio files.
-v1.3 
      -Fixed despawning issue.
      -added visible indicator for taming.
      -added un-taming.
      -lambs now drop bones if killed.
-v1.2 
      -Added following and taming capabilities (babies won't despawn if tamed).
-v1.1 
      -Added ModLoader and Spawnlist compatibility.
-v1.0 
      -First release.

Item IDs
--------
8450 - Squicken Egg
8451 - Miracle Potion
8452 - Sheep Shears (being phased out as of version 1.7.4, you can no longer craft these)
8453 - Lasso
8454 - Fertile Egg

Block ID
--------
216 - Hay Bale


What you can do with the Baby Animals Mod
-----------------------------------------

There are a fair few videos out there that show this mod but here are the facts:

Table of Contents
1. Babies
2. Adults
   2.1 Special Cases
       a. Chickens
       b. Cows
       c. Pigs
       d. Sheep
       e. Wolves
       f. Squickens
3. Recipes
4. FAQ


*******************************************************************
* 1. Babies (calves, chicks, lambs, piglets, puppies and squicks) *
*******************************************************************

Baby animals can be found wandering around the world.

Drops if a baby animal is killed
- chicks drop feathers
- calves drop leather
- lambs drop bones
- piglets drop pork
- puppies don't drop anything
- squicks drop feathers and ink sacs

Items you can use: Seeds, wheat, cactus/cooked cactus, empty hand, lasso, cake, 
lightstone dust, bones, pork(raw or cooked), fish(raw or cooked)

Seeds (baby livestock only)
---------------------------
Give a baby seeds and it will follow you. If you get too far away from it, it 
will teleport to you.

Hand
----
Right click the baby and it will stop following you (puppies will sit.)

Lasso
-----
Right-click with the lasso to get your baby animal to follow you closely. Best 
only used for short periods. Right click again to release. Can be used alone or 
in conjunction with seeds.

Wheat (baby livestock only)
---------------------------
Feed a baby a piece of wheat and it will be tamed. Tame babies won't go away 
when you log off or go adventuring far away. Keep them in a secure area though, 
because they can wander off and then you have to go find them! Wheat can also 
be fed to hurt babies to heal 2 HP each.

Cactus/Cooked Cactus (baby livestock only)
----------------------------------
If you feed a baby a piece of (yucky) cactus green, it will become wild again 
and eventually disappear the way other wild animals do.

Cake
----
Only works if the baby is tame! Give a baby a cake and it will become a 
permanently tame adult instantly.

Lightstone Dust
---------------
Works like medicine on tame animals. If a tame animal has been hurt, one 
piece of lightstone dust will fully heal it.

Bones (puppies only)
--------------------
Use bones to tame puppies. The number needed to tame a puppy is random

Pork (puppies only)
-------------------
Use pork to heal puppies. It restores 3 HP each piece.

Fish (squicks only)
-------------------
Use fish to heal squicks. It restores 3 HP each fish.


*************
* 2. Adults *
*************

Adult animals are permanently tame, they won't take cactus green from you. They 
don't randomly spawn in the world, you have to raise them from a baby.

Drops if an adult animal is killed
- chickens drop feathers
- cows drop leather
- sheep drop bones
- pigs drop pork
- wolves don't drop anything
- squickens drop feathers and ink sacs

Items you can use on adults: Seeds, empty hand, shears, lasso, miracle potion, 
lightstone dust, wheat, pork(raw or cooked), fish(raw or cooked)

Seeds (livestock only)
----------------------
Like with babies, give an adult seeds and it will follow you. If you get too 
far away from it, it will teleport to you.

Hand 
----
Like with babies, right click the adult and it will stop following you (wolves will sit.)

Lasso
-----
Right-click with the lasso to get your animal to follow you closely. Best only
used for short periods. Right click again to release. Can be used alone or in 
conjunction with seeds.

Sheep Shears (tame sheep only)
------------------------------
Right-click a tame sheep with the shears and its wool will come off.

Miracle Potion (mammals only)
-----------------------------
Give an adult a Miracle Potion and after some time, it will have a new tame baby. 
Cows take 9 full Minecraft days, sheep take 5 days, pigs take 4 days and wolves 
take 2 days. A full Minecraft day is 20 minutes. Sleeping does not speed this up.

Lightstone Dust
---------------
Works like medicine on tame animals. If a tame animal has been hurt, one piece
of lightstone dust will fully heal it.

Wheat (livestock only)
----------------------
Wheat can be used to heal tamed adults. Each piece of wheat heals 2 HP.

Pork (wolves only)
------------------
Use pork to heal wolves. It restores 3 HP each piece.

Fish (squickens only)
---------------------
Use fish to heal squickens. It restores 3 HP each fish.


/////////////////////
/ 2.1 Special Cases /
/////////////////////

Each adult animal has it's own special qualities and uses.

a. Chickens
   - Lightstone dust will make a chicken lay an egg instantly
   - Chickens will lay white or brown eggs. Brown eggs hatch chicks. White eggs are the default eggs.

b. Cows
   - Lightstone dust will make a pregnant cow have it's calf instantly
   - You can get milk from a cow by right-clicking it with an empty bucket

c. Pigs
   - Lightstone dust will make a pregnant pig have it's piglet instantly
   - You can put a saddle on a tame pig and right-click it with a stick to ride it

d. Sheep
   - Lightstone dust will grow back the fur on a tame sheep instantly
   - Lightstone dust will make a pregnant sheep have it's lamb instantly
   - You can use dyes to color a tame sheep
   - To shear a tame sheep, right click on it with shears

e. Wolves
   - Lightstone dust will make a pregnant wolf have it's puppy instantly
   - When you go to sleep, if your wolf is paying attention, it will sit (puppies too!)

f. Squickens
   - Lightstone dust will make a Squicken drop an ink sac instantly.
   - To get a squicken you must first create a squicken egg by adding an ink sac to
     an egg. When the squicken egg is hatched a new squick is spawned. It is 
     automatically tame and cannot be un-tamed.


**************
* 3. Recipes *
**************

Lasso: 
	-------
	|@|@|@|
	-------
	|@| |@|
	-------
	|@|@|@|	@ = string
	-------

Miracle Potion (yields 3):

	-------
	|%|%|%|
	-------
	|x|O|x|
	-------
	|U|U|U| % = wheat, x = seeds, O = cake, U = bucket of water
	-------

Squicken Egg: Put 1 ink sac and one egg anywhere on a crafting grid.

Hay Bale: Place 4 pieces of wheat in a 2x2 square anywhere on a crafting grid.

9 string: Place a white wool block anywhere on a crafting grid.


**********
* 4. FAQ *
**********

Q: I installed everything right but I can't hear the babies!
A: Make sure the sounds are in .minecraft/resources/mod/sound. If this doesn't fix it, reinstall Audio Mod.

Q: Where are the babies, I can't see them (but I can hear them)?
A: Make sure that there is a mob folder in .minecraft/mods/[baby animals zip folder] and that there are textures in it.

Q: I fed my babies wheat but they still de-spawned!
A: Make sure that their tag shows up when you feed them wheat. If they are tame they won't take any more wheat from you. Also, they must be in a secure pasture/barn/etc or they will wander off. Make fences 2 blocks tall, sometimes the animals bump into each other when they are jumping around and get knocked out of fenced in areas.

Q: Why did my baby stop following me? (shouldn't be an issue from Baby Animals versions 1.6 and up)
A: You ran too far ahead of it and it lost you. Go back to it and it will see you and start following you again.

Q: I'm getting a black screen after I login?
A: Please post the Modloader.txt file to the Baby Animals thread. Modloader.txt can be found directly in the .minecraft folder.

Q: Does this mod work with XXXXXX mod?
A: I don't know? Back up your minecraft.jar and try it out. If it is a ModLoader mod, there is a good chance it will. There is a short list in the forum thread of mods that other people have told me work OK. Check there.




