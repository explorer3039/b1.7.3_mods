No Fog Mod for Beta 1.7.3
Made by Johnanater

To install:
1. Add the classes to your minecraft.jar
2. Delete META-INF
3. Enjoy!

Classes Changed:
EntityRenderer (px.class)

I just changed the fog start to be multiplied by 0 and
fog end to be multiplied by 1000.

(I don't own any of the code, it all belongs to Mojang)