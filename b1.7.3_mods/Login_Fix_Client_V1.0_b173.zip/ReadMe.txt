These are the files I changed to make Minecraft Beta 1.7.3 (Client & Server) to work with the new login servers (URL).

Yes, you can use offline mode, but if anyone knows your IP, it can be insecure.

For Client:

1. Open your minecraft.jar with a program like WinRar or 7zip. (on windows, no idea about other OSes)
2. Delete the META-INF
3. Copy the class file (nb.class) into your minecraft.jar
4. Close the jar file and start Minecraft

For Server:

1. Open the minecraft_server.jar with a program like WinRar or 7zip. (on windows, no idea about other OSes)
2. DO NOT DELETE THE META-INF!
3. Copy the class file (cv.class) to the minecraft_server.jar
4. Close the jar file and launch the server

For Craftbukkit:

1. Open the Craftbukkit jar (craftbukkit-0.0.1-SNAPSHOT) with a program like WinRar or 7zip. (on windows, no idea about other OSes)
2. DO NOT DELETE ANY FILES IN THE JAR
3. Open the net folder
4. Open the minecraft folder
5. open the server folder
6. Copy the class file (ThreadLoginVerifier.class) into the craftbukkit jar.
7. Close the jar file and start the server


Other Info:

This mod was really easy to make. All I did was edit a URL to the Minecraft Login Servers. I'm only releasing this so you don't have to edit code to do it. Oh, and if you think it steals your password, you can look at the source code. If you still think it does, your loss.

Craftbukkit - The file used in the craftbukkit version was from an early Beta 1.8 version of bukkit. The source of it looks mostly the same.

- DarkenMoon

Changelog:

V1.0 - First Release. (probably the only one)