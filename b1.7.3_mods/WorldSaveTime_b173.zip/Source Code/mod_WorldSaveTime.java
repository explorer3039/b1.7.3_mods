package net.minecraft.src;

public class mod_WorldSaveTime extends BaseMod {
	@MLProp(info="20ticks / sec, 1000ticks / mc day.  Min value=20",min=20)
	public static int tickCount = 6000;
	
	@MLProp public static boolean autosaveDisabled = false;

	@Override
	public String Version() {
		return "Beta v1.7.3 ";
	}
	
	protected mod_WorldSaveTime() {
		if( autosaveDisabled == true) {
			tickCount = 2000000000;
		}
		World world = ModLoader.getMinecraftInstance().theWorld;
		try {
		ModLoader.setPrivateValue(World.class, world, 22, tickCount);
		} catch(Exception exception) {}
	}

}

