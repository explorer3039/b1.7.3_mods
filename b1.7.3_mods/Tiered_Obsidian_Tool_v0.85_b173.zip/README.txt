Tiered Obsidian Tools v0.85
By Brain Cancer

THIS MOD REQUIRES MODLOADER


1. go to 'Start'
2. click 'run'
3. type '%appdata% in the text box
4. click '.minecraft'
5. go to your 'bin' folder
6. open 'minecraft.jar' with WinRAR or similar
7. delete the 'META-INF' folder
8. open Tiered Obsidian Tools v0.8 and Modloader v1.7.3
9. drag all the '.class' folders from Modloader into your minecraft.jar
10. drag all the files from the 'Minecraft' folder from Tiered Obsidian Tools into your minecraft.jar

OPTIONAL
11. Drag all the '.class' files from the 'Molten Obsidian' folder from Tiered Obsidian Tools into your minecraft.jar

12. run Minecraft and enjoy!

If you have suggestions, comments, or find any bugs, post it in my forums page.

Thanks,
Brain__Cancer