Gtreeko's Critters Mod Version [1.03]
Copyright 2011 Gtreeko
Compatible with Minecraft [1.7.3].

This mod currently adds these creatures to your game:
- Grawls
- Roosters

How to install this mod: 

1. Install Modloader and Audiomod
2. Create a backup of your minecraft.jar and put it in a safe place
3. Open it up (not the copy) with WinRar, 7Zip etc.
4. Copy the .class files into your minecraft.jar
5. Copy all the .png files in the "Textures" folder into the .minecraft/bin/minecraft.jar/mob
6. Copy the "grawl" and "rooster" folders that are in the "Sounds" folder into .minecraft/resources/mod/sound 
7. Make sure you close the minecraft.jar back up (into a .jar again)
8. Enjoy!

Grawl info:

Grawls are now tameable! All you need is a single raw drum stick (dropped from Roosters). Have one in your hand, and right click on a Grawl when you are close to it. If hearts appear, the Grawl has been tamed! Congratulations! Your Grawl will follow you around, and try it's best to defend you when you are being attacked. You may have as many Grawls as you want!

If you would like your Grawl to stop following you around you can make it "sit" (it does not have a siting animation yet), and it will not move around (exactly in the same way as making wolves sit). Make sure you have an empty inventory slot, and right click on your tamed Grawl to make it stop moving. You will see green musical notes (I know) if this is successful. It will not move or attack anything while it is "sitting". If you would like it to follow you again after this, just right click it again with an empty inventory slot and it will follow you again.

Be careful! If you get in a fight with an un-tamed Grawl, your tamed Grawls will not attack it! Also, if you are close to your tamed Grawl and you hurt it, it may bite you! Grawls that are tamed will also not randomly attack chickens anymore.

If your Grawl is hurt, it will make the same noise if you damage a Grawl instead of the happy normal noise Grawls make. In order to heal it, you can give it a raw drum stick (dropped from Roosters) by having one in your hand and right clicking on your tamed Grawl when you are close to it. If it is successful you will hear a munching sound. You may need to feed it at least two raw drum sticks to fully heal it when it is seriously hurt.

If you ever get tired of your Grawl, and would like to un-tame it, have a stick in your hand (the same sticks you use to make torches), and right click on your already-tamed Grawl. You will see smoke appear if this is successful. It will no longer follow you and act exactly the same before it was tamed.

Make sure to check the link at the bottom of this read-me regularly!

http://www.minecraftforum.net/viewtopic.php?f=1032&t=350344