PlasticCraft v2.1.2 for Minecraft Beta 1.7.3
Moar technologiez.

Version 2.1.3 Changelog:
- Fixed burning plastic turning it into lime plastic.
- Fixed pistons not being able to push plastic.

Installation:
(This is written on the premise you know how to get to your minecraft.jar)

1. Backup your minecraft.jar.
2. Delete META-INF from your minecraft.jar and close.
3. First make sure you have Risugami's Modloader *ALREADY* installed!
4. Copy ALL of the files and folders from "minecraft" folder into your minecraft.jar
5. Copy "PlasticCraft.props" into your /.minecraft/ folder.*
6. Start up minecraft and play.

* = PlasticCraft.props should generate anyway, but the one included in this download has comments.

On Encountering an Error:
- Copypaste the error into a post on my thread, surrounded by [code][/code] tags. If there are not [code] tags, I will probably ignore it.
- If you do not get an error screen, and instead it closes or gives you a blackscreen, use the debug.bat to get an error report.

FAQ:
(Read before posting on thread)^

Q: I haz blackscreen. Fix.
A: Delete META-INF.

Q: I installed this on v1.7.2-/v1.8+ but I got blackscreen..
A: This mod is for 1.7.3.

Q: Why duzzn't recipes working?
A: Did you install ModLoader?

Q: My custom recordz song doesn't workz!!!?
A: Is it an .ogg? Do you have AudioMod, and is it placed in /resources/mod/streaming/? Is "redRecordSong=yourmusic"? Is it even properly converted to .ogg?

Q: "java.lang.NoClassDefFoundError: ModLoader" or "java.lang.NoClassDefFoundError: BaseMod"
A: Get ModLoader.

Q: "java.lang.IllegalArgumentException: Slot X is already occupied by Y@d1e7c2 when adding Z@c68a98"
A: Change X in PlasticCraft.props to something that isn't used. *this error means ID conflict*

Q: "java.lang.Exception: No more empty item sprite indices left!"
A: You have too many mods.

Q: Why blocks no show up?
A: This is a ModLoader/MCPatcher issue.

Q: How open .props file?
A: Notepad may, but I recommend Notepad++.

^ = If your problem isn't solved here, post an error log, and add "Rawr" to the end of your post. That way, I know you actually read this thing.