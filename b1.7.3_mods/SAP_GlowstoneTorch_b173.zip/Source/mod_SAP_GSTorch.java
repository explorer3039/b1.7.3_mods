package net.minecraft.src;

import java.io.*;
import net.minecraft.client.Minecraft;

public class mod_SAP_GSTorch extends BaseMod {

    public static Block gstorchIdle;
    public static Block gstorchActive;
	
    public String modname = "SAP_GlowstoneTorch";
	
	static int blockID1 = 188;
	static int blockID2 = 189;
		
	public void setIDs() {
		File dir = Minecraft.getAppDir("minecraft/mods/"+modname+"/");
		File file = new File(dir, "config.txt");
			

		
		try {
			if (!file.exists()) {
			
				System.out.println("config.txt not found - Load mod defaults!");
				
				FileWriter fstream = new FileWriter(file,true);
				BufferedWriter out = new BufferedWriter(fstream);
				out.write("< BLOCK ID >\n");
				out.write("GSTorchIdle=" + Integer.toString(blockID1) + "\n");
				out.write("GSTorchActive=" + Integer.toString(blockID2) + "\n");
				out.close();
				System.out.println("config.txt successfully created.");

			} else {

				FileReader fstream = new FileReader(file);
				BufferedReader in = new BufferedReader(fstream);
				
				in.readLine();
				blockID1 = Integer.valueOf((in.readLine()).replaceAll(".*?=", ""));
				blockID2 = Integer.valueOf((in.readLine()).replaceAll(".*?=", ""));
				in.close();
			
				System.out.println("config.txt successfully readed.");
			}
			
			System.out.println("BlockID's are now: " + blockID1 + " and " + blockID2);
		}
		catch (IOException e) {
			System.out.println(e);
		}
	}
	
	public static int	gst_texture1 = ModLoader.addOverride("/terrain.png", "/SAP_GSTorch/gstorch_1.png"),
						gst_texture2 = ModLoader.addOverride("/terrain.png", "/SAP_GSTorch/gstorch_2.png");

    public mod_SAP_GSTorch() 
	{
		setIDs();
			
		gstorchIdle = new BlockGlowstoneTorch(blockID1, blockID2, gst_texture1, false).setHardness(0.0F).setBlockName("gstidle").disableStats();
		gstorchActive = new BlockGlowstoneTorch(blockID2, blockID1, gst_texture2, true).setHardness(0.0F).setLightValue(1.0F).setBlockName("gstactive").disableStats();
   
        ModLoader.RegisterBlock(gstorchIdle);
        ModLoader.RegisterBlock(gstorchActive);
		ModLoader.AddName(gstorchIdle, "Glowstone Torch");
		ModLoader.AddName(gstorchActive, "Glowstone Torch");
		ModLoader.AddRecipe(new ItemStack(gstorchActive, 1), new Object[]
		{
               "#",
               "I",
               "R",
               Character.valueOf('#'), Block.glowStone, // glowstone dust
               Character.valueOf('I'), Item.stick, // stick
               Character.valueOf('R'), Item.redstone // redstone dust
		}); }

	public String Version() 
	{
		return "1.7.3 v.1.0";
	}
}