=========================================
POKEBALL MOD FOR MINECRAFT BETA V1.7.3
=========================================

THIS MOD WAS ORIGINALLY MADE BY Apox159 AND I CLAIM NO OWNERSHIP OVER IT!!! THIS IS JUST A FAN UPDATE SO IT CAN BE USED WITH THE NEWEST VERSION OF MINECRAFT!!!

Additional Mods Required:
ModLoader: http://www.minecraftforum.net/topic/75440-v173-risugamis-mods-updates/

Pokeball BlockID: None
Pokeball ItemID: 1159

Original Minecraft Classes Modified: None

Recipe: http://img217.imageshack.us/img217/7176/pokeballrecipe14.png

Original Author's Comment: This is a pokeball. You can catch, store and fight (Hostile + ground only) with any mobs in the game! (works with Humans and maybe other mods!) The recipe looks a bit expensive but you will never lose a pokeball. (Except if you throw it in lava... -_-) There may be some bugs.

Original Author's Thread:
http://www.minecraftforum.net/viewtopic.php?f=25&t=196429

INSTALLATION:
Put all .class files + pokeball.png in the minecraft.jar. If you have a folder called "META-INF" in there, then delete it. Don't forget to install Modloader!