package net.minecraft.src;

import java.lang.reflect.Field;
import java.util.Set;

import net.minecraft.client.Minecraft;

public final class mod_SkinFix extends BaseMod {
	
	public final String Name() {
		return "Skin Fix Uni";
	}
	
	public final String Description() {
		return "A SkinFix that works";
	}
	
	public final String Version() {
		return "v1.0";
	}

	public mod_SkinFix() {
		ModLoader.SetInGameHook(this, true, false);
	}
	
	@MLProp(name = "Skin URL",
			info = "If a skin API went down, you can easily replace it with another one.")
	public static String skinUrl = "http://resourceproxy.pymcl.net/skinapi.php?user=";
	
	@MLProp(name = "Append \".png\" in skin",
			info = "Defines whether or not should the mod add \".png\" after username in skin API request. Some APIs work in both ways.")
	public static boolean appendSkinPNG = true;
	
	@MLProp(name = "Cape URL",
			info = "If a cape API went down, you can easily replace it with another one.")
	public static String capeUrl = "http://resourceproxy.pymcl.net/capeapi.php?user=";
	
	@MLProp(name = "Append username in cape",
			info = "Defines whether or not should the mod add username after cape url. If it's set to false, you can put custom cape image URL in \"Cape URL\" property and everyone will have it.")
	public static boolean appendCapeUsername = true;
	
	@MLProp(name = "Append \".png\" in cape",
			info = "Defines whether or not should the mod add \".png\" after username in cape API request. Some APIs work in both ways.")
	public static boolean appendCapePNG = true;
	
	@SuppressWarnings("unchecked")
	public final boolean OnTickInGame(Minecraft minecraft) {
		updateSkinAndCape(minecraft.thePlayer);
		if (minecraft.theWorld instanceof WorldClient) {
			try {
				for (Entity entity : (Set<Entity>) field_20914_EField.get((WorldClient) minecraft.theWorld))
					if (entity instanceof EntityOtherPlayerMP)
						updateSkinAndCape((EntityPlayer) entity);
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			}
		}
		return true;
	}
	
	private final void updateSkinAndCape(EntityPlayer entityplayer) {
		if (entityplayer.skinUrl != skinUrl + entityplayer.username + (appendSkinPNG ? ".png" : "")
				|| entityplayer.playerCloakUrl != capeUrl + (appendCapeUsername ? entityplayer.username + (appendCapePNG ? ".png" : "") : "")
				|| entityplayer.cloakUrl != entityplayer.playerCloakUrl) {
			entityplayer.skinUrl = skinUrl + entityplayer.username + (appendSkinPNG ? ".png" : "");
			ModLoader.getMinecraftInstance().renderGlobal.obtainEntitySkin(entityplayer);
			entityplayer.playerCloakUrl = capeUrl + (appendCapeUsername ? entityplayer.username + (appendCapePNG ? ".png" : "") : "");
			entityplayer.cloakUrl = entityplayer.playerCloakUrl;
			ModLoader.getMinecraftInstance().renderEngine.obtainImageData(entityplayer.cloakUrl, new ImageBufferDownload());
		}
	}
	
	private final Field getObfuscatedPrivateField(Class<?> target, String names[]) {
		for (Field field : target.getDeclaredFields())
			for (String name : names)
				if (field.getName() == name) {
					field.setAccessible(true);
					return field;
				}
		return null;
	}
	
	private final Field field_20914_EField = getObfuscatedPrivateField(WorldClient.class, new String[] {"G", "field_20914_E"});
}