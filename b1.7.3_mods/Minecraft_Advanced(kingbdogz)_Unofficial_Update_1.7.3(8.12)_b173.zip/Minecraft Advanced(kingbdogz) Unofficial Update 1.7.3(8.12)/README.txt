This mod is installed like any other.

But before you install this mod...you must install Modloader, Audiomod, and ToolMaterial API

The mod has been Updated to 1.7.3 by Cooldudepoke.

I Cooldudepoke take no credit whatsoever for making the original mod.

All Credit except updating goes to Kingbdogs!

If you notice any bugs, glitches, typos, etc...

Post a reply to the topic!