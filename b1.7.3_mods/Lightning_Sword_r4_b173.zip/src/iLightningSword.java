public class iLightningSword extends qd {
	public iLightningSword(int itemID) {
		super(itemID,bu.d); a(getClass().getName());
		c(ModLoader.addOverride("/gui/items.png","/Shockah/LightningSword/iLightningSword.png"));
		e(64-1);
	}
	
	public int a(sn entity) {
		return 10;
	}

	public iz a(iz stack, fd world, gs player) {
		float f1 = 1F;

		float f2 = player.aV + (player.aT - player.aV) * f1;
		float f3 = player.aU + (player.aS - player.aU) * f1;

		double d1 = player.aJ + (player.aM - player.aJ) * f1;
		double d2 = player.aK + (player.aN - player.aK) * f1 + 1.62D - player.bf;
		double d3 = player.aL + (player.aO - player.aL) * f1;

		bt localbm1 = bt.b(d1, d2, d3);

		float f4 = in.b(-f3 * 0.01745329F - 3.141593F);
		float f5 = in.a(-f3 * 0.01745329F - 3.141593F);
		float f6 = -in.b(-f2 * 0.01745329F);
		float f7 = in.a(-f2 * 0.01745329F);

		float f8 = f5 * f6;
		float f9 = f7;
		float f10 = f4 * f6;

		double d4 = 200D;
		bt localbm2 = localbm1.c(f8 * d4, f9 * d4, f10 * d4);
		vf localty = world.a(localbm1, localbm2, false);
		if (localty == null) return stack;

		if (localty.a == jg.a) {
			int i = localty.b;
			int j = localty.c;
			int k = localty.d;

			if (!world.a(player, i, j, k)) {
				return stack;
			}
			
			stack = new iz(stack.c,stack.a,stack.i()+4);
			if (stack.i() > f()) stack = new iz(stack.c,0,0);
			
			double dist = Math.sqrt(Math.pow(i-player.aM,2)+Math.pow(j-player.aN,2)+Math.pow(k-player.aO,2));
			if (dist <= 5) player.a(mod_LightningSword.acHitYourself,1);
			
			if (uu.m[world.a(i,j,k)].bA.a()) j++;
			world.b(new c(world,i,j,k));
			new Loc(i,j,k).setBlockNotify(world,mod_LightningSword.bFIRE.bn);
		} else if (localty.g != null) {
			if (localty.g instanceof ls) {
				world.b(new c(world,localty.g.aM,localty.g.aN,localty.g.aO));
				
				stack = new iz(stack.c,stack.a,stack.i()+4);
				if (stack.i() > f()) stack = null;
			}
		}

		return stack;
	}
}