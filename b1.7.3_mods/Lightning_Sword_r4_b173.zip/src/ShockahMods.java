import java.util.Random;

public class ShockahMods {
	private static class Page extends ACPage {
		private Page() {
			super("Shockah");
		}
		
		public int bgGetSprite(Random rand, int x, int y) {
			int sprite = uu.bc.bm;
			int rnd = rand.nextInt(1+y)+y/2;
			Random rand2 = new Random((int)(Math.tan(x)*4234D+Math.sin(y)*130D));
			
			if (y < 10) {
				sprite = -1;
				if (rand2.nextInt(Math.max(1,y)) == 0) sprite = uu.be.bm;
			} else {
				if (rand2.nextInt(15) == 0) sprite = uu.bd.bm;
				if (rnd > 37 || y == 35) sprite = uu.A.bm;
			}
			
			return sprite;
		}
	}
	
	private static Page acPage = new Page();
	
	public static void addAchievements(ny... achievements) {
		acPage.addAchievements(achievements);
	}
}