import java.io.File;

import net.minecraft.client.Minecraft;

public class mod_LightningSword extends BaseMod {
	private static final int itemOff = 256;
	
	@MLProp public static int idLightningSword = 5400;
	
	static final uu
		bGLOWSTONE = uu.be,
		bFIRE = uu.as;
	static final gm iSTICK = gm.B;
	
	public static gm iLIGHTNINGSWORD;
	
	public static ny acMakeSword,acHitYourself;
	
	public mod_LightningSword() {
		iLIGHTNINGSWORD = new iLightningSword(idLightningSword-itemOff);
		
		ModLoader.AddName(iLIGHTNINGSWORD,"Lightning Sword");
		ModLoader.AddRecipe(new iz(iLIGHTNINGSWORD),"G","G","/",'G',bGLOWSTONE,'/',iSTICK);
		
		acMakeSword = new ny(6843900,"lightningSword",4,1,iLIGHTNINGSWORD,ep.o).c();
		acHitYourself = new ny(6843901,"lightningSword2",5,0,iLIGHTNINGSWORD,acMakeSword).c();
		
		ModLoader.AddAchievementDesc(acMakeSword,"Lightning Sword","Make a Lightning Sword");
		ModLoader.AddAchievementDesc(acHitYourself,"Fail","Hit yourself with a lightning");
		
		ShockahMods.addAchievements(acMakeSword,acHitYourself);
		SAPI.acHide(acHitYourself);
		
		try {
			Class.forName("EnumRarity");
			EnumRarity.setRarity(EnumRarity.Epic,iLIGHTNINGSWORD);
		} catch (Exception e) {}
	}
	
	public void TakenFromCrafting(gs player, iz stack) {
		if (stack.c == iLIGHTNINGSWORD.bf) player.a(acMakeSword,1);
	}
	
	public String Version() {
		return "r4";
	}
	
	public static File GetAppdataLocation() {
		return Minecraft.b();
	}
}