Pav's Nano and Speed Block mod v1
---------------------------------
- add's 1 new ore
- add's 16 new items
- add's 2 pickaxe's, 2 shovel's 2 hoe's, 2 sword's, 2 axe's
- add's 1 new ingot
- add's another item whihc is a smetled ingot which then becomes a nonotube
- add's 4 new craftiable armours
- the nano ore naturally spawns more likely to find then coal and strongest thing around
- the speed blocks can work like a conveir belt
install
-------
- drag and drop all files from Bin folder into minecraft.jar
- delete met-inf
- drag and drop modloader files in mod loader files
- enjoy

Recipes
-------
-nano recipes (they are in raw form)
{
	
	CraftingManager.getInstance().addRecipe (new ItemStack(pickaxenano, 1), new Object[]{
			"^^^", " $ ", " $ ", Character.valueOf('$'), Item.stick, Character.valueOf('^'), nanoingot  
	});	
		
	CraftingManager.getInstance().addRecipe (new ItemStack(axenano, 1), new Object[]{
			"## ", "#$ ", " $ ", Character.valueOf('$'), Item.stick, Character.valueOf('#'), nanoingot  
	});	
		
	CraftingManager.getInstance().addRecipe (new ItemStack(shovelnano, 1), new Object[]{
			"#", "$", "$", Character.valueOf('$'), Item.stick, Character.valueOf('#'), nanoingot  
	});	
		
	CraftingManager.getInstance().addRecipe (new ItemStack(hoenano, 1), new Object[]{
			"##", " $", " $", Character.valueOf('$'), Item.stick, Character.valueOf('#'), nanoingot  
	});	
		
	CraftingManager.getInstance().addRecipe (new ItemStack(swordnano, 1), new Object[]{
			"#", "#", "$", Character.valueOf('$'), Item.stick, Character.valueOf('#'), nanoingot  
	});	
		
	
	
        CraftingManager.getInstance().addRecipe (new ItemStack(pickaxepurenano, 1), new Object[]{
			"###", " $ ", " $ ", Character.valueOf('#'), nanotube, Character.valueOf('$'), nanoingot 
		});	
        
        
        CraftingManager.getInstance().addRecipe (new ItemStack(axepurenano, 1), new Object[]{
			"## ", "#$ ", " $ ",  Character.valueOf('#'), nanotube, Character.valueOf('$'), nanoingot   
		});	
        
        CraftingManager.getInstance().addRecipe (new ItemStack(shovelpurenano, 1), new Object[]{
			 "#", "$", "$",  Character.valueOf('#'), nanotube, Character.valueOf('$'), nanoingot   
		});	
        
        CraftingManager.getInstance().addRecipe (new ItemStack(hoepurenano, 1), new Object[]{
			"##", " $", " $",  Character.valueOf('#'), nanotube, Character.valueOf('$'), nanoingot   
		});	
        
        CraftingManager.getInstance().addRecipe (new ItemStack(swordpurenano, 1), new Object[]{
			"#", "#", "$",  Character.valueOf('#'), nanotube, Character.valueOf('$'), nanoingot  
		});	
        
        // armour
        CraftingManager.getInstance().addRecipe (new ItemStack(helmetnano, 1), new Object[]{
			"###", "# #",  Character.valueOf('#'), nanoingot  
		});	
        
        CraftingManager.getInstance().addRecipe (new ItemStack(platenano, 1), new Object[]{
			"# #", "###", "###",  Character.valueOf('#'), nanoingot  
		});	
        
        CraftingManager.getInstance().addRecipe (new ItemStack(legsnano, 1), new Object[]{
			"###", "# #", "# #",  Character.valueOf('#'), nanoingot  
		});	
        
        CraftingManager.getInstance().addRecipe (new ItemStack(bootsnano, 1), new Object[]{
			"# #", "# #",  Character.valueOf('#'), nanoingot  
		});	
	
}



known Glitches
--------
- the nano ore can be broken by any pickaxe

If you are a modder and would like the src files then please contact me thankyou.