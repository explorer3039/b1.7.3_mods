===================
FlashShelter Mod v2.0 Beta 4
===================
Place all folders and .CLASS files in minecraft.jar

Place all .PROPERTIES files in the %APPDATA%/.minecraft folder