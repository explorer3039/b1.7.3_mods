This is BetaTweaks v1.1 for Minecraft Beta 1.7.3 Client
Compatible with servers that have v1 installed (probably)

DESCRIPTION
This mod adds a bunch of quality of life/aesthetic features, 
most of which were removed before b1.7.3 was released or implemented afterwards. 
My favourite changes are the various gui improvements that are enabled by default.
If a server has the mod installed, you can also ping the server from the menu and use the TAB server list.
I would recommend you sort out the config yourself to fit things to suit your needs.

INSTALL
1. Install Modloader
2. Install ModLoaderMP (OPTIONAL: Required to function on servers with BetaTweaks installed)
3. Install GuiAPI (OPTIONAL: Allows you to configure the mod in game from the options menu)
4. Delete META-INF from the minecraft.jar
5. Insert this zip into the .minecraft/mods folder
6. ???
7. Success!

KNOWN ISSUES
Panorama background is pixelated and spams the log with errors if you have optifine installed.
GuiAPI tooltips are bad, will be fixed in the future.
Mouse dragging shortcuts may be slightly buggy, report them to me via @ModificationStation discord.

CREDIT
- Large number of original tweaks/fixes - various people
- Ingame Texture Pack Button, Panorama menu - Logan
- Old logo original port, Ladder gaps, No tall grass - Johnanater
- Old logo transparency fix - Dereku
- Code helper man - mine_diver
- Large ideas and hype guy - LowMango
- Original 1.2.4 Scrollable Controls mod - North101
- More various tweaks I can't remember - Exalm, Snowshoe, Zyga
- Code and nyan cat implementation - me, rek

CHANGELOG for v1.1
Added Inventory Dragging Shortcuts!
	This is my attempt at the InventoryTweaks/Convenient Inventory industry.
	When enabled, it gives the following features when in an inventory:
		- Holding LMB with an item to increase the stacksize of the item when hovering another item of the same type.
		- Holding LMB with an item on an empty slot to equally spread the stack accross the slots.
		- Holding RMB with an item to drop 1 on each slot you come accross.
		- Shift + LMB on a crafting result to craft a whole stack.
		- Shift + LMB with an empty cursor to shift click any items you hover.
		- Shift + LMB with an item to shift click any items you hover of the same type.
		- Q with an item to quickly drop the item (one by one).
		- Q with an empty cursor to drop 1 of the item being hovered.
		- Shift + Q with an item to drop the stack held.
		- Shift + Q with an empty cursor to drop the stack being hovered
		- Maybe some other stuff I forgot + bugs.
In other news:
- Server menu is now scrollable with scroll wheel.
- Hovering server ping thing on server menu correctly shows tooltip.
- Hoe grass for seeds works with BTW hemp seeds.
- Improved code fixing pickaxe speed on old storage blocks, improved mod compatibility.
- Total classes & LOC reduced, code optimisations etc.
- This version hasn't been tested on BetaTweaks servers but I think I only changed clientside stuff so it should be okay.

CHANGELOG for v1.0
This mod implements a lot of other mods and some new features.
Some have a large number of changes, some have next to none. Here are the ones I can remember.
OldCustomLogo
	- No longer edits base classes (Uses a shady main menu hijack instead)
	- Blocks are correctly oriented
	- Mod blocks should load correctly on startup
	- Logo config can be changed and saved and will update the in game logo
		(may require a refresh with ESC to load some new blocks)
	- Added some basic options in the custom logo config for scaling and such
ScrollableControls
	- You can now set controls to unbound with ESC
	- Crash fixed when you try to bind a key to a mouse button
Misc Details
	- Hiding long grass and dead bushes is now a client side option
		If you use it on vanilla servers you will see some particles when you break one
	- OPs can change server settings from the GuiAPI menu
	- The main menu shouldn't be overrided if you use the vanilla logo and background so 
		hopefully it is compatible with the Aether main menu
		
TODO
- Fix bugs
- Improve drop rate with Q spam
- Probably improve inv drag tweaks
- Do better tooltips/avoid guiapi somehow
- Spruce/Birch leaf thing
- Snowy leaves (maybe)
- New features: DM me
