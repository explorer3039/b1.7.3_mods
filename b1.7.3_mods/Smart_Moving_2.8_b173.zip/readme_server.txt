=======================
Smart Moving Server Mod
=======================

Version 2.8 for Minecraft 1.7.3

by Divisor



Description
===========

The Smart Moving server mod provides smart moving specific communication between different SMP clients.

Additionally using a SMP server with this mod avoids bugs that can happen when using Smart Moving clients with standard SMP servers.


The entire server-client communication is disabled by default (also see chapter "Compatibility" and "Configuration" below) and can to be enabled:

* in the file "smart_moving_options.txt" at every client for client-to-server communication and
* in the file "smart_moving_server_options.txt" at the server for server-to-client communication



Installation
============

Currently only one standalone installation package is available.

If you want to have smart moving together with other mods on your server and these other packages conflict with this one you will have to wait for furure updates.


Standalone Server
-----------------
Your minecraft installation does not use any mod management systems.

Copy all files inside the included "Server Standalone" zip package to their corresponding locations in your "minecraft_server.jar".
Do not forget to delete the "META-INF" directory while you are at it.

The standalone package "dl-gt" overwrites the files "dl.class" and "gt.class".

This package should not be combined with other mods that overwrite any of these files.



Compatibility
=============

This mod adds a new packet type to the client server communication.

If one of these packets is send to a client or sever that is not correctly configured to receive it, the respective connection is lost.

This packet type's unique id can be changed (see chapter "Configuration" below), but every change needs to be performed at all connecting clients too.



Configuration
=============

The file "smart_moving_server_options.txt" can be used to configure the behavior this server mod.
It should be placed next to your "minecraft_server.jar".

move.packet.id:-1             => the smart moving packet is nether registered nor send to the clients
move.packet.id:17             => the smart moving packet is registered with an id that conflicts with another minecraft packet => CRASH
move.packet.id:231            => the smart moving packet is registered with an id that conflicts with no standard minecraft packet (default when absent)
move.packet.id:241            => the smart moving packet is registered with another id that conflicts with no standard minecraft packet
move.packet.id:256            => the smart moving packet is registered with an id greater than 255 => CRASH

move.packet.send:false        => no smart moving packets are send to the clients (default when absent)
move.packet.send:true         => smart moving packets are send to the clients (results in connection failures for all clients in the same dimension that are not smart-moving-modded or not properly smart-moving-configured)
