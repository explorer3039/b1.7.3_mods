Installation:

- Install the Skills Mod.
- Drag everything in "To jar" into your minecraft jar (%appdata%/.minecraft/bin/mincraft.jar or your OS's equivalent).
- Enjoy!

Know Conflicts:

- Item IDs 31500+ (the very last ones; I doubt anyone uses them)
	If someone finds a mod that uses them, tell me and I'll add a properties file.


The main thread is here: http://www.minecraftforum.net/topic/364710-/