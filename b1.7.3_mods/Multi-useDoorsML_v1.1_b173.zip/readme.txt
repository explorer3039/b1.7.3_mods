Multi-use Doors
- Made by Evandela
- Compatible with Minecraft Beta version 1.7.2 (v1.1)
- Required: Modloader

Installation:
1. Download and install Modloader from the following thread, making sure that the version is for the version of Minecraft you are using: http://www.minecraftforum.net/index.php?showtopic=75440
2. Open .minecraft/mods/ or create that folder if it doesn't yet exist. (If you don't know how to find .minecraft: Opening the texture packs folder will place you in the .minecraft/texturepacks/ folder.)
3. Place this .zip file in there.
4. Start the game.
5. (Optional) Edit the mod_MultiuseDoors.cfg file in .minecraft/config which Modloader created when you ran the game.

Customizing graphics:
See instructions in the doors folder or delete the texture files if you want this to use one from your texture pack.

!Warning!: Be careful about changing blocks near window doors without this mod installed. The block directly below will be deleted even if it isn't a door, so don't place window doors on diamond blocks. Also, make sure to back up your world if you care about your work, just in case. Even without any mods, backing up is a good idea.

Features:
- New - There is a configuration file .minecraft/config/mod_MultiuseDoors.cfg.
	- All features are disabled or enabled there. Ask on the thread if you want any other options.
	- You can even install this and disable everything if you really want.
- New - Diagonal doors
	- To close these, click the block in the doorway, instead of the door.
- New - Each door has a window variant.
- New - Trapdoors let liquid through when open
	- Note: The liquid needs two blocks of space to fall before it will spread.
- New - Trapdoors can be placed by clicking the top or bottom of a block. Your orientation will choose where the hinge is.
- New - Craftable door panels:
	Instead of punching the tops off, you now break them in half on your knee or crafting table.
	- 1 door -> 2 solid door panels
	- 1 door and 1 glass -> 4 window door panels
	- 2 door panels stacked -> regular door
- Changed - Opening double doors by hand will only open two doors now, based on where you stand and which direction you face.
	- If only one opened, try opening them from a spot where your hands can reach the handles next time or turning to face the direction you will pass through them.
	- Whichever method you use to open double diagonal doors, only two will open.
- Fixed - Interaction with multiplayer. Troublesome features disable themselves when you play on a server so they won't interfere.
- Fixed - The mod compatibility issues should be gone, so using BetterBlocks should not cause problems anymore.
- Fixed - Trapdoors are much easier to place than in the previous version.
- Fixed - Two crash-causing bugs from v1

- Optional door-specific graphics
- Aligned trap doors open and close together.
- Trap doors require one block by the hinge, whether on the same level or the level below.

- No new block IDs
- One-click and one-signal double doors
	- Open up to 4 doors in a 2x2 square at once with redstone or 2 by hand.
	- Works for all door types in this mod.
	- Compatible with preexisting double door wiring.
- Half-doors
- Gates
	- Half doors next to fences become gates.
	- Gates automatically line up with fences.
- Shutters
- Doors are placeable on transparent cubes like glass and half-blocks.
- Gates' height works like fences'.
- Half doors, gates, and shutters will stay and continue to work in unmodded Minecraft without the graphical changes. However, they may break if you edit surrounding blocks. If the doors are single window panels, they may also delete whichever block is directly below.
