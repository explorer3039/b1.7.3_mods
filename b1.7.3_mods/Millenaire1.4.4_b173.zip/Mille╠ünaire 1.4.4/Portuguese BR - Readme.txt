Instalação do Millenaire

- Instale o ModLoader Beta 1.7.3
- Apague a pasta META-INF do arquivo minecraft.jar
- Copie o conteudo da pasta "put in minecraft folder" para a pasta do minecraft (.minecraft no windows) (junto das pastas bin, saves etc.)
- Copie o arquivo zipado da pasta "Put in mods folder" para a pasta .minecrat/mods (sem descompactar). Caso você não tenha uma pasta mods, crie uma.
- Não é mais necessário adicionar classes no arquivo minecraft.jar como antes. Isso foi alterado para a o arquivo zip na pasta mods.

Caso o mod esteja funcionando corretamente, aparecerá uma mensagem quando você carregar o mundo pela primeira vez: "Millenaire carregado. Explore e pressione 'v' para localizar vilarejos."

Millenaire update

- Caso você não tenha feito nenhuma alteração nos arquivos de Millenaire, simplesmente delete a pasta antiga de millenaire e o arquivo zip e substitua pelos novos arquivos no mesmo processo descrito acima.

Precisa de ajuda?

Procure por sua questão na Millenaire Wiki no endereço millenaire.wikia.com, e especialmente na seção de FAQ onde muitas questões comuns sobre a instalação ou sobre o gameplay são solucionadas. Caso você não encontre a resposta, pergunte no tópico de millenaire no forum: http://www.minecraftforum.net/