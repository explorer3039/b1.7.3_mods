A)

Per installare Mill�naire:
1) Scaricare la versione pi� aggiornata di Modloader (attualmente ModLoader Beta 1.7.3), e copiare i file in minecraft.jar; (http://www.minecraftforum.net/topic/75440-v173-risugamis-mods-recipe-book-updated/)
2) Cancellare la cartella META-INF
3) Scaricare la versione pi� aggiornata di Mill�naire (attualmente la 1.3.2), e seguire le istruzioni interne (una parte deve essere copiata in /Roaming/.minecraft; l'altra parte nella cartella mods, all'interno della cartella generale di minecraft)
4) Enjoy!

B)

La traduzione italiana di Mill�naire � stata curata da DucaDelSud.

La traduzione attualmente in uso � la 1.3.2 per la versione 1.3.2 di Mill�naire e 1.7.3 di Minecraft.

Si prega di scrivere a millenaire_italian@hotmail.it nei seguenti casi:

1) Qualora sia disponibile una nuova versione di Mill�naire ma non ancora la traduzione aggiornata in italiano;
2) Qualora si siano riscontrati errori di battitura in qualche stringa;
3) Qualora si abbiano idee su una traduzione diversa di alcune stringhe;


Saluti.