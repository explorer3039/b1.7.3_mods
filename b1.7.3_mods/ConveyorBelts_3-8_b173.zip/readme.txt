######### CONVEYOR BELTS ##########
The Minecraft modification.

Invented, coded and designed by:

  *** MightyPork ***
the Grandmaster Modder

(All rights reserved.)


contact:
ondra@ondrovo.com
www.ondrovo.com
icq: 217-419-545

Any redistribution or copying of the mod or it's parts is strictly prohibited.
It was a hard work, and I don't want anybody to steal it or include in any mod packs.

INSTALLATION
------------
* Download & install ModLoader
* Place this zip file, as is, into .minecraft/mods
* Play


>> This mod is not inspired by any other mod, it is purely original. <<