More Health V7.5

For Minecraft Beta 1.7.3 (Should Work with all versions)

ModLoader required!
Mod Options Required!
Links in my thread on the forum

1. Install Modloader

2. Instal Mod Options 

Now, for my mod:

1.Go to %appdata%/.minecraft/bin/minecraft.jar

2.Drag the class files and the "moreHealth" folder in the "add to minecraft.jar" folder into the minecraft jar. Basically Copy & Paste EVERYTHING in the folder "add to minecraft.jar" into your minecraft.jar.

*New! Select the set of images you want! New images provided by some nice minecraft modders! 
Original Set: Seronis
Alternate Set: (more zelda-like heart piece): DarkOmegaMK2
New Set: Kanza

3. Delete the Meta-inf folder.


4. Read the instructions on mod options. This lets you pick your starting health and max health, whatever you desire!

5. Run minecraft, enjoy! :D

6. Find heart pieces and containers in dungeon chests, per you request.

7. Any questions/suggestions, post in the thread!


Backup your minecraft jar! Might conflict with other mods!

New in More Health 7.3: Bug Fix

Bug fixes-
Sleeping in bed at night teleports you far away or very high in the air. Due to strange unobfuscation by java decompiler, odd.