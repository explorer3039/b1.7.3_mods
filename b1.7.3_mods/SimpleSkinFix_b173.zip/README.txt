Simple SkinFix for b1.7.3
Made by Johnanater

Because of Mojang's removal of the legacy skin servers, I made this mod
which uses my web API to retrieve player's skins and capes.

All of this is done with a few simple bytecode edits. (See below!)


Installation:
--------------

Normal jar modding:

1. Drag the modified classes into the jar.

2. Delete META-INF.

3. Done!

MultiMC:

1. Click "Add to jar".

2. Select the zip.

3. Done!


Modified Classes:
- EntityPlayer (gs.class)
- EntityPlayerSP (dc.class)
- EntityOtherPlayerMP (xz.class)

---

How to make this work with pretty much any Legacy Minecraft version:

1. Download JByteMod here: https://grax.info/

2. Open it and open the client.jar
   (Client jars can be found here (https://mcversions.net/)

3. First, we'll fix skins. Search -> Search LDC -> Type "skins"

4. You'll see that there are two results,
   Find dc.<init> -> Right click -> Jump to declaration -> Right click -> Edit

   Change it with this "https://icebergcraft.com/api/Minecraft/GetSkinByUsername/?username="

   Warning: Your class file name might be different depeneding on the version.

5. Do the same thing with the match found in xz.<init>

6. Now for capes/cloaks, Search -> Search LDC "cloak" 
   Find gs.u_, jump to declaration, right click and edit
   Replace it with "https://icebergcraft.com/api/Minecraft/GetCapeByUsername/?username="

7. Delete META-INF

8. You're all set! :D

---

All the original code belongs to Mojang.