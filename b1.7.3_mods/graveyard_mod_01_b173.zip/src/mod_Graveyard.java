package net.minecraft.src;
import java.io.*;
import java.util.*;
import net.minecraft.client.Minecraft;


public class mod_Graveyard extends BaseMod

{


public String Version()
        {
                return "1.7.3";
        }

		static Item[][] possessions;
		static String[] professions;
		static String[] epitaphs;
		static String[] name1, name2, name3;
		static int chunkCount;

		public Random random;

        static
        {
			chunkCount=0;
			possessions=new Item[6][];
			name1=new String[]
			{ "Al", "Bor", "Ca", "Ches", "Di", "Dei", "Dio", "Dmi", "E", "El", "Ethel", "Geor", "Gri", "Ha", "Ho",
			"Ja", "Je", "Jo", "Kin", "Kre", "Ky", "Me", "No", "On", "Sun", "Sve", "Roy", "Ten", "Ven", "Vla", "Wil", "Wy"};
			name2=new String[]
			{ "dre", "the", "di", "mi", "gu", "ni", "tri", "le", "ge", "go", "sti", "pki", "ri", "sca",
			"cki", "ha", "co", "se", "cki", "bu", "ren", "lise", "mo", "si"};
			name3=new String[]
			{ "lav", "rad", "bor", "cus", "sius", "d", "n", "gei", "c", "rd", "nn", "nne", "rgh", "nd", "t", "li",
			};


			professions=new String[] { "Pious Farmer", "Dutiful Miner", "Skilled Woodsman", "Brave Warrior", "Fierce Knight", "Rich Dude"};
			epitaphs=new String[] {
			"Loved Husband", "Loved Wife", "R.I.P.", "Gone Too Soon",
			"Remembered", "Bad Husband", "Bad Wife", "S.O.B.",
			"Nether With You", "Forgotten",	"Damn Creepers", "Mind the Gap",
			"Do Not Disturb", "Deal With It", "Problem?", "Ya Rly", "(BUG)" };
			possessions[0]=new Item[] { Item.hoeSteel,     Item.helmetLeather, Item.plateLeather, Item.legsLeather, Item.bootsLeather, Item.shovelSteel, Item.seeds, 	 Item.bowlEmpty };
			possessions[1]=new Item[] { Item.pickaxeSteel, Item.helmetLeather, Item.plateLeather, Item.legsLeather, Item.bootsLeather, Item.shovelSteel, Item.ingotIron, Item.ingotGold };
			possessions[2]=new Item[] { Item.axeSteel,     Item.helmetLeather, Item.plateLeather, Item.legsLeather, Item.bootsLeather, Item.fishingRod,   Item.flintAndSteel, Item.fishRaw  };
			possessions[3]=new Item[] { Item.bow,  		   Item.helmetChain, 	Item.plateChain,   Item.legsChain,  Item.bootsChain,   Item.swordSteel,   		 Item.arrow, 	 Item.arrow  };
			possessions[4]=new Item[] { Item.swordSteel,   Item.helmetSteel, 	Item.plateSteel,   Item.legsSteel,  Item.bootsSteel,   Item.bow,   		 Item.arrow, 	 Item.saddle  };
			possessions[5]=new Item[] { Item.book,         Item.helmetGold, 	Item.plateGold,    Item.legsGold,   Item.bootsGold,    Item.painting,   	 Item.ingotGold, Item.diamond  };

		}



        public mod_Graveyard()
        {
			random = new Random();
			ModLoader.SetInGameHook(this, true, true);
        }


	    private static Set eligibleChunksForSpawning = new HashSet();

		public boolean OnTickInGame(Minecraft minecraft)
		{ // 24000 ticks per day
			if (minecraft.theWorld.isDaytime()) return true;
			if (random.nextInt(400)!=0) return true;

            eligibleChunksForSpawning.clear();

            int var3;
            int var6;
            for(var3 = 0; var3 < minecraft.theWorld.playerEntities.size(); ++var3)
            {
                EntityPlayer var4 = (EntityPlayer)minecraft.theWorld.playerEntities.get(var3);
                int var5 = MathHelper.floor_double(var4.posX / 16.0D);
                var6 = MathHelper.floor_double(var4.posZ / 16.0D);
                byte var7 = 8;

                for(int var8 = -var7; var8 <= var7; ++var8)
                {
                    for(int var9 = -var7; var9 <= var7; ++var9)
                    {
						if (minecraft.theWorld.getBlockMetadata((var8 + var5)*16, 0, (var9 + var6)*16)==1)
	                       eligibleChunksForSpawning.add(new ChunkCoordIntPair(var8 + var5, var9 + var6));
                    }
                }
            }

			Iterator var39 = eligibleChunksForSpawning.iterator();

			int x, y, z;
			while(var39.hasNext())
			{
				ChunkCoordIntPair var10 = (ChunkCoordIntPair)var39.next();
				x = var10.chunkXPos*16+2+random.nextInt(12);
				z = var10.chunkZPos*16+2+random.nextInt(12);
				for (y=127; y>=64; y--)
					if (minecraft.theWorld.getBlockMaterial(x, y, z).isSolid()) break;
				if (y<=64) continue;
				y=y+1;

	            EntityLiving entityliving = (EntityLiving)EntityList.createEntityInWorld("Zombie", minecraft.theWorld);
                entityliving.setLocationAndAngles((float)x + 0.5F, y, (float)z + 0.5F, random.nextFloat() * 360.0F, 0.0F);
                if (entityliving.getCanSpawnHere())
                {
					minecraft.theWorld.entityJoinedWorld(entityliving);
				}
			}

            return true;
		}

        public void PutChest(World world, int x, int y, int z, Random random, int person, int structure)
        {
			world.setBlockWithNotify(x, y, z, Block.chest.blockID);
			TileEntityChest tileentitychest = (TileEntityChest)world.getBlockTileEntity(x, y, z);

			int n = 0;
			int k = 0;
			int odd = 9; if (structure<4) odd=8;
			do
			{
				if(n >= 8) break;
				k = random.nextInt(4) + 1;
				if (random.nextInt(4)<structure)
				switch(random.nextInt(odd))
				{
					case 0: case 1: case 2: case 3:
						tileentitychest.setInventorySlotContents(random.nextInt(tileentitychest.getSizeInventory()), new ItemStack(Item.bone, k)); break;
					case 4:  tileentitychest.setInventorySlotContents(random.nextInt(tileentitychest.getSizeInventory()), new ItemStack(Item.leather, 1)); break;
					case 5:  tileentitychest.setInventorySlotContents(random.nextInt(tileentitychest.getSizeInventory()), new ItemStack(Item.silk, k)); break;
					case 6: tileentitychest.setInventorySlotContents(random.nextInt(tileentitychest.getSizeInventory()), new ItemStack(Block.cloth, 1)); break;
					case 7: case 8:
						int dmg=possessions[person][n].getMaxDamage()-random.nextInt(8*structure);
						if (dmg<0) dmg=0;
						tileentitychest.setInventorySlotContents(random.nextInt(tileentitychest.getSizeInventory()), new ItemStack(possessions[person][n], 1, dmg)); break;
				}
				n+=k;
			} while(true);
		}

	public void SetFencing (World world, int x, int z, int min, int max)
	{
		int y;
		for (y=max; y>=min; y--)
			if (world.getBlockId(x, y, z) == 2)
			{
				world.setBlockWithNotify(x, y+1, z, 85);
				return;
			}
	}


	public void GenerateSurface(World world, Random rand, int chunkx, int chunkz)
	{
		chunkCount++;
		if (chunkCount<50) return;
		if (rand.nextInt(5)!=0) return;



		//getChunkFromBlockCoords(int i, int j);


		int x, y, z, xd=0, yd=0, dir;

		int[] posx, posy, posz, posd;
		int i=0;

		int maxgraves=8;

		posx=new int[maxgraves];
		posy=new int[maxgraves];
		posz=new int[maxgraves];
		posd=new int[maxgraves];

		dir=rand.nextInt(4);

			x=0; y=0; z=0;

		for (int t=0; t<maxgraves; t++)
		{

			switch (dir)
			{
				case 0: xd=-1; yd= 0; x=rand.nextInt(4)*3+2; z=rand.nextInt(6)*2+2; break;
				case 1: xd= 1; yd= 0; x=rand.nextInt(4)*3+2; z=rand.nextInt(6)*2+2; break;
				case 2: xd= 0; yd=-1; x=rand.nextInt(6)*2+2; z=rand.nextInt(4)*3+2; break;
				case 3: xd= 0; yd= 1; x=rand.nextInt(6)*2+2; z=rand.nextInt(4)*3+2; break;
			}
			for (y=127; y>64; y--)
				if (world.getBlockId(chunkx+x, y, chunkz+z) == 2) break;

			if (y==64) continue;

			if (world.getBlockId(chunkx+x+xd, y, chunkz+z+yd) != 2) continue;
			if (world.getBlockId(chunkx+x-xd, y, chunkz+z-yd) != 2) continue;


			posx[i]=chunkx+x;
			posy[i]=y;
			posz[i]=chunkz+z;
			posd[i]=dir;
			i++;
		}

		if (i<4) return;
		int md;

		int minheight=127, maxheight=0;
		for (int j=0; j<i; j++)
		{
			if (maxheight<posy[j]) maxheight=posy[j];
			if (minheight>posy[j]) minheight=posy[j];
		}

		if (maxheight>minheight+2) return;

		// haaaaaack
		world.setBlockMetadataWithNotify(chunkx, 0, chunkz, 1);

		chunkCount=0;

		// the more graves, the better state the graveyard is in (0-4)
		int graveyard_structure = i-4;
		if (graveyard_structure>4) graveyard_structure=4;

		for (i--; i>=0; i--)
		{
			int person=rand.nextInt(6);

			// the state of this particular grave (0-7)
			int structure=graveyard_structure+rand.nextInt(4);

			md=0;
			switch (posd[i])
			{
				case 0: xd=-1; yd= 0; md=5; break;
				case 1: xd= 1; yd= 0; md=4; break;
				case 2: xd= 0; yd=-1; md=3; break;
				case 3: xd= 0; yd= 1; md=2;  break;
			}

			if (world.getBlockId(posx[i]+xd, posy[i]+1, posz[i]+yd) == 4) continue;
			if (world.getBlockId(posx[i]+xd, posy[i]+1, posz[i]+yd) == 48) continue;

			if (structure>4) world.setBlockWithNotify(posx[i]+xd, posy[i]+1, posz[i]+yd, 4);
			else if (structure>0) world.setBlockWithNotify(posx[i]+xd, posy[i]+1, posz[i]+yd, 48);

			if (rand.nextInt(3)+5<=structure) world.setBlockWithNotify(posx[i]-xd, posy[i]+1, posz[i]-yd, 37+rand.nextInt(2));
			if (rand.nextInt(4)+6<=structure) world.setBlockWithNotify(posx[i]-xd, posy[i]+1, posz[i]-yd, 50);
			if (rand.nextInt(4)+6<=structure) world.setBlockWithNotify(posx[i]+xd, posy[i]+2, posz[i]+yd, 50);


			if (structure>1)
			{
			world.setBlockWithNotify(posx[i], posy[i]+1, posz[i], 68);
			world.setBlockMetadataWithNotify(posx[i], posy[i]+1, posz[i], md);
			TileEntitySign tileentitysign = (TileEntitySign)world.getBlockTileEntity(posx[i], posy[i]+1, posz[i]);

			if (tileentitysign!=null && tileentitysign.signText!=null && tileentitysign.signText.length>=4)
			{
			if (rand.nextInt(6)<structure) tileentitysign.signText[0]="Here lies";
				else tileentitysign.signText[0]=".... ....";
			if (rand.nextInt(6)<structure) tileentitysign.signText[1]=(new StringBuilder()).append(name1[rand.nextInt(name1.length)]).append(name2[rand.nextInt(name2.length)]).append(name3[rand.nextInt(name3.length)]).toString();
				else tileentitysign.signText[1]=".......";
			if (rand.nextInt(6)<structure) tileentitysign.signText[2]=professions[person];
				else tileentitysign.signText[2]="....... ........";
			if (rand.nextInt(6)<structure) tileentitysign.signText[3]=epitaphs[rand.nextInt(16)];
				else tileentitysign.signText[3]=".... ......";
			}
			}


			if (rand.nextInt(6)>structure)	world.setBlockWithNotify(posx[i], posy[i]-1, posz[i], 5);
			else PutChest(world, posx[i], posy[i]-1, posz[i], rand, person, structure);
			if (rand.nextInt(6)>structure)	world.setBlockWithNotify(posx[i]-xd, posy[i]-1, posz[i]-yd, 5);
			else PutChest(world, posx[i]-xd, posy[i]-1, posz[i]-yd, rand, person, structure);
		}

		int side1, side2, side3, side4;
		side1=graveyard_structure+rand.nextInt(4);
		side2=graveyard_structure+rand.nextInt(4);
		side3=graveyard_structure+rand.nextInt(4);
		side4=graveyard_structure+rand.nextInt(4);

		for (x=0; x<15; x++)
		{
			if (rand.nextInt(6)+1<side1)	SetFencing(world, chunkx+x , chunkz, minheight-1, maxheight+1);
			if (rand.nextInt(6)+1<side2)	SetFencing(world, chunkx+x , chunkz+14, minheight-1, maxheight+1);
			if (rand.nextInt(6)+1<side3)	SetFencing(world, chunkx   , chunkz+x, minheight-1, maxheight+1);
			if (rand.nextInt(6)+1<side4)	SetFencing(world, chunkx+14, chunkz+x, minheight-1, maxheight+1);
		}


    }

}
