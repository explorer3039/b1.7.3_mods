+-----------------------------------------------------------------------------+
|                             [v1.7.3] Somnia v13                             |
|                                                                             |
|     http://www.minecraftforum.net/topic/162771-173-somnia-v13-sspmltfc/     |
+-----------------------------------------------------------------------------+

REQUIREMENTS
============
Minecraft Client Beta 1.7.3
Mod Loader 1.7.3


INSTALLATION
============
Using TFC Mod Manager:
   1. Download and run TFC Mod Manager.
      http://www.minecraftforum.net/topic/132071-jar-tfcs-mod-manager
   2. Use TFC to install Mod Loader.
   3. Use TFC to install Somnia.
   4. Enjoy!

Manual:
   1. Install Mod Loader into your minecraft.jar file.
      http://www.minecraftforum.net/topic/75440-v172-risugamis-mods-updates/
   2. Run Minecraft and make sure it still works.  If not, reinstall Mod Loader
      and make sure you didn't miss any steps (like removing the META-INF
	  folder).
   3. Copy the contents of the "minecraft" folder inside the Somnia ZIP into
      your minecraft.jar.
   4. Enjoy!


FEATURES
========
This mod replaces the behavior of Minecraft's bed in a number of ways.  Most of
these changes only apply to single-player.

Normal: If you activate a bed, you go to sleep immediately.
Somnia: If you activate a bed, you are presented with a confirmation dialog
        before you sleep.

Normal: You can only sleep at night.
Somnia: You can sleep at any time.

Normal: You automatically wake at dawn.  You cannot manually wake.
Somnia: You automatically wake at dawn or dusk, whichever is next in the
        day/night cycle.  If you have a Clock, you can wake automatically at
		several points throughout the day.  You can wake up manually at any
		time.

Normal: Sleeping resets your spawn point.
Somnia: Sleeping only resets your spawn point if "Reset Spawn" is set to "Yes".

Normal: If you sleep within 2 blocks of an "unsafe area," there is a random
        chance that a monster will spawn on you and interrupt your sleep.
Somnia: Monsters spawn normally and are active while you sleep.  They may
        still interrupt you, but only if they actually reach you and damage
        you.

Normal: If a monster interrupts your sleep, no time passes.
Somnia: Time passes continuously until you wake or are interrupted.

Normal: Only time progresses while you are sleeping.  Nothing in the world
        changes.
Somnia: The world is simulated while you are sleeping.  Time passes, crops and
        trees grow, smelting continues, monsters and animals are active, and
        dropped items decay.

Normal: Sleep is more or less instantaneous.
Somnia: Sleep takes some time because the world is being simulated.

Normal: You do not regenerate any health while sleeping.
Somnia: You regenerate hearts based on the difficulty setting and the amount of
        in-game time spent sleeping.
        Peaceful - full hearts instantly
		Easy     - heals half a heart per "hour"
		Medium   - heals half a heart per 2 "hours"
		Hard     - no healing

Normal: Stepping on a bed produces a stone sound.
Somnia: Stepping on a bed produces a cloth sound.

Normal: It takes very few hits to disassemble a bed.
Somnia: It takes a few more hits to disassemble a bed so that clicking the GUI
        buttons does not disassemble your bed.
