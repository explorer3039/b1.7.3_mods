package net.mine_diver.mainmenuinfo.proxy;

import java.lang.reflect.Field;

import net.mine_diver.mainmenuinfo.gui.InfoRender;
import net.minecraft.src.FontRenderer;
import net.minecraft.src.GameSettings;
import net.minecraft.src.GuiScreen;
import net.minecraft.src.RenderEngine;

public class FontRendererProxy extends FontRenderer {

	public FontRendererProxy(GameSettings gamesettings, String s, RenderEngine renderengine) {
		super(gamesettings, s, renderengine);
	}
	
	@Override
	public void drawStringWithShadow(String s, int x, int y, int color) {
		if (s.equals("Minecraft Beta 1.7.3"))
			super.drawStringWithShadow(s, x, target.height - 10 - infoRender.drawPanoramaInfo(target, color), color);
		else
			super.drawStringWithShadow(s, x, y, color);
	}
	
	public void initSuper(FontRenderer sup) {
		try {
			for (Field field : FontRenderer.class.getDeclaredFields()) {
				boolean access = field.isAccessible();
				field.setAccessible(true);
				field.set(this, field.get(sup));
				field.setAccessible(access);
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public InfoRender infoRender;
	public GuiScreen target;
}