package net.mine_diver.mainmenuinfo;

import net.mine_diver.mainmenuinfo.gui.GUIHandler;
import net.mine_diver.mainmenuinfo.gui.InfoRender;
import net.mine_diver.mainmenuinfo.providers.ForgeProvider;
import net.mine_diver.mainmenuinfo.providers.MCPProvider;
import net.mine_diver.mainmenuinfo.providers.ModsProvider;
import net.minecraft.src.BaseMod;
import net.minecraft.src.GuiScreen;
import net.minecraft.src.ModLoader;

public class Core {
	
	public final GUIHandler GUI_HANDLER = new GUIHandler();
	
	public void init(BaseMod mod) {
		if (MLCore == null)
			MLCore = mod;
		ModLoader.SetInGUIHook(MLCore, true, false);
		
		InfoRender.providers.add(new ModsProvider());
		InfoRender.providers.add(new ForgeProvider());
		InfoRender.providers.add(new MCPProvider());
	}
	
	public void onTickInGUIEvent(GuiScreen guiscreen) {
		GUI_HANDLER.setGuiScreen(guiscreen);
		GUI_HANDLER.tick();
	}
	
	protected BaseMod MLCore;
}
