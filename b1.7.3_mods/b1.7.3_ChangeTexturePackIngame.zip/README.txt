This is ChangeTexturePackIngame for Minecraft Beta 1.7.3 Client

INTRO
This mod adds a button to the in game ESC menu to let you change your texture pack without the world changing
You can disable it in .minecraft/config/ModLoader.cfg

INSTALL
1. Install Modloader
2. Delete META-INF from the minecraft.jar
3. Insert OverrideAPI v0.0.1_fix into the .minecraft/mods folder
4. Insert this zip into the .minecraft/mods folder
5. ???
6. Success!

CREDIT
Modloader + OverrideAPI port - me, rek
Override help + API - mine_diver
Original 1.7.3 mod - Logan