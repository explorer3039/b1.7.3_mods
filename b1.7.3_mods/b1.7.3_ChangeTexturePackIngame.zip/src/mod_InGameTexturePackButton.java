package net.minecraft.src;
public class mod_InGameTexturePackButton extends BaseMod {

	@Override
	public String Version() {
		return "v1";
	}
	
	mod_InGameTexturePackButton() {
		OverrideAPI.overrideGUIScreen(GuiIngameMenu.class, new GuiIngameMenuWithTexturePackButton());
	}
}
