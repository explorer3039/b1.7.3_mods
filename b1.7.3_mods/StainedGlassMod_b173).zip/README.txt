
    Do the base installation
    Take stainedGlass.zip
    Place into .minecraft/mods folder.
    Optional, but recommended (required for water visibility): Install renderhacks or Optimine compatible version (renderhacks-optifog_hde.zip)
    Optional: Copy sk.class minecraft.jar (needed to be able to smelt colored sand into stained glass)
    Start minecraft.
    Enjoy.
    If there are any block ID conflicts, open up .minecraft/config/tmim.conf and change the ID.
