How to install:

1. Go to the Start menu and type in %appdata%, press enter and open your .minecraft folder.
2. Go to bin, open minecraft.jar, and DELETE META-INF!  The mod will not work if this is not done.
3. Download ModLoader+AudioMod and add their ENTIRE contents to minecraft.jar
4. Open the AvP mod archive.
5. Put the .png files from "add to items folder in minecraft.jar" to the items folder.
6. Do the same for the other .png files in the "add to mobs folder in minecraft.jar", except put them in mobs.
7. Add the AvP folder into the minecraft.jar along with the class files.  These MUST go in next to the regular class files you see in there, NOT in a folder.  The AvP folder contains the block texture for the egg.
8. Add the resources folder into the .minecraft folder.  When asked to merge, click yes.
9. Close all archives and the minecraft.jar.
10. Profit!!(e.g. open Minecraft and play!)