Kodas Creepers for Minecraft 1.7.3

by Kodaichi

Place this .ZIP intact into .minecraft/mods  

Do not unzip unless you wish to install manually in your MINECRAFT.JAR file



