This is a patch created to make "Water Shader" and the classic "OptiFine" compatible.

All mods are property of they authors. I just meshed the code together, and offered very little.
Thanks to Notch and Mojang (for making a great game) and Ocean Labs' MCP (for helping to make this
possible).


Instructions:
------------------------------------------------------
You can turn the water shaders on by setting Water to fancy (Options > Video Settings > Details), 
and turn them off by changing Water to fast. The shaders are turned off when 3D Anaglyph is
activated, as well. All other "OptiFine" options are the same and working as were as of version HD_G.

To Install:
------------------------------------------------------
1. Install "ModLoader" by Risugami.
   Link as of Sept. 1: http://www.minecraftforum.net/topic/75440-v173-risugamis-mods-recipe-book-updated/

2. Install "OptiFine" by sp614x.
   Link as of Sept. 1: http://www.minecraftforum.net/topic/249637-173-optifine-hd-g-fps-boost/
   Made with "OptiFine 1.7.3_HD_G" and tested on "OptiFine 1.7.3_HD_S_G"

3. Install "Water Shader" by Necrowizzard.
   Link as of Sept. 1: http://www.minecraftforum.net/topic/542215-173-water-shader-alpha-v3/
   Made and tested with "Water Shader Alpha v4c"
   
4. Install my patch.

5. Install other mods 
   They must be compatible with "Water Shader" and "Optifine". The "Aether Collaboration", "Better Than
   Wolves", "Zan's Minimap", and "Too Many Items" all worked for me.

6. Delete META-INF

7. ???

8. Profit

 -- HomelessJoe --