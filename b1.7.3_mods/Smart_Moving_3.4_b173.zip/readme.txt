================
Smart Moving Mod
================

Version 3.4 for Minecraft 1.7.3

by Divisor



Description
===========

The Smart moving mod provides various additionaly moving possibilities:

* Climbing only via gaps in the walls
* Climb ladders with different speeds depending on ladder coverage and/or neighbour blocks
* Configurable sneaking
* Alternative swimming
* Alternative diving
* Charged jumps
* Sprinting
* Crawling

Exact behavior depends on configuration (see chapter 'Configuration' below)



Required Mods
=============

The modloader and the modloadermp client installation packages require

    * Flan's PlayerAPI version 1.7 or higher

to be installed too.


The stand alone client installation packages do not need any other mods to be installed.



Installation
============

Installation varies depending on your minecraft installation.
So choose your package and install it - do NOT install more than one package.

In any case, NEVER forget: ALWAYS back up your stuff!


Standalone
----------
* Your minecraft installation does not use any mod management system.
* You don't care about other mods, you just want to smart move while playing Minecraft.
* You don't care about Minecraft SMP with other players.

Copy all files inside one of the included "Standalone" zip packages to their corresponding locations in your "Minecraft.jar" in your "/.minecraft/bin/".
Do not forget to delete the "META-INF" directory while you are at it.

Choosing the package depends on the other mods you want to be installed in your "Minecraft.jar".

The standalone package "Minecraft-ob-xk" overwrites the files "net/minecraft/client/Minecraft.class", "ob.class" and "xk.class".
The standalone package "dc-kv-uq" overwrites the files "dc.class", "kv.class" and "uq.class".

Each package should not be combined with other mods that overwrite any of its corresponding files.


ModLoader
---------
* You are allready playing minecraft using Risugamis ModLoader.
* You don't use Risugamis ModLoader but you might want to install other ModLoader mods in the future.

Copy all files inside the included "ModLoader" zip package to their corresponding locations in your "Minecraft.jar" in your "/.minecraft/bin/".

Don't forget to:
* ensure you have the mod PlayerAPI version 1.4 or higher installed!
* ensure you have the latest version of Risugamis ModLoader installed!


ModLoaderMp Client
--------------------
* You are allready playing minecraft using SDK's ModLoaderMp.
* You want to play Minecraft SMP with all Smart Moving features working correctly.

Copy all files inside the included "ModLoaderMp" zip package to their corresponding locations in your "Minecraft.jar" in your "/.minecraft/bin/".

Don't forget to:
* ensure you have the mod PlayerAPI version 1.4 or higher installed!
* ensure you have the latest version of Risugamis ModLoader installed!
* ensure you have the latest version of SDK's ModLoaderMp client installed!
* ensure the minecraft server you connect to has the package "Smart Moving Server for ModLoaderMp" installed correctly



Compatibility (for mod system users only)
=============

This mod replaces specific previously created instances with proprietary ones:

* 'GameSettings' "Minecraft.theMinecraft.gameSettings" at game startup

* 'EntityPlayerSP' at "Minecraft.theMinecraft.thePlayer" and
* 'MovementInputFromOptions' "Minecraft.theMinecraft.thePlayer.movementInput" at world startup
* 'GiuIngame' at "Minecraft.theMinecraft.ingameGUI"

Mods that use similar replacements will not work correctly with this mod.



Configuration
=============

The file "smart_moving_options.txt" can be used to configure the behavior this mod.
It should be placed in your ".minecraft" folder next to minecrafts "options.txt".

When placed you can use its content to manipulate this mods ladder climbing, free climbing, swimming, diving, jumping, crawling, sneaking and sprinting behavior.


Examples for movement manipulation:
----------------------------------

move.climb.ladder:standard      => standard ladder behavior of Minecraft 1.7.3
move.climb.ladder:simple        => simple behavior (scan both player blocks for being a ladder)
move.climb.ladder:smart         => complex behavior (also scan surroundings for ladder substitutions) (default pre 2.7)
move.climb.ladder:free          => integrated in free climbing (only if free climbing itself is enabled) (default)

move.climb.free:false           => no free climbing (behavior of Minecraft 1.7.3)
move.climb.free:true            => free climbing enabled (default when absent)

move.swim:false                 => standard swimming behavior of Minecraft 1.7.3
move.swim:true                  => alternative swimming enabled (default when absent)

move.dive:false                 => standard diving behavior of Minecraft 1.7.3
move.dive:true                  => alternative diving enabled (default when absent)

move.sprint:false               => no sprinting
move.sprint:true                => sprinting for walking, swimming, diving, limbing and crawling
                                 (speed will depend on value of property "moving.sprint.factor")

move.sprint.factor:0.1          => sprinting speed same as normal speed (factor 1 is minimum)
move.sprint.factor:1            => sprinting speed same as normal speed (100%)
move.sprint.factor:1.5          => sprinting speed is 150% of normal speed (default when absent)
move.sprint.factor:10           => sprinting speed is 1000% of normal speed (no maximum)

move.sprint.exhaustion:false    => no exhaustion from sprinting
move.sprint.exhaustion:true     => sprinting possible until exhausted


move.jump:true                  => no jumping
move.jump:false                 => jumping enabled

move.jump.horizontal.factor:0.5 => standard horizontal jumping (factor 1 is minimum)
move.jump.horizontal.factor:1   => standard horizontal jumping (default when absent)
move.jump.horizontal.factor:2   => jumping horizontally with extra speed (capped by maximum speed multiplied with factor)

move.jump.vertical.factor:0.5   => half jump height
move.jump.vertical.factor:1     => standard jump height (default when absent)
move.jump.vertical.factor:2     => double jump height (falling damage remains the same)

move.jump.exhaustion:false      => double jump height (falling damage remains the same)
move.jump.exhaustion:true       => double jump height (falling damage remains the same)


move.jump.charge:true           => charged jumps enabled
move.jump.charge:false          => no charged jumps

move.jump.charge.maximum:-1     => maximum charge reached immediately (value 0 is minimum)
move.jump.charge.maximum:0      => maximum charge reached immediately
move.jump.charge.maximum:10     => maximum charge reached after 10 ticks
move.jump.charge.maximum:20     => maximum charge reached after 20 ticks (default when absent)
move.jump.charge.maximum:30     => maximum charge reached after 30 ticks

move.jump.charge.factor:0.5     => charged jump as high as normal jump (value 1 is minimum)
move.jump.charge.factor:1       => charged jump as high as normal jump
move.jump.charge.factor:1.3     => charged jump from dry ground is two blocks high (default when absent)
move.jump.charge.factor:2       => this charged jump may hurt


move.crawl:false              => no crawling
move.crawl:true               => crawling enabled

move.crawl.factor:2           => crawling speed same as normal speed (factor 1 is maximum)
move.crawl.factor:1           => crawling speed same as normal speed (100%)
move.crawl.factor:0.15        => crawling speed is 15% of normal speed (default when absent)
move.crawl.factor:0.01        => crawling speed is 1% of normal speed (factor 0 is minimum)

move.sneak:false              => no sneaking
move.sneak:true               => sneaking enabled

move.sneak.factor:2           => sneaking speed same as normal speed (factor 1 is maximum)
move.sneak.factor:1           => sneaking speed same as normal speed (100%)
move.sneak.factor:0.3         => sneaking speed is 30% of normal speed (default when absent, sneaking speed of Minecraft 1.7.3)
move.sneak.factor:0.02        => sneaking speed is 2% of normal speed (factor 0 is minimum)

move.toggle.key:67            => key code to toggle Smart Moving features in-game (default: F9)
