                                           THE RILLA
                                         Minecraft 1.7.3
                                             ver 0.1


Installation:
Requires Modloader and AudioMod 
PropertyReader included

***These instructions assume you already know where your .minecraft directory is.***
***And that ModLoader and AudioMod are installed.***

1. Using your favorite archiving tool(ex. 7zip), open the zip you just downloaded (TheRillaMod.zip).
2. Then just copy the 2 folders (mods, resources) to your .minecraft folder. (Overwrite if prompted)
3. Make sure Meta-INF folder is deleted. (.minecraft/bin/minecraft.jar)
4. Run game and enjoy!

-Notice- 
These Gorilla mobs will NOT spawn on peaceful setting.

-Features-
*passive mob until attacked or at night (in low light)
*chance to drop both leather and bone
*4 different skins
*different biome spawn locations - reg gorilla (rainforest, forest)   snow gorilla(taiga)
*tendency to find the tallest point in the area and will climb trees
*custom sound effects


-Properties File-

Currently the properties file (.minecraft/mods/Rilla/rilla.properties) allows for Spawn Rate control. Just change the default numbers to anything between 1-99. Only whole numbers accepted (no decimal numbers). The properties file is automatically created for you(after your first log in with the mod). Location - .minecraft/mods/Rilla/rilla.properties.


For those that would like to change the textures for The Rilla, all textures can be found in:
mods/TheRilla.zip/LK  -  rilla.png, rilla2.png, rillasnow.png, rillasnow2.png

Just rename the texture you would like to use and overwrite the default.These directions are for AFTER the mod is installed.


