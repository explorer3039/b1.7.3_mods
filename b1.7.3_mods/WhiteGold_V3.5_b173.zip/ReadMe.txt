Welcome To The Read Me For WhiteGold Mod V1 For Minecraft Version 1.7.3

Files You Need;
1.Obviously The "Whitegold" Files
2.ModLoader 

How To Install;
1.Navigate Your Way To You %appdata% Folder (If You Know Know How To Read The "%appdata% Navigation" Down Below).
2.Open The "Roaming" Folder --> ".minecraft" Folder --> "bin" Folder.
3.Once Your In The "bin" File Open The "minecraft.jar" File.
4.Delete The "META-INF" File.
5.You Need To Install "ModLoader" Into The .jar Or The Mod Wont WORK!
6.Now Drag The Contents Of The "WhiteGold Mod V3.zip" Into The .jar

TroubleShooting;-

1.The Folder "armor" Has 2 Pictures whitegold_1 and whitegold_2 They Should Go In The "armor" File Of The .jar
2.The Folder "whitegold" Should Simply Be Placed Into The .jar.
3.Well, The .class' Should Just Go Into The .jar With The Rest...
4.Ensure That You Have Deleted "META-INF" OR It Wont Work (As I Have Found Out Previously In The Past xD)
5.Ensure That You Have Install "ModLoader" Into The .jar Or The Items Wont Show Up At All...

%appdata% Navigation;
(For The People Who Don't Know How To Get To The %Appdata% File)
1.Open The Start Menu And Type %appdata% In Search - (Windows 7 - Vista)
2.Open The Run Command Prompt At The Start Menu And Type %appdata% (Windows XP)
