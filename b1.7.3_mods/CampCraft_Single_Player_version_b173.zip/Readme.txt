Backup your minecraft.jar and saves best to be safe then sorry :)

Instructions:

Instal Single player version:

1. Instal "ModLoader" 

2. DELETE "Meta-INF" inside minecraft.jar 

3. Put all the files inside the "Goes into minecraft.jar" folder into your "/.minecraft/bin/minecraft.jar".

4. Put all the files inside the "Goes into mods folder" folder into you "/.minecraft/mods/CampCraft".

5. Open Tent.properties inside the "/.minecraft/mods/CampCraft folder" and change the block id if you got block id clash.

6. If you want empty tents open Tent.properties inside the "/.minecraft/mods/CampCraft folder" and change emptytents=false to true

7. If you want to disable full tents with equipment its same as above but change fulltents=true to false

The recipes folder is not needed to install CampCraft it's for personal use if you need to know the recipes 

Links for ModLoader is on main post


Please post bugs or ideas you may have on this mod :)


Happy camping


