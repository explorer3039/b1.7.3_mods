hooktail154's Redstone Indicators Mod (v1.6.6)
(Compatible with Minecraft Version 1.6.6)

[*** COPYRIGHT NOTICE ***]
 This document is Copyright ©(2011) and is the intellectual property of the author. It may be not be reproduced under any circumstances except for personal, private use as long as it remains in its unaltered, unedited form. It may not be placed on any web site or otherwise distributed publicly without advance written permission. Use of this mod on any other website is strictly prohibited, and a violation of copyright.
[************************]

For detailed item descriptions (including crafting recipes), an up to date version of this mod, video feature demonstrations, and other useful info, please consult the following thread in the Minecraft forums:

http://www.minecraftforum.net/viewtopic.php?f=1032&t=275333

****** Installation Instructions ******

1) Make sure Minecraft is not running
2) Install Risugami's ModLoader (http://www.minecraftforum.net/viewtopic.php?f=1032&t=80246)
3) Put the "Redstone Indicators 1.66.zip" file in .minecraft/mods (This is /Users/*yourusername*/Library/Application Support/minecraft/mods/ for mac users)
4) If you wish to change the block ID of the Probe block, you can move the indicators.txt file to the .minecraft folder and follow the instructions below.
5) Launch Minecraft and profit!

********** Configuration ************

To change the block ID of the Probe, open indicators.txt in the .minecraft folder. The first line should be "ID↬:97" or, depending on what you open it with, "ID?:97". Change the 97 to whichever block ID you want (as long as it's between 97 and 255).

If there is no indicators.txt file, you can find it in the download. Alternatively, you can launch the game with the mod installed (even if there is a known conflict) and it should create the file. Then, you can edit the block ID and launch the game normally.

You modify block IDs at your own risk. I am not responsible if you bugger your world by doing this.


********** Change Log ************

Version 1.7.3

-Added new texture and renderer
-Changed "Indicator" block to "Probe" block
-Fixed loads of bugs
-Implemented ability to change block ID
-1.7.3 compatibility
-You can now walk through the Probe blocks
-The probe block is now classified as a redstone circuit, so it is destroyed instantly (1 click) and must be placed on a solid block
-Tidied up the code (for my own sake)

Version 1.6.6

-Initial Release