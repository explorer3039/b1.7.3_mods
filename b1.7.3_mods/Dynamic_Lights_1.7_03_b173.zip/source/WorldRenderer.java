// This file ONLY tells you what and where this mod specifically adds to the minecraft sourcecode.


public class WorldRenderer
{

	// inside this function
    public void updateRenderer()
    {
		// just put it at the end		
        LightCache.cache.clear();
        BlockCoord.resetPool();
    }
}
