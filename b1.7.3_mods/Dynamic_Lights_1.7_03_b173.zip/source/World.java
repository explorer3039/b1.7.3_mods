// This file ONLY tells you what and where this mod specifically adds to the minecraft sourcecode.


public class World
    implements IBlockAccess
{

	/*
    public float getBrightness(int i, int j, int k, int l)
    {
        int i1 = getBlockLightValue(i, j, k);
        if(i1 < l)
        {
            i1 = l;
        }
        return worldProvider.lightBrightnessTable[i1];
    }
	*/
	
    public float getBrightness(int i, int j, int k, int l)
    {
		float lc = LightCache.cache.getLightValue(i, j, k);
		if(lc > l)
		{
			return lc;
		}
	
		int lightValue = getBlockLightValue(i, j, k);
		float torchLight = PlayerTorchArray.getLightBrightness(this, i, j, k);
		if(lightValue < torchLight)
		{
			int floorValue = (int)java.lang.Math.floor(torchLight);
			if(floorValue==15)
			{
				return this.worldProvider.lightBrightnessTable[15];
			}
			else
			{
				int ceilValue = (int)java.lang.Math.ceil(torchLight);
				float lerpValue = torchLight-floorValue;
				return (1.0f-lerpValue)*this.worldProvider.lightBrightnessTable[floorValue]+lerpValue*this.worldProvider.lightBrightnessTable[ceilValue];
			}
		}

		lc = this.worldProvider.lightBrightnessTable[lightValue];
		LightCache.cache.setLightValue(i, j, k, lc);
		return lc;
    }

	/*
    public float getLightBrightness(int i, int j, int k)
    {
        return worldProvider.lightBrightnessTable[getBlockLightValue(i, j, k)];
    }
	*/
	
	public float getLightBrightness(int i, int j, int k)
	{   
		float l = LightCache.cache.getLightValue(i, j, k);
		if(l >= 0)
		{
			return l;
		}

		int lightValue = getBlockLightValue(i, j, k);
		float torchLight = PlayerTorchArray.getLightBrightness(this, i, j, k);
		if(lightValue < torchLight)
		{
			int floorValue = (int)java.lang.Math.floor(torchLight);
			if(floorValue==15)
			{
				return this.worldProvider.lightBrightnessTable[15];
			}
			else
			{
				int ceilValue = (int)java.lang.Math.ceil(torchLight);
				float lerpValue = torchLight-floorValue;
				return (1.0f-lerpValue)*this.worldProvider.lightBrightnessTable[floorValue]+lerpValue*this.worldProvider.lightBrightnessTable[ceilValue];
			}
		}

		l = this.worldProvider.lightBrightnessTable[lightValue];
		LightCache.cache.setLightValue(i, j, k, l);
		return l;
	}
	
	
	// this is an attempt to fix the "black block after mining" issue some people have persistantly complained about
	private void notifyBlockOfNeighborChange(int i, int j, int k, int l)
    {
		//....
		// add this
		markBlockNeedsUpdate(i, j, k);
	}
}