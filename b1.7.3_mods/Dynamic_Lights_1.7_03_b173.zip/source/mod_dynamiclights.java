package net.minecraft.src;

import org.lwjgl.input.Keyboard;
import java.util.*;

public class mod_dynamiclights extends BaseMod
{
	private final String togglekey = "L";
	private final int itogglekey = Keyboard.getKeyIndex(togglekey);
	private int lastEntityListHash = 0;
    private List entityList;
	long time;

	public mod_dynamiclights()
	{
		ModLoader.SetInGameHook(this, true, false);
		
		time = System.currentTimeMillis();
	}
	
	public boolean OnTickInGame(net.minecraft.client.Minecraft mc)
	{
		if (mc.thePlayer == null || mc.theWorld == null) return false;
		
		boolean newsecond = false;
		if(System.currentTimeMillis() >= time + 1000L) 
		{
			newsecond = true;
			time = System.currentTimeMillis();
		}
		
		if(lastEntityListHash != mc.theWorld.loadedEntityList.hashCode())
		{
			entityList = mc.theWorld.loadedEntityList;
			lastEntityListHash = mc.theWorld.loadedEntityList.hashCode();
			
			UpdateTorchEntities(mc.theWorld);
		}
		
		TorchEntitiesDoTick(mc, newsecond);
		
		if (newsecond)
		{
			UpdateBurningEntities(mc);
		}
		
		if (Keyboard.getEventKeyState()
		&& Keyboard.getEventKey() == itogglekey
		&& newsecond)
		{
			PlayerTorchArray.ToggleDynamicLights();
		}
		
		return true;
	}
	
	private int targetBlockID = 0;
	private int targetBlockX;
	private int targetBlockY;
	private int targetBlockZ;
	
	private void TorchEntitiesDoTick(net.minecraft.client.Minecraft mc, boolean newsecond)
	{
		for(int j = 0; j < PlayerTorchArray.torchArray.size(); j++) // loop the PlayerTorch List
		{
			PlayerTorch torchLoopClass = (PlayerTorch)PlayerTorchArray.torchArray.get(j);
			Entity torchent = torchLoopClass.GetTorchEntity();
			
			if(torchent instanceof EntityPlayer)
			{
				EntityPlayer entPlayer = (EntityPlayer)torchent;
				TickPlayerEntity(mc, newsecond, torchLoopClass, entPlayer);
			}
			
			else if(torchent instanceof EntityItem)
			{
				TickItemEntity(mc, newsecond, torchLoopClass, torchent);
			}
			
			else
			{
				torchLoopClass.setTorchPos(mc.theWorld, (float)torchent.posX, (float)torchent.posY, (float)torchent.posZ);
			}
		}
	}
	
	private void TickPlayerEntity(net.minecraft.client.Minecraft mc, boolean newsecond, PlayerTorch torchLoopClass, EntityPlayer entPlayer)
	{
		int oldbrightness = torchLoopClass.isTorchActive() ? torchLoopClass.GetTorchBrightness() : 0;
		
		if (newsecond)
		{
			if (GetPlayerArmorLightValue(torchLoopClass, entPlayer, oldbrightness) == 0 && !entPlayer.isBurning()) // case no (more) shiny armor
			{
				torchLoopClass.IsArmorTorch = false;
			}
		}
		
		int itembrightness = 0;
		if (entPlayer.inventory.mainInventory[entPlayer.inventory.currentItem] != null)
		{
			int ID = entPlayer.inventory.mainInventory[entPlayer.inventory.currentItem].itemID;
			if (ID != torchLoopClass.currentItemID
			|| (newsecond && !torchLoopClass.IsArmorTorch))
			{
				torchLoopClass.currentItemID = ID;
				
				// this is a debug function for modder use.
				//mc.ingameGUI.addChatMessage("Player Item changed, item now: " + ID);
				
				itembrightness = PlayerTorchArray.GetItemBrightnessValue(ID);
				if (itembrightness >= oldbrightness)
				{
					if (torchLoopClass.IsArmorTorch)
						torchLoopClass.IsArmorTorch = false;
				
					torchLoopClass.SetTorchBrightness(itembrightness);
					torchLoopClass.SetTorchRange(PlayerTorchArray.GetItemLightRangeValue(ID));
					torchLoopClass.SetWorksUnderwater(PlayerTorchArray.GetItemWorksUnderWaterValue(ID));
					torchLoopClass.setTorchState(entPlayer.worldObj, true);
				}
				else if(!torchLoopClass.IsArmorTorch && GetPlayerArmorLightValue(torchLoopClass, entPlayer, oldbrightness) == 0)
				{
					torchLoopClass.setTorchState(entPlayer.worldObj, false);
				}
			}
		}
		else
		{
			torchLoopClass.currentItemID = 0;
			if (!torchLoopClass.IsArmorTorch && GetPlayerArmorLightValue(torchLoopClass, entPlayer, oldbrightness) == 0)
			{
				torchLoopClass.setTorchState(entPlayer.worldObj, false);
			}
		}
		
		if (torchLoopClass.isTorchActive())
		{
			torchLoopClass.setTorchPos(entPlayer.worldObj, (float)entPlayer.posX, (float)entPlayer.posY, (float)entPlayer.posZ);
		}
	}
	
	private int GetPlayerArmorLightValue(PlayerTorch torchLoopClass, EntityPlayer entPlayer, int oldbrightness)
	{
		int armorbrightness = 0;
		int armorID;
		
		
		if(entPlayer.isBurning())
		{
			torchLoopClass.IsArmorTorch = true;
			torchLoopClass.SetTorchBrightness(15);
			torchLoopClass.SetTorchRange(31);
			torchLoopClass.setTorchState(entPlayer.worldObj, true);
		}
		else
		{
			for(int l = 0; l < 4; l++)
			{
				ItemStack armorItem = entPlayer.inventory.armorItemInSlot(l);
				if(armorItem != null)
				{
					armorID = armorItem.itemID;
					armorbrightness = PlayerTorchArray.GetItemBrightnessValue(armorID);
					
					if (armorbrightness > oldbrightness)
					{
						oldbrightness = armorbrightness;
						torchLoopClass.IsArmorTorch = true;
						torchLoopClass.SetTorchBrightness(armorbrightness);
						torchLoopClass.SetTorchRange(PlayerTorchArray.GetItemLightRangeValue(armorID));
						torchLoopClass.SetWorksUnderwater(PlayerTorchArray.GetItemWorksUnderWaterValue(armorID));
						torchLoopClass.setTorchState(entPlayer.worldObj, true);
					}
				}
			}
		}
		
		return armorbrightness;
	}
	
	private void TickItemEntity(net.minecraft.client.Minecraft mc, boolean newsecond, PlayerTorch torchLoopClass, Entity torchent)
	{
		torchLoopClass.setTorchPos(mc.theWorld, (float)torchent.posX, (float)torchent.posY, (float)torchent.posZ);
		
		if (torchLoopClass.hasDeathAge())
		{
			if (torchLoopClass.hasReachedDeathAge())
			{
				torchent.setEntityDead();
				PlayerTorchArray.RemoveTorchFromArray(mc.theWorld, torchLoopClass);
			}
			else if (newsecond)
			{
				torchLoopClass.doAgeTick();
			}
		}
	}
	
	private void UpdateBurningEntities(net.minecraft.client.Minecraft mc)
	{
		for(int k = 0; k < entityList.size(); k++) // we loop ALL entities
		{
			Entity tempent = (Entity)entityList.get(k);
			
			if (tempent.isBurning())
			{
				//mc.ingameGUI.addChatMessage("Found burning entity: " + tempent);
			
				PlayerTorch torchent = PlayerTorchArray.GetTorchForEntity(tempent);
			
				if (torchent == null) // if it is on fire and not yet a playertorch...
				{
					//mc.ingameGUI.addChatMessage("Burning ent has no Torch yet, adding");
				
					PlayerTorch newtorch = new PlayerTorch(tempent); // add one with torch data!
					PlayerTorchArray.AddTorchToArray(newtorch);
					newtorch.SetTorchBrightness(15);
					newtorch.SetTorchRange(31);
					newtorch.setTorchState(mc.theWorld, true);
				}
			}
		}
	}
	
	private void UpdateTorchEntities(World worldObj)
	{
		List tempList = new ArrayList();
	
		for(int k = 0; k < entityList.size(); k++)
		{
			Entity tempent = (Entity)entityList.get(k);
			
			if(tempent instanceof EntityPlayer)
			{
				tempList.add(tempent);
			}
			
			else if(tempent instanceof EntityItem)
			{
				EntityItem helpitem = (EntityItem)tempent;
				int brightness = PlayerTorchArray.GetItemBrightnessValue(helpitem.item.itemID);
				if (brightness > 0)
				{			
					tempList.add(tempent);
				}
			}
		}
		// tempList is now a fresh list of all Entities that can have a PlayerTorch
		
		for(int j = 0; j < PlayerTorchArray.torchArray.size(); j++) // loop the old PlayerTorch List
		{
			PlayerTorch torchLoopClass = (PlayerTorch)PlayerTorchArray.torchArray.get(j);
			Entity torchent = torchLoopClass.GetTorchEntity();
			
			if (tempList.contains(torchent)) // check if the old entities are still in the world
			{
				tempList.remove(torchent); // if so remove them from the fresh list
			}
			else if ((!torchLoopClass.IsTorchCustom() && !torchent.isBurning()) // exclude foreign modded torches and burning stuff
					|| torchent != null && !torchent.isEntityAlive()) // but do delete dead stuff
			{
				PlayerTorchArray.RemoveTorchFromArray(worldObj, torchLoopClass); // else remove them from the PlayerTorch list
			}
		}
		
		for(int l = 0; l < tempList.size(); l++) // now to loop the remainder of the fresh list, the NEW lights
		{
			Entity newent = (Entity)tempList.get(l);
			
			PlayerTorch newtorch = new PlayerTorch(newent);
			PlayerTorchArray.AddTorchToArray(newtorch);
			
			if(newent instanceof EntityItem)
			{
				EntityItem institem = (EntityItem)newent;
				newtorch.SetTorchBrightness(PlayerTorchArray.GetItemBrightnessValue(institem.item.itemID));
				newtorch.SetTorchRange(PlayerTorchArray.GetItemLightRangeValue(institem.item.itemID));
				newtorch.setDeathAge(PlayerTorchArray.GetItemDeathAgeValue(institem.item.itemID));
				newtorch.SetWorksUnderwater(PlayerTorchArray.GetItemWorksUnderWaterValue(institem.item.itemID));
				newtorch.setTorchState(worldObj, true);
			}
		}
	}
	
	private boolean hasTargetBlockChanged(EntityPlayer p)
	{
		double x = -MathHelper.sin((p.rotationYaw / 180F) * 3.141593F) * MathHelper.cos((p.rotationPitch / 180F) * 3.141593F);
		double z = MathHelper.cos((p.rotationYaw / 180F) * 3.141593F) * MathHelper.cos((p.rotationPitch / 180F) * 3.141593F);
		int targetX = MathHelper.floor_double(p.posX + x);
		int targetY = MathHelper.floor_double(p.posY) - 1;
		int targetZ = MathHelper.floor_double(p.posZ + z);
		int blockID = p.worldObj.getBlockId(targetX, targetY, targetZ);
		
		if (blockID != targetBlockID)
		{
			targetBlockID = blockID;
			return true;
		}
		
		return false;
	}
	
	public String Version()
	{
		return "v1.2.0";
	}
}