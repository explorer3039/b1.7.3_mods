Simply add the villager skin to the mobs folder, replace the ITEM.PNG in the GUI folder with the one in the
PNGS folder and finally add the class files to the Minecraft.JAR