Put files inside "Put in jar" folder into .minecraft/bin/minecraft.jar

Put mod_massdestruction.props into .minecraft foler

if you have black screen(possibly ID conflict), open mod_massdestruction.props and find the conflicting ID, then change it.
Be aware, items and blocks already exist before you change there IDs will be removed after that.

Thanks for using my mod! Hope you enjoy it.