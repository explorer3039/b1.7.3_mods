package net.minecraft.src;

import net.minecraft.client.Minecraft;

public class mod_FeatherFall extends BaseMod {

	@Override
	public String Version() {
		return "Beta v1.7.3";
	}

	protected mod_FeatherFall() {
		ModLoader.SetInGameHook(this, true, true);
	}

	@Override
	public boolean OnTickInGame(Minecraft mc) {
		if(mc.theWorld.multiplayerWorld) return true;

		// 
		ItemStack itemstack = mc.thePlayer.inventory.getCurrentItem();
		if(itemstack != null && itemstack.itemID == Item.feather.shiftedIndex)
		{
			//feather step
			int count = itemstack.stackSize;
			for( mc.thePlayer.stepHeight = 0.5f; count >= 1.0; count /= 2 ){
				mc.thePlayer.stepHeight += 0.67f;
			}

			//feather fall
			if(!mc.thePlayer.onGround && mc.thePlayer.motionY < 0) {
				count = itemstack.stackSize;
				while( (count/=2) >= 1 )
					mc.thePlayer.fallDistance *= .975;
			}
			return true;
		}
		//feather step no-op
		mc.thePlayer.stepHeight = 0.5f;

		//feather fall no-op
		return true;
	}


}
