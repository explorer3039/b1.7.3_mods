-------------------------------------------------------------------------------
---Contents--------------------------------------------------------------------
-------------------------------------------------------------------------------

Section 1  - General Information
Section 2  - Install Instructions
Section 3  - What's New (Changelog)
Section 4  - License

-------------------------------------------------------------------------------
---1. General Information------------------------------------------------------
-------------------------------------------------------------------------------

Created By: squirrelman
Version: 1.1
Mincraft Version: Beta 1.7.3
Thread: http://www.minecraftforum.net/topic/581402-173wip-japanese-mod/

-------------------------------------------------------------------------------
---2. Install Instructions-----------------------------------------------------
-------------------------------------------------------------------------------

1. Go to the minecraft bin directory and backup minecraft.jar
2. Using 7zip or equally capable ZIP viewer open minecraft.jar
3. Delete the META-INF folder
4. Copy ALL the ".class" files contained within the mod to minecraft.jar, replacing the existing files.
5. Close minecraft.jar

-------------------------------------------------------------------------------
---2. Install Instructions-----------------------------------------------------
-------------------------------------------------------------------------------

---V1.2------------------------------------------------------------------------

- added pocki
- added craftable cocoa

---V1.1------------------------------------------------------------------------

- Fixed Ninjas and readded em
- Added ghost ninjas
- Added only drop aquired katanas

---V1.0_1------------------------------------------------------------------------

-removed ninjas
- fixed durabilities

---V1.0------------------------------------------------------------------------

- added in a couple weapons
- craftable steel

-------------------------------------------------------------------------------
---3. License-----------------------------------------------------------------
-------------------------------------------------------------------------------

This software is Copyright �(2011) of simo_415 (hereafter referred to as "The Owner") 
and is the intellectual property of The Owner. Only Minecraftforum.net is able to host 
any of The Owner's material without the consent of The Owner. It may not be placed on 
any other web site or otherwise distributed publicly without advance written 
permission. (Electronic mail is acceptable as long as you wait for a response.) 