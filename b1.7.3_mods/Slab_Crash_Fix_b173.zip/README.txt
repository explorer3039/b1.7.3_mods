Slab Crash for 1.7.3 Fix by Johnanater

This fixes the Minecraft 1.7.3 slab crash, caused by a null item damage type. Such as 44:4, 44:5, etc

It doesn't give a name to the slab, it's just empty.

All of the original code belongs to Mojang.