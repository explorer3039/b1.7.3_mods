ModLoader and Minecraft version 1.7.3 are required

*The presentation:
http://www.youtube.com/watch?v=kCmsWWpEJps

*Installation:
We copy all files (except this) to minecraft.jar the same way as when installing ModLoader

* To operation:

** LEFT CONTROL = SPRINT

Hoping for HopBlock, we hold the sprint key

By setting blocks in different combinations, we get more punching power and thus our form
It flies a lot farther than the one from HopBlock, which is well shown in the movie.

By using HopBlock when falling from a high altitude, we do not lose our lives.

Hopping from one HopBlock to the other (while holding the sprint key), we multiply our speed.

* Crafting:

planks = X
leather = R
slimeball = S
air = 0

0 0 0
0 S 0
X R X

*Version:
SprintAndHopBlock 1.0.1