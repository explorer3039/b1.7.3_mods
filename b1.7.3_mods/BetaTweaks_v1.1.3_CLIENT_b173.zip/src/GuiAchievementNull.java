// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;

import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;

// Referenced classes of package net.minecraft.src:
//            Gui, RenderItem, StatCollector, Achievement, 
//            ScaledResolution, RenderHelper, FontRenderer, RenderEngine

public class GuiAchievementNull extends GuiAchievement
{

    public GuiAchievementNull(Minecraft minecraft)
    {
    	super(null);
    }

    public void updateAchievementWindow()
    {
  	
    }
}
