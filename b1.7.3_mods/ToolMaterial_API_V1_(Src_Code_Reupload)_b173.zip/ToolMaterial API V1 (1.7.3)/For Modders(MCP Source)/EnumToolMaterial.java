package net.minecraft.src;

public class EnumToolMaterial
{
    static EnumToolMaterial WOOD = new EnumToolMaterial("WOOD", 0, 0, 59, 2.0F, 0);
    static EnumToolMaterial STONE = new EnumToolMaterial("STONE", 1, 1, 131, 4F, 1);
    static EnumToolMaterial IRON = new EnumToolMaterial("IRON", 2, 2, 250, 6F, 2);
    static EnumToolMaterial EMERALD = new EnumToolMaterial("EMERALD", 3, 3, 1561, 8F, 3);
    static EnumToolMaterial GOLD = new EnumToolMaterial("GOLD", 4, 0, 32, 12F, 0);
    
    public EnumToolMaterial(String s, int i, int j, int k, float f, int l)
    {
    	harvestLevel = j;
        maxUses = k;
        efficiencyOnProperMaterial = f;
        damageVsEntity = l;
    }

    public int getMaxUses()
    {
        return maxUses;
    }

    public float getEfficiencyOnProperMaterial()
    {
        return efficiencyOnProperMaterial;
    }

    public int getDamageVsEntity()
    {
        return damageVsEntity;
    }

    public int getHarvestLevel()
    {
        return harvestLevel;
    }

    public int harvestLevel;
    public int maxUses;
    public float efficiencyOnProperMaterial;
    public int damageVsEntity;
    public static EnumToolMaterial field_21209_j[]; /* synthetic field */

    
    static 
    {	
        field_21209_j = (new EnumToolMaterial[] {
            WOOD, STONE, IRON, EMERALD, GOLD
        });
        
    }
}
