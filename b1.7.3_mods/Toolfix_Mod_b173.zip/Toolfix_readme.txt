Digital Cougar : 07/07/2011

These .class files adjust (correct!) the function of the pick, axe, shovel, and sword in Minecraft.

The Axe now works effectivly on all wooden blocks, including things like signs, fences, wooden pressure plates, and bookshelves. (Bookshelves still don't drop without another mod, though. Why not, Notch?)

Picks work on all stone and metal blocks, including furnaces, dispensers, and metal doors. Glass, too. (Glass still doesn't drop without another mod. Notch?)

The Shovel is now effective against all types of rails as well as dirt, gravel, etc. (It's easiest to dig up rails, don't you know?)

The Sword now does a little more damage against blocks and objects, for slightly faster harvesting of various things like cactus and whatnot. (It was barely doing more than a punch, before. Sword > Fist, so I tweaked it). It now only takes regular damage when used on thin plant materials like reeds, leaves, cactus, and pumpkins. 


The fixes to the tools work with or without ModLoader - they totally don't care. Add these files to your minecraft.jar to make the changes. They overwrite existing tool classes, so back up minecraft.jar so you can revert if you don't like it. Also, there will be conflicts with any other mods that change these classes. Anything that adds items, tools, or materials via ModLoader should be fine.

  Axes    - ta.class
  Picks   - au.class
  Shovels - wc.class
  Swords  - qd.class


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
Use this mod at your own risk! Although I have extensively playtested it, I cannot and will not guarantee that it won't cause your computer to spontaneously erupt into flames, your plants, pets and/or family members to wither and die, your power to go off, sunspots and solar eruptions, plagues, oceans of blood, demonic possessions, or monkeys to fly out of your butt. The author is not responsible for any damages, direct or consequential, that may result from its use.
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=