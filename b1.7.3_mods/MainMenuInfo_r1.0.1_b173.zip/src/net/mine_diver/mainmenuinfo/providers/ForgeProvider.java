package net.mine_diver.mainmenuinfo.providers;

import net.mine_diver.mainmenuinfo.api.IInfoProvider;
import net.minecraft.src.GuiScreen;
import net.minecraft.src.ModLoader;
import net.minecraft.src.mod_MainMenuInfo;

public class ForgeProvider implements IInfoProvider {
	
	@Override
	public String[] updateInfo(int color) {
		if (ForgeInstalled) {
			if (!ForgeVersion.equals(latestVersion)) {
				GuiScreen guiscreen = ModLoader.getMinecraftInstance().currentScreen;
				String s = "New Forge version available: " + latestVersion;
				guiscreen.drawString(mod_MainMenuInfo.PackageAccess.GuiScreen.getFontRenderer(guiscreen), s, guiscreen.width - s.length() * 5 - 2, guiscreen.height - 20, color);
			}
			return new String[] {"Minecraft Forge " + ForgeVersion};
		} else {
			return new String[]{};
		}
	}
	
	public static boolean ForgeInstalled = false;
	public static String latestVersion = "1.0.6";
	public static String ForgeVersion = "Undefined (1.0.0 - 1.0.4)";
	
	static {
		try {
			Class.forName("forge.MinecraftForge");
			ForgeInstalled = true;
		} catch (ClassNotFoundException e) {
			try {
				Class.forName("net.minecraft.src.forge.MinecraftForge");
				ForgeInstalled = true;
			} catch (ClassNotFoundException e1) {}
		}
		if (ForgeInstalled) {
			Class<?> forgehooks = null;
			try {
				forgehooks = Class.forName("forge.ForgeHooks");
			} catch (ClassNotFoundException e) {
				try {
					forgehooks = Class.forName("net.minecraft.src.forge.ForgeHooks");
				} catch (ClassNotFoundException e1) {}
			}
			if (forgehooks != null)
				try {
					ForgeVersion = forgehooks.getDeclaredField("majorVersion").get(null) +
							"." + forgehooks.getDeclaredField("minorVersion").get(null) +
							"." + forgehooks.getDeclaredField("revisionVersion").get(null);
				} catch (Exception e) {
					throw new RuntimeException(e);
				}
		}
	}
}
