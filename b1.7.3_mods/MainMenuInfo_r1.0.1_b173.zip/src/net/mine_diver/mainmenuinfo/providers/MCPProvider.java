package net.mine_diver.mainmenuinfo.providers;

import net.mine_diver.mainmenuinfo.api.IInfoProvider;

public class MCPProvider implements IInfoProvider {
	
	@Override
	public String[] updateInfo(int color) {
		return new String[]{"MCP " + MCPVersion};
	}
	
	public static String MCPVersion = "4.3";
}
