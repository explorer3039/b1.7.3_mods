package net.mine_diver.mainmenuinfo.providers;

import java.util.List;

import net.mine_diver.mainmenuinfo.api.IInfoProvider;
import net.minecraft.src.BaseMod;
import net.minecraft.src.ModLoader;

public class ModsProvider implements IInfoProvider {

	@Override
	public String[] updateInfo(int color) {
		@SuppressWarnings("unchecked")
		List<BaseMod> mods = ModLoader.getLoadedMods();
		return new String[]{mods.size() + " " + (mods.size() == 1 ? "mod" :  "mods") + " loaded, " + mods.size() + " " + (mods.size() == 1 ? "mod" :  "mods") + " active"};
	}

}
