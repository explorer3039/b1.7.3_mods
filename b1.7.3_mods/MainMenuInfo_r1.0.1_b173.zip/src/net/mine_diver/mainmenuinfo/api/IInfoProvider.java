package net.mine_diver.mainmenuinfo.api;

public interface IInfoProvider {
	String[] updateInfo(int color);
}
