package net.mine_diver.mainmenuinfo.gui;

import java.lang.reflect.Field;

import net.mine_diver.mainmenuinfo.proxy.FontRendererProxy;
import net.minecraft.src.GuiMainMenu;
import net.minecraft.src.GuiScreen;
import net.minecraft.src.mod_MainMenuInfo.PackageAccess;
import sun.misc.Unsafe;

public class GUIHandler {
	
	public void setGuiScreen(GuiScreen guiscreen) {
		currentGuiScreen = guiscreen;
	}
	
	public void tick() {
		if (currentGuiScreen instanceof GuiMainMenu
				&& !(PackageAccess.GuiScreen.getFontRenderer(currentGuiScreen) instanceof FontRendererProxy)) {
			try {
				FontRendererProxy proxy = (FontRendererProxy) unsafe.allocateInstance(FontRendererProxy.class);
				proxy.initSuper(PackageAccess.GuiScreen.getFontRenderer(currentGuiScreen));
				proxy.target = currentGuiScreen;
				proxy.infoRender = new InfoRender();
				PackageAccess.GuiScreen.setFontRenderer(currentGuiScreen, proxy);
			} catch (InstantiationException e) {
				throw new RuntimeException(e);
			}
		}
	}
	
	private GuiScreen currentGuiScreen;
	
	private static final Unsafe unsafe;
	static {
		Unsafe instance = null;
		try {
			Field field = Unsafe.class.getDeclaredField("theUnsafe");
			field.setAccessible(true);
			instance = (Unsafe) field.get(null);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		unsafe = instance;
	}
}
