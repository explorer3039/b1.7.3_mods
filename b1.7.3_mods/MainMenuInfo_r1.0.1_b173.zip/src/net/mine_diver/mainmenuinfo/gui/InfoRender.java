package net.mine_diver.mainmenuinfo.gui;

import java.util.ArrayList;
import java.util.List;

import net.mine_diver.mainmenuinfo.api.IInfoProvider;
import net.minecraft.src.FontRenderer;
import net.minecraft.src.GuiScreen;
import net.minecraft.src.mod_MainMenuInfo.PackageAccess;

public class InfoRender {
	public int drawPanoramaInfo(GuiScreen guiscreen, int color) {
		FontRenderer fontrenderer = PackageAccess.GuiScreen.getFontRenderer(guiscreen);
		int i = 0;
		for (IInfoProvider provider : providers)
			for (String line : provider.updateInfo(color)) {
				i+=10;
				fontrenderer.drawStringWithShadow(line, 2, guiscreen.height - i, color);
			}
		return i;
	}
	
	public static final List<IInfoProvider> providers = new ArrayList<IInfoProvider>();
}
