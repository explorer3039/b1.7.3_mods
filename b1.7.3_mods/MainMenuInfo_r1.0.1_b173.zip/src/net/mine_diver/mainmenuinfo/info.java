package net.mine_diver.mainmenuinfo;

public class info {
	public static final String NAME = "MainMenu Info";
	public static final String DESCRIPTION = "Modern Forge-like MainMenu info";
	public static final String VERSION = "r1.0.1";
}
