package net.minecraft.src;

import net.mine_diver.mainmenuinfo.Core;
import net.mine_diver.mainmenuinfo.info;
import net.minecraft.client.Minecraft;

public class mod_MainMenuInfo extends BaseMod {
	
	public String Name() {
		return info.NAME;
	}
	
	public String Description() {
		return info.DESCRIPTION;
	}

	@Override
	public String Version() {
		return info.VERSION;
	}
	
	public mod_MainMenuInfo() {
		CORE.init(this);
	}
	
	@Override
	public boolean OnTickInGUI(Minecraft minecraft, GuiScreen guiscreen) {
		CORE.onTickInGUIEvent(guiscreen);
		return true;
	}
	
	public static final Core CORE = new Core();
	
	public static class PackageAccess {
		public static class GuiScreen {
			public static FontRenderer getFontRenderer(net.minecraft.src.GuiScreen guiscreen) {
				return guiscreen.fontRenderer;
			}
			
			public static void setFontRenderer(net.minecraft.src.GuiScreen guiscreen, FontRenderer fontrenderer) {
				guiscreen.fontRenderer = fontrenderer;
			}
		}
	}
}
