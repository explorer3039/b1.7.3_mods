Rways 1.7.3v1
by thethirdmike

Installation Instructions for PCs
1. Use WinRAR or a similar file utility to open up minecraft.jar.
2. Place the class files and the 'thethirdmike' folder in 'jarfiles' into minecraft.jar
3. Delete the META-INF folder in minecraft.jar!
4. Place the file mod_Rways.props into your .minecraft directory.
5. Start Minecraft.
6. If you get an ID conflict, open up mod_Rways.props and change the conflicting ID(s) to something else.

Installation Instructions for Macs
1. Buy a PC.
2. Follow above instructions.
(But seriously folks, I don't have a Mac, so I have no idea. 
Go find a mod that does have Mac instructions and they will probably work for this too.)