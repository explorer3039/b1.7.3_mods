
   MAtmos
   
   
    More information on:
      Minecraftforum http://goo.gl/wLTaJ


   INSTALL NOTES
   
:In this note, "archive" will refer to the ZIP you have extracted in order to read this Readme.


1a) ModLoader is required. ( http://www.minecraftforum.net/topic/75440-v166-risugamis-mods-updates/ )

1b) This mod WILL WORK with MCPatcher contrary to what have been said before.
    The HD Textures Mod from MCPatcher is compatible with this mod.
    However, ModLoader may conflict with BetterGrass/GrassMod.



The installation is better explained in the thread: http://goo.gl/wLTaJ

2) The .class files contained in this archive within the folder "CLASSFILES" should go directly into the "(Roaming)/.minecraft/bin/minecraft.jar" using a file archive editor.

3) You have to move the contents of this archive "minecraft" folder to your actual "(Roaming)/.minecraft/" folder where Minecraft save data in installed.

You can usually find the location of the (Roaming) folder by doing this:
Run Minecraft Launcher, and DON'T LOG IN but press the Options button above the Login button. The location should be written and accessible in the popup that opens there, which is clickable.


- On Windows, this is usually located in %appdata%/.minecraft.
- On Mac, it should be on ~/Library/Application Support/minecraft where ~ is your username.
  Caution, it can be tricky as Mac hides some folders. Read the forums for more info.
- On Linux, perform a "locate .minecraft", it should do it.


At the end, you should have a file structure similar to this:

- .minecraft/bin/minecraft.jar[/mod_MAtmosphere.class] (for example)
- .minecraft/resources/newsound/atmos_hl/ (in general)
- .minecraft/resources/newsound/atmos_hl/atmosphere/cave_hit1.wav (for example)
- .minecraft/matmos_default.dat
- .minecraft/matmos_append.dat
- .minecraft/matmos_translation_datavalues.dat
- .minecraft/matmos_translation_instant.dat

---

?) What is the patch.properties file?

It's supposed to be a file used by a Mod Manager (TFC Mod Manager) to install the pack.
I couldn't test it since I couldn't register onto their website, so be careful.

You don't need to place this file anywhere.
