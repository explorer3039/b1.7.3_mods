package net.minecraft.src;

import java.io.*;
import java.util.*;
import net.minecraft.client.Minecraft;
import net.minecraft.src.lawnMower.core.*;

public class mod_LawnMower extends BaseMod {
	
	private static int ids[] = getIDs();
	public static final Item lawnMower = new ItemLawnMower(ids[0]);
	public static final Item lawnMowerKey = new Item(ids[1]).setIconIndex(ModLoader.addOverride("/gui/items.png", "/lawnMower/textures/lawnmowerkey.png")).setMaxStackSize(1).setItemName("lawnMowerKey");
	public static final Item wrench = new Item(ids[2]).setIconIndex(ModLoader.addOverride("/gui/items.png", "/lawnMower/textures/wrench.png")).setMaxStackSize(1).setMaxDamage(100).setItemName("wrench");
	private HUDLawnMower lawnMowerHUD = new HUDLawnMower(ModLoader.getMinecraftInstance());

	public mod_LawnMower() {
		ModLoader.AddName(wrench, "Wrench");
		ModLoader.AddShapelessRecipe(new ItemStack(wrench, 1), new Object[] {
			new ItemStack(Item.ingotIron) , new ItemStack(Item.coal)});
		ModLoader.AddName(lawnMowerKey, "Lawn Mower Key");
		ModLoader.AddShapelessRecipe(new ItemStack(lawnMowerKey, 1), new Object[] {
			new ItemStack(Item.ingotIron) , new ItemStack(Item.seeds)});
		ModLoader.AddName(lawnMower, "Lawn Mower");
		ModLoader.AddRecipe(new ItemStack(lawnMower, 1), new Object[] {
			" B ", "III", Character.valueOf('B'), Item.boat, Character.valueOf('I'), Item.ingotIron });
		ModLoader.RegisterEntityID(EntityLawnMower.class, "Lawn Mower", ModLoader.getUniqueEntityId());
		ModLoader.SetInGameHook(this, true, false);
	}
	
	private static int[] getIDs() {
		int ids[]={31455,31456,31457};
		FileInputStream propFile = null;
		Properties mowerProps = new Properties();
		try {
			propFile = new FileInputStream(Minecraft.getMinecraftDir().toString()+"/LawnMower.properties");
			mowerProps.load(propFile);
			ids[0]=Integer.parseInt(mowerProps.getProperty("LawnMowerID", "31455"));
			ids[1]=Integer.parseInt(mowerProps.getProperty("LawnMowerKeyID", "31456"));
			ids[2]=Integer.parseInt(mowerProps.getProperty("WrenchID", "31457"));
		} catch (Exception e){
		} finally {
			if(propFile!=null)
				try {propFile.close();} catch (IOException e){}
		}
		return ids;
	}

	@Override
	public boolean OnTickInGame(Minecraft game) {
		if(game.thePlayer.ridingEntity != null && game.thePlayer.ridingEntity instanceof EntityLawnMower && game.currentScreen==null && !game.isGamePaused)
			lawnMowerHUD.renderSkillHUD((EntityLawnMower) game.thePlayer.ridingEntity);
		return true;
    }

	@Override
	@SuppressWarnings({"rawtypes", "unchecked"})
	public void AddRenderer(Map map) {
		map.put(EntityLawnMower.class, new RenderLawnMower());
	}
	
	@Override
	public String Version() {
		return "for MC Beta 1.7.3";
	}
}
