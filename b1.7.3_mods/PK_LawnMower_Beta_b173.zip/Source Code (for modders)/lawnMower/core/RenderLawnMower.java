package net.minecraft.src.lawnMower.core;

import net.minecraft.src.*;
import org.lwjgl.opengl.GL11;

public class RenderLawnMower extends Render {

	protected ModelLawnMower modelLawnMower = new ModelLawnMower();

	public RenderLawnMower() {
		shadowSize = 0.5F;
	}

	public void doRender(Entity lawnMower, double posX, double posY, double posZ, float yaw, float pitch) {
		GL11.glPushMatrix();
		GL11.glTranslatef((float) posX, (float) posY, (float) posZ);
		GL11.glRotatef(180F - yaw, 0.0F, 1.0F, 0.0F);
		GL11.glScalef(-1F, -1F, 1F);
		loadTexture("/lawnMower/textures/lawnmowerbody.png");
		modelLawnMower.renderBody();
		loadTexture("/lawnMower/textures/lawnmowerblades.png");
		modelLawnMower.renderBlades((EntityLawnMower) lawnMower);
		GL11.glPopMatrix();
	}
}