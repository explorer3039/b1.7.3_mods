package net.minecraft.src.lawnMower.core;

import net.minecraft.src.*;

public class ModelLawnMower extends ModelBase {

	public ModelRenderer lawnMowerSides[];
	public ModelRenderer blades;

	public ModelLawnMower() {
        lawnMowerSides = new ModelRenderer[5];
        lawnMowerSides[0] = new ModelRenderer(0, 8);
        lawnMowerSides[1] = new ModelRenderer(0, 0);
        lawnMowerSides[2] = new ModelRenderer(0, 0);
        lawnMowerSides[3] = new ModelRenderer(0, 0);
        lawnMowerSides[4] = new ModelRenderer(0, 0);
        byte byte0 = 24;
        byte byte1 = 6;
        byte byte2 = 20;
        byte byte3 = 4;
        lawnMowerSides[0].addBox(-byte0 / 2, -byte2 / 2 + 2, -3F, byte0, byte2 - 4, 4, 0.0F);
        lawnMowerSides[0].setRotationPoint(0.0F, 0 + byte3, 0.0F);
        lawnMowerSides[1].addBox(-byte0 / 2 + 2, -byte1 - 1, -1F, byte0 - 4, byte1, 2, 0.0F);
        lawnMowerSides[1].setRotationPoint(-byte0 / 2 + 1, 0 + byte3, 0.0F);
        lawnMowerSides[2].addBox(-byte0 / 2 + 2, -byte1 - 1, -1F, byte0 - 4, byte1, 2, 0.0F);
        lawnMowerSides[2].setRotationPoint(byte0 / 2 - 1, 0 + byte3, 0.0F);
        lawnMowerSides[3].addBox(-byte0 / 2 + 2, -byte1 - 1, -1F, byte0 - 4, byte1, 2, 0.0F);
        lawnMowerSides[3].setRotationPoint(0.0F, 0 + byte3, -byte2 / 2 + 1);
        lawnMowerSides[4].addBox(-byte0 / 2 + 2, -byte1 - 1, -1F, byte0 - 4, byte1, 2, 0.0F);
        lawnMowerSides[4].setRotationPoint(0.0F, 0 + byte3, byte2 / 2 - 1);
        lawnMowerSides[0].rotateAngleX = 1.570796F;
        lawnMowerSides[1].rotateAngleY = 4.712389F;
        lawnMowerSides[2].rotateAngleY = 1.570796F;
        lawnMowerSides[3].rotateAngleY = 3.141593F;
        
        blades = new ModelRenderer(0, 0);
        blades.addBox(-3F, -3F, -10.5F, 6, 6, 21, 0);
        blades.setRotationPoint(-12, 4, 0);
    }

	public void renderBody() {
		for (int i = 0; i < 5; i++)
			lawnMowerSides[i].render(0.0625F);
	}

	public void renderBlades(EntityLawnMower lawnMower) {
		blades.rotateAngleZ = lawnMower.bladesAngle;
		blades.render(0.0625F);
	}
}