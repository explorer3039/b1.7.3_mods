package net.minecraft.src.lawnMower.core;

import org.lwjgl.opengl.GL11;
import net.minecraft.src.*;
import net.minecraft.client.Minecraft;

public class HUDLawnMower {
	
	private Minecraft game;
	private int windowWidth, wave = 0;

	public HUDLawnMower(Minecraft game) {
		this.game = game;
	}
	
	public void renderSkillHUD(EntityLawnMower rcCar) {
		windowWidth = new ScaledResolution(game.gameSettings, game.displayWidth, game.displayHeight).getScaledWidth();
		
		renderBG();
		renderHealthBar(rcCar);
		renderFuelBar(rcCar);
		renderSpeedometer(rcCar);
		
		if(wave>360)
			wave=0;
		wave += 20;
	}

	private void renderBG() {
		GL11.glEnable(3042 /*GL_BLEND*/);
		GL11.glBindTexture(3553, game.renderEngine.getTexture("/lawnMower/textures/lawnmowerhud.png"));
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.5F);
		game.ingameGUI.drawTexturedModalRect((windowWidth-155)/2, 0, 0, 0, 155, 44);
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
	}

	private void renderHealthBar(EntityLawnMower lawnMower) {
		game.ingameGUI.drawTexturedModalRect((windowWidth-102)/2 + 19, 10 - 5, 0, 44, 102, 8);
		if(lawnMower.health*2<=15)
			GL11.glColor4f(1.0F, 1.0F, 1.0F, (float) ((Math.sin(Math.toRadians(wave))/2)+0.5));
		game.ingameGUI.drawTexturedModalRect((windowWidth-102)/2 + 19 + 1, 10 + 1 - 5, 0, 44+8, lawnMower.health*2, 6);
		game.fontRenderer.drawStringWithShadow("Health:", windowWidth/2 - 68, 10 - 5, 0xFFFFFF);
	}
	
	private void renderFuelBar(EntityLawnMower lawnMower) {
		GL11.glBindTexture(3553, game.renderEngine.getTexture("/lawnMower/textures/lawnmowerhud.png"));
		game.ingameGUI.drawTexturedModalRect((windowWidth-102)/2 + 19, 10 + 5, 0, 44, 102, 8);
		if(lawnMower.fuel<=15)
			GL11.glColor4f(1.0F, 1.0F, 1.0F, (float) ((Math.sin(Math.toRadians(wave))/2)+0.5));
		game.ingameGUI.drawTexturedModalRect((windowWidth-102)/2 + 19 + 1, 10 + 1 + 5, 0, 44+14, lawnMower.fuel, 6);
		game.fontRenderer.drawStringWithShadow("Fuel:", windowWidth/2 - 68, 10 + 5, 0xFFFFFF);
	}
	
	private void renderSpeedometer(EntityLawnMower lawnMower) {
		game.fontRenderer.drawStringWithShadow("Speed: " + ((float)Math.round((float)(lawnMower.speed*10)))/10 + " bps on " + lawnMower.drivingOn, windowWidth/2 - 68 + 6, 29, 0xFFFFFF);
		GL11.glDisable(3042 /*GL_BLEND*/);
	}
}