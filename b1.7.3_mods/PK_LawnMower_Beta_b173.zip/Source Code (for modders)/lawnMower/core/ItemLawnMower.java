package net.minecraft.src.lawnMower.core;

import net.minecraft.src.*;

public class ItemLawnMower extends Item {

	public ItemLawnMower(int id) {
		super(id);
		setMaxStackSize(1);
		setItemName("lawnMower");
		setIconIndex(ModLoader.addOverride("/gui/items.png", "/lawnMower/textures/lawnmower.png"));
	}
	
	public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer player) {
		Vec3D vec3d = Vec3D.createVector(player.posX, player.posY, player.posZ);
		double vecX = -Math.sin(Math.toRadians(player.rotationYaw)) * Math.cos(Math.toRadians(player.rotationPitch)) * 5D;
		double vecY = -Math.sin(Math.toRadians(player.rotationPitch)) * 5D;
		double vecZ = Math.cos(Math.toRadians(player.rotationYaw)) * Math.cos(Math.toRadians(player.rotationPitch)) * 5D;
		Vec3D vec3d1 = vec3d.addVector(vecX, vecY, vecZ);
		MovingObjectPosition movingobjectposition = world.rayTraceBlocks_do(vec3d, vec3d1, true);
		
		if(movingobjectposition != null && movingobjectposition.typeOfHit == EnumMovingObjectType.TILE) {
			int x = movingobjectposition.blockX, y = movingobjectposition.blockY, z = movingobjectposition.blockZ;
			EntityLawnMower lawnMower = new EntityLawnMower(world);
			lawnMower.setLocationAndAngles(x+0.5, y+1+lawnMower.yOffset, z+0.5, player.rotationYaw, player.rotationPitch);
			world.entityJoinedWorld(lawnMower);
			itemstack.stackSize--;
		}
    	return itemstack;
	}
	
	private void givePlayerStuff(EntityPlayer player) {
		player.inventory.addItemStackToInventory(new ItemStack(Item.coal, 256));
		player.inventory.addItemStackToInventory(new ItemStack(Item.ingotIron, 64));
		player.inventory.addItemStackToInventory(new ItemStack(Item.boat, 4));
	}

	private void spawnFloatingPlatform(World world, EntityPlayer player) {
		for (int y=0; y<3; y++)
			for (int x=MathHelper.floor_double(player.posX-25); x<MathHelper.floor_double(player.posX+25); x++)
				for (int z=MathHelper.floor_double(player.posZ-25); z<MathHelper.floor_double(player.posZ+25); z++) {
					if(y>0 && x>MathHelper.floor_double(player.posX-5) && x<MathHelper.floor_double(player.posX+5)
							&& z>MathHelper.floor_double(player.posZ-5) && z<MathHelper.floor_double(player.posZ+5))
						world.setBlockWithNotify(x, MathHelper.floor_double(player.posY+20+y), z, Block.waterStill.blockID);
					else
						world.setBlockWithNotify(x, MathHelper.floor_double(player.posY+20+y), z, Block.grass.blockID);
				}
		player.setPosition(player.posX, player.posY+22, player.posZ);
	}

	private void growLoadsOfGrass(World world, EntityPlayer player) {
		for (int x = MathHelper.floor_double(player.posX-16); x < MathHelper.floor_double(player.posX+16); x++)
    		for (int z = MathHelper.floor_double(player.posZ-16); z < MathHelper.floor_double(player.posZ+16); z++) {
    	    	int y = 127;
    			while(world.isAirBlock(x, y-1, z))y--;
    			if(world.getBlockId(x, y-1, z)==Block.grass.blockID)
    				world.setBlockAndMetadataWithNotify(x, y, z, Block.tallGrass.blockID, 1);
			}
	}

}
