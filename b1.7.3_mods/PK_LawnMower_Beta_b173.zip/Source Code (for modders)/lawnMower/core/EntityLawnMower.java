package net.minecraft.src.lawnMower.core;

import java.util.List;
import org.lwjgl.input.Keyboard;
import net.minecraft.client.Minecraft;
import net.minecraft.src.*;
import net.minecraft.src.lawnMower.gui.*;

public class EntityLawnMower extends Entity{

	public Minecraft game = ModLoader.getMinecraftInstance();
	private final int pseudoHandling = 18, fuelDuration = 400;
	private InventoryLawnMower cargo;
	private double fwdVelocity = 0;
	public float bladesAngle = (float) (Math.PI/4);
	public String drivingOn = "Air";
	public int health=50, fuel=0, fuelTimer=0, waterTimer=0;
	public double speed = 0;
	
	public EntityLawnMower(World world) {
		super(world);
		cargo = new InventoryLawnMower(this, game.thePlayer);
		preventEntitySpawning = true;
		setSize(0.98F, 0.98F);
		yOffset = height/2;
	}

	protected void entityInit() {
	}
	
	protected boolean canTriggerWalking() {
		return false;
	}
	
	public boolean canBeCollidedWith() {
		return !isDead;
	}

	public AxisAlignedBB getCollisionBox(Entity entity) {
		return entity.boundingBox;
	}

	public AxisAlignedBB getBoundingBox() {
		return boundingBox;
	}

	public double getMountedYOffset() {
		return (double) height * 0.0D - 0.3D;
	}

	public boolean damage(int damage) {
		if (isDead)
			return true;
		health-=damage;
		if(health<=0) {
			health=0;
			setEntityDead();
			onDeath();
		}
		setBeenAttacked();
		return true;
	}

	public void onUpdate() {
        super.onUpdate();
		updateMotionAndRotation();
        //updateRotation();
        handleEntityCollisions();
		handleBlockCollisions();
		handleDamage();
		handleSoundEffects();
		handleParticleEffects();
		
        if(riddenByEntity != null && riddenByEntity.isDead)
            riddenByEntity = null;
    }

	private void updateMotionAndRotation() {
		if(riddenByEntity == null)
			fwdVelocity*=0.9;
		else {
			if(Keyboard.isKeyDown(game.gameSettings.keyBindForward.keyCode) && game.currentScreen==null)
				fwdVelocity+=0.02;
			if (Keyboard.isKeyDown(game.gameSettings.keyBindBack.keyCode) && game.currentScreen==null)
				fwdVelocity-=0.02;
			if(cargo.getStackInSlot(0)==null)
				fwdVelocity=0;
			if(onGround && fwdVelocity != 0) {
				if (Keyboard.isKeyDown(game.gameSettings.keyBindRight.keyCode) && game.currentScreen==null) {
					rotationYaw+=pseudoHandling*fwdVelocity;}
				if (Keyboard.isKeyDown(game.gameSettings.keyBindLeft.keyCode) && game.currentScreen==null) {
					rotationYaw-=pseudoHandling*fwdVelocity;}
			}
		}
		moveForward();
		setVelocity(motionX*0.5,motionY>-2?motionY-0.08:motionY,motionZ*0.5);
		moveEntity(motionX, motionY, motionZ);
		updateSpeedBladesFuel();
	}

	private void moveForward() {
		motionX += -Math.cos(Math.toRadians(rotationYaw))*fwdVelocity;
		motionZ += -Math.sin(Math.toRadians(rotationYaw))*fwdVelocity;
		if (onGround) {
			int id = worldObj.getBlockId(MathHelper.floor_double(posX),
					MathHelper.floor_double(boundingBox.minY) - 1,
					MathHelper.floor_double(posZ));
			if (id!=Block.grass.blockID && id!=Block.dirt.blockID)
				setVelocity(motionX*0.5,motionY,motionZ*0.5);
			drivingOn = Block.blocksList[id]!=null?StringTranslate.getInstance().translateNamedKey(Block.blocksList[id].getBlockName()):"Air";
			fwdVelocity*=0.92;
		} else {
			fwdVelocity*=0.95;
			drivingOn = "Air";
		}
		if (isInWater())
			setVelocity(motionX*0.5,motionY*0.5,motionZ*0.5);
		if(fwdVelocity<0.01 && fwdVelocity>-0.01)
			fwdVelocity = 0;
	}

	private void updateSpeedBladesFuel() {
		speed  = Math.sqrt(motionX * motionX + motionZ * motionZ)*25;
		if(speed<0.01 && speed>-0.01)
			speed = 0;
		if(!game.isGamePaused) {
			bladesAngle += (float) speed/4;
			bladesAngle = bladesAngle>=360?bladesAngle-360:bladesAngle;
			bladesAngle = bladesAngle<0?bladesAngle+360:bladesAngle;
		}
		fuelTimer-=Math.ceil(speed);
		if(fuelTimer<1) {
			cargo.decrStackSize(0, 1);
			fuelTimer=fuelDuration;
		}
	}

	private void handleEntityCollisions() {
		@SuppressWarnings("unchecked")
		List<Entity> list = worldObj.getEntitiesWithinAABBExcludingEntity(this, boundingBox.expand(0.2, 0.0, 0.2));
		for (Entity entity : list) {
			if(entity instanceof EntityItem && ((EntityItem) entity).item.itemID==Item.seeds.shiftedIndex)
				if(cargo.addItemStackToCargo(new ItemStack(Item.seeds, ((EntityItem) entity).item.stackSize)))
					entity.setEntityDead();
			if(riddenByEntity!=null && entity!=riddenByEntity && entity instanceof EntityLiving && speed>0)
				if(entity.attackEntityFrom(this, 4))
					worldObj.playSoundAtEntity(entity, "damage.hurtflesh", 1F, 0.5F);
			if(entity != riddenByEntity && entity.canBePushed())
				entity.applyEntityCollision(this);
		}
	}
	
	private void handleBlockCollisions() {
		if(this.isInWater()) 
			waterTimer++;
		else
			waterTimer=0;
		if(waterTimer>20) {
			damage(1);
			waterTimer=0;
		}
		
		for (int i = 0; i < 4; i++) {
            int x = MathHelper.floor_double(posX + ((double)(i % 2) - 0.5) * 0.8);
            int y = MathHelper.floor_double(posY);
            int z = MathHelper.floor_double(posZ + ((double)(i / 2) - 0.5) * 0.8);
            int id = worldObj.getBlockId(x, y, z);
            if(id == Block.tallGrass.blockID && riddenByEntity!=null) {
                worldObj.setBlockWithNotify(x, y, z, 0);
                if(rand.nextInt(8) == 0 && !cargo.addItemStackToCargo(new ItemStack(Item.seeds)))
					worldObj.entityJoinedWorld(new EntityItem(worldObj, x+0.5, y+0.5, z+0.5, new ItemStack(Item.seeds)));
            }
        }
	}
	
	private void handleDamage() {
		if(health*2<=15 && rand.nextInt(100)<5)
			damage(1);
	}
	
	private void handleSoundEffects() {
		if(riddenByEntity!=null && fuel>0)
			worldObj.playSoundAtEntity(this, "lawnmower", 0.1F + (float)(speed/7), (float)(speed/6));
	}
	
	private void handleParticleEffects() {
		if(speed > 0.145*25 && drivingOn.equals("Grass")) {
			double d12 = Math.cos(((double)rotationYaw * Math.PI) / 180D);
			double d15 = Math.sin(((double)rotationYaw * Math.PI) / 180D);
			for(int i1 = 0; (double)i1 < 1.0D + speed * 60D; i1++) {
				double d18 = rand.nextFloat() * 2.0F - 1.0F;
				double d20 = (double)(rand.nextInt(2) * 2 - 1) * 0.7;
				if(rand.nextInt(100)==0) {
					if(rand.nextBoolean()) {
						double x = (posX - d12 * d18 * 0.8) + d15 * d20;
						double z = posZ - d15 * d18 * 0.8 - d12 * d20;
						game.effectRenderer.addEffect(new EntitySlimeFX(worldObj, x, posY - 0.125D, z, Item.seeds));
					} else {
						double x = posX + d12 + d15 * d18 * 0.7;
						double z = (posZ + d15) - d12 * d18 * 0.7;
						game.effectRenderer.addEffect(new EntitySlimeFX(worldObj, x, posY - 0.125D, z, Item.seeds));
					}
				}
			}
			
		}
		if(health*2<=25) {
			double xOffset = Math.cos(Math.toRadians(rotationYaw+50-rand.nextInt(101))) * -0.8;
            double zOffset = Math.sin(Math.toRadians(rotationYaw+50-rand.nextInt(101))) * -0.8;
            worldObj.spawnParticle("smoke", posX+xOffset, posY, posZ+zOffset, 0, 0, 0);
            if(health*2<=15)
            	worldObj.spawnParticle("flame", posX+xOffset, posY, posZ+zOffset, 0, 0, 0);
		}
			
	}
	
	public void updateRiderPosition() {
		if (riddenByEntity != null) {
			double xOffset = Math.cos(Math.toRadians(rotationYaw)) * 0.4;
			double zOffset = Math.sin(Math.toRadians(rotationYaw)) * 0.4;
			riddenByEntity.setPosition(posX + xOffset, posY + getMountedYOffset() + riddenByEntity.getYOffset(), posZ + zOffset);
		}
	}

	protected void writeEntityToNBT(NBTTagCompound nbttagcompound) {
		nbttagcompound.setTag("Cargo", cargo.writeToNBT(new NBTTagList()));
	}

	protected void readEntityFromNBT(NBTTagCompound nbttagcompound) {
        cargo.readFromNBT(nbttagcompound.getTagList("Cargo"));
	}

	public float getShadowSize() {
		return 0.0F;
	}

	public boolean interact(EntityPlayer player) {
		ItemStack heldItem = player.getCurrentEquippedItem();
		if(heldItem!=null) {
			if(heldItem.itemID==Item.coal.shiftedIndex) {
				if(cargo.addFuel()) {
					heldItem.stackSize--;
					if(heldItem.stackSize<=0)
						player.inventory.mainInventory[player.inventory.currentItem] = null;
					return true;
				}
				return false;
			}
			if(heldItem.itemID==mod_LawnMower.wrench.shiftedIndex) {
				if(health<50) {
					health++;
					heldItem.damageItem(1, player);
					if(heldItem.getItemDamage()<=0)
						player.inventory.mainInventory[player.inventory.currentItem] = null;
					worldObj.playSoundAtEntity(this, "note.hat", 1F, 1F);
					return true;
				}
				return false;
			}
			if(heldItem.itemID==mod_LawnMower.lawnMowerKey.shiftedIndex) {
				if(riddenByEntity == null || riddenByEntity == player || !(riddenByEntity instanceof EntityPlayer)) {
					if(riddenByEntity==null)
						worldObj.playSoundAtEntity(this, "ignition", 1F, 1F);
					player.mountEntity(this);
					return true;
				}
				return false;
			}
		}
		ModLoader.OpenGUI(player, new GuiLawnMower(cargo, player.inventory));
        return true;
    }
	
	public boolean attackEntityFrom(Entity entity, int damage) {
		setBeenAttacked();
		damage(damage);
		return true;
	}
	
	private void onDeath() {
		worldObj.createExplosion(this, posX, posY, posZ, fuel/25);
		cargo.cargo[0]=null;
		cargo.dropCargo();
	}
}