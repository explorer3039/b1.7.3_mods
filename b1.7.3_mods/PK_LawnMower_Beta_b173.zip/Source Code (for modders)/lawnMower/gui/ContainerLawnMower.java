package net.minecraft.src.lawnMower.gui;

import net.minecraft.src.*;

public class ContainerLawnMower extends Container {

	public ContainerLawnMower(InventoryLawnMower cargo, InventoryPlayer playerInv) {
		addSlot(new SlotLawnMower(cargo, 0, 30, 35));
		for (int row=0; row<2; row++)
			for (int col=0; col<2; col++)
				addSlot(new SlotLawnMower(cargo, 1+row+(col*2), 102+col*18, 26+row*18));
		for(int i = 0; i < 3; i++)
			for(int k = 0; k < 9; k++)
				addSlot(new Slot(playerInv, k + i * 9 + 9, 8 + k * 18, 84 + i * 18));
		for(int j = 0; j < 9; j++)
			addSlot(new Slot(playerInv, j, 8 + j * 18, 142));
	}

	@Override
	public boolean isUsableByPlayer(EntityPlayer entityplayer) {
		return true;
	}
}
