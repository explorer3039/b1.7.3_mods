package net.minecraft.src.lawnMower.gui;

import net.minecraft.src.*;
import org.lwjgl.opengl.GL11;

public class GuiLawnMower extends GuiContainer {

	public GuiLawnMower(InventoryLawnMower cargo, InventoryPlayer playerInv) {
		super(new ContainerLawnMower(cargo, playerInv));
	}

	protected void drawGuiContainerForegroundLayer() {
		fontRenderer.drawString("Fuel", 10, 10, 0x005939);
		fontRenderer.drawString("Cargo", 100, 10, 0x005939);
		fontRenderer.drawString("Inventory", 8, 72, 0x005939);
	}

	protected void drawGuiContainerBackgroundLayer(float f) {
		mc.renderEngine.bindTexture(mc.renderEngine.getTexture("/lawnMower/textures/lawnmowergui.png"));
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		drawTexturedModalRect((width-xSize)/2, (height-ySize)/2, 0, 0, xSize, ySize);
	}
	
	public void onGuiClosed() {
		super.onGuiClosed();
		inventorySlots.getSlot(0).onSlotChanged();
	}
}
