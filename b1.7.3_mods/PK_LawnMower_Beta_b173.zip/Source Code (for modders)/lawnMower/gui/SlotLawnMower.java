package net.minecraft.src.lawnMower.gui;

import net.minecraft.src.*;

class SlotLawnMower extends Slot {

	private int slotIndex;
	
	SlotLawnMower(IInventory iinventory, int slotIndex, int posX, int posY) {
		super(iinventory, slotIndex, posX, posY);
		this.slotIndex = slotIndex;
	}

	@Override
	public int getSlotStackLimit() {
		return slotIndex==0?100:64;
		//This doesn't work.
	}

	@Override
	public boolean isItemValid(ItemStack itemstack) {
		if (slotIndex == 0 && itemstack.itemID == Item.coal.shiftedIndex)
			return true;
		if (slotIndex > 0 && itemstack.itemID == Item.seeds.shiftedIndex)
			return true;
		return false;
	}
}