package net.minecraft.src.lawnMower.gui;

import java.util.Random;
import net.minecraft.src.*;
import net.minecraft.src.lawnMower.core.EntityLawnMower;

public class InventoryLawnMower implements IInventory {

	public ItemStack cargo[] = new ItemStack[5];
	public EntityLawnMower lawnMower;
	public EntityPlayer player;

	public InventoryLawnMower(EntityLawnMower lawnMower, EntityPlayer player) {
		this.lawnMower = lawnMower;
		this.player = player;
	}

	public int getInventorySlotContainItem(int i) {
		for (int j = 0; j < cargo.length; j++)
			if (cargo[j] != null && cargo[j].itemID == i)
				return j;
		return -1;
	}

	private int storeItemStack(ItemStack itemstack) {
		for (int i = 1; i < cargo.length; i++)
			if (cargo[i] != null
				&& cargo[i].itemID == itemstack.itemID
				&& cargo[i].isStackable()
				&& cargo[i].stackSize < cargo[i].getMaxStackSize()
				&& cargo[i].stackSize < getInventoryStackLimit()
				&& (!cargo[i].getHasSubtypes() || cargo[i]
					.getItemDamage() == itemstack.getItemDamage()))
				return i;
		return -1;
	}

	private int getFirstEmptyStack() {
		for (int i = 1; i < cargo.length; i++)
			if (cargo[i] == null)
				return i;
		return -1;
	}

	private int storePartialItemStack(ItemStack itemstack) {
		int i = itemstack.itemID;
		int j = itemstack.stackSize;
		int k = storeItemStack(itemstack);
		if (k < 0)
			k = getFirstEmptyStack();
		if (k < 0)
			return j;
		if (cargo[k] == null)
			cargo[k] = new ItemStack(i, 0, itemstack.getItemDamage());
		int l = j;
		if (l > cargo[k].getMaxStackSize() - cargo[k].stackSize)
			l = cargo[k].getMaxStackSize() - cargo[k].stackSize;
		if (l > getInventoryStackLimit() - cargo[k].stackSize)
			l = getInventoryStackLimit() - cargo[k].stackSize;
		if (l == 0)
			return j;
		else {
			j -= l;
			cargo[k].stackSize += l;
			cargo[k].animationsToGo = 5;
			return j;
		}
	}

	public void decrementAnimations() {
		for (int i = 0; i < cargo.length; i++)
			if (cargo[i] != null)
				cargo[i].updateAnimation(player.worldObj, player, i, false);// currentItem boolean
	}
	
	public boolean addFuel() {
		if(cargo[0]==null) {
			cargo[0]=new ItemStack(Item.coal);
			return true;
		}
		if(cargo[0].stackSize>=getInventoryStackLimit())
			return false;
		cargo[0].stackSize++;
		onInventoryChanged();
		return true;
	}

	public boolean addItemStackToCargo(ItemStack itemstack) {
		if (!itemstack.isItemDamaged()) {
			int i;
			do {
				i = itemstack.stackSize;
				itemstack.stackSize = storePartialItemStack(itemstack);
			} while (itemstack.stackSize > 0 && itemstack.stackSize < i);
			onInventoryChanged();
			return itemstack.stackSize < i;
		}
		int j = getFirstEmptyStack();
		if (j > 0) {
			cargo[j] = ItemStack.copyItemStack(itemstack);
			cargo[j].animationsToGo = 5;
			itemstack.stackSize = 0;
			onInventoryChanged();
			return true;
		}
		else
			return false;
	}

	public NBTTagList writeToNBT(NBTTagList nbttaglist) {
		for (int i = 0; i < cargo.length; i++)
			if (cargo[i] != null) {
				NBTTagCompound nbttagcompound = new NBTTagCompound();
				nbttagcompound.setByte("Slot", (byte) i);
				cargo[i].writeToNBT(nbttagcompound);
				nbttaglist.setTag(nbttagcompound);
			}
		return nbttaglist;
	}

	public void readFromNBT(NBTTagList nbttaglist) {
		cargo = new ItemStack[80];
		for (int i = 0; i < nbttaglist.tagCount(); i++) {
			NBTTagCompound nbttagcompound = (NBTTagCompound) nbttaglist
					.tagAt(i);
			int j = nbttagcompound.getByte("Slot") & 0xff;
			ItemStack itemstack = new ItemStack(nbttagcompound);
			if (itemstack.getItem() == null)
				continue;
			if (j >= 0 && j < cargo.length)
				cargo[j] = itemstack;
		}
		onInventoryChanged();
	}
	
	public void dropCargo() {
        for(int i = 1; i < cargo.length; i++)
            if(cargo[i] != null) {
            	for (int j=0; j<cargo[i].stackSize; j++)
            		lawnMower.entityDropItem(cargo[i], (new Random().nextFloat()-0.5F)*2);
                cargo[i] = null;
            }
    }

	@Override
	public ItemStack decrStackSize(int i, int j) {
		ItemStack aitemstack[] = cargo;
		if (aitemstack[i] != null) {
			if (aitemstack[i].stackSize <= j) {
				ItemStack itemstack = aitemstack[i];
				aitemstack[i] = null;
				onInventoryChanged();
				return itemstack;
			}
			ItemStack itemstack1 = aitemstack[i].splitStack(j);
			if (aitemstack[i].stackSize == 0)
				aitemstack[i] = null;
			onInventoryChanged();
			return itemstack1;
		}
		else
			return null;
	}

	@Override
	public void setInventorySlotContents(int i, ItemStack itemstack) {
		cargo[i] = itemstack;
		onInventoryChanged();
	}

	@Override
	public int getSizeInventory() {
		return cargo.length;
	}

	@Override
	public ItemStack getStackInSlot(int i) {
		return cargo[i];
	}

	@Override
	public String getInvName() {
		return "Lawn Mower";
	}

	@Override
	public int getInventoryStackLimit() {
		return 64;
	}

	@Override
	public void onInventoryChanged() {
		lawnMower.fuel=cargo[0]!=null?Math.round((float)(cargo[0].stackSize*100/64)):0;
	}

	@Override
	public boolean canInteractWith(EntityPlayer entityplayer) {
		if (entityplayer.isDead)
			return false;
		return true;/* entityplayer.getDistanceSqToEntity(player) <= 64D; */
	}
}