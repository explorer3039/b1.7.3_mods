Installation:

- Install ModLoader and AudioMod(http://www.minecraftforum.net/topic/75440-/).
- Drag the files in "To minecraft jar" to your minecraft jar located in "%appdata%/.minecraft/bin" or your OS's equivalent.
- Drag everything in "To .minecraft folder" into "%appdata%/.minecraft", allow the folders to merge and edit "LawnMower.properties" with any text editor if any ID conflicts exist (unlikely).
- Have fun!


To Modders:

My code is completely open source; you can edit or reuse whatever you want without having to worry about copyright or such.


For more info, see the main thread: www.minecraftforum.net/topic/542774-/

~Paraknight