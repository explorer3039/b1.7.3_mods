
   Minaptics
   
   
    More information on:
      Minecraftforums: http://www.minecraftforum.net/topic/356836-166-minaptics-zoom-button-tweakable-mouse-smoother/


   INSTALL NOTES
   
:In this note, "archive" will refer to the ZIP you have extracted in order to read this Readme.


1a) ModLoader is required. ( http://www.minecraftforum.net/topic/75440-v166-risugamis-mods-updates/ )

1b) This mod edits px.class, which is the file related to Entity Renderer
    (info. for developers: MCP//client/src/EntityRenderer.java).

1c) Conflicts with Optimine notably, due to pt.class.



2) The .class files contained in this archive should go directly into the "(Roaming)/.minecraft/bin/minecraft.jar" using a file archive editor.

You can usually find the location of the (Roaming) folder by doing this:
Run Minecraft Launcher, and DON'T LOG IN but press the Options button above the Login button. The location should be written and accessible in the popup that opens there, which is clickable.


- On Windows, this is usually located in %appdata%/.minecraft.
- On Mac, it should be on ~/Library/Application Support/minecraft where ~ is your username.
  Caution, it can be tricky as Mac hides some folders. Read the forums for more info.
- On Linux, perform a "locate .minecraft", it should do it.


At the end, you should have a file structure similar to this:

- .minecraft/bin/minecraft.jar[/mod_MinapticsVisual.class]
- .minecraft/bin/minecraft.jar[/Ha3KeyBinding.class]
- .minecraft/bin/minecraft.jar[/Ha3KeyManager.class]
- .minecraft/bin/minecraft.jar[/MinapticsThirdBinding.class]
- .minecraft/bin/minecraft.jar[/MinapticsZoomBinding.class]
- .minecraft/bin/minecraft.jar[/px.class]
