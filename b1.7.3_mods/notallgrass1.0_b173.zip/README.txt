http://www.minecraftforum.net/forums/mapping-and-modding/minecraft-mods/1274838-1-7-3-no-tall-grass-mod-v0-3
