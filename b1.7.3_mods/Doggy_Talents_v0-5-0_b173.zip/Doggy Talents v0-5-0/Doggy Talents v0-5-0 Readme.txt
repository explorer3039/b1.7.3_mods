{\rtf1\ansi\ansicpg1252\cocoartf1038\cocoasubrtf360
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
\margl1440\margr1440\vieww9000\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\ql\qnatural\pardirnatural

\f0\fs24 \cf0 Hello, and thank you for downloading my mod, Doggy Talents v0.5.0. This mod allows you to greatly increase the utility of your beloved pets!\
\
It requires modloader, and may conflict with some mods, but it should be compatible with most modloader mods out there.\
\
INSTALLING\
\
\pard\tx560\tx1120\tx1680\tx2240\tx2800\tx3360\tx3920\tx4480\tx5040\tx5600\tx6160\tx6720\ql\qnatural\pardirnatural
\cf0 Locate your .minecraft (or just minecraft in the user/library/application support file if you have a mac) folder, find the bin, and unarchive the minecraft.jar like you would a zip file. Open the folder that gets created from this, and drop the class files contained in the doggy talents folder into this folder. It should say one already exists and ask if you wish to replace it. Say yes. Second, take the folder labeled "DoggyTalentsItems" and put it in as well, in the same place as all the class files. There's a folder that says "put these in the GUI folder." Do so. Next, locate the "mob" folder, and open it. It should contain the image files for all the mobs in the game. Take the image files in the mod's folder and dump them in this folder. Now remove the Meta-INF folder, select all the files, compress them, rename the zip file "minecraft.jar", and replace the original minecraft.jar with this new one. Then play minecraft, and it should work! You can know right away if it worked by right clicking on a dog with a stick. It should open up a GUI listing your dog's skills.\
\
Lemme know if it works for you, and any feedback is appreciated!\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\ql\qnatural\pardirnatural
\cf0 \
DOGGYTEX INFO\
\
The way this mod is set up, it supports 9 different skins for tamed wolves at once. There's the default one, and then the 8 ones labeled "doggytex". I've provided 8 doggytex skins for you so you don't have to get a texture for each, but if you'd like to put other dog skins in, just rename your prefered skin to match one of the doggytex pngs, and then put that in instead. You can cycle through the different Doggytex skins by right clicking on your dog with a lapis lazuli block.\
\
FREE-ROAM MODE\
\
You can set your dogs to free-roaming mode by right clicking on them with a bone. In this mode, they won't follow you or teleport to you, even though they aren't sitting. Give them a little playpen and watch them frolic! Set them to follow you again by having them execute an emblem command, or just by making them sit and stand up again.\
\
NAMING WOLVES\
\
You can name your dog by typing in a name on the dog's stats screen, accessed by right clicking on the dog with a stick.\
\
\
SKILLS INFO\
\
The central feature of this mod is the ability to teach your dogs skills to make them more powerful and helpful. You teach these skills by holding the skill's teaching material while you have Training Treats in your inventory, and right clicking on your dog. Each time you do this, there is a chance that you'll increase the dog's proficiency in that skill. The more levels the dog gains, however, the lower the success rate will get for additional levels in additional skills. You can check your dog's skill levels by right clicking on them with a stick. The current skills are:\
\
1: BlackPelt: Increase dog's attack power. Taught with Leather.\
\
2: GuardDog: Increase dog's defense. Taught with iron ingots.\
\
3: CreeperSweeper: Allows your dog to smell creepers, and warn you by growling. Taught with gunpowder.\
\
4: DogLight: Produces torches when overfed. Taught with Glowstone Blocks.\
\
5: HunterDog: May produce meat with each successful attack. Success rate gets higher with increasing levels in the skill, as well as increasing amounts of damage. Taught with flint.\
\
6: HellHound: Defends against fire and lava damage. Taught with netherrack. Level 5 sets enemies on fire with each attack. Any meat produced by other skills may come pre-cooked.\
\
7: PillowPaw: Defends against fall damage. Taught with feathers.\
\
8: WolfMount: Ride your wolf at high speed, bounding over full blocks like they were stairs! Taught with a saddle, improved by DoggyDash and PillowPaw, can't swim without level 5 FisherDog.\
\
9: PackPuppy: Give your dog an inventory, and access it by right clicking while holding control. Taught with chests.\
\
10: DoggyDash: Your dog will leap into battle with a super-fast attack! Perfect for handling those pesky spiders.\
\
11: FisherDog: Your dog may catch fish in the water, and he'll give it to you when he's done drying off.\
\
To craft Training Treats, use the following recipe:\
\
String Bone Gunpowder\
Sugar Sugar Sugar\
Wheat Wheat Wheat\
\
This will create a stack of 8 training treats for you to use.\
\
\
EMBLEMS AND COMMANDS\
\
There are 5 emblems you can craft to command your dogs as a unit. When you've made one, simply right-click while holding it, and all nearby dogs will be issued a command. They are crafted the same way as watches, but with a different "core" for each, replacing the watch's redstone dust. The emblems are as follows:\
\
Attack!: Makes all dogs with at least level 3 BlackPelt attack the nearest skeleton, zombie, or spider to you. Core: Wooden Sword.\
\
Sic!: Makes all dogs with at least level 3 HunterDog auto-aggro the nearest pig, chicken or cow. Core: Bow.\
\
Stay!: Makes all nearby dogs sit. Core: Stick.\
\
Okay!: Makes all nearby dogs stand. Core: Bone.\
\
Checkup Time!: All nearby dogs will sit if they're injured, but stand if they're at full health, allowing you to easily determine who needs healing. Core: String.\
\
\
\
DOG REVIVAL AND RELEASE\
\
Dogs can't die in this mod if they're tamed. Instead, they become incapacitated, which renders nearly all skills unusable, prevents them from engaging in combat, and makes them unable to recover hp from pork. To revive them, feed them cake.\
\
If you feel you have too many dogs, you can release some back into the wild by cutting off their collar with shears. This only has a 1 in 32 success rate to avoid accidental untamings, but it doesn't consume the shears' durability, so just spam it if you want to release your dog. THEY MUST BE AT FULL HEALTH FOR THIS TO WORK.}