####################################################
#New Ore Mod 1.7.3 2011 By Marius        #
#                                        #
####################################################
---------------
How to Install
---------------
!!REQUIRES MODLOADER!!
  
(Recomended: Backup Minecraft.jar)


1: Move the files from the MINECRAFT JAR FILES folder into minecraft.jar (obviously)
2: Install modloader (there are tutorials out there)
3: And Most important HAVE FUN
