===================
AlchemyCraft v. 1.0
===================

===========
Instalation
===========

1. Open %appdata%/.minecraft/bin/minecraft.jar
2. put ModLoader inside
3. put everything from bin folder in this archive inside
4. Play

========================
Copyright by angryduck94
========================