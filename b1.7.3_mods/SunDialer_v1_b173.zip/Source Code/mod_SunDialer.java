package net.minecraft.src;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import net.minecraft.client.Minecraft;

public class mod_SunDialer extends BaseMod {
	private static int key_dawn = Keyboard.KEY_K;
	private static int key_dusk = Keyboard.KEY_L;
	private static int key_mod  = Keyboard.KEY_LSHIFT;

	private static long time_dawn = 0L;
	private static long time_dusk = 12000L;

	private boolean pressed_dawn = false;
	private boolean pressed_dusk = false;

	private long time_goal = 0;

	ItemStack is_ = null;
	int counter = 0;

	@Override
	public String Version() {
		return "Beta 1.7.3";
	}

	protected mod_SunDialer() {
		Item.pocketSundial.maxStackSize = 1;
		Item.pocketSundial.setMaxDamage(48*7);
		ModLoader.SetInGameHook(this, true, true);
	}

	private long calcTimeAdjustment(long time_, long goal_){
		//get a set of goal values for the previous and next desired time
		long goal_prev = goal_;
		long goal_next = goal_ + 24000L;

		//get an adjusted time of day that is between those values
		long time_Adj;
		if( time_ < goal_ ) {
			time_Adj = time_ + 24000L;
		} else {
			time_Adj = time_;
		}

		//which is closer based on cost adjustment? (going back in time is 3x more expensive)
		if( (time_Adj - goal_prev) > 6000 ){
			return (goal_next - time_Adj);
		}
		if( (time_Adj - goal_prev) < 6000 ){
			return (goal_prev - time_Adj);
		}

		return 0;
	}

	@Override
	public boolean OnTickInGame(Minecraft pMC) {

		if( pMC.theWorld.multiplayerWorld ) return true;

		if( ++counter % 10 == 0 )
		{
			is_ = null;
			ItemStack temp = null;
			for( int loop = 0; loop < pMC.thePlayer.inventory.mainInventory.length; ++loop ){
				temp = pMC.thePlayer.inventory.getStackInSlot(loop);
				if(temp == null)continue;
				if(temp.itemID != Item.pocketSundial.shiftedIndex)continue;
				if(is_ == null || is_.getItemDamage() > temp.getItemDamage()) {
					is_ = temp;
				}
			}
		}

		
		if( is_ == null || is_.itemID != Item.pocketSundial.shiftedIndex ) return true;
		

		long time = pMC.theWorld.getWorldTime() % 24000;
		long day  = pMC.theWorld.getWorldTime() - time;

		if( time_goal > 0 && time % 6 == 0 ) {
			if( time_goal > (pMC.theWorld.getWorldTime()+500L) ){
				incrTime(pMC.theWorld,is_,500);
			} else
			if( time_goal < (pMC.theWorld.getWorldTime()-500L) ){
				decrTime(pMC.theWorld,is_,500);
			} else {
				time_goal = 0;
			}
			if(is_.getItemDamage() > is_.getMaxDamage())
				time_goal = 0;
		}

		if (pressed_dawn) {
			if (!Keyboard.isKeyDown(key_dawn)) {
				pressed_dawn = false;
			}
		}
		else if (Keyboard.isKeyDown(key_dawn)) {
			pressed_dawn = true;
			time_goal = pMC.theWorld.getWorldTime() + calcTimeAdjustment(time,time_dawn);
		}

		if (pressed_dusk) {
			if (!Keyboard.isKeyDown(key_dusk)) {
				pressed_dusk = false;
			}
		}
		else if (Keyboard.isKeyDown(key_dusk)) {
			pressed_dusk = true;
			time_goal = pMC.theWorld.getWorldTime() + calcTimeAdjustment(time,time_dusk);
		}

		if (Keyboard.isKeyDown(key_mod))
		{
			int value = Mouse.getDWheel();
			if (value > 0) {
				incrTime(pMC.theWorld, is_, 500);
				time_goal = 0;
			}
			else if (value < 0) {
				decrTime(pMC.theWorld, is_, 500);
				time_goal = 0;
			}
		}
		
		return true;
	}

	private void adjustTime( World world, ItemStack stack, long timeGoal )
	{
		if( timeGoal > world.getWorldTime() ){
			incrTime(world,stack,timeGoal-world.getWorldTime());
		} else {
			decrTime(world,stack,world.getWorldTime()-timeGoal);
		}
	}

	private void incrTime( World world, ItemStack stack, long duration )
	{
		while( duration >= 500 && (stack.getMaxDamage()-stack.getItemDamage()) > 0 ) {
			duration -= 500;
			stack.damageItem(1,null);
			world.setWorldTime(world.getWorldTime() + 500L);
		}
	}

	private void decrTime( World world, ItemStack stack, long duration )
	{
		while( duration >= 500 && (stack.getMaxDamage()-stack.getItemDamage()) > 3 ) {
			duration -= 500;
			stack.damageItem(3,null);
			world.setWorldTime(world.getWorldTime() - 500L);
		}
	}
}
