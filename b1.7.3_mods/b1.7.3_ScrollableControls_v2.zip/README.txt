This is ScrollableControls v2 for Minecraft Beta 1.7.3 Client

DESCRIPTION
This mod adds a scroll bar to the controls screen such that any number of keybinds can be correctly displayed

INSTALL
1. Install Modloader
2. Delete META-INF from the minecraft.jar
3. Insert this zip into the .minecraft/mods folder
4. ???
5. Success!

CREDIT
Original 1.2.4 mod - North101
Override code 'borrowed' from the API - mine_diver
Port + Bug fixes - me, rek

CHANGELOG for v2
- Now requires ModLoader but no longer edits base classes
- Improved UI scaling for users on low gui scales
- Fixed bug where you could scroll when there was no scroll bar
- Fixed bug where binding something to ESC would exit the menu