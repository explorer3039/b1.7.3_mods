package net.minecraft.src;

import net.minecraft.client.Minecraft;

public class mod_ScrollControls extends BaseMod {

	public String Version() {
		return "v2";
	}
	
	public mod_ScrollControls() {
		
		ModLoader.SetInGUIHook(this, true, false);
	}
	
	public boolean OnTickInGUI(Minecraft minecraft, GuiScreen guiscreen)
    {
		if (guiscreen instanceof GuiControls) {
			minecraft.displayGuiScreen(new GuiScrollControls(parentScreen, minecraft.gameSettings));
		}
		else if (guiscreen != parentScreen) {
			parentScreen = guiscreen;
		}
		
		return true;
    }
	
	private GuiScreen parentScreen;
}
