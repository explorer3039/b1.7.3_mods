Thank you for downloading my ore pack!

How to install:

1) Install ModLoader
2) Drag all teh .class files and the folder named "Terranite" into your .jar file
3) Load up Minecraft and enjoy!
4) ????
5) Proft!