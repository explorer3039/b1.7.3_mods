OverrideAPI v1.0.1

 *Code cleaning, optimizations!*

You can:

1) Add buttons! You can add a button to GuiScreen without overriding or editing its class.

2) Override a GuiScreen so your one appears instead of original.

3) Override a vanilla block with your one.

4) Create your own EnumToolMaterial and register it in EnumToolMaterials list.

NO base class is edited. This API should be compatible with everything.

Feel free to use it in your mods! :D

ChangeLog:

1) Cleaned code

2) Optimized code

3) Now if some serious problem happens with Reflection, the game will crash immediately with proper crash info.

Credit:

- mine_diver

- rek (thanks for that trick with selectedButton, now I don't need to override the whole mouse input proccess xd)

Installation:

1) Just drop the contents of this zip into minecraft.jar,
or, if you're using MultiMC, MagicLauncher, etc, just use this zip as minecraft.jar mod

2) Enjoy OverrideAPI mods!

Using in mods:

1) Prepare a workspace with things that you'd like to have

2) Extract this zip right into the root of your MCP folder

3) Create your mod!