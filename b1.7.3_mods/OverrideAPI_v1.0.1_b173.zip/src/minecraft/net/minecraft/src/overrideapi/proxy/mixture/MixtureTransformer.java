package net.minecraft.src.overrideapi.proxy.mixture;

public class MixtureTransformer {
    
    byte[] transformClass(String name, byte[] basicClass) {
        // TODO Auto-generated method stub
        return null;
    }
}
