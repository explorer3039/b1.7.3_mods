package net.minecraft.src.overrideapi.utils.gui;

import java.lang.reflect.Field;
import java.util.List;

import net.minecraft.client.Minecraft;
import net.minecraft.src.EntityRenderer;
import net.minecraft.src.GuiButton;
import net.minecraft.src.GuiScreen;
import net.minecraft.src.ScaledResolution;
import net.minecraft.src.overrideapi.OverrideAPI;
import net.minecraft.src.overrideapi.proxy.ArrayListProxy;
import net.minecraft.src.overrideapi.utils.Reflection;

public class GuiHandler {
    
    public GuiHandler() {
        controlListField.setAccessible(true);
        selectedButtonField.setAccessible(true);
    }
    
    public void init() {
        try {
            Class<?> entityRendererProxyBaked = OverrideAPI.INSTANCE.proxyLoader.findClass((controlListField.getName() == "e" ? "" : "net.minecraft.src.") + "overrideapi.proxy.EntityRendererProxy");
            EntityRenderer entityRendererProxy = (EntityRenderer) entityRendererProxyBaked.getConstructor(Minecraft.class).newInstance(OverrideAPI.getMinecraftInstance());
            OverrideAPI.getMinecraftInstance().entityRenderer = entityRendererProxy;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    
    public void beforeDrawScreen() {
        if (OverrideAPI.guiScreenOverrides.containsKey(OverrideAPI.getMinecraftInstance().currentScreen.getClass())
                && !OverrideAPI.guiScreenOverrides.get(OverrideAPI.getMinecraftInstance().currentScreen.getClass()).isInstance(OverrideAPI.getMinecraftInstance().currentScreen))
            try {
                OverrideAPI.getMinecraftInstance().currentScreen = OverrideAPI.guiScreenOverrides.get(OverrideAPI.getMinecraftInstance().currentScreen.getClass()).newInstance();
                OverrideAPI.getMinecraftInstance().setIngameNotInFocus();
                ScaledResolution scaledresolution = new ScaledResolution(OverrideAPI.getMinecraftInstance().gameSettings,
                        OverrideAPI.getMinecraftInstance().displayWidth,
                        OverrideAPI.getMinecraftInstance().displayHeight);
                int i = scaledresolution.getScaledWidth();
                int j = scaledresolution.getScaledHeight();
                OverrideAPI.getMinecraftInstance().currentScreen.setWorldAndResolution(OverrideAPI.getMinecraftInstance(), i, j);
                OverrideAPI.getMinecraftInstance().skipRenderWorld = false;
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        
        GuiButton button = null;
        try {
            button = (GuiButton)selectedButtonField.get(OverrideAPI.getMinecraftInstance().currentScreen);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        
        if (button != null
                && prevSelectedButton != button)
            for (ButtonHandler handler : OverrideAPI.buttonHandlers)
                handler.actionPerformed(OverrideAPI.getMinecraftInstance().currentScreen, button);
        prevSelectedButton = button;
        
    	if (callOnNextTick || prevGuiScreen != OverrideAPI.getMinecraftInstance().currentScreen) {
            callOnNextTick = false;
            OverrideAPI.minButtonID = 0;
            try {
                @SuppressWarnings("unchecked")
                List<GuiButton> controlList = (List<GuiButton>)controlListField.get(OverrideAPI.getMinecraftInstance().currentScreen);
                List<GuiButton> proxy = new ArrayListProxy<GuiButton>();
                proxy.addAll(controlList);
                controlListField.set(OverrideAPI.getMinecraftInstance().currentScreen, proxy);
                for (ButtonHandler handler : OverrideAPI.buttonHandlers)
                    handler.initGui(OverrideAPI.getMinecraftInstance().currentScreen, proxy);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }
    
    public void onTick() {
        prevGuiScreen = OverrideAPI.getMinecraftInstance().currentScreen;
        prevDisplayWidth = OverrideAPI.getMinecraftInstance().displayWidth;
        prevDisplayHeight = OverrideAPI.getMinecraftInstance().displayHeight;
    }
    
    public void controlListClear() {
        if (prevDisplayWidth != OverrideAPI.getMinecraftInstance().displayWidth
                || prevDisplayHeight != OverrideAPI.getMinecraftInstance().displayHeight) {
            callOnNextTick = true;
        }
    }
    
    private final Field controlListField = Reflection.findField(GuiScreen.class, new String[] {"e", "controlList"});
    private final Field selectedButtonField = Reflection.findField(GuiScreen.class, new String[] {"a", "selectedButton"});
    private boolean callOnNextTick = false;
    private GuiButton prevSelectedButton = null;
    private GuiScreen prevGuiScreen = null;
    private int prevDisplayWidth = -1;
    private int prevDisplayHeight = -1;
}
