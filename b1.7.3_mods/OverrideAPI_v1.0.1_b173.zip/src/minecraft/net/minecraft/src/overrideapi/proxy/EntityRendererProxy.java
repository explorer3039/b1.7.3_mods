package net.minecraft.src.overrideapi.proxy;

import net.minecraft.client.Minecraft;
import net.minecraft.src.EntityRenderer;
import net.minecraft.src.overrideapi.OverrideAPI;

public class EntityRendererProxy extends EntityRenderer {

    public EntityRendererProxy(Minecraft minecraft) throws ClassNotFoundException {
		super(minecraft);
		game = minecraft;
	}
	
	@Override
	public void updateCameraAndRender(float f) {
	    if (game.currentScreen != null)
	        OverrideAPI.GUI_HANDLER.beforeDrawScreen();
        OverrideAPI.GUI_HANDLER.onTick();
        super.updateCameraAndRender(f);
	}
	
	private Minecraft game;
}
