package net.minecraft.src.overrideapi.proxy.transformer;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.HashMap;
import java.util.Map;

public class ProxyLoader extends URLClassLoader {
    
    private final Map<String, Class<?>> cachedClasses = new HashMap<String,Class<?>>(1000);
    private final ProxyTransformer transformer = new ProxyTransformer();

    public ProxyLoader(URL[] arg0) {
        super(arg0, null);
    }
    
    @Override
    public final Class<?> findClass(String name) throws ClassNotFoundException {
        
        if (cachedClasses.containsKey(name)) {
            return cachedClasses.get(name);
        }
        
        try {
            int lastDot = name.lastIndexOf('.');
            if (lastDot > -1) {
                String pkgname = name.substring(0, lastDot);
                if (getPackage(pkgname)==null)
                    definePackage(pkgname, null, null, null, null, null, null, null);
            }
            byte[] basicClass = getClassBytes(name);
            byte[] transformedClass = transformer.transformClass(name, basicClass);
            Class<?> cl;
            if (basicClass == transformedClass)
                cl = Class.forName(name);
            else
                cl = defineClass(name, transformedClass, 0, transformedClass.length);
            cachedClasses.put(name, cl);
            return cl;
        } catch (Throwable e) {
            throw new ClassNotFoundException(name, e);
        }
    }
    
    private final byte[] getClassBytes(String name) throws IOException {
        InputStream classStream = null;
        try {
            URL classResource = findResource(name.replace('.', '/').concat(".class"));
            if (classResource == null)
                return null;
            classStream = classResource.openStream();
            return readFully(classStream);
        }
        finally {
            if (classStream != null)
                try {
                    classStream.close();
                } catch (IOException e) {}
        }
    }
    
    private final byte[] readFully(InputStream stream) {
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream(stream.available());
            int r;
            while ((r = stream.read()) != -1)
                bos.write(r);

            return bos.toByteArray();
        } catch (Throwable t) {
            return new byte[0];
        }
    }
}
