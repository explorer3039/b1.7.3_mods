package net.minecraft.src.overrideapi.utils.gui;

import java.util.List;

import net.minecraft.src.GuiButton;
import net.minecraft.src.GuiScreen;

public interface ButtonHandler {
    void initGui(final GuiScreen guiscreen, final List<GuiButton> customButtons);
    void actionPerformed(final GuiScreen guiscreen, final GuiButton guibutton);
}
