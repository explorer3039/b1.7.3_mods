package net.minecraft.src.overrideapi.proxy.transformer;

import net.minecraft.src.overrideapi.OverrideAPI;
import net.minecraft.src.overrideapi.proxy.asm.ClassReader;
import net.minecraft.src.overrideapi.proxy.asm.ClassWriter;
import net.minecraft.src.overrideapi.proxy.asm.tree.AbstractInsnNode;
import net.minecraft.src.overrideapi.proxy.asm.tree.ClassNode;
import net.minecraft.src.overrideapi.proxy.asm.tree.MethodInsnNode;
import net.minecraft.src.overrideapi.proxy.asm.tree.MethodNode;

import static net.minecraft.src.overrideapi.proxy.asm.Opcodes.*;

import java.util.Iterator;

class ProxyTransformer {
    
    byte[] transformClass(String name, byte[] bytes) {
        if (name.endsWith("overrideapi.proxy.EntityRendererProxy"))
            return transformEntityRendererProxy(bytes);
        return bytes;
    }
    
    private byte[] transformEntityRendererProxy(byte[] bytes) {
        ClassNode classNode = new ClassNode();
        ClassReader classReader = new ClassReader(bytes);
        classReader.accept(classNode, 0);
        String parentEntityRenderer = OverrideAPI.getMinecraftInstance().entityRenderer.getClass().getName().replace(".", "/");
        for (MethodNode method : classNode.methods) {
            Iterator<AbstractInsnNode> insns = method.instructions.iterator();
            for (AbstractInsnNode insn = insns.next();insns.hasNext();insn = insns.next())
                if (insn.getOpcode() == INVOKESPECIAL && ((MethodInsnNode)insn).owner.equals(classNode.superName))
                    ((MethodInsnNode)insn).owner = parentEntityRenderer;
        }
        classNode.superName = parentEntityRenderer;
        ClassWriter classWriter = new ClassWriter(ClassWriter.COMPUTE_MAXS | ClassWriter.COMPUTE_FRAMES);
        classNode.accept(classWriter);
        bytes = classWriter.toByteArray();
        return bytes;
    }
}
