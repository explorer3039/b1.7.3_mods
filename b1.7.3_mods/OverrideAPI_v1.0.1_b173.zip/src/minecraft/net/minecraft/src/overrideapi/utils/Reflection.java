package net.minecraft.src.overrideapi.utils;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

public class Reflection {
    
	public static Object invokePrivateStaticMethod(Class<?> target, String name, Object[] args, Class<?>...parameterTypes) {
		try {
			Method method = target.getDeclaredMethod(name, parameterTypes);
			method.setAccessible(true);
			return method.invoke(null, args);
		} catch (Exception e) {
		    throw new RuntimeException(e);
		}
	}
	
	public static Object invokePrivateMethod(Object target, String name, Object[] args, Class<?>...parameterTypes) {
        try {
            Method method = target.getClass().getDeclaredMethod(name, parameterTypes);
            method.setAccessible(true);
            return method.invoke(target, args);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
	
	@SuppressWarnings("unchecked")
    public static void publicConstructor(@SuppressWarnings("rawtypes") Class target, Class<?>...parameterTypes) {
        try {
            target.getConstructor(parameterTypes).setAccessible(true);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
 	}
	
	public static Field publicField(Field field) {
	    try {
            field.setAccessible(true);
            modifiersField.setInt(field, field.getModifiers() & ~Modifier.FINAL);
        } catch (Exception e) {
            if (field == null)
                throw new RuntimeException("Field is null", e);
            else
                throw new RuntimeException("Field name: " + field.getName(), e);
        }
	    return field;
	}
	
	public static Field findField(Class<?> target, String... names) {
	    for (Field field : target.getDeclaredFields())
	        for (String name : names)
	            if (field.getName().equals(name))
	                return field;
	    String failedNames = "";
	    for (int i = 0; i < names.length; i++)
	        failedNames += "\"" + names[i] + "\"" + (i == names.length - 1 ? "" : ", ");
	    throw new RuntimeException("Unable to find field with names [" + failedNames + "]");
	}
	
	public static Field modifiersField;
	static {
	    try {
	        modifiersField = Field.class.getDeclaredField("modifiers");
	        modifiersField.setAccessible(true);
	    } catch (Exception e) {
	        throw new RuntimeException(e);
	    }
	}
}
