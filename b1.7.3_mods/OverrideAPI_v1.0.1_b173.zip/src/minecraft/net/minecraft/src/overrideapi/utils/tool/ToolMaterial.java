package net.minecraft.src.overrideapi.utils.tool;

import net.minecraft.src.EnumToolMaterial;
import net.minecraft.src.overrideapi.OverrideAPI;
import net.minecraft.src.overrideapi.utils.EnumHelper;

/**
 * EnumToolMaterial manager. You can add your own EnumToolMaterials without editing base classes.
 */

public class ToolMaterial {
    
    /**
     * This method creates and registers EnumToolMaterial and then returns is for further use.
     * 
     * @param name
     * @param id
     * @param harvestLevel
     * @param maxUses
     * @param efficiencyOnProperMaterial
     * @param damageVsEntity
     * @return
     */
    public static final EnumToolMaterial create(String name,
            int id,
            int harvestLevel,
            int maxUses,
            float efficiencyOnProperMaterial,
            int damageVsEntity)
    {
        try {
            EnumHelper.addEnum(EnumToolMaterial.class, name,
                    new Class[]{
                            String.class,
                            int.class,
                            int.class,
                            int.class,
                            float.class,
                            int.class
                    }, new Object[]{
                            name,
                            id,
                            harvestLevel,
                            maxUses,
                            efficiencyOnProperMaterial,
                            damageVsEntity
                    });
            OverrideAPI.LOGGER.info("Created EnumToolMaterial " + name);
            return EnumToolMaterial.valueOf(name);
        } catch (IllegalArgumentException e) {
            throw new RuntimeException(e);
        }
    }
}
