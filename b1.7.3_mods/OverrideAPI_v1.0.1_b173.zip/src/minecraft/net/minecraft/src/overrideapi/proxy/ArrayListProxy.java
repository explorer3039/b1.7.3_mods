package net.minecraft.src.overrideapi.proxy;

import java.util.ArrayList;

import net.minecraft.src.overrideapi.OverrideAPI;

public class ArrayListProxy<T> extends ArrayList<T> {
    
    private static final long serialVersionUID = 8683452581122892189L;
    
    @Override
    public void clear() {
        super.clear();
        OverrideAPI.GUI_HANDLER.controlListClear();
    }
}
