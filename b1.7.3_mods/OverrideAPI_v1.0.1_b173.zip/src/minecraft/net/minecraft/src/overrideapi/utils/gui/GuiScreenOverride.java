package net.minecraft.src.overrideapi.utils.gui;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import static java.lang.annotation.RetentionPolicy.RUNTIME;
import static java.lang.annotation.ElementType.TYPE;

import net.minecraft.src.GuiScreen;

@Retention(RUNTIME)
@Target(TYPE)
public @interface GuiScreenOverride {
    Class<? extends GuiScreen> value();
}
