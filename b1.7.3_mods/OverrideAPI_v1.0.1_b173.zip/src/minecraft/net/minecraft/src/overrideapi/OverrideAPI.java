package net.minecraft.src.overrideapi;

import java.lang.reflect.Field;
import java.net.URLClassLoader;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import net.minecraft.client.Minecraft;
import net.minecraft.src.Block;
import net.minecraft.src.GuiButton;
import net.minecraft.src.GuiScreen;
import net.minecraft.src.Item;
import net.minecraft.src.overrideapi.proxy.transformer.ProxyLoader;
import net.minecraft.src.overrideapi.utils.Reflection;
import net.minecraft.src.overrideapi.utils.gui.ButtonHandler;
import net.minecraft.src.overrideapi.utils.gui.GuiHandler;
import net.minecraft.src.overrideapi.utils.gui.GuiScreenOverride;

public class OverrideAPI {
    /**
     * With this method you can override Minecraft GuiScreens with your ones.
     * Method requires only one parameter - your class that extends GuiScreen and has GuiOverride annotation.
     * REMEMBER, if you have some parameters in constructor of your GuiOverride class, this will crash.
     * 
     * @param override
     */
    public static void overrideGuiScreen(Class<? extends GuiScreen> override) {
        if (notInitialized[0]) {
            GUI_HANDLER.init();
            notInitialized[0] = false;
            LOGGER.info("Initialized GUI handler");
        }
        guiScreenOverrides.put(override.getAnnotation(GuiScreenOverride.class).value(), override);
        LOGGER.info("Added GUIScreen override");
    }
    
    /**
     * This method can override vanilla blocks, like grass, stone, obsidian, etc, with your ones.
     * First parameter - target block, e.g Block.stone; Second parameter - your Block class.
     * REMEMBER, if you have parameters in constructor of your Block class, this will crash.
     * 
     * @param target
     * @param override
     * @return
     */
    public static Block overrideVanillaBlock(Block target, Class<? extends Block> override) {
        try {
            Block.blocksList[target.blockID] = null;
            Block overrideInst = override.newInstance();
            for (int i = 0; i < Block.class.getDeclaredFields().length; i++) {
                try {
                    if (((Block)Block.class.getDeclaredFields()[i].get(null)).equals(target)) {
                        Field field = Block.class.getDeclaredFields()[i];
                        Reflection.publicField(field);
                        field.set(null, overrideInst);
                        break;
                    }
                } catch (Exception e) {}
            }
            for (Item item : Item.itemsList)
                try {
                    Field blocksEffectiveAgainstField = Reflection.publicField(Reflection.findField(target.getClass(), new String[]{"aX", "blocksEffectiveAgainst"}));
                    Block[] blocksEffectiveAgainst = (Block[]) blocksEffectiveAgainstField.get(item);
                    for (int i = 0; i < blocksEffectiveAgainst.length; i++)
                        if (blocksEffectiveAgainst[i].equals(target)) {
                            blocksEffectiveAgainst[i] = overrideInst;
                            blocksEffectiveAgainstField.set(item, blocksEffectiveAgainst);
                            break;
                        }
                } catch (Exception e) {}
            System.gc();
            LOGGER.info("Overrided " + target.getBlockName());
            return overrideInst;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    
    /**
     * If you have a class that implements ButtonHandler, register it with this method so it'll be run
     * 
     * @param buttonHandler
     */
    public static void registerButtonHandler(ButtonHandler buttonHandler) {
        if (notInitialized[0]) {
            GUI_HANDLER.init();
            notInitialized[0] = false;
            LOGGER.info("Initialized GUI handler");
        }
        buttonHandlers = Arrays.copyOf(buttonHandlers, buttonHandlers.length + 1);
        buttonHandlers[buttonHandlers.length - 1] = buttonHandler;
        LOGGER.info("Registered " + buttonHandler.getClass().getSimpleName() + " ButtonHandler");
    }
    
    /**
     * With this method you can get a button ID for the current GuiScreen
     * 
     * @param guiscreen
     * @return
     */
    public static int getUniqueButtonID() {
        if (minButtonID == 0)
            try {
                Field controlListField = Reflection.findField(GuiScreen.class, new String[] {"e", "controlList"});
                controlListField.setAccessible(true);
                @SuppressWarnings("unchecked")
                List<GuiButton> controlList = (List<GuiButton>)controlListField.get(getMinecraftInstance().currentScreen);
                for (GuiButton guibutton : controlList)
                    if (guibutton.id < minButtonID)
                        minButtonID = guibutton.id;
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        minButtonID--;
        return minButtonID;
    }
    
    /**
     * Returns current thread's Minecraft instance
     * 
     * @return
     */
    public static Minecraft getMinecraftInstance() {
        if(MinecraftInstance == null)
            try {
                ThreadGroup threadgroup = Thread.currentThread().getThreadGroup();
                int i = threadgroup.activeCount();
                Thread athread[] = new Thread[i];
                threadgroup.enumerate(athread);
                for(Thread thread : athread)
                    if(thread.getName().equals("Minecraft main thread")){
                        MinecraftInstance = (Minecraft)Reflection.publicField(Reflection.findField(Thread.class, "target")).get(thread);
                        break;
                    }

            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        return MinecraftInstance;
    }
    
    private OverrideAPI() {
        proxyLoader = new ProxyLoader(((URLClassLoader)getClass().getClassLoader()).getURLs());
    }
    public final static Logger LOGGER = Logger.getLogger("Override API");
    private static Minecraft MinecraftInstance;
    public final ProxyLoader proxyLoader;
    public static final OverrideAPI INSTANCE = new OverrideAPI();
    public final static GuiHandler GUI_HANDLER = new GuiHandler();
    private final static boolean notInitialized[] = new boolean[] {true};
    public final static Map<Class<? extends GuiScreen>, Class<? extends GuiScreen>> guiScreenOverrides = new HashMap<Class<? extends GuiScreen>, Class<? extends GuiScreen>>();
    public static ButtonHandler buttonHandlers[] = new ButtonHandler[0];
    public static int minButtonID = 0;
}