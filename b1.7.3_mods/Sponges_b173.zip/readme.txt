[V1.7.3] Sponges (v2.5) by Exanadu

Backup your minecraft.jar file (always do this before installing any modified file)
Delete Meta-Inf folder if you havn't already in the minecraft.jar.
Make sure you have installed the latest version of Modloader. Place class files, exanadu and gui folder inside the minecraft.jar

Sponges uses block Ids 252 and 253 by default you can change the block ID number in the exanadu/Sponges.properties file located in your mincraft.jar/exanadu folder

enjoy