Put everything from "bin" folder into minecraft.jar.
Don't do anything with files from "src" folder, unless you're a modder and you know what you're doing. Just delete them.

By default, both parts of this mod are turned off. Go to .minecraft/config/mod_Max.cfg, and in this file turn on the parts you want.