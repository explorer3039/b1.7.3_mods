import net.minecraft.client.Minecraft;

public class mod_Max extends BaseMod {
	@MLProp public static boolean
		useMaxHardness = false,
		useMaxResistance = false;
	
	public static int timer = 2;
	
	public String Version() {return "r7";}
	
	public mod_Max() {
		ModLoader.SetInGameHook(this,true,false);
	}
	
	public void OnTickInGame(Minecraft game, boolean inGui) {
		if (timer > 0) {
			timer--;
			if (timer == 0) {
				for (int i = 1; i < uu.m.length; i++) {
					if (uu.m[i] == null) continue;
					if (useMaxHardness) uu.m[i].c(-1F);
					if (useMaxResistance) uu.m[i].b(6000000F);
				}
				ModLoader.SetInGameHook(this,false,false);
			}
		}
	}
}