Hello there! Welcome to My mod.

Before we can start, make sure:
-Minecraft isn't open.
-You have correctly installed ModLoader.

It's very easy to install this mod, all you need to do is follow these steps:

1- Press WindowsKey+R
2-Type %Appdata% and click OK
3-Open the .minecraft folder
4-Open the bin folder
5-Open the minecraft Jar file with WinRar or similar.
6-Copy and paste all the files from the folder this readme is in, over to the minecraft Jar.
7-Delete the META-INF folder.
8-Double check you have deleted the META-INF folder.
9-Open Minecraft, and Enjoy!

You can look at the crafting recepies in the forums.
Have fun!

-Zeem