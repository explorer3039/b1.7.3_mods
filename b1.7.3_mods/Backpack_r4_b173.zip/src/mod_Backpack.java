import java.awt.Color;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.lwjgl.input.Keyboard;

import net.minecraft.client.Minecraft;

public class mod_Backpack extends BaseMod {
	public static final int itemOff = 256;
	static final String dir = "/Shockah/Backpack/";
	private static fd worldObj;
	
	private static boolean usingGUIAPI = false;
	private static Object optionHint,optionPosition;
	
	public static qb keyBackpack = new qb("Backpack",Keyboard.KEY_R);
	public static InventoryBackpack backpack = new InventoryBackpack();
	public static InventoryQuiver quiver = new InventoryQuiver();
	
	public static gm
		iBACKPACK, iQUIVER;
	
	public static final gm
		iLEATHER = gm.aD;
	
	public static final uu
		bCHEST = uu.av;
	
	@MLProp public static int idItemBackpack = 5300, idItemQuiver = 5301;
	
	static {
		try {
			Class.forName("ModSettings");
			usingGUIAPI = true;
			prepareConfig();
		} catch (ClassNotFoundException e) {}
		
		iBACKPACK = new wa(idItemBackpack-itemOff,0,ModLoader.AddArmor("Backpack"),1).c(overrideItem(dir+"iBackpack.png")).a("iBackpack");
		ModLoader.AddName(iBACKPACK,"Backpack");
		
		iQUIVER = new wa(idItemQuiver-itemOff,0,ModLoader.AddArmor("Quiver"),1).c(overrideItem(dir+"iQuiver.png")).a("iQuiver");
		ModLoader.AddName(iQUIVER,"Quiver");
	}
	
	public mod_Backpack() {
		ModLoader.SetInGameHook(this,true,false);
		ModLoader.RegisterKey(this,keyBackpack,true);
		
		ModLoader.AddRecipe(new iz(iBACKPACK),"L L","LCL","L L",'L',iLEATHER,'C',bCHEST);
		ModLoader.AddRecipe(new iz(iQUIVER),"L L","L L","LLL",'L',iLEATHER);
	}
	
	private static void prepareConfig() {
		ModSettings Settings = new ModSettings("Backpack");
		ModSettingScreen screen = new ModSettingScreen("Backpack");
		optionHint = Settings.addSetting(screen,"Show hint","hint",true);
		optionPosition = Settings.addSetting(screen,"Position","position",3,"Top left","Top right","Bottom left","Bottom right");
		Settings.load();
	}
	
	private static boolean getHint() {
		if (usingGUIAPI) {
			return ((SettingBoolean)optionHint).get();
		} return true;
	}
	private static int getPosition() {
		if (usingGUIAPI) {
			return ((SettingMulti)optionPosition).get();
		} return 1;
	}
	
	public static boolean addItem(iz stack, boolean beforeInventory) {
		if (beforeInventory) {
			if (mod_Backpack.quiver.isEquipped()) if (mod_Backpack.quiver.a(stack)) return true;
		} else {
			if (mod_Backpack.backpack.isEquipped()) if (mod_Backpack.backpack.a(stack)) return true;
		}
		return false;
	}
	
	public boolean OnTickInGame(Minecraft game) {
		if (game.r == null) {
			if (getHint()) {
				qq res = new qq(game.z,game.d,game.e);
				int resX = res.a();
				int resY = res.b();
				
				int posX = 2;
				int posY = 2;
				boolean addW = false;
				
				int position = getPosition();
				if (position == 2 || position == 3) {
					posY = resY-10;
				}
				if (position == 1 || position == 3) {
					posX = resX-2;
					addW = true;
				}
				
				if (backpack.isEquipped()) {
					String str = "Backpack: "+backpack.countNotEmpty()+"/"+backpack.a();
					game.q.a(str,posX-(addW ? game.q.a(str) : 0),posY,new Color(255,255,255).getRGB());
				} else if (quiver.isEquipped()) {
					String str = "Quiver: "+quiver.countAmount();
					game.q.a(str,posX-(addW ? game.q.a(str) : 0),posY,new Color(255,255,255).getRGB());
				}
			}
			
			if (!backpack.isEquipped() && !backpack.checkIsEmpty()) {
				backpack.dropItems();
			}
			if (!quiver.isEquipped() && !quiver.checkIsEmpty()) {
				quiver.dropItems();
			}
		}
		
		if (!game.f.B) {
			if (game.f != worldObj) {
				if (worldObj != null) saveNBT(worldObj);
				if (game.f != null) loadNBT(game.f);
				worldObj = game.f;
			}
			if ((worldObj != null) && (worldObj.x.f() % worldObj.p == 0L)) saveNBT(worldObj);
		}
		
		return true;
	}
	
	public void saveNBT(fd world) {
		try {
			File f1 = GetWorldSaveLocation(world);
			File f2 = new File(f1,"Backpack.dat");
			if (!f2.exists()) as.a(new nu(),new FileOutputStream(f2));
			nu nbtCompound = as.a(new FileInputStream(f2));
			
			backpack.save(nbtCompound);
			quiver.save(nbtCompound);
			
			as.a(nbtCompound,new FileOutputStream(f2));
		} catch (Exception e) {e.printStackTrace();}
	}
	public void loadNBT(fd world) {
		try {
			File f1 = GetWorldSaveLocation(world);
			File f2 = new File(f1,"Backpack.dat");
			if (!f2.exists()) as.a(new nu(),new FileOutputStream(f2));
			nu nbtCompound = as.a(new FileInputStream(f2));
			
			backpack.load(nbtCompound);
			quiver.load(nbtCompound);
		} catch (Exception e) {e.printStackTrace();}
	}
	
	public void KeyboardEvent(qb event) {
		if (event.a.equals(keyBackpack.a)) {
			Minecraft game = ModLoader.getMinecraftInstance();
			
			if (game.r != null) {
				if (game.r instanceof GuiBackpack || game.r instanceof GuiQuiver) ModLoader.OpenGUI(game.h,null);
				return;
			}
			
			if (backpack.isEquipped()) {
				ModLoader.OpenGUI(game.h,new GuiBackpack(game.h.c,backpack));
			}
			if (quiver.isEquipped()) {
				ModLoader.OpenGUI(game.h,new GuiQuiver(game.h.c,quiver));
			}
		}
	}
	
	public String Version() {return "r4";}
	
	private static int overrideItem(String path) {
		return ModLoader.addOverride("/gui/items.png",path);
	}
	
	public static File GetWorldSaveLocation(fd world) {
		return world.w instanceof fm ? ((fm)world.w).a() : null;
	}
}