public class GuiSrvQuiver extends dw {
	private lw quiver;
	
	private static class Slot extends gp {
		public Slot(lw inventory, int slot, int x, int y) {
			super(inventory,slot,x,y);
		}
		
		public boolean b(iz item) {
			return mod_Backpack.quiver.list.contains(item.c);
		}
	}

	public GuiSrvQuiver(lw inventory, lw quiver) {
		this.quiver = quiver;
		
		for (int yy = 0; yy < 2; yy++)
		for (int xx = 0; xx < 2; xx++) {
			a(new Slot(quiver,xx+(yy*2),71+(18*xx),8+(18*yy)));
		}

		int j = 0;
		for (int k = 0; k < 3; k++) {
			for (int m = 0; m < 9; m++) {
				a(new gp(inventory, m + k * 9 + 9, 8 + m * 18, 60 + k * 18 + j));
			}
		}
		for (int k = 0; k < 9; k++) a(new gp(inventory, k, 8 + k * 18, 118 + j));
	}

	public boolean b(gs player) {
		return quiver.a_(player);
	}
}