import org.lwjgl.opengl.GL11;

public class GuiBackpack extends id {
	private lw inventory;
	private lw backpack;
	private int n = 0;

	public GuiBackpack(lw inventory, lw backpack) {
		super(new GuiSrvBackpack(inventory, backpack));
		this.inventory = inventory;
		this.backpack = backpack;
		f = false;

		int i = 222;
		int j = i - 108;
		n = 2;

		i = (j + n * 18);
	}

	protected void k() {
		g.b(backpack.c(), 8, 6, 4210752);
		g.b(inventory.c(), 8, 56, 4210752);
	}

	protected void a(float paramFloat) {
		int i2 = b.p.b("/gui/container.png");
		GL11.glColor4f(1F, 1F, 1F, 1F);
		b.p.b(i2);
		int j = (c - a) / 2;
		int k = (d - i) / 2;
		b(j, k, 0, 0, a, n * 18 + 17);
		b(j, k + n * 18 + 17, 0, 126, a, 96);
	}
}