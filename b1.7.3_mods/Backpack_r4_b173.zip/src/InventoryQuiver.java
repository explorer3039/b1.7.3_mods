import java.util.ArrayList;

import net.minecraft.client.Minecraft;

public class InventoryQuiver extends InventoryExtraSlots {
	public ArrayList<Integer> list = new ArrayList<Integer>();
	
	public InventoryQuiver() {
		super("Quiver",4);
		list.add(gm.j.bf);
		
		try {
			Class.forName("mod_Arrows");
			list.add(mod_Arrows.exp.bf);
			list.add(mod_Arrows.lig.bf);
			list.add(mod_Arrows.fir.bf);
			list.add(mod_Arrows.egg.bf);
			list.add(mod_Arrows.ice.bf);
		} catch (Exception e) {}
	}
	
	public void load(nu nbtCompound) {
		sp list = nbtCompound.l("QuiverItems");
		for (int i = 0; i < list.c(); i++) {
			nu cmp1 = (nu)list.a(i);
			int slot = cmp1.c("Slot") & 0xFF;
			a(slot,new iz(cmp1));
		}
	}

	public void save(nu nbtCompound) {
		sp list = new sp();
		for (int i = 0; i < a(); i++) {
			if (f_(i) != null) {
				nu cmp1 = new nu();
				cmp1.a("Slot",(byte)i);
				f_(i).a(cmp1);
				list.a(cmp1);
			}
		}
		nbtCompound.a("QuiverItems",list);
	}
	
	public boolean acceptItem(iz stack) {
		return list.contains(stack.c);
	}
	
	public int eatArrow() {
		for (int i = 0; i < a(); i++) {
			if (f_(i) == null) continue;
			int id = f_(i).c;
			f_(i).a--; if (f_(i).a == 0) a(i,null);
			return id;
		}
		return 0;
	}
	
	public boolean isEquipped() {
		Minecraft game = ModLoader.getMinecraftInstance();
		
		iz armorChest = game.h.c.b[2];
		boolean isQuiver = (armorChest != null);
		if (isQuiver) isQuiver = armorChest.c == mod_Backpack.iQUIVER.bf;
		
		return isQuiver;
	}
}