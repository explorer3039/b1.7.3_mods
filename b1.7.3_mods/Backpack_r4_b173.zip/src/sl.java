import java.util.List;

public class sl extends sn
{
	private int d = -1;
	private int e = -1;
	private int f = -1;
	private int g = 0;
	private int h = 0;
	protected boolean i = false;
	public boolean a = false;
	public int b = 0;
	public ls c;
	private int j;
	private int k = 0;
	protected ls target;
	public final boolean homing;

	public sl(fd paramfd)
	{
		this(paramfd, false);
	}

	public sl(fd paramfd, boolean ishoming) {
		super(paramfd);
		this.homing = ishoming;
		b(0.5F, 0.5F);
	}

	public sl(fd paramfd, double paramDouble1, double paramDouble2, double paramDouble3) {
		this(paramfd, paramDouble1, paramDouble2, paramDouble3, false);
	}

	public sl(fd paramfd, double paramDouble1, double paramDouble2, double paramDouble3, boolean ishoming) {
		super(paramfd);
		this.homing = ishoming;
		b(0.5F, 0.5F);

		e(paramDouble1, paramDouble2, paramDouble3);
		this.bf = 0.0F;
	}

	public sl(fd paramfd, ls paramls) {
		this(paramfd, paramls, false);
	}

	public sl(fd paramfd, ls paramls, boolean ishoming) {
		super(paramfd);
		this.homing = ishoming;
		this.c = paramls;
		this.a = (paramls instanceof gs);

		b(0.5F, 0.5F);

		c(paramls.aM, paramls.aN + paramls.w(), paramls.aO, paramls.aS, paramls.aT);

		this.aM -= in.b(this.aS / 180.0F * 3.141593F) * 0.16F;
		this.aN -= 0.1000000014901161D;
		this.aO -= in.a(this.aS / 180.0F * 3.141593F) * 0.16F;
		e(this.aM, this.aN, this.aO);
		this.bf = 0.0F;

		this.aP = (-in.a(this.aS / 180.0F * 3.141593F) * in.b(this.aT / 180.0F * 3.141593F));
		this.aR = (in.b(this.aS / 180.0F * 3.141593F) * in.b(this.aT / 180.0F * 3.141593F));
		this.aQ = (-in.a(this.aT / 180.0F * 3.141593F));

		a(this.aP, this.aQ, this.aR, 1.5F, 1.0F);
	}

	protected void b() {
	}

	public void a(double paramDouble1, double paramDouble2, double paramDouble3, float paramFloat1, float paramFloat2) {
		float f1 = in.a(paramDouble1 * paramDouble1 + paramDouble2 * paramDouble2 + paramDouble3 * paramDouble3);

		paramDouble1 /= f1;
		paramDouble2 /= f1;
		paramDouble3 /= f1;

		paramDouble1 += this.bs.nextGaussian() * 0.007499999832361937D * paramFloat2;
		paramDouble2 += this.bs.nextGaussian() * 0.007499999832361937D * paramFloat2;
		paramDouble3 += this.bs.nextGaussian() * 0.007499999832361937D * paramFloat2;

		paramDouble1 *= paramFloat1;
		paramDouble2 *= paramFloat1;
		paramDouble3 *= paramFloat1;

		this.aP = paramDouble1;
		this.aQ = paramDouble2;
		this.aR = paramDouble3;

		float f2 = in.a(paramDouble1 * paramDouble1 + paramDouble3 * paramDouble3);

		this.aU = (this.aS = (float)(Math.atan2(paramDouble1, paramDouble3) * 180.0D / 3.141592741012573D));
		this.aV = (this.aT = (float)(Math.atan2(paramDouble2, f2) * 180.0D / 3.141592741012573D));
		this.j = 0;
	}

	public void a(double paramDouble1, double paramDouble2, double paramDouble3) {
		this.aP = paramDouble1;
		this.aQ = paramDouble2;
		this.aR = paramDouble3;
		if ((this.aV == 0.0F) && (this.aU == 0.0F)) {
			float f1 = in.a(paramDouble1 * paramDouble1 + paramDouble3 * paramDouble3);
			this.aU = (this.aS = (float)(Math.atan2(paramDouble1, paramDouble3) * 180.0D / 3.141592741012573D));
			this.aV = (this.aT = (float)(Math.atan2(paramDouble2, f1) * 180.0D / 3.141592741012573D));
			this.aV = this.aT;
			this.aU = this.aS;
			c(this.aM, this.aN, this.aO, this.aS, this.aT);
			this.j = 0;
		}
	}

	@SuppressWarnings({ "static-access", "rawtypes" })
	public void w_() {
		super.w_();

		if ((this.aV == 0.0F) && (this.aU == 0.0F)) {
			float f1 = in.a(this.aP * this.aP + this.aR * this.aR);
			this.aU = (this.aS = (float)(Math.atan2(this.aP, this.aR) * 180.0D / 3.141592741012573D));
			this.aV = (this.aT = (float)(Math.atan2(this.aQ, f1) * 180.0D / 3.141592741012573D));
		}

		int m = this.aI.a(this.d, this.e, this.f);
		if (m > 0) {
			uu.m[m].a(this.aI, this.d, this.e, this.f);
			eq localeq1 = uu.m[m].e(this.aI, this.d, this.e, this.f);
			if ((localeq1 != null) && (localeq1.a(((bt)null).b(this.aM, this.aN, this.aO)))) {
				this.i = true;
			}

		}

		if (this.b > 0) {
			this.b -= 1;
		}
		if (this.i) {
			m = this.aI.a(this.d, this.e, this.f);
			int n = this.aI.e(this.d, this.e, this.f);
			if ((m != this.g) || (n != this.h)) {
				this.i = false;

				this.aP *= this.bs.nextFloat() * 0.2F;
				this.aQ *= this.bs.nextFloat() * 0.2F;
				this.aR *= this.bs.nextFloat() * 0.2F;
				this.j = 0;
				this.k = 0;
				return;
			}
			this.j += 1;
			if (this.j == 1200)
			K();
			return;
		}

		this.k += 1;
		if (this.homing) {
			if ((this.target == null) || (this.target.bd) || (!this.target.e(this))) {
				this.target = getTarget(this.aM, this.aN, this.aO, 16.0D);
			}

			if (this.target != null) {
				double xdiff = this.target.aW.a + (this.target.aW.d - this.target.aW.a) / 2.0D - this.aM;
				double ydiff = this.target.aW.b + (this.target.aW.e - this.target.aW.b) / 2.0D - this.aN;
				double zdiff = this.target.aW.c + (this.target.aW.f - this.target.aW.c) / 2.0D - this.aO;

				a(xdiff, ydiff, zdiff, 1.5F, 0.0F);
			}
		}

		bt localbt1 = ((bt)null).b(this.aM, this.aN, this.aO);
		bt localbt2 = ((bt)null).b(this.aM + this.aP, this.aN + this.aQ, this.aO + this.aR);
		vf localvf1 = this.aI.a(localbt1, localbt2, false, true);

		localbt1 = ((bt)null).b(this.aM, this.aN, this.aO);
		localbt2 = ((bt)null).b(this.aM + this.aP, this.aN + this.aQ, this.aO + this.aR);
		if (localvf1 != null) {
			localbt2 = ((bt)null).b(localvf1.f.a, localvf1.f.b, localvf1.f.c);
		}
		sn localObject = null;
		List localList = this.aI.b(this, this.aW.a(this.aP, this.aQ, this.aR).b(1.0D, 1.0D, 1.0D));
		double d1 = 0.0D;
		for (int i1 = 0; i1 < localList.size(); i1++) {
			sn localsn = (sn)localList.get(i1);
			if ((!localsn.h_()) || ((localsn == this.c) && (this.k < 5)))
			continue;
			float f4 = 0.3F;
			eq localeq2 = localsn.aW.b(f4, f4, f4);
			vf localvf2 = localeq2.a(localbt1, localbt2);
			if (localvf2 != null) {
				double d2 = localbt1.c(localvf2.f);
				if ((d2 < d1) || (d1 == 0.0D)) {
					localObject = localsn;
					d1 = d2;
				}
			}
		}

		if (localObject != null) {
			localvf1 = new vf(localObject);
		}

		if (localvf1 != null) {
			if (localvf1.g != null) {
				if (hitTarget(localvf1.g)) {
					localvf1.g.a(this.c, 4);
					this.aI.a(this, "random.drr", 1.0F, 1.2F / (this.bs.nextFloat() * 0.2F + 0.9F));
					K();
				} else {
					this.aP *= -0.1000000014901161D;
					this.aQ *= -0.1000000014901161D;
					this.aR *= -0.1000000014901161D;
					this.aS += 180.0F;
					this.aU += 180.0F;
					this.k = 0;
				}
			} else {
				this.d = localvf1.b;
				this.e = localvf1.c;
				this.f = localvf1.d;
				this.g = this.aI.a(this.d, this.e, this.f);
				this.h = this.aI.e(this.d, this.e, this.f);
				this.aP = (float)(localvf1.f.a - this.aM);
				this.aQ = (float)(localvf1.f.b - this.aN);
				this.aR = (float)(localvf1.f.c - this.aO);
				double f2 = in.a(this.aP * this.aP + this.aQ * this.aQ + this.aR * this.aR);
				this.aM -= this.aP / f2 * 0.0500000007450581D;
				this.aN -= this.aQ / f2 * 0.0500000007450581D;
				this.aO -= this.aR / f2 * 0.0500000007450581D;

				this.aI.a(this, "random.drr", 1.0F, 1.2F / (this.bs.nextFloat() * 0.2F + 0.9F));
				this.i = true;
				this.b = 7;

				hitGround(localvf1.b, localvf1.c, localvf1.d, localvf1.e, this.f);
			}
		}
		this.aM += this.aP;
		this.aN += this.aQ;
		this.aO += this.aR;

		float f2 = in.a(this.aP * this.aP + this.aR * this.aR);
		this.aS = (float)(Math.atan2(this.aP, this.aR) * 180.0D / 3.141592741012573D);
		this.aT = (float)(Math.atan2(this.aQ, f2) * 180.0D / 3.141592741012573D);

		while (this.aT - this.aV < -180.0F)
		this.aV -= 360.0F;
		while (this.aT - this.aV >= 180.0F) {
			this.aV += 360.0F;
		}
		while (this.aS - this.aU < -180.0F)
		this.aU -= 360.0F;
		while (this.aS - this.aU >= 180.0F) {
			this.aU += 360.0F;
		}
		this.aT = (this.aV + (this.aT - this.aV) * 0.2F);
		this.aS = (this.aU + (this.aS - this.aU) * 0.2F);

		float f3 = 0.99F;
		float f4 = 0.03F;

		if (ag()) {
			for (int i2 = 0; i2 < 4; i2++) {
				float f5 = 0.25F;
				this.aI.a("bubble", this.aM - this.aP * f5, this.aN - this.aQ * f5, this.aO - this.aR * f5, this.aP, this.aQ, this.aR);
			}
			f3 = 0.8F;
		}

		if (!this.homing) {
			this.aP *= f3;
			this.aQ *= f3;
			this.aR *= f3;
			this.aQ -= f4;
		}

		e(this.aM, this.aN, this.aO);
	}

	public void b(nu paramnu) {
		paramnu.a("xTile", (short)this.d);
		paramnu.a("yTile", (short)this.e);
		paramnu.a("zTile", (short)this.f);
		paramnu.a("inTile", (byte)this.g);
		paramnu.a("inData", (byte)this.h);
		paramnu.a("shake", (byte)this.b);
		paramnu.a("inGround", (byte)(this.i ? 1 : 0));
		paramnu.a("player", this.a);
	}

	public void a(nu paramnu) {
		this.d = paramnu.d("xTile");
		this.e = paramnu.d("yTile");
		this.f = paramnu.d("zTile");
		this.g = (paramnu.c("inTile") & 0xFF);
		this.h = (paramnu.c("inData") & 0xFF);
		this.b = (paramnu.c("shake") & 0xFF);
		this.i = (paramnu.c("inGround") == 1);
		this.a = paramnu.m("player");
	}

	public boolean hitTarget(sn target) {
		return true;
	}

	public void hitGround(int x, int y, int z, int side, int block) {
	}

	public iz getItem() {
		return new iz(gm.j, 1);
	}

	public void b(gs paramgs) {
		if (this.aI.B) return;

		if ((this.i) && (this.a) && (this.b <= 0) && 
				(paramgs.c.a(getItem()))) {
			this.aI.a(this, "random.pop", 0.2F, ((this.bs.nextFloat() - this.bs.nextFloat()) * 0.7F + 1.0F) * 2.0F);
			paramgs.b(this, 1);
			K();
		}
	}

	public boolean validTarget(ls target) {
		return true;
	}

	@SuppressWarnings("rawtypes")
	private ls getTarget(double x, double y, double z, double range) {
		double bestdist = -1.0D;
		ls target = null;

		List found = this.aI.b(this, this.aW.b(16.0D, 16.0D, 16.0D));
		for (int i1 = 0; i1 < found.size(); i1++) {
			sn entity = (sn)found.get(i1);
			if ((!(entity instanceof ls)) || 
					(entity == this.c) || (!validTarget((ls)entity)))
			continue;
			double dist = entity.g(x, y, z);
			if (((range < 0.0D) || (dist < range * range)) && ((bestdist == -1.0D) || (dist < bestdist)) && (((ls)entity).e(this))) {
				bestdist = dist;
				target = (ls)entity;
			}
		}

		return target;
	}

	public float x_() {
		return 0.0F;
	}
}