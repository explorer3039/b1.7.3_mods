import java.lang.reflect.Constructor;

public class qz extends gm {
	public final boolean homing;
	
	public qz(int itemID) {
		this(itemID,false);
	}

	public qz(int itemID, boolean ishoming) {
		super(itemID);
		homing = ishoming;
		bg = 1;
	}

	@SuppressWarnings("rawtypes")
	public iz a(iz stack, fd world, gs player) {
		if (mod_Backpack.quiver.isEquipped()) {
			int eatArrow = mod_Backpack.quiver.eatArrow();
			if (eatArrow != 0) {
				sl arrow = null;
				
				try {
					Constructor cstr;
					
					cstr = Class.forName("EntityArrowExplosive").getConstructor(fd.class,gs.class,Boolean.class);
					if (eatArrow == mod_Arrows.exp.bf) arrow = (sl)cstr.newInstance(world,player,homing);
					
					cstr = Class.forName("EntityArrowLightning").getConstructor(fd.class,gs.class,Boolean.class);
					if (eatArrow == mod_Arrows.lig.bf) arrow = (sl)cstr.newInstance(world,player,homing);
					
					cstr = Class.forName("EntityArrowFire").getConstructor(fd.class,gs.class,Boolean.class);
					if (eatArrow == mod_Arrows.fir.bf) arrow = (sl)cstr.newInstance(world,player,homing);
					
					cstr = Class.forName("EntityArrowEgg").getConstructor(fd.class,gs.class,Boolean.class);
					if (eatArrow == mod_Arrows.egg.bf) arrow = (sl)cstr.newInstance(world,player,homing);
					
					cstr = Class.forName("EntityArrowIce").getConstructor(fd.class,gs.class,Boolean.class);
					if (eatArrow == mod_Arrows.ice.bf) arrow = (sl)cstr.newInstance(world,player,homing);
				} catch (Exception e) {}
				
				if (arrow == null) arrow = new sl(world,player,homing);
				
				world.a(player, "random.bow", 1.0F, 1.0F / (b.nextFloat() * 0.4F + 0.8F));
				if (!world.B) world.b(arrow);
			}
		}
		return stack;
	}
}