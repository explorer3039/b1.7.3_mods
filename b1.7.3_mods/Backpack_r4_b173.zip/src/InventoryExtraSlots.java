public class InventoryExtraSlots extends qo implements lw {
	public InventoryExtraSlots(String title, int slots) {
		super(title,slots);
	}
	
	public boolean checkIsEmpty() {
		for (int i = 0; i < a(); i++) {
			if (f_(i) != null) return false;
		}
		return true;
	}
	public int countNotEmpty() {
		int count = 0;
		for (int i = 0; i < a(); i++) {
			if (f_(i) != null) count++;
		}
		return count;
	}
	public int countAmount() {
		int count = 0;
		for (int i = 0; i < a(); i++) {
			if (f_(i) != null) count += f_(i).a;
		}
		return count;
	}
	public void dropItems() {
		gs player = ModLoader.getMinecraftInstance().h;
		for (int i = 0; i < a(); i++) {
			if (f_(i) != null) player.a(f_(i));
			a(i,null);
		}
	}
	
	public boolean acceptItem(iz stack) {
		return true;
	}
	
	public boolean a(iz iz1) {
		if (!acceptItem(iz1)) return false;
		
		if(!iz1.g()) {
			int k;

			do {
				k = iz1.a;
				iz1.a = e(iz1);
			} while(iz1.a > 0 && iz1.a < k);

			return iz1.a < k;
		}

		int l = j();

		if(l >= 0) {
			a(l,iz.b(iz1));
			f_(l).b = 5;
			iz1.a = 0;
			return true;
		} else {
			return false;
		}
	}
	private int j() {
		for(int k = 0; k < a(); k++)
		if(f_(k) == null)
		return k;

		return -1;
	}
	private int e(iz iz1) {
		int k = iz1.c;
		int l = iz1.a;
		int i1 = d(iz1);

		if(i1 < 0)
		i1 = j();

		if(i1 < 0)
		return l;

		if(f_(i1) == null) a(i1,new iz(k, 0, iz1.i()));

		int j1 = l;
		if(j1 > f_(i1).c() - f_(i1).a) j1 = f_(i1).c() - f_(i1).a;
		if(j1 > d() - f_(i1).a) j1 = d() - f_(i1).a;

		if(j1 == 0) {
			return l;
		} else {
			l -= j1;
			f_(i1).a += j1;
			f_(i1).b = 5;
			return l;
		}
	}
	private int d(iz iz1) {
		for(int k = 0; k < a(); k++)
		if(f_(k) != null && f_(k).c == iz1.c && f_(k).d() && f_(k).a < f_(k).c() && f_(k).a < d() && (!f_(k).f() || f_(k).i() == iz1.i()))
		return k;

		return -1;
	}
}