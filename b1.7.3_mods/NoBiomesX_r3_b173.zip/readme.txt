/---------------\
/- No Biomes X -\
/- revision 3  -\
/---------------\

Installation:

1: Open minecraft.jar with a zip utility, like 7-zip
2: Install ModLoader and ModOptionsAPI 0.7
3: Place all the class files and terrain.png into the root of minecraft.jar (you can skip terrain.png if you wish to use a texture pack only).
4: Place the contents of the misc folder in the No Biomes X archive into the misc folder in minecraft.jar
5: Generate a new level. There is a 1/4th chance that the level will be snowy. 

Notes:
1: Tall grass is not in, so you can hoe grass to get seeds again. I may need to check the rate, it doesn't feel right at the moment.

--InsanityBringer