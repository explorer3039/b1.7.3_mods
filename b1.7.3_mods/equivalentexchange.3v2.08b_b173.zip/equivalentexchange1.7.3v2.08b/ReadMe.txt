Installation:

1: Install Risugami's Modloader. If you don't know what that is, look it up on Google.
Follow the directions on his page to learn how to install mods. It will help you install this.
(1b: install Risugami's Audiomod if you want wall sound effect)
2: Merge the "resources" folder with the resources folder in your .minecraft directory.
*This is if you want sound, and you must use Audiomod to enable the sounds.
3: Merge the "mods" folder with the mods folder in your .minecraft directory. If you do not have a "mods"
folder in your .minecraft directory, create one, and merge.
4: If you have any problems playing the mod, you can always install manually: open your minecraft.jar and copy
the contents of the EquivalentExchange[version].zip directly into the .jar file.
5: Enjoy!

My forum name is x3n0ph0b3 if you have any questions, I'm also on MCModcenter. Stop by and say hello!

You can also join #risucraft on irc.esper.net, I troll there frequently! :D


