package net.minecraft.src;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.lwjgl.input.Mouse;

import org.lwjgl.input.Keyboard;

public class AutoToolMode 
{
	private static boolean toolChangeBuffer = false;
	private static AutoToolMode off = new AutoToolMode();
	private static ArrayList<AutoToolMode> autoToolModes = new ArrayList<AutoToolMode>();
	private static boolean isModifiable = autoToolModes.add(off);//should give true
	private static int index = 0;
	private static KeyBinding toolChangeKey = new KeyBinding("key.toolChange", 2 - 100);
	
	public static boolean registerAutoToolMode(int index, AutoToolMode atm)
	{
		if(!isModifiable || index < 1)
			return false;
		while(autoToolModes.size() - 1 < index)
		{
			autoToolModes.add(null);
		}
		autoToolModes.set(index, atm);
		return true;
	}
	public static boolean setIndex(int toIndex)
	{
		if(!isModifiable || index < 0 || autoToolModes.size() - 1 < index)
		{
			return false;
		}
		index = toIndex;
		return true;
	}
	public static boolean setToolChangeKey(int keycode)
	{
		if(!isModifiable)
			return false;
		toolChangeKey = new KeyBinding("key.toolChange", keycode);
		return true;
	}
	public static void lock()
	{
		isModifiable = false;
	}
	public static boolean isToolChangeKeyPressEvent()
	{
		if(checkByMC1_8Keycode() && !toolChangeBuffer)
		{
			toolChangeBuffer = true;
			return true;
		}
		if(!checkByMC1_8Keycode())
			toolChangeBuffer = false;
		return false;
	}
	public static boolean checkByMC1_8Keycode()
	{
		if(toolChangeKey.keyCode < 0)
			return Mouse.isButtonDown(toolChangeKey.keyCode + 100);
		return Keyboard.isKeyDown(toolChangeKey.keyCode);
	}
	public static int getToolChangeKeyCode()
	{
		return toolChangeKey.keyCode;
	}
	public static AutoToolMode currentAutoToolMode()
	{
		return autoToolModes.get(index);
	}
	public static AutoToolMode nextAutoToolMode()
	{
		if(index++ >= autoToolModes.size() - 1)
		{
			index = 0;
		}
		return currentAutoToolMode() != null ? currentAutoToolMode() : nextAutoToolMode();
	}
	public static int getIndex()
	{
		return index;
	}
	public static List<AutoToolMode> getAutoToolModes()
	{
		return Collections.unmodifiableList(autoToolModes);
	}
	
	private static boolean verifySortingMethod(int toSort)
	{
		return toSort >= 0 && toSort <= 5;
	}
	
	private boolean baseFunction;
	private boolean useBucket;
	private boolean useHoe;
	private boolean useShearOnBlocks;
	private boolean useShearOnSheep;
	private boolean useAxeOnEntitys;
	private boolean usePickaxeOnEntitys;
	private boolean useShovelOnEntitys;
	private boolean useSwordOnTiles;
	private int sortingMethod;
	
	public AutoToolMode()
	{}//TODO Make stuff non-final until modifiable turns false!
	
	public boolean isBaseFunctionEnabled() 
	{
		return baseFunction;
	}
	public AutoToolMode setBaseFunction(boolean baseFunction) 
	{
		if(isModifiable)
			this.baseFunction = baseFunction;
		return this;
	}
	public boolean isUseBucketEnabled() 
	{
		return useBucket;
	}
	public AutoToolMode setUseBucket(boolean useBucket) 
	{
		if(isModifiable)
			this.useBucket = useBucket;
		return this;
	}
	public boolean isUseHoeEnabled() 
	{
		return useHoe;
	}
	public AutoToolMode setUseHoe(boolean useHoe) 
	{
		if(isModifiable)
			this.useHoe = useHoe;
		return this;
	}
	public boolean isUseShearOnBlocksEnabled() 
	{
		return useShearOnBlocks;
	}
	public AutoToolMode setUseShearOnBlocks(boolean useShearOnBlocks) 
	{
		if(isModifiable)
			this.useShearOnBlocks = useShearOnBlocks;
		return this;
	}
	public boolean isUseShearOnSheepEnabled() 
	{
		return useShearOnSheep;
	}
	public AutoToolMode setUseShearOnSheep(boolean useShearOnSheep) 
	{
		if(isModifiable)
			this.useShearOnSheep = useShearOnSheep;
		return this;
	}
	public boolean isUseAxeOnEntitysEnabled() 
	{
		return useAxeOnEntitys;
	}
	public AutoToolMode setUseAxeOnEntitys(boolean useAxeOnEntitys) 
	{
		if(isModifiable)
			this.useAxeOnEntitys = useAxeOnEntitys;
		return this;
	}
	public boolean isUsePickaxeOnEntitysEnabled() 
	{
		return usePickaxeOnEntitys;
	}
	public AutoToolMode setUsePickaxeOnEntitys(boolean usePickaxeOnEntitys) 
	{
		if(isModifiable)
			this.usePickaxeOnEntitys = usePickaxeOnEntitys;
		return this;
	}
	public boolean isUseShovelOnEntitysEnabled() 
	{
		return useShovelOnEntitys;
	}
	public AutoToolMode setUseShovelOnEntitys(boolean useShovelOnEntitys) 
	{
		if(isModifiable)
			this.useShovelOnEntitys = useShovelOnEntitys;
		return this;
	}
	public boolean isUseSwordOnTilesEnabled() 
	{
		return useSwordOnTiles;
	}
	public AutoToolMode setUseSwordOnTiles(boolean useSwordOnTiles) 
	{
		if(isModifiable)
			this.useSwordOnTiles = useSwordOnTiles;
		return this;
	}
	public int getSortingMethod() 
	{
		return sortingMethod;
	}
	public AutoToolMode setSortingMethod(int sortingMethod) 
	{
		if(isModifiable)
			this.sortingMethod = sortingMethod;
		return this;
	}	
}
