package net.minecraft.src;

public class ComparatorByDurability implements java.util.Comparator<ItemStack>
{

	@Override
	public int compare(ItemStack arg0, ItemStack arg1) 
	{
		if(arg0 == null && arg1 == null)
			return 0;
		if(arg0 == null)
			return -1;
		if(arg1 == null)
			return 1;
		if (arg0.getItem() instanceof ItemBucket && arg0.getClass().equals(arg1.getClass()))
			return 0;
		if (!arg0.isItemStackDamageable() || !arg1.isItemStackDamageable())
		{
			throw new IllegalArgumentException();
		}
		return ((arg0.getMaxDamage() - arg0.getItemDamage())-(arg1.getMaxDamage() - arg1.getItemDamage()));
	}
}
