package net.minecraft.src;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Properties;

import org.lwjgl.input.Keyboard;

import net.minecraft.client.Minecraft;

public class mod_ATL extends BaseMod
{
	private boolean readFromFile = true;
	private static File ff;
	private static File fff;
	private static File ffk;
	private static File override;
	public mod_ATL()
	{
		ModLoader.SetInGameHook(this, true, true);
	}
	@Override
	public boolean OnTickInGame(Minecraft minecraft)
    {
		if(readFromFile)
		{
			AutoToolMode.registerAutoToolMode(1, new AutoToolMode().setBaseFunction(true));
			AutoToolMode.registerAutoToolMode(2, new AutoToolMode().setBaseFunction(true).setUseBucket(true).setUseHoe(true).setUseShearOnBlocks(true).setUseShearOnSheep(true).setUseAxeOnEntitys(true).setUsePickaxeOnEntitys(true).setUseShovelOnEntitys(true).setUseSwordOnTiles(true));
			ff = new File(Minecraft.getMinecraftDir().getAbsolutePath().concat("/mods/AutoTool"));
			fff = new File(ff.getAbsolutePath().concat("/AutoToolMode.txt"));
			override = new File(Minecraft.getMinecraftDir().getAbsolutePath().concat("/override.txt"));
			FileInputStream fis = null;
			Properties p = new Properties();
			try
			{	
				ff.mkdirs();
				fis = new FileInputStream(fff);
				p.load(fis);
				int in = Integer.parseInt(p.getProperty("ToolMode"));
				if(in > 0 && in < 3)
				{
					AutoToolMode.setIndex(in);
					AutoTool.notifyModeChange();
				}
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			finally
			{
				try
				{
					fis.close();
				}
				catch(Exception e)
				{}
			}
			ffk = new File(ff.getAbsolutePath().concat("/AutoToolKey.txt"));
			try
			{	
				fis = new FileInputStream(ffk);
				p.load(fis);
				int in = Integer.parseInt(p.getProperty("key_key.toolChange"));
				AutoToolMode.setToolChangeKey(in);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			finally
			{
				try
				{
					fis.close();
				}
				catch(Exception e)
				{}
			}
			FileOutputStream fos = null;
			try
			{
				p.clear();
				p.setProperty("key_key.toolChange", Integer.toString(AutoToolMode.getToolChangeKeyCode()));
				fos = new FileOutputStream(ffk);
				p.store(fos, null);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			finally
			{
				try
				{
					fos.close();
				}
				catch(Exception e)
				{}
			}
			minecraft.fontRenderer.drawStringWithShadow("ToolMode:".concat(Integer.toString(AutoToolMode.getIndex())), 2, 53, 0xffffff);
			readFromFile = false;
		}
		if(override.exists() || minecraft.theWorld != null && !minecraft.theWorld.multiplayerWorld)
		{
			AutoTool.setInventorySlot(minecraft.currentScreen,minecraft.theWorld, minecraft.objectMouseOver, minecraft.playerController);
			if(AutoTool.getHasAutoToolModeChanged())
			{
				minecraft.fontRenderer.drawStringWithShadow("ToolMode:".concat(Integer.toString(AutoToolMode.getIndex())), 2, 53, 0xffffff);
				FileOutputStream fos = null;
				try
				{
					ff.mkdirs();
					Properties p = new Properties();
					p.setProperty("ToolMode", Integer.toString(AutoToolMode.getIndex()));
					fos = new FileOutputStream(fff);
					p.store(fos, null);
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
				finally
				{
					try
					{
						fos.close();
					}
					catch(Exception e)
					{}
				}
			}
		}
		return true;
	}
	 @Override
	 public String Version()
	 {
		 return ("1.8.1 V:1.3");
	 }

}
