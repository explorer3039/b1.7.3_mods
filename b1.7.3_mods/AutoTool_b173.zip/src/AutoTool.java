package net.minecraft.src;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

public class AutoTool 
{	
	private static boolean hasAutoToolModeChanged;
	private static int inventoryBuffer;
	private static boolean needsRestore;
	private static List<Integer> locations = new ArrayList<Integer>();//needs to get updated every tick
	private static ArrayList<Class> optimalClassList = new ArrayList<Class>();//too
	private static Comparator<ItemStack> listSorter;//needs to get updated every time mode changes
		private static final Comparator<ItemStack> materialDown = new ComparatorBySpeed();
		private static final Comparator<ItemStack> materialUp = Collections.reverseOrder(materialDown);
		private static final Comparator<ItemStack> durabilityDown = new ComparatorByDurability();
		private static final Comparator<ItemStack> durabilityUp = Collections.reverseOrder(durabilityDown);
	
	public static void notifyModeChange()
	{
		switch(AutoToolMode.currentAutoToolMode().getSortingMethod())
		{
			case 2:{ listSorter = materialDown; break;}
			case 3:{ listSorter = materialUp; break;}
			case 4:{ listSorter = durabilityDown; break;}
			case 5:{ listSorter = durabilityUp; break;}
			default: listSorter = null;
		}
	}
	
	public static void setInventorySlot(GuiScreen currentScreen, World theWorld, MovingObjectPosition objectMouseOver, PlayerController playerController)
	{
		///System.out.println(kb.func_35962_c());die hattedownevent funktion!
		hasAutoToolModeChanged = false;
		if(currentScreen == null)
		{
			if (theWorld != null)
			{
				EntityPlayer thePlayer = (EntityPlayer)theWorld.playerEntities.get(0);
				InventoryPlayer inventoryPlayer = thePlayer.inventory;
				if (Mouse.isButtonDown(0))
				{
					updateRequestedItems(inventoryPlayer, false);
					updateOptimalClassList(theWorld, thePlayer, objectMouseOver);
					for(Class each: optimalClassList)
					{
						for(int eachLocation: locations)
						{
							ItemStack itemStack = inventoryPlayer.mainInventory[eachLocation];
							Item item = itemStack.getItem();
							if (each == item.getClass())
							{
								removeNotFromClass(each, inventoryPlayer);
								if(item instanceof ItemPickaxe)
									removeWrongPickaxes(theWorld, inventoryPlayer, objectMouseOver);
								if (!locations.isEmpty())
								{
									if (!needsRestore)
										inventoryBuffer = inventoryPlayer.currentItem;
									needsRestore = true;
									inventoryPlayer.currentItem = doSort(inventoryPlayer);
									if (item instanceof ItemBucket)
										playerController.sendUseItem(thePlayer, theWorld, inventoryPlayer.getCurrentItem());
									if (item instanceof ItemHoe)
									{
										playerController.sendPlaceBlock(thePlayer, theWorld, inventoryPlayer.getCurrentItem(), objectMouseOver.blockX, objectMouseOver.blockY, objectMouseOver.blockZ, objectMouseOver.sideHit);//TODO this doesnt really work!!!!!!!
										thePlayer.onItemStackChanged(thePlayer.getCurrentEquippedItem());
									}
									//there may be bugs because the itemstack gets changed too fast!
									//itemstacks size gets negative
									//destroying a block afterward with it will destroy it!
									if (item instanceof ItemShears && objectMouseOver.typeOfHit == EnumMovingObjectType.ENTITY && objectMouseOver.entityHit instanceof EntitySheep)
									{
										EntitySheep theSheep = (EntitySheep) objectMouseOver.entityHit;
										if (!theSheep.getSheared())
											playerController.interactWithEntity(thePlayer, objectMouseOver.entityHit);
									}
									//check for stacksize 0 and remove!
									if(itemStack.stackSize == 0)
					                    thePlayer.inventory.mainInventory[thePlayer.inventory.currentItem] = null;
									return;
								}
							}
						}
					}
				}
				if (needsRestore)
				{
					inventoryPlayer.currentItem = inventoryBuffer;
					needsRestore = false;
				}
				if (AutoToolMode.isToolChangeKeyPressEvent())
				{	
					hasAutoToolModeChanged = true;
					AutoToolMode.nextAutoToolMode();
					notifyModeChange();
				}
			}
		}
	}
	private static void updateRequestedItems(InventoryPlayer ip, boolean doFullInventory)
	{
		locations.clear();
		int invSize;
		if (doFullInventory)
		{
			invSize = 36;
		}
		else
		{
			invSize = 9;
		}
		for ( int i = 0;i<=invSize; i++ )
        {
			ItemStack is = ip.mainInventory[i];
			if (is != null)
			{
				Item it = is.getItem();
				AutoToolMode atm = AutoToolMode.currentAutoToolMode();
				if((it instanceof ItemSword && (atm.isBaseFunctionEnabled() || atm.isUseSwordOnTilesEnabled())) ||
					it instanceof ItemTool ||
					(it instanceof ItemHoe && atm.isUseHoeEnabled()) ||
					(it instanceof ItemShears && (atm.isUseShearOnSheepEnabled() || atm.isUseShearOnBlocksEnabled())) ||
					(it == Item.bucketEmpty && atm.isUseBucketEnabled()))
						locations.add(i);
			}	
        }
	}
	private static void updateOptimalClassList(World theWorld, EntityPlayer thePlayer, MovingObjectPosition objectMouseOver)
	{
		optimalClassList.clear();
		if (isBucketAnOption(theWorld, thePlayer))
			optimalClassList.add(ItemBucket.class);
		if (objectMouseOver != null)
		{
			AutoToolMode atm = AutoToolMode.currentAutoToolMode();
			if (objectMouseOver.typeOfHit == EnumMovingObjectType.TILE)
			{
				int currentBlockID = theWorld.getBlockId(objectMouseOver.blockX, objectMouseOver.blockY, objectMouseOver.blockZ);
				if  ((currentBlockID == 63 || currentBlockID == 68) && atm.isUseSwordOnTilesEnabled())
				{
					optimalClassList.add(ItemSword.class);
				}
				if (Block.blocksList[currentBlockID] != null)
				{
					Block currentBlock = Block.blocksList[currentBlockID];
					if(isHoeAnOption(theWorld,objectMouseOver))
						optimalClassList.add(ItemHoe.class);
					if(isShearOnBlockAnOption(currentBlockID) && atm.isUseShearOnBlocksEnabled())
						optimalClassList.add(ItemShears.class);
					if(atm.isBaseFunctionEnabled())
						registerBaseFunctionOnBlock(currentBlock);
					if (isSwordOnBlockAnOption(currentBlock) && atm.isUseSwordOnTilesEnabled())
						optimalClassList.add(ItemSword.class);
				}
			}
			else
			{
				if (objectMouseOver.entityHit instanceof EntityLiving)
				{
					if (objectMouseOver.entityHit instanceof EntitySheep && atm.isUseShearOnSheepEnabled())
					{
						EntitySheep theSheep = (EntitySheep) objectMouseOver.entityHit;
						if (!theSheep.getSheared())
							optimalClassList.add(ItemShears.class);
					}
					if(atm.isBaseFunctionEnabled())
						optimalClassList.add(ItemSword.class);
					if (atm.isUseAxeOnEntitysEnabled())
						optimalClassList.add(ItemAxe.class);
					if (atm.isUsePickaxeOnEntitysEnabled())
						optimalClassList.add(ItemPickaxe.class);
					if (atm.isUseShovelOnEntitysEnabled())
						optimalClassList.add(ItemSpade.class);
				}
			}			
		}
	}
	private static boolean isBucketAnOption(World theWorld, EntityPlayer thePlayer)
	{
		/*copy-pasted from ItemBucket*/
		float f = 1.0F;
        float f1 = thePlayer.prevRotationPitch + (thePlayer.rotationPitch - thePlayer.prevRotationPitch) * f;
        float f2 = thePlayer.prevRotationYaw + (thePlayer.rotationYaw - thePlayer.prevRotationYaw) * f;
        float f3 = MathHelper.cos(-f2 * 0.01745329F - 3.141593F);
        float f4 = MathHelper.sin(-f2 * 0.01745329F - 3.141593F);
        float f5 = -MathHelper.cos(-f1 * 0.01745329F);
        float f6 = MathHelper.sin(-f1 * 0.01745329F);
        float f7 = f4 * f5;
        float f8 = f6;
        float f9 = f3 * f5;
		double d = thePlayer.prevPosX + (thePlayer.posX - thePlayer.prevPosX) * (double)f;
        double d1 = (thePlayer.prevPosY + (thePlayer.posY - thePlayer.prevPosY) * (double)f + 1.6200000000000001D) - (double)thePlayer.yOffset;
        double d2 = thePlayer.prevPosZ + (thePlayer.posZ - thePlayer.prevPosZ) * (double)f;
        double d3 = 5D;
        Vec3D vec3d = Vec3D.createVector(d, d1, d2);
        Vec3D vec3d1 = vec3d.addVector((double)f7 * d3, (double)f8 * d3, (double)f9 * d3);
	    MovingObjectPosition movingObjectPosition = theWorld.rayTraceBlocks_do(vec3d, vec3d1, true);
	    if (movingObjectPosition != null)
	    {
	    	if(movingObjectPosition.typeOfHit == EnumMovingObjectType.TILE)
	    	{
	    		int i = movingObjectPosition.blockX;
	            int j = movingObjectPosition.blockY;
	            int k = movingObjectPosition.blockZ;
	    		return((theWorld.getBlockMaterial(i, j, k) == Material.water || theWorld.getBlockMaterial(i, j, k) == Material.lava) && theWorld.getBlockMetadata(i, j, k) == 0);
	    	}
	    	else
	    		return (movingObjectPosition.entityHit instanceof EntityCow);
	    }
	    return false;
	}
	private static boolean isHoeAnOption(World theWorld, MovingObjectPosition objectMouseOver)
	{
		if (objectMouseOver != null && objectMouseOver.typeOfHit == EnumMovingObjectType.TILE)
		{
			int blockID = theWorld.getBlockId(objectMouseOver.blockX, objectMouseOver.blockY, objectMouseOver.blockZ);
			int blockAboveID = theWorld.getBlockId(objectMouseOver.blockX, objectMouseOver.blockY + 1, objectMouseOver.blockZ);
			return(blockAboveID == 0 && blockID == Block.grass.blockID || blockID == Block.dirt.blockID);
		}
		return false;
	}
	private static boolean isShearOnBlockAnOption(int blockID)
	{
		return(blockID == Block.leaves.blockID || blockID == Block.cloth.blockID || blockID == Block.web.blockID);
	}
	private static void registerBaseFunctionOnBlock(Block currentBlock)
	{
		if (Item.pickaxeDiamond.canHarvestBlock(currentBlock))
			optimalClassList.add(ItemPickaxe.class);
		if (Item.shovelWood.getStrVsBlock(null, currentBlock) > 1.0F)
			optimalClassList.add(ItemSpade.class);
		if (Item.axeWood.getStrVsBlock(null, currentBlock) > 1.0F)
			optimalClassList.add(ItemAxe.class);
	}
	private static boolean isSwordOnBlockAnOption(Block block)
	{
		return (block.blockMaterial != Material.rock && block.blockMaterial != Material.iron && block.blockMaterial != Material.builtSnow && block.blockMaterial != Material.snow && block.getHardness() > 0.2F);
	}
	private static void removeNotFromClass(Class item, InventoryPlayer inventoryPlayer)
	{
		for (int i = 0; i < locations.size(); i++)
        {
			 if (inventoryPlayer.mainInventory[locations.get(i)].getItem().getClass() != item)
			 {
					 locations.remove(i);
					 i--;
			 }	
        }
	}
	private static void removeWrongPickaxes(World theWorld, InventoryPlayer ip, MovingObjectPosition objectMouseOver)
	{
		for (int i = 0; i < locations.size(); i++)
        {
			if(!(doesPickaxeFit(theWorld, ip.mainInventory[locations.get(i)].getItem(), objectMouseOver)))
			{
				locations.remove(i);
				 i--;
			}
        }
	}
	private static boolean doesPickaxeFit(World theWorld, Item item, MovingObjectPosition objectMouseOver)
	{
		if (objectMouseOver.typeOfHit == EnumMovingObjectType.TILE)
		{
			int currentBlockID = theWorld.getBlockId(objectMouseOver.blockX, objectMouseOver.blockY, objectMouseOver.blockZ);
			Block currentBlock = Block.blocksList[currentBlockID];
			return (item.canHarvestBlock(currentBlock));
		}
		return true;
	}
	private static int doSort(InventoryPlayer inventoryPlayer)
	{
		
		AutoToolMode atm = AutoToolMode.currentAutoToolMode();
		if (atm.getSortingMethod() == 1)
			return locations.get(locations.size() - 1);
		int locationOut = 0;
		if (listSorter != null)
		{
		ItemStack bestItemStack = null;
			for ( int i = 0;i < locations.size(); i++ )
		    {
				ItemStack itemStack = inventoryPlayer.mainInventory[locations.get(i)];
				if (bestItemStack == null)
				{
					bestItemStack = itemStack;
					locationOut = i;
				}
				if (listSorter.compare(itemStack, bestItemStack) > 0)
				{
					bestItemStack = itemStack;
					locationOut = i;
				}
			}
		}
		return locations.get(locationOut);
	}
	public static boolean getHasAutoToolModeChanged()
	{
		return hasAutoToolModeChanged;
	}
}