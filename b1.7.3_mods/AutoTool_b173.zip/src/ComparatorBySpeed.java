package net.minecraft.src;

public class ComparatorBySpeed implements java.util.Comparator<ItemStack>{

	@Override
	public int compare(ItemStack arg0, ItemStack arg1) 
	{
		if(arg0 == null && arg1 == null)
			return 0;
		if(arg0 == null)
			return -1;
		if(arg1 == null)
			return 1;
		if ((arg0.getItem() instanceof ItemBucket || arg0.getItem() instanceof ItemShears) && arg0.getClass().equals(arg1.getClass()))
				return 0;
		if (!((arg0.getItem() instanceof ItemTool || arg0.getItem() instanceof ItemSword || arg0.getItem() instanceof ItemHoe) && arg0.getClass().equals(arg1.getClass())))
		{
			throw new IllegalArgumentException();
		}
		int compArg0 = (arg0.getMaxDamage());
		int compArg1 = (arg1.getMaxDamage());
		if (arg0.getItem() instanceof ItemTool)
		{
			if (arg0.getMaxDamage() == EnumToolMaterial.GOLD.getMaxUses())
				compArg0 = (EnumToolMaterial.EMERALD.getMaxUses() + 1);
			if (arg1.getMaxDamage() == EnumToolMaterial.GOLD.getMaxUses())
				compArg1 = (EnumToolMaterial.EMERALD.getMaxUses() + 1);
		}
		return (compArg0 - compArg1);
	}

}
