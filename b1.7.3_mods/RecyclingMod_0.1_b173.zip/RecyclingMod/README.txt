+++++++++++Installation:+++++++++++++++

Open the .minecraft folder. Then go to bin and now open the minecraft.jar with winrar 7zip or something else.
Then put the .class files into the directory. the oldGlass.png you have to put into the gui folder.
At last delete the META-INF folder.