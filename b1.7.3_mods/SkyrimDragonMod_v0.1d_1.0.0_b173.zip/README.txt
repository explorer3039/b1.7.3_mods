Works with 1.8.1, do read below, all credit goes to "thatsgerman"
theres bound to be bugs, so back up your saves and .jar

*****************************************************************
*****************************************************************
*****************************************************************

Skyrim Dragon Mob for Minecraft!

This is the testing version, its far from being a "release" for it as I have SO much more to add
Version 0.1

Installation: 
Put all the files in "Put in Minecraft.jar" in your Minecraft.jar, that includes all the .class files and the arrows folder
put the resources file in your .minecraft
That should be all

Requirements: 
ModLoader for 1.7.3
AudioMod
Minecraft 1.7.3
NOT 1.8 COMPATIBLE (at least as far as I know as of right now [Sep 7th, at 6:17 Pacific Time] 1.8 has not been released)

If you use this mod...
This mod has taken an astronomical amount of time, and ive enjoyed it but I need feedback!
If you use this mod I would really appreciate it if you would leave a comment on this mods page
and tell me how it can be improved! whether its slower attack, less fire, less health for the dragon... ect

For more information please visit the forum which you got this from!

Trademark blobedy blah whatever

Credits:
Me! thatsgerman
All the tutorials I learned from!
inlanoche in particular, hes made a pheonominal tutorial on mobs and if you want to make a mob, check this guy out! hes brilliant! 

