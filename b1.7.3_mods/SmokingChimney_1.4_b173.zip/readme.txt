Smoking Chimney Minecraft mod
v 1.4 for Minecraft 1.7.3

Created by MightyPork (c) 2011, all rights reserved.
www.ondrovo.com
ondra@ondrovo.com
icq 217-419-545

First published at planetminecraft.com.

Licence: 
* You can decompile and edit this mod as you wish, but do not redistribute any original or modified parts.
* The base textures were created by Mojang, do not redistribute them as well.
* Always link to the download page, not the zip file
* Sources are hosted here: http://www.ondrovo.com/mods/chimneysource.zip. 
*  Do not redistribute original nor modified source files.

Crafting recipe:
#.#
#.# --> 6 chimney blocks
#.#
where # = cobblestone or brick wall


When does chimney smoke:
* If lit furnace is directly connected to it
* If fire is lit under the chimney (up to 2 blocks far), or on a block neighbour to the block under the chimney (not diagonal)
* If diagonal fire/furnace is providing smoke to other chimney, which is connected to this one
* Only the topmost chimney smokes, others are just a "tube".

Tips:
* You can combine both chimney types, it doesn't matter.
* Chimney won't get smoke if it's interrupted by a non-chimney block (eg. air, dirt).
* You can create double and triple chimneys with just one smoke source (eg. furnace). For triple chimney, the source must be connected to the middle chimney.
* Chimney height is not limited, but if higher than 16 blocks, you won't see any smoke..

Technical info:
* IDs: 243 (cobble), 244 (brick)
* REQUIRES MODLOADER
* Smoke is generated only if you stand closer than 16 blocks. This cannot be changed, it is a limitation of the minecraft renderer.