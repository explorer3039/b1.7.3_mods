package net.minecraft.src.breadCrumbs;

import net.minecraft.src.*;

public class EntityBreadCrumb extends Entity {

	public EntityBreadCrumb(World world) {
		super(world);
		setSize(mod_BreadCrumbs.size*0.1F, mod_BreadCrumbs.size*0.1F);
	}

	protected void entityInit() {
	}

	public boolean isInRangeToRenderDist(double d) {
		double d1 = boundingBox.getAverageEdgeLength() * 4D;
		d1 *= 64D;
		return d < d1 * d1;
	}

	public void onUpdate() {
		super.onUpdate();
		// fire = 10;
		if(onGround)
			motionY=0;
		else
			motionY-=0.1;
		pushOutOfBlocks(posX, (boundingBox.minY + boundingBox.maxY) / 2D, posZ);
        moveEntity(motionX, motionY, motionZ);
	}

	public void writeEntityToNBT(NBTTagCompound nbttagcompound) {
	}

	public void readEntityFromNBT(NBTTagCompound nbttagcompound) {
	}

	public boolean canBeCollidedWith() {
		return true;
	}

	public float getCollisionBorderSize() {
		return mod_BreadCrumbs.size*0.1F;
	}

	public boolean attackEntityFrom(Entity entity, int i) {
		if(!ModLoader.getMinecraftInstance().thePlayer.inventory.addItemStackToInventory(new ItemStack(mod_BreadCrumbs.breadCrumbs)))
			return false;
		setEntityDead();
		worldObj.playSoundAtEntity(this, "random.pop", 0.2F, ((rand.nextFloat() - rand.nextFloat()) * 0.7F + 1.0F) * 2.0F);
		return true;
    }
	
//	public boolean interact(EntityPlayer player) {
//		// TODO: BC gui?
//		if(!player.inventory.addItemStackToInventory(new ItemStack(mod_BreadCrumbs.breadCrumbs)))
//			return false;
//		setEntityDead();
//		worldObj.playSoundAtEntity(this, "random.pop", 0.2F, ((rand.nextFloat() - rand.nextFloat()) * 0.7F + 1.0F) * 2.0F);
//		return true;
//	}

	public float getEntityBrightness(float f) {
		if (mod_BreadCrumbs.brightness < 0) {
			int i = MathHelper.floor_double(posX);
			double d = (boundingBox.maxY - boundingBox.minY) * 0.66000000000000003D;
			int j = MathHelper.floor_double((posY - (double) yOffset) + d);
			int k = MathHelper.floor_double(posZ);
			if (worldObj.checkChunksExist(
					MathHelper.floor_double(boundingBox.minX),
					MathHelper.floor_double(boundingBox.minY),
					MathHelper.floor_double(boundingBox.minZ),
					MathHelper.floor_double(boundingBox.maxX),
					MathHelper.floor_double(boundingBox.maxY),
					MathHelper.floor_double(boundingBox.maxZ))) {
				return worldObj.getLightBrightness(i, j, k);
			} else {
				return 0.0F;
			}
		} else
			return mod_BreadCrumbs.brightness;
	}

	public float getShadowSize() {
		return 0.0F;
	}
}