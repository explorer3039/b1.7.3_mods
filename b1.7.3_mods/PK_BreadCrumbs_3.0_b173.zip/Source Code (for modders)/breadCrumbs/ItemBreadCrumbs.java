package net.minecraft.src.breadCrumbs;

import net.minecraft.src.*;
import net.minecraft.client.Minecraft;

public class ItemBreadCrumbs extends Item {

	public ItemBreadCrumbs(int i) {
		super(i);
		maxStackSize = 64;
	}

	public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer player) {
		// TODO: Allow players to customise the message?
		if (!world.multiplayerWorld) {
			Minecraft game = ModLoader.getMinecraftInstance();
			mod_BreadCrumbs.trailOn = !mod_BreadCrumbs.trailOn;
			if (mod_BreadCrumbs.trailOn)
				game.ingameGUI.addChatMessage(player.username + ": This should help me find my way back.");
			else
				game.ingameGUI.addChatMessage(player.username + ": That should do the trick!");
		}
		return itemstack;
	}
}