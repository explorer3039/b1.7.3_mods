package net.minecraft.src;

import java.io.*;
import java.util.Map;
import java.util.Properties;

import net.minecraft.client.Minecraft;
import net.minecraft.src.breadCrumbs.*;

public class mod_BreadCrumbs extends BaseMod {
	
	public static final Item breadCrumbs = (new ItemBreadCrumbs(getCrumbsID())).setItemName("breadCrumbs");
	public static boolean trailOn = false;
	public static float frequency = 5;
	public static float size = 1;
	public static float brightness = -1;
	private EntityBreadCrumb lastCrumb;

	public mod_BreadCrumbs() {
		loadProperties();
		breadCrumbs.iconIndex = ModLoader.addOverride("/gui/items.png","/breadCrumbs/textures/crumbs.png");
		ModLoader.AddName(breadCrumbs, "Bread Crumbs");
		ModLoader.AddRecipe(new ItemStack(breadCrumbs, 64), new Object[] {
			//"#", Character.valueOf('#'), Block.sand });
			"#", Character.valueOf('#'), Item.bread });
		ModLoader.SetInGameHook(this, true, false);
	}
	
	private static int getCrumbsID() {
		int id=31400;
		FileInputStream propFile = null;
		Properties crumbProps = new Properties();
		try {
			propFile = new FileInputStream(Minecraft.getMinecraftDir().toString()+"/BreadCrumbs.properties");
			crumbProps.load(propFile);
			id=Integer.parseInt(crumbProps.getProperty("CrumbsID", "31400"));
		} catch (Exception e){
		} finally {
			if(propFile!=null)
				try {propFile.close();} catch (IOException e){}
		}
		return id;
	}
	
	private void loadProperties() {
		FileInputStream propFile = null;
		Properties crumbProps = new Properties();
		try {
			propFile = new FileInputStream(Minecraft.getMinecraftDir().toString()+"/BreadCrumbs.properties");
			crumbProps.load(propFile);
			frequency = Integer.parseInt(crumbProps.getProperty("Frequency", "5"));
			size = Integer.parseInt(crumbProps.getProperty("Size", "1"));
			brightness=Integer.parseInt(crumbProps.getProperty("Brightness", "-1"));
		} catch (Exception e){
		} finally {
			if(propFile!=null)
				try {propFile.close();} catch (IOException e){}
		}
	}

	public boolean OnTickInGame(net.minecraft.client.Minecraft game) {
		// game.ingameGUI.addChatMessage("OnTickIngame running");
		EntityPlayer player = game.thePlayer;
		if (trailOn && player != null && player.health > 0)
			if (farEnoughFromLastCrumbXZ(player))
				if(player.inventory.consumeInventoryItem(mod_BreadCrumbs.breadCrumbs.shiftedIndex)) {
					EntityBreadCrumb crumb = new EntityBreadCrumb(player.worldObj);
					crumb.setLocationAndAngles(player.posX, player.posY, player.posZ, player.rotationYaw, player.rotationPitch);
					game.thePlayer.worldObj.entityJoinedWorld(crumb);
					lastCrumb = crumb;
				} else {
					trailOn = false;
					game.ingameGUI.addChatMessage(player.username + ": I'm out of bread crumbs!");
				}
		return true;
	}

	private boolean farEnoughFromLastCrumbXZ(EntityPlayer player) {
		if(lastCrumb==null)
			return true;
		double distance = Math.sqrt(((player.posX - lastCrumb.posX)*(player.posX - lastCrumb.posX))
										+ ((player.posZ - lastCrumb.posZ)*(player.posZ - lastCrumb.posZ)));
		return distance>=frequency?true:false;
	}

	public void AddRenderer(Map map) {
		map.put(net.minecraft.src.breadCrumbs.EntityBreadCrumb.class, new RenderBreadCrumb());
	}

	public String Version() {
		return "for beta 1.7.3";
	}
}