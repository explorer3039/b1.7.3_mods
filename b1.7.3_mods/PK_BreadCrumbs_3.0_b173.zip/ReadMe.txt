Installation:

- Install ModLoader (http://www.minecraftforum.net/topic/75440-/).
- Install this mod by dragging the files in "To minecraft jar" to your minecraft jar located in "%appdata%/.minecraft/bin" or your OS's equivalent.
- If you want to change the crumb item ID, the frequency you drop crumbs, the size of the crumbs or their brightness, edit "BreadCrumbs.properties" in "To .minecraft folder" with any text editor and then drag it into "%appdata%/.minecraft".
- Have fun!


To Modders:

My code is completely open source; you can edit or reuse whatever you want without having to worry about copyright or such.


For more info, see the main thread: http://www.minecraftforum.net/topic/498768-/

~Paraknight