****************
* GeoCraft Mod *
****************
By: Zaikyu

Hello I'm Zaikyu and this is my first Mod which I have deemed GeoCraft. GeoCraft is an attempt to add a spark of realism to minecraft while making it slightly more challenging. It adds many more blocks to the game most of them being new types of stone. In the theme of realizm it adds a new rock layer around the 25th block height the stone starts transitioning to a new block modeled after the real stone granite. This granite is harder than the current stone and requires a iron pickaxe or higher to harvest. This now mean Diamond, Redstone and Lapis Lazuli all are now found in granite. All other ores have been adjusted to only spawn on higher levels than this. Many other blocks also have been added such as Marble, Red Clay, Slate, Basalt, White Granite and one block I will keep as a secret. All the new Blocks have there own hardness levels that will vary depending on the real life hardness (ie: Granite and Basalt are quite hard while Marble and Slate are weaker).

Beside the new rock layer generation there also is sepcial generation for marble in large deposits above the granite level and White Granite in the granite level. Granite can also spawn in deposits above it's own level as well. Shale will spawn below water around sea level. Red Clay and gravel will now spawn underneath dirt around the sea level. The large grandom deposits of gravel near water has been changed to cobble stone with the chance of mossy cobble stone mixed in, To produce a more rocky weathered river bed look which I believe was originally intended. Basalt is now created when lava meets water instead of cobblestone and around lava pools naturally.

A few new recipies have been added for clay. You can bow make a clay bowl and put it into a furnace to bake it into a usable bowl. With the new type of clay comes with its own times of bricks and brick blocks, Including a mix between the two.


[All mentioned above have been implemented but I have a lot more planned for future releases =D ]

-----------------------------------------------------------------------------------------------

Images:

http://www.flickr.com//photos/65183731@N04/sets/72157627189898900/show/

-----------------------------------------------------------------------------------------------

Installation

Windows:
1) Open up %appdata% by searching for it.
2) Navigate to .minecraft/bin
3) Open up minecraft.jar with WinRAR or 7zip.
4) Drag and drop the files from within the Scripts folder into the jar.
5) Delete the META-INF folder in the jar.
6) Install the Texture pack by dropping the Zip folder into the Texture Pack folder in the .minecraft Folder
7) Start a new world and play.

-----------------------------------------------------------------------------------------------

The downloading and installation of this Mod signifies the agreement to the Terms and conditions stated below.

-----------------------------------------------------------------------------------------------

TERMS AND CONDITIONS
0. USED TERMS
MOD - modification, plugin, a piece of software that interfaces with the Minecraft client to extend, add, change or remove original capabilities.
MOJANG - Mojang AB
OWNER - , Original author(s) of the MOD. Under the copyright terms accepted when purchasing Minecraft (http://www.minecraft.net/copyright.jsp) the OWNER has full rights over their MOD despite use of MOJANG code.
USER - End user of the mod, person installing the mod.

1. LIABILITY
THIS MOD IS PROVIDED 'AS IS' WITH NO WARRANTIES, IMPLIED OR OTHERWISE. THE OWNER OF THIS MOD TAKES NO RESPONSIBILITY FOR ANY DAMAGES INCURRED FROM THE USE OF THIS MOD. THIS MOD ALTERS FUNDAMENTAL PARTS OF THE MINECRAFT GAME, PARTS OF MINECRAFT MAY NOT WORK WITH THIS MOD INSTALLED. ALL DAMAGES CAUSED FROM THE USE OR MISUSE OF THIS MOD FALL ON THE USER.

2. USE
Use of this MOD to be installed, manually or automatically, is given to the USER without restriction.

3. REDISTRIBUTION
This MOD may only be distributed where uploaded, mirrored, or otherwise linked to by the OWNER solely. All mirrors of this mod must have advance written permission from the OWNER. ANY attempts to make money off of this MOD (selling, selling modified versions, adfly, sharecash, etc.) are STRICTLY FORBIDDEN, and the OWNER may claim damages or take other action to rectify the situation.

4. DERIVATIVE WORKS/MODIFICATION
 Public distribution of modified versions of this MOD require advance written permission of the OWNER and may be subject to certain terms.