// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packfields(4) packimports(3) nonlb 
// Source File Name:   SourceFile

// search: "Tile"
public class ju extends sn {

    public ju(fd fd1) {
        super(fd1);
        b = 0;
    }

    public ju(fd fd1, double d, double d1, double d2, 
            int i) {
        super(fd1);
        b = 0;
        a = i;
        aF = true;
        b(0.98F, 0.98F);
        bf = bh / 2.0F;
        e(d, d1, d2);
        aP = 0.0D;
        aQ = 0.0D;
        aR = 0.0D;
        aJ = d;
        aK = d1;
        aL = d2;
    }

    protected boolean n() {
        return false;
    }

    protected void b() {
    }

    public boolean h_() {
        return !be;
    }

    public void w_() {
        if(a == 0) {
            K();
            return;
        }
        int dir = ZMod.fallDirHandle(aM, aN, aO);
        aJ = aM;
        aK = aN;
        aL = aO;
        b++;
        if(dir == -1) {
            aQ -= 0.039999999105930328D;
        } else {
            if(dir == 1) aQ -= 0.04;
            else if(dir == 2) aP += 0.05;
            else if(dir == 3) aP -= 0.05;
            else if(dir == 4) aR += 0.05;
            else if(dir == 5) aR -= 0.05;
        }
        b(aP, aQ, aR);
        
        if(dir == 1 && Math.abs(aK - aN) > 0.01) {
            //aM = Math.floor(aM) + 0.5;
            aP = 0.0;
            //aO = Math.floor(aO) + 0.5;
            aR = 0.0;
        }
        
        aP *= 0.98000001907348633D;
        aQ *= 0.98000001907348633D;
        aR *= 0.98000001907348633D;
        int i = in.b(aM);
        int j = in.b(aN);
        int l = in.b(aO);
        if(aI.a(i, j, l) == a)
            aI.f(i, j, l, 0);
        if(aX) {
            if(dir <= 0) {
                aP *= 0.69999998807907104D;
                aR *= 0.69999998807907104D;
                aQ *= -0.5D;
                K();
                if((!aI.a(a, i, j, l, true, 1) || gk.c_(aI, i, j - 1, l) || !aI.f(i, j, l, a)) && !aI.B)
                    b(a, 1);
            } else {
                if(dir == 0 || dir == 1) {
                    aP *= 0.75;
                    aR *= 0.75;
                }
                aQ *= 0.5;
                b = 0;
                // safety net
                //if(b > 100) { b(a, 1); K(); }
            }
        } else if(b > 100 && !aI.B) {
            b(a, 1);
            K();
        }
    }

    protected void b(nu nu1) {
        nu1.a("Tile", (byte)a);
    }

    protected void a(nu nu1) {
        a = nu1.c("Tile") & 0xff;
    }

    public float x_() {
        return 0.0F;
    }

    public fd k() {
        return aI;
    }

    public int a, b;
}
