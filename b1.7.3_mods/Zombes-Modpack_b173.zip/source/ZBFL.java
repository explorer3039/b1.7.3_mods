
// BlockFarmland
public final class ZBFL extends vl {

    public ZBFL() {
        super(60);
        c(0.6F).a(f).a("farmland"); // "farmland" * drop the last function.
    }

    // function with  nextInt(4) == 0  in it
    public void b(fd fd1, int j, int k, int l, sn sn) {
        return;
    }

}
