
import java.util.Random;

// BlockLeaves
public final class ZBL extends bk {

    public ZBL() {
        super(18, 52);
        c(0.2F).g(1).a(g).a("leaves").q(); // "leaves" * drop the last function.
    }

    public int a(Random random) { // only functon with Random * drop count
        return ZMod.leavesDropHandle();
    }

    private static int meta = 0;
    public int a(int i, Random random) { // drop-what?  i=meta-data
        int id = ZMod.leavesHandle(i & 3);
        meta = id >> 16;
        return id & 65535;
    }

    protected int b_(int i) { // i=meta-data
        return meta;
    }

}

