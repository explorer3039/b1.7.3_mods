
import java.util.Random;

// BlockMobSpawner
public final class ZBM extends dd {

    public ZBM() {
        super(52, 65);
        c(5F).a(i).a("mobSpawner").q(); // "mobSpawner"
    }
    
    public void c(fd map, int x, int y, int z) {
        super.c(map, x, y, z);
        // "Delay" - TileEntityMobSpawner  : cy.a(Name)
        String mob = ZMod.mobTypeHandle();
        if(mob == null) return;
        cy spawner = (cy)(map.b(x,y,z)); // get tileEntity
        spawner.a(mob); // set spawner
    }

    public int a(int i, Random random) { // both in parent class
        return ZMod.spawnderDropHandle() ? 52 : 0;
    }
    
    public int a(Random random) {
        return ZMod.spawnderDropHandle() ? 1 : 0;
    }

}
