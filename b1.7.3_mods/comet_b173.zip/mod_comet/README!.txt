####################################################
#Comed Mod V 0.5 2011 By Burnner                   #
#                                                  #
#Massive descrution                                #
####################################################
---------------
How to Install
---------------
!!REQUIRES MODLOADER!!

1. Move the files from the intominecraft.jar folder into minecraft.jar (obviously)

2. Open Minecraft




If you like it, plz donate :)


Have Fun!

Burnner


28.08.2011
