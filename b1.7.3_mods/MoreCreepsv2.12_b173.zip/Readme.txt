
MoreCreeps AND Weirdos v2.12
----------------------------

For MineCraft version BETA 1.7.3



This mod adds more than 40 MORE CREEPS and WEIRDOS to your MineCraft world!




CREEPS and WEIRDOS
------------------


*** BATTLE CASTLES ***
A huge castle that challenges players to find five elemental gems and defeat the King at the top of the castle. A fantastic reward awaits the player who can complete this quest.


*** CASTLE GEMS ***
Five unique gems that grant the player the ability to fly, set fire to enemies, heal wounds, transmute common rock into valueable minerals and magically grow crops


*** CASTLE KING ***
The handsome owner of the Battle Castle who does not usually like many visitors, especially those brandishing weapons.


*** CASTLE GUARDS ***
Stylish and well-groomed guards to the King. They will defend him to the death or lose their donuts in the process.


*** CASTLE CRITTERS ***
Dirty little castle rats. They are not very powerful, but can spell trouble if found in large enough numbers.


*** KID ***
A young boy looking to reunite with his Lolliman, who happens to be wandering around somewhere. Put him on your shoulders and help him in his quest.


*** LOLLIMAN ***
A wacked-out candy guy who lost his son in the woods while eating candy. If you help him find his boy, he will reward you with delicious sweets.


*** ARMY GUYS ***
These tough guys can be found wandering around or you can make your own gang from an ArmyGem. They fight to the death, losing limbs until they are just a head. 


*** TOMBSTONE ***
Now you can revive your precious pets with the help of a LifeGem. Now there is hope for little Skippy the level 20 GuineaPig!


*** SHRINK RAY ***
Shrink your enemies down to size, or send them away completely with the powerful ShrinkRay. You can also use them on your pets, but be careful of losing them!


*** ZEBRAS ***
Stylish creatures that wander around looking cool. Tamable and ridable if you like travelling in style.


*** BIG BABY ***
A giant baby with a short temper. Shrink him down and put him in a jar, which you can then take to your home and grow your own Schlump, which will give you rewards over time.


*** RATMEN ***
These goons defend Sneaky Sal. They may not be that tough, but they do tend to gang up on the player and will happily provide a beatdown on Sal's behalf.


*** SNEAKY SAL ***
A wandering merchant of questionable character. You can purchase hard to find goods from him, and even get a good bargain now and then.


** ROCKET-POWERED HORSEHEAD ***
The easiest way to travel around your Minecraft world. Hop on one of these Horseheads and hit the SPACEBAR to take off!


*** TROPHY SMASH ***
Each achievement that you win is cause for a big celebration. Smash the Trophy to earn extra cash, but act quickly!


*** LAWYERS FROM HELL ***
These dirty tricksters mind their own buiness until provoked, and then try to litigate you to death. You can beat the cash out of the Lawyers, but doing so will increase your FINE. If you exceed your limit of $2,500, the Lawyers may decide to send you to jail! If you defeat a Lawyer, they may either turn into Dirty Bums, or rise from the grave as Undead Lawyers From Hell!


*** HOTDOGS ***
These delightful pooches can be tamed and trained with bones. They will become your loyal pets, getting stronger and more powerful as they gain experience. If you train them in ATTACK and charge them up with Redstone, they will gain a special fire attack. If you train them in HEALING, they can learn to heal themselves and if they are critically wounded, stop fighting and return to you for healing. SPEED training makes the Hotdogs faster, and ultimately the ability to teleport to your side if they stray too far. DEFENSE training will help protect from attacks. You can add armor for increased vitality and protection. These loyal dogs are more then hot, they are on fire!


*** LETTER G ***
Grumpy Letter G would like to rip out your GUTS, and give you a kick in the GROIN! If you manage to kill a Letter G, there is a chance it will drop something that starts with G, such as grain, gold, golden apples, or other 'G' items.


*** HIPPOS ***
Peaceful animals that love water.


*** ROBOT TED ***
Robot Ted hates Robot Todd! He will do anything to disassemble him. Robot Ted floats around bragging about how cool he is and drops 16K RAM boards when terminated.


*** ROBOT TODD ***
Robot Todd hates Robot Ted! Robot Todd runs around making fun of how uncool and dumb Robot Ted is. He drops Batteries when terminated.


*** EVIL SNOWMAN ***
These creeps made of snow are the result of a botched experiment by the Evil Scientist. They shrink and get weaker in warm weather, and grow larger and more powerful in colder climates. Kill them before they get too huge!


*** ROCKET GIRAFFE ***
These majestic creatures can be tamed with cookies. Once tamed, you can ride them and fire rockets at unsuspecting idiots from high atop your steed.


*** DIG BUG ***
Green bugs that love to dig holes in the hopes that a BubbleScum will fall in and become lunch! A curious side effect of digested BubbleScum meat is an exploding fountain of delicious cookies!


*** BUBBLESCUM ***
Passive pink creatures that spend their days wandering around and blowing bubbles. Their innocence is only matched by their willingness to take piggy back rides.


*** FLOOBS ***
Dangerous aliens who arrive in their Floob Ships and shoot Ray Guns at you! Destory their ships quickly, or your world will be overrun with RayGun shooting Floobs!


*** EVIL SCIENTIST ***
Added Evil Scientist who builds towers, conducts experiments and uleashes his mutations: Evil Creatures, Evil Pigs and Evil Chickens


*** MANDOG ***
A passive creature who growls and can be tamed with cooked meat. He will then fetch frisbees thrown by the player. Frisbees can be crafted with Lapis Lazuli and Clay.


*** PYRAMIDS ***
These Mummy Tombs will appear randomly on your landscape. If you are feeling brave, explore the labryinth to recover the valuable Mummy Treasure!


*** GOO GOAT ***
A rather peaceful animal that munches on grass and fills up with slime. You can see him fill up and grow as he strips the landscape of grass. Killing it will yeild Goo Donuts dependent on his size and slime capacity.


*** BLORP ***
A herbivorous creature that grows as it eats leaves. You may want to kill it before it gets too big! Blorps are hostile toward other Blorps, and drop a refreshing drink called BlorpCola. The bigger the Blorp, the more cola you get. Or, you could just leave it alone to eat in peace. The choice is yours.


*** BABY MUMMY ***
These ripening youths [only hundreds of years old instead of thousands] are a mischevious bunch who love to play with humans. If you step on sand, watch out! These little creeps will try to bury you in their sand traps. They do appear during the day, but will burn up at high noon. 


*** PREACHER ***
Sometimes you just need a good sacrifice. It's a good thing that the world of Minecraft has so many sheep and pigs just wandering about, making them the perfect offering to the Gods of Minecraft*. These holy dudes may be loaded with donations, but they will also perform the ritual on you if you try to take it from them. Repent!


*** HUNCHBACK ***
This poor fellow is desperate for some delicious, fresh cake. If you can bake a cake for this Hunchback, he will become your loyal servant. This is where the fun begins, because if you throw him a bone, he will raise a skeleton army to wreak havok on the land. They are an uncontrollable and temporary band of hoodlums. Watch them kick some serious butt.


*** DESERT LIZARDS ***
Creeping around in the hot sun, these rowdy reptiles are always looking for a little something to munch on. Are you a little something? They shoot mini fireballs at a distance, and leap on you when close.


*** SNOW DEVILS ***
These double-headed devils are fearsome beasts which live primarily in the Ice Desert regions. If you kill them, they will drop pure ice, which can be used to build or as a source of portable water. They have a fearsome bite, but can be tamed if you throw snowballs at close range. But beware! They make very dangerous pets! Also, for whatever reason, these Snow Devils do not like the night and burn accordingly.


*** THIEVES ***
Keep a watchful eye for these scumbags of Minecraft, for they are out to steal your valuables. But don't worry, you can recover your stolen goods if you kill the pesky fellows or if they meet thier untimely demise in other ways.


*** DIRTY BUMS ***
These unfortunate fellows wander around looking for a kind soul such as yourself to offer them iron, gold or diamonds. If you treat these rotten bums nicely, you will be rewarded! The more generous your gift, the better the reward.


*** GUINEA PIGS ***
These delightful creatures just love to explore the world of Minecraft. They will follow you around on your adventures if you feed them enough apples or wheat. Apples are much more effective than wheat. If you tame them, they will fight [and die] for you. Each guinea pig has it's own name and unique personality, and will tell you when it is wounded. Feeding it more apples or wheat will heal your pigs. You can equip your pigs with armor and it will increase their attack and health.


*** MUMMY ***
The Mummies are slightly quick but not that powerful. They drop mostly sand and cloth. Mummies can also be found in Pyramids, which contain heavily guarded Mummy Treasure!


*** BLACK SOUL ***
The evil Black Souls are sluggish in movement, but they have a powerful attack and can take a lot of damage.
They drop coal - harvested from the souls of fallen miners. 
Also, there is a small chance they will drop the soul of an innocent miner who was never tempted by mineral deposits. This rare drop is a diamond.


*** INVISIBLE MAN ***
This dapper fellow wanders around delighted with the world around him. For many of his journeys, he takes only a delicious red apple and his walking stick.
However, sometimes he brings along a little extra ice cream money and you may find gold bars. If you attack him, he reveals himself in order to seek revenge.


*** ROCK MONSTER ***
Rock Monster's spawn during the day and are peaceful unless disturbed. Do so at your own peril, as these lapidarian lunks spring to life seeking revenge if provoked.
They are composed mostly of rock and gravel, but some of these beasts possess an iron will and will drop such a covetous prize upon their untimely demise.




INSTALL:
--------

Copy the contents of "COPY CONTENTS TO MINECRAFT FOLDER" into your MINECRAFT folder. That means you simply drag "MODS" and "RESOURCES" to your .minecraft folder. Keep the directory structure intact and say YES if asked to overwrite anything!

SPAWN RATES ARE SET THIS WAY: Change the number from 0 - 12. 0 = NO SPAWN and 12 = MAX SPAWN in the MoreCreeps.txt file found in .minecraft/mods directory

Do not forget to delete the META-INF folder in your minecraft.jar or no mods will ever run.

You must have Risugami's Modloader and AudioMod and Shocka's API installed for MoreCreeps to function. 


Make sure you are running Risugami's Modloader V3 or later, Risugami's AudioMod and Shocka's Achievement Tabs! All three are needed to run!
MODLOADER and AUDIOMOD here --- http://www.minecraftforum.net/topic/75440-v173-risugamis-mods-updates/
SHOCKAH API here --- http://adf.ly/373209/shockahpi-r5





TROUBLESHOOTING
----------------

I GOT NO DROPS FROM BLOCKS AND CREEPS! - You need to get the latest version of Modloader. See link under REQUIRED MODS at the top!

OH, MAN, I GOTZ PROBLEMZ- In order to solve your problems, you must provide a crash report! Without this vital information, nothing can be done to help you. Read the instructions in this thread for creating and submitting your crash report. REMEMBER: use CODE tags when posting your report!

I INSTALLED THE REQUIRED MODS, BUT CRASH! Be careful when you install Achievement Tabs. You want to put the three class files found in the BIN folder into your MINECRAFT.JAR. Do not put the BIN folder itself in there, just the three files inside of that BIN folder. YOU DID INSTALL ACHIEVEMENT TABS, DIDN'T YOU!?!?

NONE OF THE NEW ITEMS ARE SHOWING UP You are probably using a custom texture pack and need to run MCPATCHER first! Download MCPATCHER

CANT SEE ANYTHING - You have probably taken the textures out of the creeps folder! Just copy all of the content of the MINECRAFT-JAR folder and drag them to your MINECRAFT.JAR. The textures must be in a folder called CREEPS which is INSIDE the MOB folder in your minecraft.jar

CAN'T HEAR ANYTHING - You have either not installed AudioMod correctly, or have removed the sounds from the CREEPSOUNDS directory! All of the hideous and wacky sounds must remain in the CREEPSOUNDS folder, which should be located to your .MINECRAFT/RESOURCES/MOD/SOUND directory. Check to make sure that there is a CREEPSOUNDS folder in that SOUND directory. Double-check that you installed AudioMod correctly. The complete directory structure for More Creeps & Weirdos sounds is: .minecraft\resources\mod\sound\creepsounds

NO CREEPS SPAWN - Reset the spawns by playing on peaceful and then crank the difficulty to hard.

PROPERTIES FILE NOT WORKING The MoreCreeps.txt file must be located in your .minecraft directory. This directory contains other directories called BIN, MODS and RESOURCES. If Minecraft cannot locate this properties file, the mod will use default values and turn every creep on.

I DON'T SEE THE CUSTOM ITEMS Your texture pack is probably the culprit. Change your texture pack to default and see if the items like Delicious Blorp Cola or the RayGun show up. If they do, then you need to use a different texture pack.

FLOOB SHIPS ARE KILLING MY WORLD! You can turn off Floob Ship explosions in the properties file. Just change the config to FloobshipExplode=0. Puny human!

FLOOBS ARE SETTING FIRE TO EVERYTHING! You can turn off Floob Ship explosions in the properties file. Just put a 0 in front of RayGunFire. If you want to prevent the RayGuns from melting blocks, change the config to RayGunMelt=0. Oh, the punarity of humans!

BETTER THAN WOLVES CRASHES! Here is a solution provided by wittenkwirk. Put the file called "BTWConfig.txt" into your .minecraft folder (NOT your minecraft.jar) Edit this file, changing "fcDisableAxeChanges=0" to "fcDisableAxeChanges=1" It should work now!

PREMIUM WOOD CRASHES! Install SCOTTOOLS again - make sure you have the latest version of SCOTTOOLS.

SINGLE PLAYER COMMANDS CRASH! Install SPC mod AFTER you install the required SHOCKAH API mod. This should eliminate crashes from WORLD.CLASS conflicts.





VERSION NOTES:
--------------

v2.12
-----

ADDED: Shrink Ray additional creeps: Bum, BubbleScum, LawyerFromHell, G
FIXED: Tombstone killable by player only and will not be hurt by its surroundings
FIXED: Army Guys will incur fines when attacking Lawyers on your behalf
FIXED: Stop Army Guy heads carrying weapons. After all, its only a head, how can it hold a gun?
FIXED: Lolliman now has a plan B. Stuck Lolliman will explode after delivering his treats so watch out!
TWEAK: Battle Castle location selection improved and moved away from player
TWEAK: Doubled durability of the Arm Sword



v2.11
-----

ADDED: Lolliman achievement for reuniting him with his Kid
ADDED: Recipie for ArmSword - Nine Limbs
ADDED: Recipie for BabyJar - Three iron ingots at top. Six glass block on bottom
TWEAK: Lolliman and Kid spawn less frequently
TWEAK: Lolliman gives less treats when reunited with his Kid
FIXED: GuineaPigs and Hotdogs getting stuck in stacks with Kid and MoCreatures LitterBox or KittyBeds



v2.10
-----

ADDED: Battle Castles that reward the player for collecting five gems and defeating the King
ADDED: Five Battle Castle gems that allow player a fire attack, flying ability, magical mining, crop generation and healing 
ADDED: Gem Sword - ultimate reward for defeating Battle Castles: Amazing sword that can kill and mine rock instantly!
ADDED: Castle Guards that defend the castle and protect the King
ADDED: Castle critters that scamper around Battle Castles looking for trouble
ADDED: King of the Battle Castles. Defeating him while carrying 5 Castle Gems will grant the player a GemSword
ADDED: GemSword which can both mine blocks and vanquish enemies with supreme power and prejudice
ADDED: Tombstones to mark the demise of a cherished pet. Re-animate them with a Life Gem without any side-effects or messy drool.
ADDED: Shrink Ray that can reduce creeps to nothing. Be careful when using on your pets.
ADDED: Giant Baby who crawls around looking for something to eat
ADDED: Baby Jar to capture a Giant Baby that has been shrunken down
ADDED: Zebras who wander around looking pretty fancy
ADDED: Lolliman who is searching for his kid. Once reunited, they fly away, excreting a trail of treats for the player
ADDED: Kid who is lost and asks the player to help him find his Lolliman. You can carry the kid on your shoulders in your quest
ADDED: Lollys which heal the player when eaten
ADDED: Sneaky Sal the vendor who provides rare goods. You can try to ripoff Sal, but you may get caught!
ADDED: RatMen who obey Sneaky Sal and will exact revenge on his behalf
ADDED: Himalayan Guinea Pigs which will make a cute addition to your Guinea Pig Army
ADDED: Rocket-powered Pony Heads that give player easy transport option. However,they rocket away into space after inactivity
ADDED: Pony Head gem - creates Pony Head transport
ADDED: Army Guys that can fight for player and lose their arms and legs in battle
ADDED: Army Guy Gem - Create your own army of army dudes!
ADDED: Arm Sword - made from collected limbs of fallen Army Guys
ADDED: Ability to rename tamed SnowDevil - SNEAK + RIGHT CLICK
ADDED: Ability to rename tamed Camel - SNEAK + RIGHT CLICK
ADDED: Audio and text notification for Pyramid and Battle Castle creation 
TWEAK: Added redstone powerup sound for Hotdogs
TWEAK: Added feedback messages for RocketGiraffes - how many cookies needed and tamed confirmation
TWEAK: Added names for Giraffe, adjusted tamed cookie amount randomly between 5-12
TWEAK: Text message added to confirm Guinea Pig taming
TWEAK: Enhanced Guinea Pig model to eliminate z-fighting on legs and added new geometry for ears. Techne is so wonderful!
TWEAK: Hotdogs start tiny and grow in size as they level up
TWEAK: Increased Hotdog damage and attack success
TWEAK: Adjusted Hotdog experience level requirements
TWEAK: Increased drop rate of Floob rayguns on death
TWEAK: Added feedback messages for Camels - how many cookies needed and tamed confirmation
TWEAK: Adjusted cookies needed for tamed camels - random 5-15
TWEAK: Camel Jockeys can no longer steal tamed Camels
TWEAK: SNEAK + RIGHT CLICK anything to adjust properties / training / naming - no more empty hands requirement - default sneak key is SHIFT
TWEAK: Dirty Bum urination more realistic flow. Still a spray because stream is too boring to watch for long periods of time.
FIXED: Mandog jumping to death during attempts to return frisbee to player
FIXED: Madman Evil Scientist restored after save
FIXED: Camel settings saved correctly - fixes tamed camels going AWOL
FIXED: Lawyers only assess fines on player attacks or player's pet attacks
FIXED: Attacking undead lawyers does not increase fines
FIXED: Guinea Pigs and Hotdogs get themselves unstuck if trapped in a stack
FIXED: Guinea Pigs and Hotdogs are able to unmount indoors without taking damage



v2.00
-----
UPDATED to minecraft 1.7.3
TWEAK: Camels now 2 blocks wide
TWEAK: Laywer fines reset to 0 when thrown in jail



v1.99a
-----
ADDED: Camels that are fun-loving and free, until Camel Jockies turn them sour!
ADDED: Camel Jockeys. These diminutive, power-mad freaks love turn good camels bad and give you nightmares
ADDED: New sounds for Hotdogs: stacking and fighting
ADDED: Blood effects for Hotdog attacks. Can be toggled in config
ADDED: New Achievement Sand Humper : Tame a Camel
TWEAK: No creeps allowed to spawn on WOOL, WOOD PLANKS, WOOD, SINGLE or DOUBLE STAIRS and COBBLESTONE
TWEAK: DigBugs mine ores they come across as they dig! Look in their holes to find them
TWEAK: DigBugs will now fill holes if they find no BubbleScums to digest
TWEAK: Undead Lawyers do more damage
TWEAK: Lawyers fines are now cumulative. Throw cash at them to lower your FINE amount.
TWEAK: Getting thrown in jail will reset your FINE to zero
TWEAK: Lawyers From Hell will sometimes jail you when near player if fine exceeds $2,500. Stay clear!
TWEAK: BubbleScum now on the spawnlist and will show up randomly
TWEAK: Hotdog healing: number of hearts now shows how much healing is done
FIXED: DigBugs now save their data. No more abandoned holes or forever hungry DigBugs
FIXED: Hotdogs only teleport when in FIGHT mode
FIXED: Guinea Pigs will fight and kill instead of following Hotdogs around
FIXED: Hotdogs who are told to STAY or WANDER will not teleport to player
FIXED: Hotdog attack and leveling system revamped
FIXED: Minecraft Extended support added
FIXED: Cannot feed food to dead Guinea Pigs and Hotdogs


v1.99
-----
ADDED: Hotdogs that can be tamed, trained and will fight for you!
ADDED: Hotdog training gives perks in ATTACK, DEFENSE, SPEED and HEALING
ADDED: Lawyers from Hell who attack and steal your money, turning into Undead Lawyers or Bums when defeated
ADDED: Jail to imprison player if he exceeds his allowable FINE of $2,500. Jail toggle available in MoreCreeps.txt file for chickens.
ADDED: Hippos who love water
ADDED: Letter G that drops 'G' stuff like Grain, Gold bars, Glowstone, Golden apple, etc.
ADDED: Celebration when any achievement is reached. Smash the trophy for extra cash, but you have to act fast!
ADDED: Sound effects for Evil Snowman
FIXED: Robots Ted and Todd reprogrammed. Now their cutting comments and self congratulations are logical.
FIXED: BubbleScum achivements now correctly awarded
TWEAK: Falldamage removed for Evil Scientist experiments
TWEAK: Public Urination defaults to ON. Turn off in MoreCreeps.txt file
TWEAK: Bums will exhibit better bladder control and not urinate so often
TWEAK: Guinea Pig and Hotdog Command Center - SHIFT-RIGHT-CLICK with empty hands
TWEAK: Particles enhanced - partial implementation
TWEAK: Giving Hunchbacks cake is now cumulative. Stuff your Hunchbacks full of cake!



v1.98
-----
ADDED: Robot Ted who hates Robot Todd
ADDED: Robot Todd who hates Robot Ted
ADDED: Batteries drop from Todd
ADDED: 16K RAM drop from Ted
ADDED: Evil Snowman created by Evil Scientist. Snowmen grow more powerful on snow and get weaker everywhere else. 
ADDED: Atom Packet and atomic power - crafted from batteries and 16K RAM boards
ADDED: Atomic Age - combine atoms to create havok
ADDED: Congratulations on achievements voiceover
ADDED: 10 new Achievements for a total of 39!
ADDED: Bums may produce obsidian if given lava buckets while urinating - they may also give you back an empty bucket
ADDED: Public Urination in settings file. You can turn off/on public urination
FIXED: Goo Donut, Money and Evil Egg crashing Mo'Creatures mod
FIXED: Bum urinating when given valuables
FIXED: Guinea Pig Iron Armor texture
TWEAK: Goo Donut sinks in water instead of vanishing. Recover your wet Donuts
TWEAK: Evil Scientist has more misfortunes - more botched experiments per tower
TWEAK: Cannot build Guinea Pig Hotel if pig is on your head. Put him down!
TWEAK: Cannot mount RocketGiraffe if you have stuff on your head!



v1.97
-----
ADDED: Bums urinate and beautify the world
ADDED: Guinea Pig Command Screen - SHIFT+right click on tamed Guinea Pig with a Guinea Pig Radio, or use Paper or Book
ADDED: 29 Achievements for some wacky fun! Uses Achievement Tabs mod - now required
ADDED: Ability to switch Guinea Pig armor at any time - Upgrade to diamond when you can!
ADDED: Money hurts Preachers. Still not intended use, but just for fun!
TWEAK: Limit max spawns of Mummies, Black Souls, Evil Scientists and DigBugs
TWEAK: Guinea Pigs can now be healed and tamed with cookies 
TWEAK: RocketGiraffe will now fit in two-block passage
TWEAK: Player no longer damaged when dismounting RocketGiraffe
TWEAK: Adjusted rider position on RocketGiraffe
TWEAK: You can only ride RocketGiraffes if no creatures are mounted
TWEAK: DigBugs will only dig one hole
TWEAK: DigBugs are no longer ungodly strong
TWEAK: Goo Goats and Blorps will not attack MOST Millenaire villagers



v1.96
-----

ADDED: Ability to name tamed RocketGiraffe with Book in hand
ADDED: Particle effects for RayGun
ADDED: Cobwebs in Pyramids
FIXED: EvilScientist experimental electricity blending mode 
TWEAK: DigBugs fill in their holes when they are satiated with BubbleScums
TWEAK: Spawnrates for BlackSouls, EvilScientists, DigBugs and ManDogs adjusted downward



v1.95
-----
UPDATED to Minecraft 1.5.1
ADDED: DigBugs who dig holes in order to attract BubbleScums. They spray a fountain of cookies after digesting them.
ADDED: BubbleScums who wander around blowing bubbles and love to take piggy-back rides
ADDED: RocketGiraffes which can be tamed with cookies and ridden by the player. RocketGiraffes also fire rockets!
ADDED: Rockets made with one iron ingot and two torches
ADDED: Evil Chicken Eggs: Explosive on impact and has a chance of spawning another Evil Chicken.
ADDED: Configuration file now plain text file and allows full control over spawnrate and other properties.
ADDED: Glow effects for BlackSoul and Evil Scientist electricity
TWEAK: FloobShips will only explode when player kills them. Explosions can be turned off in configruation file.
TWEAK: FloobShips will not spawn on peaceful
TWEAK: All creeps will never spawn on Wood, Half or Full steps or Cobblestone, nor will they spawn indoors.
TWEAK: SnowDevils are a bit tougher and have more health.
TWEAK: Guinea Pig Radio now mounts / unmounts pigs with one click
TWEAK: Guinea Pigs no longer take damage when mounted on player
TWEAK: Preachers can now be killed in lava
TWEAK: Preachers drops now include: diamonds, gold, cocoa beans, rose red, lapis lazuli, apples and books
TWEAK: Evil Creature now is stronger
FIXED: Clean-shaven Bums remain dressed after a reload.




v1.94
-----
ADDED: Guinea Pig commands: Use flowers to tell pigs to Fight, Stay and Wander
ADDED: Guinea Pig Radio: Stacks all fighting pigs in a 50 block area on your head
ADDED: Guinea Pig speedboost. Sugar Cane gives pigs 10 minutes of super speed
ADDED: Guinea Pigs will now get faster as they level up!
FIXED: Theives do not restore damaged weapons. Cheat fixed!
FIXED: Guinea Pig lag reduced
FIXED: Preachers can no longer be drowned
TWEAK: More detailed stats for Guinea Pigs and * indicator by name to indicate speedboost
TWEAK: Evil Scientist towers no longer contain bedrock
TWEAK: Floobs RayGun fire now more deadly at close range
TWEAK: Floob melee attack reduced
TWEAK: Floob Ship explosion on death reduced



v1.93
-----
UPDATED to Minecraft 1.4_01
TWEAK: Guinea Pigs are quiet when on your head
TWEAK: Preachers can now handle unlimited enemies
TWEAK: Wheat, Red Apple and Golden Apples heal Guinea Pigs more
TWEAK: Guinea Pigs in huge stack don't take fall damage when unmounting
TWEAK: Rock Monster larger and has better attack



v1.92
-----
FIXED: Spawnrates greatly improved. Still need some work
FIXED: Floobs cannot melee attack through walls
FIXED: Floobs and Preachers will not spawn indoors
FIXED: Snow Devils will drop Snow Blocks instead of snow
FIXED: Floobs will not shoot other Floobs and commit Floobicide!
FIXED: Frisbee recipie now works again
TWEAK: Floobs will not always drop RayGuns
TWEAK: Goo Donuts given a little more oomph!
TWEAK: Snow Devils will not burn at night
TWEAK: Guinea Pigs will be partially healed with Wheat and Apples
TWEAK: Pyramids have much better loot - zero item bug fixed
TWEAK: Better jumping protection for excited ManDog
TWEAK: RayGun setting fire to objects turned off by default. Turn it on cowards!
TWEAK: Preachers now will have greater rewards!




v1.91
-----
ADDED: Shocking sounds from the Evil Towers
ADDED: ManDogs display collar only when tamed
ADDED: Tamed Guinea Pigs now display a health bar
ADDED: Right-click with paper on tamed Guinea Pigs to get stats
FIXED: Tamed Guinea Pigs fight harder for you and KICK ASS!
FIXED: Theives cannot steal through walls
FIXED: Tamed Guinea Pigs leveling calculations corrected
TWEAK: Additional overlap allowed on Pyramids to help spawning
TWEAK: Nighttime spawns on some creeps adjusted - no spawing at night
TWEAK: Mummies are back in Pyramids


v1.90
-----

VERSION: Updated to Minecraft 1.4
ADDED: Guinea Pig HOTEL available for a Diamond with any level 20 pig!
ADDED: Guinea Pig healing animation any time you heal your pig
FIXED: RayGuns will respect properties selection of RayGunMelt
FIXED: Evil Scientists will remove the bottom part of their towers





v1.83
-----
ADDED: Pyramid Guardian - kill him to break the curse - removes bedrock, reveals central tomb
ADDED: Floobship explosions toggled on/off in properties
ADDED: Pyramid rarity adjustable in properties: Default is 700. Range is between 200 (more chance)  - 1000 (less chance)
FIXED: Pyramids should not get cut in half
FIXED: Evil Scientist towers should not cut into geometry
FIXED: Guinea Pig level up message no longer one level behind
FIXED: Level 20 Guinea Pig shouldn't crash minecraft! A bit too powerful!
FIXED: Evil Scientists will only build towers above ground and will not remove non-existant towers. Dummy Evil Scientists, what were they thinking?
TWEAK: Preachers will only use anti-cheat protection on player
TWEAK: Desert Lizards fire less frequently
TWEAK: Desert Lizard range reduced to 30 blocks
TWEAK: Floobships spawn less Floobs. Pitiful EARTHLINGS!
TWEAK: Weakened Floobs slightly to compensate for puny humans punarity.



v1.82
-----
ADDED: RayGun melt blocks on/off in properties file
FIXED: Guinea Pig infinite pork bug


v1.81
-----
ADDED: Floob sounds! Prepare for takeover!
ADDED: RayGun fire now set with properties file - to Burn or not to Burn
ADDED: Pyramids toggle on/off with properties file
FIXED: Pyramids spawn on sand, don't overlap and don't obstruct world geometry
FIXED: Can't hit large Goo Goats. Bounding Box size fixed 
FIXED: Infinite Goo Donuts bug
FIXED: SnowDevils now die when tamed and killed
FIXED: ManDog not despawning
FIXED: RayGun missing its RAY!
FIXED: RayGun stacksize is now 1 - infinite RayGun bug
TWEAK: Goo Goats get stronger with size
TWEAK: Pyarmids appear less frequently
TWEAK: BlackSoul attack
TWEAK: Floobships and Evil Scientist appear less frequently
TWEAK: Goo Donuts now dissolve in water instead of dissapear
TWEAK: ManDog facing what he is chasing - somewhat
TWEAK: SnowDevils drop more snow  instead of ice


v1.8
-----
NEW CREEP! Added Floobs, aliens who arrive in their Floob Ships and shoot Ray Guns at you!
NEW CREEP! Added Evil Scientist who conducts experiments and uleashes his mutations: Evil Creatures, Evil Pigs and Evil Chickens
NEW CREEP! Added ManDog, who growls and can be tamed with cooked meat. He will then fetch frisbees thrown by the player.
Added Frisbee, which can be crafted with Lapis Lazuli and Clay
Added Mummy Pyramids, which contain randomly generated mazes leading to buried treasure!
Preachers are better protected against Goo Donuts, but will still take some damage
Preachers will toss heathens and sacrifices around
Preachers will make sure that heathens atone for sins with anti-cheat powers
Added a few more Preacher sounds
Guinea Pigs can level up! Brave pigs increase attack strength and health up to level 20!
Guinea Pig code optimized - less lag
Guinea Pigs - less squealing when fighting
Mounted Guinea Pigs will not squawk
Guinea Pigs no longer attack tamed Hunchbacks
Goo Donuts handling improved. More bouncy and more fun!
Bums save exploit fixed - No longer can you cheat the dirty Bums
Improved the attacks of Goo Goats, Desert Lizards and Black Souls




v1.7
-----
Added Goo Goat which feeds on grass and fills up with slime. Killing it will yeild Goo Donuts dependent on the size of the Goo Goat
Added Goo Donuts which explode if you throw them
Made Baby Mummy traps a bit harder on the player
Mummies now drop bandages which heal the player
Mummies also drop sandstone
Snow Devils now survive the night if they are on snow or ice. Keep your pet in cage with a snow or ice floor
Snow Devil spawn rate increased slightly
Fixed Invisible Man not attacking when angry
Hunchback that is caked up will now take small damage from you, but will still thank you


v1.6
-----
Simple update to new Minecraft Beta 1.3_01


v1.5
-----
Added Blorp which grows as it eats leaves and drops BlorpCola, the most refreshing drink you've ever had!
Adjusted Hunchback Skeletons to not drop as many bones and arrows
Preacher's victims now get pushed around a bit more



v1.4
-----
Added Baby Mummies who try to catch you in their sand traps. Stay away from sand!
Once a Bum cheats you, you can't bribe him any longer.
Reduced adult Mummy speed


v1.32
-----
Hunchback will fight back if not your servant. If he is, then wail away!
Hunchback now faces his demise if attacked
Hunchback will demand more cake after awhile. He loves it!
Carry a Guinea Pig on your head if right-click with empty hands
Guinea Pigs can now be stacked 20 high. Thanks to Kodaichi and 303 for code and help.



v1.31
-----
Fixed pacifist Preachers. You will now see sacrifices of all who dare to lay angry hands on these holy dudes
Fixed Preacher drop error. Preahcers sometimes drop books. They now will drop gold!
Fixed Hunchback Skeleton Army fighting amongst themselves if caught in the crossfire
Hunchback can now be beaten after he is caked up!
Added Hunchback sounds in gratitude for the beating his master gives him
Hunchback will now seek revenge if he isn't caked up.after being attacked



v1.3
----
Added Preachers which ramble on and on and perform rituals for the Gods of Minecraft. 
Invisible Man turns visible when hit. He gets invisible again after awhile.
Added Invisible Man angry voices. Now you can hear his displeasure!
Sometimes the Invisible Man carries cake
Hunchbacks will gobble up cake blocks and cake
Hunchbacks will follow you after they have cake
Hunchback Skeleton Army now attacks other mobs and creatures. They won't attack Guinea Pigs, Hunchbacks or SnowDevils
Decreased Rock Monster spawnrate




v1.2
----
Added Hunchbacks which love cake and will raise an army of skeletons for your amusement
Improved tail animation for DesertLizards
Reduced spawn rate of Guinea Pigs




v1.1
----
Added five varieties of Desert Lizards who are always on the lookout for a snack - YOU!
Guinea Pigs now keep their armor when reloading
Guinea Pig lag reduced. Tested to 20 tamed pigs
Guinea Pigs are now tamed instantly with Golden Apples
Added sound for equiping Guinea Pigs with armor
Added smoke effect for feeding, taming and armor
Added more Guinea Pig sounds for variety
Adjusted spawning of SnowDevils
Adjusted SnowDevil drops - random mostly snow and a few ice
Fixed SnowDevil sounds not playing



v1.0
----
Added Snow Devils which can be tamed with snowballs


v0.9 
----
New configuration file MoreCreeps.properties - turn off the creeps you don't want
Added three new guinea pigs for six total. 
Guinea pigs now fight [and die] for you if tamed.
Apples tame and heal Guinea Pigs faster than wheat.
Each guinea pig has a unique name and tells you when it is wounded. 
You can equip your Guinea Pigs with all kinds of armor.
Armor grants them increased attack and health stats depending on the quality of armor.
Guinea Pigs push you around less and follow eachother more.
Raise an army of pigs and charge into battle!
Thief now steals randomly from inventory and takes a random amount.
Invisible Man stops whistling when angry.
Bums are not be as generous.
Bums will sometimes make a sucker out of you.
BlackSoul sometimes drops more coal and diamonds.
Mummy drops more sand and cloth.

v0.8 Added Thieves. Lowered the volume of guinea pigs.

v0.7a Fixed spawn rates of daytime creeps and lag issues.

v0.7 Updated for MineCraft 1.2_02

v0.6 Spawn rates adjusted for Guinea Pigs, Rock Monster and Invisible man. Guinea Pigs make a chime sound when they are full. 

v0.55 Dirty Bums added. Guinea Pigs will no longer take over the world. Also, Mo Creatures and other mobs spawn correctly now. Invisible man should appear as a solitary figure instead of a group.

v0.5 New Guinea Pig added. Black Guinea Pig explodes on death. Pigs drop only one meat now. Pigs should not despawn.

v0.4 Guinea Pigs added. Invisible Man drops gold less frequently.

v0.3 BETA 1.1_02 compatible, texture fix on invisibleman, spawn logic updated

v0.2 renamed 'more creeps and weirdos' added invisible man and rock monster

v0.1 initial release - mummy and blacksoul




THANKS
-------

Shout out to my coding creeps who helped me - 303, Club559 and Okushama. Also DrZhark for the following and configuration code. Kodaichi for use of his tower generation code. Thanks, guys! Thanks to OgreSean for the name display code from his Builders mod.

Thanks to FOXY1990 for all of his testing and bug reports. Also thank you to Risugami for Modloader, 303 for incredible assistance and code guidance, Shockah for his API and the MCP team for the tools! Thanks Okushama for the Dirty Bum idea. 



