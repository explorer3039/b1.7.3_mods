Sor1n's Camouflage Mod V1.0
(Compatible with Minecrat Version 1.7.3)

[*** COPYRIGHT NOTICE ***]
 This document is Copyright �(2011) and is the intellectual property of the author. It may be not be reproduced under any circumstances except for personal, private use as long as it remains in its unaltered, unedited form. It may not be placed on any web site or otherwise distributed publicly without advance written permission. Use of this mod on any other website is strictly prohibited, and a violation of copyright.
 
~~~~~~~~~~~~~~~~~~~~~~~~~~~

For detailed item descriptions (including crafting recipes), an up to date version of this mod, video feature demonstrations, and other useful info, please consult the following thread in the Minecraft forums:
http://www.minecraftforum.net/topic/442602-172-camouflage-mod-v10/

****** Installation Instructions ******

**Singleplayer**

1) Make sure minecraft is not running.
2) Install Risugami's ModLoader (http://www.minecraftforum.net/viewtopic.php?f=1032&t=80246)
3) Open your minecraft.jar with Winrar or other program
4) Delete the META-INF folder in minecraft.jar (you should have already done this when you installed ModLoader)
5) Copy all the files and folders in this mod's SINGLEPLAYER FILES folder into your minecraft.jar (overwriting any existing files).
6) Profit!

NOTE: This mod can NOT be installed by using the ModLoader method of simply copying this zip file into the ".minecraft/mods/" folder.  It modifies base classes, and thus this ModLoader functionality can not be supported (as explicitly stated in the ModLoader documentation).  You MUST copy the appropriate files into minecraft.jar as described above for this mod to function properly.

Version 1.0

- Initial Release

Version 1.1

- Added Colored Glass
- Removed Multiplayer cuz I ballsed up when updating to the new version of Minecraft

Version 1.2

- Added the rest of colored glass (there are now all 15 colors and fixed glitch)
- Added Obscure Glass
- Added a new block (I keep it a secret until someone post on th thread what it is =D)