package net.mine_diver.infsprites.api;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.src.Block;
import net.minecraft.src.RenderBlocks;

public interface IRenderHook {
	
	public static final List<IRenderHook> renderHooks = new ArrayList<IRenderHook>();
	
	void beforeRenderPass(int pass);
	default boolean canRenderInPass(Block block, int pass) {return true;}
	void beforeBlockRender(Block block, RenderBlocks renderblocks);
	void afterBlockRender(Block block, RenderBlocks renderblocks);
	void afterRenderPass(int pass);
	void overrideTexture(Object o);
}
