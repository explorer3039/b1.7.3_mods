package net.mine_diver.infsprites.util.compatibility;

import net.minecraft.src.ModLoader;
import net.minecraft.src.mod_IDResolver;

public class IDResolver implements ICompatibilityPatcher {
	
	@Override
	public String requiredClass() {
		return null;
	}
	
	@Override
	public void patch() {
		try {
			ModLoader.setPrivateValue(mod_IDResolver.class, null, "mcExtendedInstalled", true);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
}
