package net.mine_diver.infsprites.util;

public class BlockCoord {

    public BlockCoord(int i, int j, int k) {
        posX = i;
        posY = j;
        posZ = k;
        blockID = -1;
    }

    public BlockCoord(int i, int j, int k, int l) {
        posX = i;
        posY = j;
        posZ = k;
        blockID = l;
    }

    public int hashCode() {
        return posX << 11 | posZ << 7 | posY;
    }

    public boolean equals(Object obj) {
        if(obj instanceof BlockCoord) {
            BlockCoord blockcoord = (BlockCoord)obj;
            return posX == blockcoord.posX && posZ == blockcoord.posZ && posY == blockcoord.posY && blockcoord.blockID == blockcoord.blockID;
        } else
            return super.equals(obj);
    }

    public final int posX;
    public final int posY;
    public final int posZ;
    public final int blockID;
}
