package net.mine_diver.infsprites.proxy;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.lwjgl.opengl.GL11;

import net.mine_diver.infsprites.mcextended.MCExtendedManagers;
import net.mine_diver.infsprites.util.compatibility.Forge;
import net.minecraft.src.EffectRenderer;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityDiggingFX;
import net.minecraft.src.EntityFX;
import net.minecraft.src.MathHelper;
import net.minecraft.src.ModLoader;
import net.minecraft.src.RenderEngine;
import net.minecraft.src.Tessellator;
import net.minecraft.src.World;
import net.minecraft.src.mod_InfSprites;
import net.minecraft.src.forge.BlockTextureParticles;
import net.minecraft.src.overrideapi.utils.Reflection;

public class EffectRendererProxy extends EffectRenderer {

	public EffectRendererProxy(World world, RenderEngine renderengine) {
		super(world, renderengine);
	}
	
	@Override
	public void renderParticles(Entity entity, float f) {
		loadFieldsFromSuper();
        float f1 = MathHelper.cos((entity.rotationYaw * 3.141593F) / 180F);
        float f2 = MathHelper.sin((entity.rotationYaw * 3.141593F) / 180F);
        float f3 = -f2 * MathHelper.sin((entity.rotationPitch * 3.141593F) / 180F);
        float f4 = f1 * MathHelper.sin((entity.rotationPitch * 3.141593F) / 180F);
        float f5 = MathHelper.cos((entity.rotationPitch * 3.141593F) / 180F);
        EntityFX.interpPosX = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * (double)f;
        EntityFX.interpPosY = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * (double)f;
        EntityFX.interpPosZ = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * (double)f;
        for(int i = 0; i < 3; i++) {
            if(fxLayers[i].size() == 0)
                continue;
            int j = 0;
            if(i == 0)
                j = renderer.getTexture("/particles.png");
            if(i == 1)
                j = renderer.getTexture("/terrain.png");
            if(i == 2)
                j = renderer.getTexture("/gui/items.png");
            GL11.glBindTexture(3553, j);
            Tessellator tessellator = Tessellator.instance;
            for(int k = 0; k < fxLayers[i].size(); k++) {
                EntityFX entityfx = (EntityFX)fxLayers[i].get(k);
                if (!Forge.installed || !(entityfx instanceof EntityDiggingFX)) {
	                if (i == 1)
	                	GL11.glBindTexture(3553, MCExtendedManagers.TerrainManager.getTerrain(mod_InfSprites.getParticleTextureIndex(entityfx) / 256));
                	tessellator.startDrawingQuads();
	                entityfx.renderParticle(tessellator, f, f1, f5, f2, f3, f4);
	                tessellator.draw();
                }
            }
        }
        if (Forge.installed) {
	        Tessellator tessellator = Tessellator.instance;
	        for(int k = 0; k < effectList.size(); k++) {
	            BlockTextureParticles blocktextureparticles = (BlockTextureParticles)effectList.get(k);
	            GL11.glBindTexture(3553, renderer.getTexture(blocktextureparticles.texture));
	            tessellator.startDrawingQuads();
	            for(int i1 = 0; i1 < blocktextureparticles.effects.size(); i1++) {
	                EntityFX entityfx1 = (EntityFX)blocktextureparticles.effects.get(i1);
	                if (blocktextureparticles.texture == "/terrain.png")
	                	GL11.glBindTexture(3553, MCExtendedManagers.TerrainManager.getTerrain(mod_InfSprites.getParticleTextureIndex(entityfx1) / 256));
	                entityfx1.renderParticle(tessellator, f, f1, f5, f2, f3, f4);
	            }
	            tessellator.draw();
	        }
        }
    }
	
	private List<EntityFX> fxLayers[];
	private RenderEngine renderer;
	private List<BlockTextureParticles> effectList;
	
	public void initSuper() {
		try {
			for (Field field : EffectRenderer.class.getDeclaredFields())
				Reflection.publicField(field).set(this, Reflection.publicField(field).get(ModLoader.getMinecraftInstance().effectRenderer));
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
	
    private static final List<Field> superFields = new ArrayList<Field>();
    
    static {
    	List<String[]> names = new ArrayList<String[]>();
    	names.add(new String[]{"b", "fxLayers"});
    	names.add(new String[]{"c", "renderer"});
    	if (Forge.installed)
    		names.add(new String[]{"effectList"});
    	for (String[] s : names)
    		superFields.add(Reflection.publicField(Reflection.findField(EffectRenderer.class, s)));
    }
	
    private void loadFieldsFromSuper() {
    	for (int i = 0; i < superFields.size(); i++)
			try {
				getClass().getDeclaredFields()[i].set(this, superFields.get(i).get(this));
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
    }
}
