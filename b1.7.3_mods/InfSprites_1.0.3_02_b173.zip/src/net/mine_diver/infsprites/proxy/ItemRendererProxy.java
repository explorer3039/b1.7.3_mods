package net.mine_diver.infsprites.proxy;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.lwjgl.opengl.GL11;

import net.mine_diver.infsprites.api.IRenderHook;
import net.mine_diver.infsprites.mcextended.MCExtendedManagers;
import net.minecraft.client.Minecraft;
import net.minecraft.src.Block;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.Item;
import net.minecraft.src.ItemRenderer;
import net.minecraft.src.ItemStack;
import net.minecraft.src.RenderBlocks;
import net.minecraft.src.Tessellator;
import net.minecraft.src.overrideapi.utils.Reflection;

public class ItemRendererProxy extends ItemRenderer {

	public ItemRendererProxy(Minecraft minecraft) {
		super(minecraft);
	}
	
	@Override
	public void renderItem(EntityLiving entityliving, ItemStack itemstack)
    {
		loadFieldsFromSuper();
        GL11.glPushMatrix();
        if(itemstack.itemID < Block.blocksList.length && RenderBlocks.renderItemIn3d(Block.blocksList[itemstack.itemID].getRenderType())) {
            GL11.glBindTexture(3553, MCExtendedManagers.TerrainManager.getTerrain(itemstack.getIconIndex() / 256));
            for (IRenderHook hook : IRenderHook.renderHooks)
            	hook.overrideTexture(Block.blocksList[itemstack.itemID]);
            renderBlocksInstance.renderBlockOnInventory(Block.blocksList[itemstack.itemID], itemstack.getItemDamage(), entityliving.getEntityBrightness(1.0F));
        } else {
            int i = entityliving.getItemIcon(itemstack);
            if(itemstack.itemID < Block.blocksList.length) {
                GL11.glBindTexture(3553, MCExtendedManagers.TerrainManager.getTerrain(i / 256));
                for (IRenderHook hook : IRenderHook.renderHooks)
                	hook.overrideTexture(Block.blocksList[itemstack.itemID]);
            } else {
                GL11.glBindTexture(3553, MCExtendedManagers.ItemManager.getItem(i / 256));
                for (IRenderHook hook : IRenderHook.renderHooks)
                	hook.overrideTexture(Item.itemsList[itemstack.itemID]);
            }
            Tessellator tessellator = Tessellator.instance;
            float f = ((float)((i % 16) * 16) + 0.0F) / 256F;
            float f1 = ((float)((i % 16) * 16) + 15.99F) / 256F;
            float f2 = ((float)((i / 16) * 16) + 0.0F) / 256F;
            float f3 = ((float)((i / 16) * 16) + 15.99F) / 256F;
            float f4 = 1.0F;
            float f5 = 0.0F;
            float f6 = 0.3F;
            GL11.glEnable(32826);
            GL11.glTranslatef(-f5, -f6, 0.0F);
            float f7 = 1.5F;
            GL11.glScalef(f7, f7, f7);
            GL11.glRotatef(50F, 0.0F, 1.0F, 0.0F);
            GL11.glRotatef(335F, 0.0F, 0.0F, 1.0F);
            GL11.glTranslatef(-0.9375F, -0.0625F, 0.0F);
            float f8 = 0.0625F;
            tessellator.startDrawingQuads();
            tessellator.setNormal(0.0F, 0.0F, 1.0F);
            tessellator.addVertexWithUV(0.0D, 0.0D, 0.0D, f1, f3);
            tessellator.addVertexWithUV(f4, 0.0D, 0.0D, f, f3);
            tessellator.addVertexWithUV(f4, 1.0D, 0.0D, f, f2);
            tessellator.addVertexWithUV(0.0D, 1.0D, 0.0D, f1, f2);
            tessellator.draw();
            tessellator.startDrawingQuads();
            tessellator.setNormal(0.0F, 0.0F, -1F);
            tessellator.addVertexWithUV(0.0D, 1.0D, 0.0F - f8, f1, f2);
            tessellator.addVertexWithUV(f4, 1.0D, 0.0F - f8, f, f2);
            tessellator.addVertexWithUV(f4, 0.0D, 0.0F - f8, f, f3);
            tessellator.addVertexWithUV(0.0D, 0.0D, 0.0F - f8, f1, f3);
            tessellator.draw();
            tessellator.startDrawingQuads();
            tessellator.setNormal(-1F, 0.0F, 0.0F);
            for(int j = 0; j < 16; j++) {
                float f9 = (float)j / 16F;
                float f13 = (f1 + (f - f1) * f9) - 0.001953125F;
                float f17 = f4 * f9;
                tessellator.addVertexWithUV(f17, 0.0D, 0.0F - f8, f13, f3);
                tessellator.addVertexWithUV(f17, 0.0D, 0.0D, f13, f3);
                tessellator.addVertexWithUV(f17, 1.0D, 0.0D, f13, f2);
                tessellator.addVertexWithUV(f17, 1.0D, 0.0F - f8, f13, f2);
            }

            tessellator.draw();
            tessellator.startDrawingQuads();
            tessellator.setNormal(1.0F, 0.0F, 0.0F);
            for(int k = 0; k < 16; k++) {
                float f10 = (float)k / 16F;
                float f14 = (f1 + (f - f1) * f10) - 0.001953125F;
                float f18 = f4 * f10 + 0.0625F;
                tessellator.addVertexWithUV(f18, 1.0D, 0.0F - f8, f14, f2);
                tessellator.addVertexWithUV(f18, 1.0D, 0.0D, f14, f2);
                tessellator.addVertexWithUV(f18, 0.0D, 0.0D, f14, f3);
                tessellator.addVertexWithUV(f18, 0.0D, 0.0F - f8, f14, f3);
            }

            tessellator.draw();
            tessellator.startDrawingQuads();
            tessellator.setNormal(0.0F, 1.0F, 0.0F);
            for(int l = 0; l < 16; l++) {
                float f11 = (float)l / 16F;
                float f15 = (f3 + (f2 - f3) * f11) - 0.001953125F;
                float f19 = f4 * f11 + 0.0625F;
                tessellator.addVertexWithUV(0.0D, f19, 0.0D, f1, f15);
                tessellator.addVertexWithUV(f4, f19, 0.0D, f, f15);
                tessellator.addVertexWithUV(f4, f19, 0.0F - f8, f, f15);
                tessellator.addVertexWithUV(0.0D, f19, 0.0F - f8, f1, f15);
            }

            tessellator.draw();
            tessellator.startDrawingQuads();
            tessellator.setNormal(0.0F, -1F, 0.0F);
            for(int i1 = 0; i1 < 16; i1++) {
                float f12 = (float)i1 / 16F;
                float f16 = (f3 + (f2 - f3) * f12) - 0.001953125F;
                float f20 = f4 * f12;
                tessellator.addVertexWithUV(f4, f20, 0.0D, f, f16);
                tessellator.addVertexWithUV(0.0D, f20, 0.0D, f1, f16);
                tessellator.addVertexWithUV(0.0D, f20, 0.0F - f8, f1, f16);
                tessellator.addVertexWithUV(f4, f20, 0.0F - f8, f, f16);
            }

            tessellator.draw();
            GL11.glDisable(32826);
        }
        GL11.glPopMatrix();
    }
	
    private RenderBlocks renderBlocksInstance;
    
    public void initSuper(ItemRenderer itemrenderer) {
		try {
			for (Field field : ItemRenderer.class.getDeclaredFields())
				Reflection.publicField(field).set(this, Reflection.publicField(field).get(itemrenderer));
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
    
    private static final List<Field> superFields = new ArrayList<Field>();
    
    static {
    	List<String[]> names = new ArrayList<String[]>();
    	names.add(new String[]{"e", "renderBlocksInstance"});
    	for (String[] s : names)
    		superFields.add(Reflection.publicField(Reflection.findField(ItemRenderer.class, s)));
    }
    
    private void loadFieldsFromSuper() {
    	for (int i = 0; i < superFields.size(); i++)
			try {
				getClass().getDeclaredFields()[i].set(this, superFields.get(i).get(this));
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
    }
}
