package net.mine_diver.infsprites.handlers;

import java.io.File;
import java.lang.reflect.Field;

import javax.imageio.ImageIO;

import net.mine_diver.infsprites.mcextended.MCExtendedManagers;
import net.minecraft.src.ModLoader;
import net.minecraft.src.PReader;
import net.minecraft.src.overrideapi.utils.Reflection;

public class ModLoaderMethodsHandler {
	
	public static void resetTerrainSprites() throws IllegalArgumentException, IllegalAccessException
	{
		boolean[] newUsedTerrainSprites = ((boolean[])usedTerrainSpritesField.get(null));
    	for(int i = 0; i < ((boolean[])usedTerrainSpritesField.get(null)).length; i++)
    	{
    		newUsedTerrainSprites[i] = false;
    	}
		usedTerrainSpritesField.set(null, newUsedTerrainSprites);
    	
    	terrainSpriteIndexField.set(null, 0);
    	ModLoaderFieldsHandler.currentTerrain = MCExtendedManagers.TerrainManager.registerTerrain((new StringBuilder()).append("/terrain").append(ModLoaderFieldsHandler.terrainNum).append(".png").toString());
    	File file = new File(PReader.MF(), (new StringBuilder()).append("mods/smith_61/ExtendedTerrains/terrain").append(ModLoaderFieldsHandler.terrainNum).append(".png").toString());
    	if(!file.exists())
    	{
    		try
    		{
    			File file1 = new File(PReader.MF(), "mods/smith_61/ExtendedTerrains");
    			if(!file1.exists())
    			{
    				file1.mkdirs();
    			}
    			File file2 = new File(PReader.MF(), "mods/smith_61/ExtendedTerrains/terrain1.png");
    			if(file2.exists())
    			{
    				ImageIO.write(ImageIO.read(file2), "png", file);
    			} else
    			{
    				ModLoaderFieldsHandler.terrainsToCopy.add(file);
    			}
    		}
    		catch(Exception exception)
    		{
    			throw new RuntimeException(exception);
    		}
    	}
    	MCExtendedManagers.TextureManager.registerOutsideTexture((new StringBuilder()).append("/terrain").append(ModLoaderFieldsHandler.terrainNum).append(".png").toString(), file);
    	ModLoaderFieldsHandler.terrainNum++;
	}
	
	private static final Field usedTerrainSpritesField = Reflection.publicField(Reflection.findField(ModLoader.class, "usedTerrainSprites"));
	private static final Field terrainSpriteIndexField = Reflection.publicField(Reflection.findField(ModLoader.class, "terrainSpriteIndex"));
	
	public static void resetItemSprites() throws IllegalArgumentException, IllegalAccessException
    {
		boolean[] newUsedItemSprites = ((boolean[])usedItemSpritesField.get(null));
        for(int i = 0; i < ((boolean[])usedItemSpritesField.get(null)).length; i++)
        {
            newUsedItemSprites[i] = false;
        }
		usedItemSpritesField.set(null, newUsedItemSprites);
        
        itemSpriteIndexField.set(null, 0);
        ModLoaderFieldsHandler.currentItem = MCExtendedManagers.ItemManager.registerItem((new StringBuilder()).append("/item").append(ModLoaderFieldsHandler.itemNum).append(".png").toString());
        File file = new File(PReader.MF(), (new StringBuilder()).append("mods/smith_61/ExtendedItems/item").append(ModLoaderFieldsHandler.itemNum).append(".png").toString());
        if(!file.exists())
        {
            try
            {
                File file1 = new File(PReader.MF(), "mods/smith_61/ExtendedItems");
                if(!file1.exists())
                {
                    file1.mkdirs();
                }
                File file2 = new File(PReader.MF(), "mods/smith_61/ExtendedItems/item1.png");
                if(file2.exists())
                {
                    ImageIO.write(ImageIO.read(file2), "png", file);
                } else
                {
                	ModLoaderFieldsHandler.itemsToCopy.add(file);
                }
            }
            catch(Exception exception)
            {
                throw new RuntimeException(exception);
            }
        }
        MCExtendedManagers.TextureManager.registerOutsideTexture((new StringBuilder()).append("/item").append(ModLoaderFieldsHandler.itemNum).append(".png").toString(), file);
        ModLoaderFieldsHandler.itemNum++;
    }
	
	private static final Field usedItemSpritesField = Reflection.publicField(Reflection.findField(ModLoader.class, "usedItemSprites"));
	private static final Field itemSpriteIndexField = Reflection.publicField(Reflection.findField(ModLoader.class, "itemSpriteIndex"));
	
	public static void checkTerrainSizes()
	{
		File file = new File(PReader.MF(), "mods/smith_61/ExtendedTerrains");
		if(file.exists())
		{
			try
			{
				java.awt.image.BufferedImage bufferedimage = ImageIO.read(ModLoader.getMinecraftInstance().texturePackList.selectedTexturePack.getResourceAsStream("/terrain.png"));
				File afile[] = file.listFiles();
				for(int i = 0; i < afile.length; i++)
				{
					File file1 = afile[i];
					if(file1.isFile() && file1.getName().endsWith(".png") && !checkImageSizes(bufferedimage, ImageIO.read(file1)))
					{
						ModLoaderFieldsHandler.terrainsToCopy.add(file1);
					}
				}
			}
			catch(Exception exception)
			{
				throw new RuntimeException(exception);
			}
		}
	}
	
	public static void checkItemSizes()
    {
        File file = new File(PReader.MF(), "mods/smith_61/ExtendedItems");
        if(file.exists())
        {
            try
            {
                java.awt.image.BufferedImage bufferedimage = ImageIO.read(ModLoader.getMinecraftInstance().texturePackList.selectedTexturePack.getResourceAsStream("/gui/items.png"));
                File afile[] = file.listFiles();
                for(int i = 0; i < afile.length; i++)
                {
                    File file1 = afile[i];
                    if(file1.isFile() && file1.getName().endsWith(".png") && !checkImageSizes(bufferedimage, ImageIO.read(file1)))
                    {
                        ModLoaderFieldsHandler.itemsToCopy.add(file1);
                    }
                }
            }
            catch(Exception exception)
            {
                throw new RuntimeException(exception);
            }
        }
    }

	
	private static boolean checkImageSizes(java.awt.image.BufferedImage bufferedimage, java.awt.image.BufferedImage bufferedimage1)
	{
		int i = bufferedimage.getWidth();
		int j = bufferedimage.getHeight();
		return i == bufferedimage1.getWidth() && j == bufferedimage1.getHeight();
	}
	
	public static void copyImages()
	{
		try
		{
			for(int i = 0; i < ModLoaderFieldsHandler.terrainsToCopy.size(); i++)
			{
				File file = (File)ModLoaderFieldsHandler.terrainsToCopy.get(i);
				ImageIO.write(ImageIO.read(ModLoader.getMinecraftInstance().texturePackList.selectedTexturePack.getResourceAsStream("/terrain.png")), "png", file);
			}
			
			for(int j = 0; j < ModLoaderFieldsHandler.itemsToCopy.size(); j++)
            {
                File file1 = (File)ModLoaderFieldsHandler.itemsToCopy.get(j);
                ImageIO.write(ImageIO.read(ModLoader.getMinecraftInstance().texturePackList.selectedTexturePack.getResourceAsStream("/gui/items.png")), "png", file1);
            }
		}
		catch(Throwable throwable)
		{
			throw new RuntimeException(throwable);
		}
		ModLoaderFieldsHandler.terrainsToCopy.clear();
		ModLoaderFieldsHandler.itemsToCopy.clear();
	}
}