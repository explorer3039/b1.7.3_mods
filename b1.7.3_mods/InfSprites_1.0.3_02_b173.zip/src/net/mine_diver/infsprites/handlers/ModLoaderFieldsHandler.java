package net.mine_diver.infsprites.handlers;

import java.io.File;
import java.util.ArrayList;

public class ModLoaderFieldsHandler {
	public static int currentTerrain = 0;
	static int terrainNum = 1;
	public static int currentItem = 0;
    static int itemNum = 1;
	static ArrayList<File> terrainsToCopy = new ArrayList<File>();
    static ArrayList<File> itemsToCopy = new ArrayList<File>();
}