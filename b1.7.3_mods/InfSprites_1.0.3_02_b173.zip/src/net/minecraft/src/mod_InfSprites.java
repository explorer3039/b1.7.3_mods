package net.minecraft.src;

import java.util.Map;

import net.mine_diver.infsprites.Core;
import net.mine_diver.infsprites.info;
import net.minecraft.client.Minecraft;

public class mod_InfSprites extends BaseMod {
	
	public String Name() {
		return info.NAME;
	}
	
	public String Description() {
		return info.DESCRIPTION;
	}
	
	@Override
	public String Version() {
		return info.VERSION;
	}	
	
	public mod_InfSprites() {
		CORE.preInit(this);
		/*for (int i = 0; i < 90; i++)
			ModLoader.addOverride("/terrain.png", "/test/refinedSoulSand.png");
		int j = ModLoader.addOverride("/terrain.png", "/test/chargedSand.png");
		Block testBlock = new Block(200, j, Material.sand).setBlockName("testBlock");
		ModLoader.RegisterBlock(testBlock);
		ModLoader.AddName(testBlock, "Test Block");
		ModLoader.AddRecipe(new ItemStack(Block.obsidian, 64), new Object[]{"X", Character.valueOf('X'), Block.dirt});
		ModLoader.AddRecipe(new ItemStack(Item.flintAndSteel), new Object[]{"X", Character.valueOf('X'), Block.obsidian});
		ModLoader.AddRecipe(new ItemStack(testBlock, 64), new Object[]{"X", Character.valueOf('X'), Block.sand});
		ModLoader.AddRecipe(new ItemStack(Block.waterStill, 64), new Object[]{"X", Character.valueOf('X'), testBlock});
		for (int i = 0; i < 300; i++)
			ModLoader.addOverride("/gui/items.png", "/test/chargedSand.png");
		j = ModLoader.addOverride("/gui/items.png", "/test/refinedSoulSand.png");
		Item testItem = new Item(4000).setIconIndex(j).setItemName("testItem");
		ModLoader.AddName(testItem, "Test Item");
		ModLoader.AddRecipe(new ItemStack(testItem, 64), new Object[]{"X", Character.valueOf('X'), Block.waterStill});*/
	}
	
	@Override
	public void ModsLoaded() {
		CORE.init();
	}
	
	@Override
	public boolean OnTickInGUI(Minecraft minecraft, GuiScreen guiscreen) {
		CORE.postInit(minecraft);
		return false;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public void AddRenderer(@SuppressWarnings("rawtypes") Map map) {
		CORE.addRenderer(map);
	}
	
	public static void setPrevSortX(RenderGlobal renderglobal, double prevSortX) {
		renderglobal.prevSortX = prevSortX;
	}
	
	public static void setPrevSortY(RenderGlobal renderglobal, double prevSortY) {
		renderglobal.prevSortY = prevSortY;
	}
	
	public static void setPrevSortZ(RenderGlobal renderglobal, double prevSortZ) {
		renderglobal.prevSortZ = prevSortZ;
	}
	
	public static int getParticleTextureIndex(EntityFX entityfx) {
		return entityfx.particleTextureIndex;
	}
	
	public static final Core CORE = new Core();
	public static final boolean workspace = mod_InfSprites.class.getName() != mod_InfSprites.class.getSimpleName();
}