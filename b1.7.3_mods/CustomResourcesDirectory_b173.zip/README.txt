CustomResource Location for Beta 1.7.3
Made by Johnanater

To install:
1. Add the classes to your minecraft.jar
2. Delete META-INF
3. Start Minecraft
4. Edit your options.txt (In your .minecraft)
   The the line will be customResoucesDirectory, you
   can change this to where ever you want!
3. Enjoy!

Classes Changed:
GameSettings (kv.class)
ThreadDownloadResources (cz.class)

I just added a gamesetting for a custom directory to downlod the resources to.

(I don't own any of the code, it all belongs to Mojang)