package net.mine_diver.infsprites.proxy;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.mine_diver.infsprites.mcextended.MCExtendedManagers;
import net.minecraft.client.Minecraft;
import net.minecraft.src.ModLoader;
import net.minecraft.src.TexturePackBase;
import net.minecraft.src.TexturePackCustom;
import net.minecraft.src.TexturePackList;
import net.minecraft.src.overrideapi.utils.Reflection;

public class TexturePackListProxy extends TexturePackList {
	
	public TexturePackListProxy(Minecraft minecraft, File file) {
		super(minecraft, file);
	}
	
	@Override
	public void updateAvaliableTexturePacks() {
		loadFieldsFromSuper();
		List<TexturePackBase> arraylist = new ArrayList<TexturePackBase>();
        selectedTexturePack = null;
        arraylist.add(defaultTexturePack);
        if(texturePackDir.exists() && texturePackDir.isDirectory()) {
            File afile[] = texturePackDir.listFiles();
            File afile1[] = afile;
            int i = afile1.length;
            for(int j = 0; j < i; j++) {
                File file = afile1[j];
                if(!file.isFile() || !file.getName().toLowerCase().endsWith(".zip"))
                    continue;
                String s = file.getName() + ":" + file.length() + ":" + file.lastModified();
                try {
                    if(!field_6538_d.containsKey(s)) {
                        TexturePackCustom texturepackcustom = new MCExtendedManagers.TexturePackC(file, new TexturePackCustom(file));
                        texturepackcustom.field_6488_d = s;
                        field_6538_d.put(s, texturepackcustom);
                        texturepackcustom.func_6485_a(mc);
                    }
                    TexturePackBase texturepackbase1 = field_6538_d.get(s);
                    if(texturepackbase1.texturePackFileName.equals(currentTexturePack))
                        selectedTexturePack = texturepackbase1;
                    arraylist.add(texturepackbase1);
                }
                catch(IOException ioexception) {
                    ioexception.printStackTrace();
                }
            }
        }
        if(selectedTexturePack == null)
            selectedTexturePack = defaultTexturePack;
        availableTexturePacks.removeAll(arraylist);
        TexturePackBase texturepackbase;
        for(Iterator<TexturePackBase> iterator = availableTexturePacks.iterator(); iterator.hasNext(); field_6538_d.remove(texturepackbase.field_6488_d)) {
            texturepackbase = iterator.next();
            texturepackbase.func_6484_b(mc);
        }

        availableTexturePacks = arraylist;
        saveFieldsToSuper();
	}
	
	private List<TexturePackBase> availableTexturePacks;
	private TexturePackBase defaultTexturePack;
    private Map<String, TexturePackBase> field_6538_d;
    private Minecraft mc;
    private File texturePackDir;
    private String currentTexturePack;
	
	public void initSuper() {
		try {
			for (Field field : TexturePackList.class.getDeclaredFields())
				Reflection.publicField(field).set(this, Reflection.publicField(field).get(ModLoader.getMinecraftInstance().texturePackList));
			loadFieldsFromSuper();
			availableTexturePacks.clear();
			defaultTexturePack = new MCExtendedManagers.TexturePackD();
			selectedTexturePack = null;
			field_6538_d.clear();
			saveFieldsToSuper();
			updateAvaliableTexturePacks();
	        selectedTexturePack.func_6482_a();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
	
	private static final List<Field> superFields = new ArrayList<Field>();
    
    static {
    	List<String[]> names = new ArrayList<String[]>();
    	names.add(new String[]{"b", "availableTexturePacks"});
    	names.add(new String[]{"c", "defaultTexturePack"});
    	names.add(new String[]{"d", "field_6538_d"});
    	names.add(new String[]{"e", "mc"});
    	names.add(new String[]{"f", "texturePackDir"});
    	names.add(new String[]{"g", "currentTexturePack"});
    	for (String[] s : names)
    		superFields.add(Reflection.publicField(Reflection.findField(TexturePackList.class, s)));
    }
	
    private void loadFieldsFromSuper() {
    	for (int i = 0; i < superFields.size(); i++)
			try {
				getClass().getDeclaredFields()[i].set(this, superFields.get(i).get(this));
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
    }
    
    private void saveFieldsToSuper() {
    	for (int i = 0; i < superFields.size(); i++)
			try {
				superFields.get(i).set(this, getClass().getDeclaredFields()[i].get(this));
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
    }
}
