package net.mine_diver.infsprites.proxy;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.lwjgl.opengl.GL11;

import net.mine_diver.infsprites.api.IRenderHook;
import net.mine_diver.infsprites.mcextended.MCExtendedManagers;
import net.mine_diver.infsprites.util.BlockCoord;
import net.mine_diver.infsprites.util.compatibility.Forge;
import net.minecraft.src.Block;
import net.minecraft.src.Chunk;
import net.minecraft.src.ChunkCache;
import net.minecraft.src.RenderBlocks;
import net.minecraft.src.Tessellator;
import net.minecraft.src.TileEntity;
import net.minecraft.src.TileEntityRenderer;
import net.minecraft.src.World;
import net.minecraft.src.WorldRenderer;
import net.minecraft.src.overrideapi.utils.Reflection;

public class WorldRendererProxy extends WorldRenderer {

	public WorldRendererProxy(World world, List<TileEntity> list, int i, int j, int k, int l, int i1) {
		super(world, list, i, j, k, l, i1);
	}

	@SuppressWarnings("unchecked")
	@Override
	public void updateRenderer() {
		loadFieldsFromSuper();
        if(!needsUpdate)
            return;
        chunksUpdated++;
        int i = posX;
        int j = posY;
        int k = posZ;
        int l = posX + sizeWidth;
        int i1 = posY + sizeHeight;
        int j1 = posZ + sizeDepth;
        for(int k1 = 0; k1 < 2; k1++)
            skipRenderPass[k1] = true;
        Chunk.isLit = false;
        Set<TileEntity> hashset = new HashSet<TileEntity>();
        hashset.addAll(tileEntityRenderers);
        tileEntityRenderers.clear();
        int l1 = 1;
        ChunkCache chunkcache = new ChunkCache(worldObj, i - l1, j - l1, k - l1, l + l1, i1 + l1, j1 + l1);
        RenderBlocks renderblocks = new RenderBlocksProxy(chunkcache);
        int i2 = 0;
        do {
            if(i2 >= 2)
                break;
            boolean flag = false;
            boolean flag1 = false;
            boolean flag2 = false;
            Map<Integer, List<BlockCoord>> hashmap = new HashMap<Integer, List<BlockCoord>>();
            List<Integer> arraylist = new ArrayList<Integer>();
            for(int j2 = j; j2 < i1; j2++) {
                for(int k2 = k; k2 < j1; k2++) {
                    for(int l2 = i; l2 < l; l2++) {
                        int i3 = chunkcache.getBlockId(l2, j2, k2);
                        if(i3 <= 0)
                            continue;
                        if(!flag2) {
                            flag2 = true;
                            GL11.glNewList(glRenderList + i2, 4864);
                            GL11.glBindTexture(3553, MCExtendedManagers.TerrainManager.getTerrain(0));
                            GL11.glPushMatrix();
                            setupGLTranslation();
                            float f = 1.000001F;
                            GL11.glTranslatef((float)(-sizeDepth) / 2.0F, (float)(-sizeHeight) / 2.0F, (float)(-sizeDepth) / 2.0F);
                            GL11.glScalef(f, f, f);
                            GL11.glTranslatef((float)sizeDepth / 2.0F, (float)sizeHeight / 2.0F, (float)sizeDepth / 2.0F);
                            for (IRenderHook hook : IRenderHook.renderHooks)
                            	hook.beforeRenderPass(i2);
                            (Forge.installed ? Tessellator.instance : tessellator).startDrawingQuads();
                            (Forge.installed ? Tessellator.instance : tessellator).setTranslationD(-posX, -posY, -posZ);
                        }
                        if(i2 == 0 && Block.isBlockContainer[i3]) {
                            TileEntity tileentity = chunkcache.getBlockTileEntity(l2, j2, k2);
                            if(TileEntityRenderer.instance.hasSpecialRenderer(tileentity))
                                tileEntityRenderers.add(tileentity);
                        }
                        Block block = Block.blocksList[i3];
                        int j3 = block.getRenderBlockPass();
                        
                        if(j3 > i2)
                            flag = true;
                        
                        BlockCoord blockcoord1 = new BlockCoord(l2, j2, k2, i3);
                        boolean flag5 = false;
                        List<Integer> arraylist2 = new ArrayList<Integer>();
                        for(int j4 = 0; j4 < 6; j4++) {
                        	int k4 = block.getBlockTexture(worldObj, l2, j2, k2, j4) / 256;
                            if(k4 == 0) {
                                flag5 = true;
                                continue;
                            }
                            if(arraylist2.contains(k4))
                                continue;
							List<BlockCoord> arraylist3 = hashmap.get(Integer.valueOf(k4));
                            if(arraylist3 == null) {
                                arraylist3 = new ArrayList<BlockCoord>();
                                hashmap.put(Integer.valueOf(k4), arraylist3);
                            }
                            arraylist3.add(blockcoord1);
                            if(!arraylist.contains(Integer.valueOf(k4)))
                                arraylist.add(Integer.valueOf(k4));
                            arraylist2.add(Integer.valueOf(k4));
                        }
                        
                        boolean pass = true;
                        for (IRenderHook hook : IRenderHook.renderHooks)
                        	if (!hook.canRenderInPass(block, i2))
                        		pass = false;
                        
                        if(flag5 && pass) {
                        	for (IRenderHook hook : IRenderHook.renderHooks)
                        		hook.beforeBlockRender(block, renderblocks);
                            flag1 |= ((RenderBlocksProxy)renderblocks).renderBlockByRenderType(block, l2, j2, k2, 0);
                        	for (IRenderHook hook : IRenderHook.renderHooks)
                        		hook.afterBlockRender(block, renderblocks);
                        }
                    }
                }
            }

            if(flag2) {
            	for (IRenderHook hook : IRenderHook.renderHooks)
            		hook.afterRenderPass(i2);
            	(Forge.installed ? Tessellator.instance : tessellator).draw();
            }
            
            for(int k2 = 0; k2 < arraylist.size(); k2++) {
                boolean flag4 = false;
                int j3 = ((Integer)arraylist.get(k2)).intValue();
				List<BlockCoord> arraylist1 = hashmap.get(Integer.valueOf(j3));
                for(int l3 = 0; l3 < arraylist1.size(); l3++) {
                    if(!flag4) {
                        GL11.glBindTexture(3553, MCExtendedManagers.TerrainManager.getTerrain(j3));
                        (Forge.installed ? Tessellator.instance : tessellator).startDrawingQuads();
                        flag4 = true;
                    }
                    BlockCoord blockcoord = (BlockCoord)arraylist1.get(l3);
                    flag1 |= ((RenderBlocksProxy)renderblocks).renderBlockByRenderType(Block.blocksList[blockcoord.blockID], blockcoord.posX, blockcoord.posY, blockcoord.posZ, j3);
                }

                if(flag4)
                	(Forge.installed ? Tessellator.instance : tessellator).draw();
            }
            
            if(flag2) {
                GL11.glPopMatrix();
                GL11.glEndList();
                (Forge.installed ? Tessellator.instance : tessellator).setTranslationD(0.0D, 0.0D, 0.0D);
            } else
                flag1 = false;
            if(flag1)
                skipRenderPass[i2] = false;
            if(!flag)
                break;
            i2++;
        } while (true);
		Set<TileEntity> hashset1 = new HashSet<TileEntity>();
        hashset1.addAll(tileEntityRenderers);
        hashset1.removeAll(hashset);
        tileEntities.addAll(hashset1);
        hashset.removeAll(tileEntityRenderers);
        tileEntities.removeAll(hashset);
        isChunkLit = Chunk.isLit;
        isInitialized = true;
        saveFieldsToSuper();
    }
	
    private int glRenderList;
    @SuppressWarnings("unused")
	private boolean isInitialized;
	private List<TileEntity> tileEntities;
    private static Tessellator tessellator;
	
    private static final List<Field> superFields = new ArrayList<Field>();
    
    static {
    	List<String[]> names = new ArrayList<String[]>();
    	names.add(new String[]{"C", "glRenderList"});
    	names.add(new String[]{"E", "isInitialized"});
    	names.add(new String[]{"F", "tileEntities"});
    	if (!Forge.installed)
        	names.add(new String[]{"D", "tessellator"});
    	for (String[] s : names)
    		superFields.add(Reflection.publicField(Reflection.findField(WorldRenderer.class, s)));
    }
    
    private void loadFieldsFromSuper() {
    	for (int i = 0; i < superFields.size(); i++)
			try {
				getClass().getDeclaredFields()[i].set(this, superFields.get(i).get(this));
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
    }
    
    private void saveFieldsToSuper() {
    	for (int i = 0; i < superFields.size(); i++)
			try {
				superFields.get(i).set(this, getClass().getDeclaredFields()[i].get(this));
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
    }
    
    private static final Method setupGLTranslation;
	
	static {
		Method method = null;
		for (Method m : WorldRenderer.class.getDeclaredMethods())
			if ((m.getName().equals("g") || m.getName().equals("setupGLTranslation")) && Arrays.equals(m.getParameterTypes(), new Class<?>[]{})) {
				m.setAccessible(true);
				method = m;
				break;
			}
		setupGLTranslation = method;
	}
    
	private void setupGLTranslation() {
		try {
        	saveFieldsToSuper();
        	setupGLTranslation.invoke(this, new Object[]{});
			loadFieldsFromSuper();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
}