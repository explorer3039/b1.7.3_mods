package net.mine_diver.infsprites.proxy;

import net.minecraft.src.Block;
import net.minecraft.src.IBlockAccess;
import net.minecraft.src.RenderBlocks;
import net.minecraft.src.Tessellator;

public class RenderBlocksProxy extends RenderBlocks {

	public RenderBlocksProxy(IBlockAccess iblockaccess) {
		this();
		blockAccess = iblockaccess;
	}
	
	public RenderBlocksProxy() {
		super();
		textureNum = -1;
	}
	
    public int getCurrentTexture() {
        return textureNum;
    }

    public boolean renderBlockByRenderType(Block block, int i, int j, int k, int l) {
        textureNum = l;
        boolean flag = renderBlockByRenderType(block, i, j, k);
        textureNum = -1;
        return flag;
    }
    
    @Override
    public void renderCrossedSquares(Block block, int i, double d, double d1, double d2) {
        Tessellator tessellator = Tessellator.instance;
        int j = block.getBlockTextureFromSideAndMetadata(0, i);
        if(textureNum != -1) {
            if(j / 256 != textureNum)
                return;
            j -= textureNum * 256;
        }
        if(overrideBlockTexture >= 0)
            j = overrideBlockTexture;
        int k = (j & 0xf) << 4;
        int l = j & 0xf0;
        double d3 = (float)k / 256F;
        double d4 = ((float)k + 15.99F) / 256F;
        double d5 = (float)l / 256F;
        double d6 = ((float)l + 15.99F) / 256F;
        double d7 = (d + 0.5D) - 0.44999998807907104D;
        double d8 = d + 0.5D + 0.44999998807907104D;
        double d9 = (d2 + 0.5D) - 0.44999998807907104D;
        double d10 = d2 + 0.5D + 0.44999998807907104D;
        tessellator.addVertexWithUV(d7, d1 + 1.0D, d9, d3, d5);
        tessellator.addVertexWithUV(d7, d1 + 0.0D, d9, d3, d6);
        tessellator.addVertexWithUV(d8, d1 + 0.0D, d10, d4, d6);
        tessellator.addVertexWithUV(d8, d1 + 1.0D, d10, d4, d5);
        tessellator.addVertexWithUV(d8, d1 + 1.0D, d10, d3, d5);
        tessellator.addVertexWithUV(d8, d1 + 0.0D, d10, d3, d6);
        tessellator.addVertexWithUV(d7, d1 + 0.0D, d9, d4, d6);
        tessellator.addVertexWithUV(d7, d1 + 1.0D, d9, d4, d5);
        tessellator.addVertexWithUV(d7, d1 + 1.0D, d10, d3, d5);
        tessellator.addVertexWithUV(d7, d1 + 0.0D, d10, d3, d6);
        tessellator.addVertexWithUV(d8, d1 + 0.0D, d9, d4, d6);
        tessellator.addVertexWithUV(d8, d1 + 1.0D, d9, d4, d5);
        tessellator.addVertexWithUV(d8, d1 + 1.0D, d9, d3, d5);
        tessellator.addVertexWithUV(d8, d1 + 0.0D, d9, d3, d6);
        tessellator.addVertexWithUV(d7, d1 + 0.0D, d10, d4, d6);
        tessellator.addVertexWithUV(d7, d1 + 1.0D, d10, d4, d5);
    }
    
    @Override
    public void func_1245_b(Block block, int i, double d, double d1, double d2) {
        Tessellator tessellator = Tessellator.instance;
        int j = block.getBlockTextureFromSideAndMetadata(0, i);
        if(textureNum != -1) {
            if(j / 256 != textureNum)
                return;
            j -= textureNum * 256;
        }
        if(overrideBlockTexture >= 0)
            j = overrideBlockTexture;
        int k = (j & 0xf) << 4;
        int l = j & 0xf0;
        double d3 = (float)k / 256F;
        double d4 = ((float)k + 15.99F) / 256F;
        double d5 = (float)l / 256F;
        double d6 = ((float)l + 15.99F) / 256F;
        double d7 = (d + 0.5D) - 0.25D;
        double d8 = d + 0.5D + 0.25D;
        double d9 = (d2 + 0.5D) - 0.5D;
        double d10 = d2 + 0.5D + 0.5D;
        tessellator.addVertexWithUV(d7, d1 + 1.0D, d9, d3, d5);
        tessellator.addVertexWithUV(d7, d1 + 0.0D, d9, d3, d6);
        tessellator.addVertexWithUV(d7, d1 + 0.0D, d10, d4, d6);
        tessellator.addVertexWithUV(d7, d1 + 1.0D, d10, d4, d5);
        tessellator.addVertexWithUV(d7, d1 + 1.0D, d10, d3, d5);
        tessellator.addVertexWithUV(d7, d1 + 0.0D, d10, d3, d6);
        tessellator.addVertexWithUV(d7, d1 + 0.0D, d9, d4, d6);
        tessellator.addVertexWithUV(d7, d1 + 1.0D, d9, d4, d5);
        tessellator.addVertexWithUV(d8, d1 + 1.0D, d10, d3, d5);
        tessellator.addVertexWithUV(d8, d1 + 0.0D, d10, d3, d6);
        tessellator.addVertexWithUV(d8, d1 + 0.0D, d9, d4, d6);
        tessellator.addVertexWithUV(d8, d1 + 1.0D, d9, d4, d5);
        tessellator.addVertexWithUV(d8, d1 + 1.0D, d9, d3, d5);
        tessellator.addVertexWithUV(d8, d1 + 0.0D, d9, d3, d6);
        tessellator.addVertexWithUV(d8, d1 + 0.0D, d10, d4, d6);
        tessellator.addVertexWithUV(d8, d1 + 1.0D, d10, d4, d5);
        d7 = (d + 0.5D) - 0.5D;
        d8 = d + 0.5D + 0.5D;
        d9 = (d2 + 0.5D) - 0.25D;
        d10 = d2 + 0.5D + 0.25D;
        tessellator.addVertexWithUV(d7, d1 + 1.0D, d9, d3, d5);
        tessellator.addVertexWithUV(d7, d1 + 0.0D, d9, d3, d6);
        tessellator.addVertexWithUV(d8, d1 + 0.0D, d9, d4, d6);
        tessellator.addVertexWithUV(d8, d1 + 1.0D, d9, d4, d5);
        tessellator.addVertexWithUV(d8, d1 + 1.0D, d9, d3, d5);
        tessellator.addVertexWithUV(d8, d1 + 0.0D, d9, d3, d6);
        tessellator.addVertexWithUV(d7, d1 + 0.0D, d9, d4, d6);
        tessellator.addVertexWithUV(d7, d1 + 1.0D, d9, d4, d5);
        tessellator.addVertexWithUV(d8, d1 + 1.0D, d10, d3, d5);
        tessellator.addVertexWithUV(d8, d1 + 0.0D, d10, d3, d6);
        tessellator.addVertexWithUV(d7, d1 + 0.0D, d10, d4, d6);
        tessellator.addVertexWithUV(d7, d1 + 1.0D, d10, d4, d5);
        tessellator.addVertexWithUV(d7, d1 + 1.0D, d10, d3, d5);
        tessellator.addVertexWithUV(d7, d1 + 0.0D, d10, d3, d6);
        tessellator.addVertexWithUV(d8, d1 + 0.0D, d10, d4, d6);
        tessellator.addVertexWithUV(d8, d1 + 1.0D, d10, d4, d5);
    }
    
    @Override
    public void renderBottomFace(Block block, double d, double d1, double d2, int i) {
    	if(textureNum != -1) {
            if(i / 256 != textureNum)
                return;
            i -= textureNum * 256;
        }
    	super.renderBottomFace(block, d, d1, d2, i);
    }
    
    @Override
    public void renderTopFace(Block block, double d, double d1, double d2, int i) {
    	if(textureNum != -1) {
            if(i / 256 != textureNum)
                return;
            i -= textureNum * 256;
        }
    	super.renderTopFace(block, d, d1, d2, i);
    }
    
    @Override
    public void renderEastFace(Block block, double d, double d1, double d2, int i) {
    	if(textureNum != -1) {
            if(i / 256 != textureNum)
                return;
            i -= textureNum * 256;
        }
    	super.renderEastFace(block, d, d1, d2, i);
    }
    
    @Override
    public void renderWestFace(Block block, double d, double d1, double d2, int i) {
    	if(textureNum != -1) {
            if(i / 256 != textureNum) 
                return;
            i -= textureNum * 256;
        }
    	super.renderWestFace(block, d, d1, d2, i);
    }
    
    @Override
    public void renderNorthFace(Block block, double d, double d1, double d2, int i) {
    	if(textureNum != -1) {
            if(i / 256 != textureNum)
                return;
            i -= textureNum * 256;
        }
    	super.renderNorthFace(block, d, d1, d2, i);
    }
    
    @Override
    public void renderSouthFace(Block block, double d, double d1, double d2, int i) {
    	if(textureNum != -1) {
            if(i / 256 != textureNum)
                return;
            i -= textureNum * 256;
        }
    	super.renderSouthFace(block, d, d1, d2, i);
    }
	
	private int textureNum;
}
