package net.mine_diver.infsprites.util.compatibility;

import net.mine_diver.infsprites.api.IRenderHook;
import net.minecraft.src.Block;
import net.minecraft.src.RenderBlocks;
import net.minecraft.src.mod_InfSprites;
import net.minecraft.src.forge.ForgeHooksClient;

public class Forge implements ICompatibilityPatcher, IRenderHook {
	
	public static boolean installed = false;
	
	@Override
	public String requiredClass() {
		return (mod_InfSprites.workspace ? "net.minecraft.src." : "") + "forge.ForgeHooksClient";
	}
	
	@Override
	public void patch() {
		IRenderHook.renderHooks.add(this);
		installed = true;
	}

	@Override
	public void beforeRenderPass(int pass) {
		ForgeHooksClient.beforeRenderPass(pass);
	}

	@Override
	public boolean canRenderInPass(Block block, int pass) {
		return ForgeHooksClient.canRenderInPass(block, pass);
	}

	@Override
	public void beforeBlockRender(Block block, RenderBlocks renderblocks) {
		ForgeHooksClient.beforeBlockRender(block, renderblocks);
	}

	@Override
	public void afterBlockRender(Block block, RenderBlocks renderblocks) {
		ForgeHooksClient.afterBlockRender(block, renderblocks);
	}

	@Override
	public void afterRenderPass(int pass) {
		ForgeHooksClient.afterRenderPass(pass);
	}

	@Override
	public void overrideTexture(Object o) {
		ForgeHooksClient.overrideTexture(o);
	}
}
