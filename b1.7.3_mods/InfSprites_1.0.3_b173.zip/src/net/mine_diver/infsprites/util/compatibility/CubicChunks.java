package net.mine_diver.infsprites.util.compatibility;

public class CubicChunks implements ICompatibilityPatcher {
	
	public static boolean installed = false;
	
	@Override
	public String requiredClass() {
		return null;
	}
	
	@Override
	public void patch() {
		installed = true;
	}
}
