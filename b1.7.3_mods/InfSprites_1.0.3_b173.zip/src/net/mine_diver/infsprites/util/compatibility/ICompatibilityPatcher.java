package net.mine_diver.infsprites.util.compatibility;

import java.util.ArrayList;
import java.util.List;

public interface ICompatibilityPatcher {
	
	public static final List<ICompatibilityPatcher> compatibilityPatchers = new ArrayList<ICompatibilityPatcher>();

	String requiredClass();
	void patch();
}
