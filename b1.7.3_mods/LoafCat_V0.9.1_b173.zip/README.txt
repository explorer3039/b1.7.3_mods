                                           LOAFCAT
                                      Minecraft 1.7.2
                                             ver 0.9.1

       
Installation:
Requires Modloader and AudioMod 
PropertyReader included

These instructions assume you already know where your .minecraft directory is.
And that ModLoader and AudioMod are installed.

1. Using your favorite archiving tool(ex. 7zip), extract LoafCat to a temporary folder.
2. Then just copy the folders (mods, resorces) to your .minecraft folder.
3. Make sure Meta-INF folder is deleted. (.minecraft/bin/minecraft.jar)
4. Run game and enjoy!


-Differnt skin options-

LoafCat randomly changes the texture of each cat as it spawns for more variety in your feline world. At the moment the maximum variety is 5. This feature only applies to the regular LoafCat, not the Alpha Cat minion. This will be increased and configurable in the near future.

-Properties File-

Currently the properties file (.minecraft/mods/LoafCat/loafCat.properties) allows for Spawn Rate control. Just change the default numbers to anything between 1-99. Only whole numbers accepted (no decimal numbers). The properties file is automatically created for you(after your first log in with the mod). Location - .minecraft/mods/LoafCat/loafcat.properties.

-Alpha Cat-

These bad boys are tame-able just like the wolf. I used the code that was already there for the wolf AI and applied it to AlphaCat. Currently Alpha Cats are tame-able with raw fish. I have not yet implemented the sit animtion so they stand in place when commanded. They also protect them selves but not the player. Fickle felines! I will remedy this in the future. 

For those that would like to change the textures for Alpha Cat, here are their respective locations.
Wild - .minecraft/mods/LoafCat.zip  Inside the zip - LK/alphacat.png
Angry - .minecraft/mods/LoafCat.zip  Inside the zip - LK/alphacat_angry.png
Tamed - .minecraft/mods/LoafCat.zip  Inside the zip - LK/alphacat_tame.png
Just rename the texture you would like to use to either alphacat.png, alpacat_angry.png, or alphacat_tame.png and overwrite the default. These directions are for AFTER the mod is installed.

-LK


-ChangeLog-
0.8 - beta release
0.8.1 - added 5 color varieties
0.8.2 - MC version update
0.9 - added Alpha Cats , minor model changes
0.9.1 - MC version update (1.7.2), new alphacat_angry texture

 - Acknowledgements -

BIG HUGE thank you to Amalah for the inspiration for the mod and all the gorgeous texture work. Salut!!

Davyxo - the cat model was slightly based on his model concept.
All of the great tutorials and info on the Minecraft Community forums. 
Randomobs src (source code) - apply function for random textures.
MCP - would not be possible without this superb tool
Techne - ^^ same as above
And I sincerely thank YOU for using one of my projects.