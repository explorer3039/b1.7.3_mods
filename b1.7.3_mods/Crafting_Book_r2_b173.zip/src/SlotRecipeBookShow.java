public class SlotRecipeBookShow extends gp {
	public SlotRecipeBookShow(lw inventory, int slot, int x, int y) {
		super(inventory,slot,x,y);
	}
	
	public boolean b(iz stack) {
		return false;
	}
	
	public void a(iz stack) {
		c(new iz(stack.c,stack.a,stack.i()));
		super.a(stack);
		ModLoader.getMinecraftInstance().h.c.b((iz)null);
	}
}