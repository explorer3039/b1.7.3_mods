import org.lwjgl.opengl.GL11;

public class GuiRecipesCraft extends id {
	public GuiRecipesCraft(lw playerInventory) {
		super(new GuiSrvRecipesCraft(playerInventory));
		mod_CraftingBook.recCraft.getRecipes();
		
		d = 166;
		f = false;
	}

	public void h() {
		super.h();
		j.a(b.h);
	}

	protected void k() {
		int num = mod_CraftingBook.recCraft.getRecipeNum();
		g.b(num+" crafting recipe"+(num == 1 ? "" : "s"), 6, 6, 4210752);
	}

	protected void a(float paramFloat) {
		i();
		int x = c-a >> 1;
		int y = d-i >> 1;

		int image = b.p.b("/Shockah/CraftingBook/guiRecipeCraft.png");
		GL11.glColor4f(1F,1F,1F,1F);
		b.p.b(image);
		b(x,y,0,0,a,i);
	}
	
	@SuppressWarnings("unchecked")
	public void b() {
		int x = c-a >> 1;
		int y = d-i >> 1;
		
		e.clear();
		e.add(new ab(1, x+6, y+60, 20, 20, "<"));
		e.add(new ab(2, x+26, y+60, 20, 20, ">"));
		
		super.b();
	}
	
	protected void a(ke button) {
		if (button.f == 1) mod_CraftingBook.recCraft.recipePrev();
		else if (button.f == 2) mod_CraftingBook.recCraft.recipeNext();

		super.a(button);
	}
}