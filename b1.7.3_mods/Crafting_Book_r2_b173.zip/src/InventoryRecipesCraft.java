import java.util.ArrayList;
import java.util.List;

public class InventoryRecipesCraft implements lw {
	private static List<dt> recipes = null;
	private ArrayList<dt> currentRecipes = new ArrayList<dt>();
	private iz[] items = new iz[11];
	private int index = 0;
	
	public String c() {
		return "Craftables";
	}
	public int a() {
		return items.length;
	}
	public int d() {
		return 64;
	}
	
	public void a(int slot, iz stack) {
		items[slot] = stack;
		if (stack != null) if (stack.a > d()) stack.a = d();
		y_();
	}
	public iz f_(int slot) {
		return items[slot];
	}

	public iz a(int slot, int amount) {
		if (items[slot] != null) {
			if (items[slot].a <= amount) {
				iz item = items[slot];
				items[slot] = null;
				y_();
				
				return item;
			}
			
			iz item = items[slot].a(amount);
			if (items[slot].a == 0) items[slot] = null;
			y_();
			
			return item;
		}
		return null;
	}
	public boolean a_(gs player) {
		return true;
	}
	
	public void y_() {}
	
	public void clearItems() {
		for (int i = 0; i < a(); i++) items[i] = null;
		currentRecipes.clear();
	}
	
	public void updateItems() {
		currentRecipes = getMatchingRecipes(items[10]);
		setRecipe(0);
	}
	
	public void recipeNext() {
		if (getRecipeNum() == 0) {
			index = 0;
			return;
		}
		index++;
		if (index > currentRecipes.size()-1) index = 0;
		setRecipe(index);
	}
	public void recipePrev() {
		if (getRecipeNum() == 0) {
			index = 0;
			return;
		}
		index--;
		if (index < 0) index = currentRecipes.size()-1;
		setRecipe(index);
	}
	
	@SuppressWarnings("rawtypes")
	public void setRecipe(int index) {
		this.index = index;
		
		for (int i = 0; i < 10; i++) items[i] = null;
		if (currentRecipes.isEmpty()) return;
		
		dt tmp = currentRecipes.get(index);
		items[0] = new iz(tmp.b().c,tmp.b().a,tmp.b().i());
		if (tmp instanceof is) {
			is recipe = (is)tmp;
			try {
				int x = 0, y = 0;
				
				int w = ModLoader.getPrivateValue(is.class,recipe,"b");
				
				iz[] req = ModLoader.getPrivateValue(is.class,recipe,"d");
				for (int i = 0; i < recipe.a(); i++) {
					iz stack = req[i];
					if (stack != null) items[1+(y*3+x)] = new iz(stack.c,1,stack.i());
					
					x++;
					if (x >= w) {
						x = 0;
						y++;
					}
				}
			} catch (Exception e) {e.printStackTrace();}
		} else if (tmp instanceof tt) {
			tt recipe = (tt)tmp;
			try {
				List req = ModLoader.getPrivateValue(tt.class,recipe,"b");
				for (int i = 0; i < req.size(); i++) {
					iz stack = (iz)req.get(i);
					items[i+1] = new iz(stack.c,1,stack.i());
				}
			} catch (Exception e) {e.printStackTrace();}
		}
	}
	
	@SuppressWarnings("unchecked")
	public void getRecipes() {
		if (recipes == null) {
			try {
				recipes = (List<dt>)ModLoader.getPrivateValue(hk.class,hk.a(),"b");
			} catch (Exception e) {e.printStackTrace();}
		}
	}
	
	public int getRecipeNum() {
		if (currentRecipes == null) return 0;
		return currentRecipes.size();
	}
	
	@SuppressWarnings("rawtypes")
	public ArrayList<dt> getMatchingRecipes(iz stack) {
		ArrayList<dt> matching = new ArrayList<dt>();
		if (stack == null) return matching;
		for (dt tmp : recipes) {
			if (stack.c == tmp.b().c && (tmp.b().i() == stack.i() || tmp.b().i() < 0)) {
				matching.add(tmp);
				continue;
			}
			
			if (tmp instanceof is) {
				is recipe = (is)tmp;
				try {
					iz[] req = ModLoader.getPrivateValue(is.class,recipe,"d");
					for (iz check : req) {
						if (check == null) continue;
						if (stack.c == check.c && (check.i() == stack.i() || check.i() < 0)) { 
							matching.add(tmp);
							break;
						}
					}
				} catch (Exception e) {e.printStackTrace();}
			} else if (tmp instanceof tt) {
				tt recipe = (tt)tmp;
				try {
					List req = ModLoader.getPrivateValue(tt.class,recipe,"b");
					for (Object chk : req) {
						iz check = (iz)chk;
						if (stack.c == check.c && (check.i() == stack.i() || check.i() < 0)) {
							matching.add(tmp);
							break;
						}
					}
				} catch (Exception e) {e.printStackTrace();}
			}
		}
		return matching;
	}
}