public class SlotRecipeBookInput extends gp {
	InventoryRecipesCraft inv;
	
	public SlotRecipeBookInput(InventoryRecipesCraft inventory, int slot, int x, int y) {
		super(inventory,slot,x,y);
		inv = inventory;
	}
	
	public void c() {
		super.c();
		inv.updateItems();
	}
}