public class GuiSrvRecipesCraft extends dw {
	public GuiSrvRecipesCraft(lw playerInventory) {
		int i = 3;
		int j = (i - 4) * 18;
		
		for (int y = 0; y < 3; y++)
		for (int x = 0; x < 3; x++)
		a(new SlotRecipeBookShow(mod_CraftingBook.recCraft, x + y * 3 + 1, 54 + x * 18, 17 + y * 18));
		a(new SlotRecipeBookShow(mod_CraftingBook.recCraft, 0, 148, 35));
		a(new SlotRecipeBookInput(mod_CraftingBook.recCraft, 10, 12, 35));

		for (int k = 0; k < 3; k++)
		for (int m = 0; m < 9; m++)
		a(new gp(playerInventory, m + k * 9 + 9, 8 + m * 18, 102 + k * 18 + j));
		
		for (int k = 0; k < 9; k++) a(new gp(playerInventory, k, 8 + k * 18, 160 + j));
	}
	
	public void a(gs player) {
		if (mod_CraftingBook.recCraft.f_(10) != null) {
			player.a(mod_CraftingBook.recCraft.f_(10));
		}
		mod_CraftingBook.recCraft.clearItems();
		
		super.a(player);
	}

	public boolean b(gs player) {
		return mod_CraftingBook.recCraft.a_(player);
	}
}