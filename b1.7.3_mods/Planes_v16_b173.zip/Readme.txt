Flan's Planes Mod for Minecraft 1.7.3

Version 16

------------
Installation
------------

1. Open the .zip archive (already done)
2. Open your .minecraft directory (appdata/.minecraft)
3. Drag the files from "resource files" into the folder called "resources"
4. Go to .minecraft/bin and open your minecraft.jar in winRAR, winZIP, 7zip or any other suitiable program
5. Drag the files from "jar files" into the minecraft.jar
6. Drag the planes folder into your .minecraft folder
7. Install Risugami's ModLoader (similar instructions to above, included in ModLoader download)
8. Install SDK's ModLoaderMp (similar instructions to above)
9. Install GaryCXJk's TurboModel Thingy 2.2.5(same again)
10. Install AudioMod (optional, but you wont get sound if you don't)
11. DELETE THE META-INF FOLDER
12. Play!
