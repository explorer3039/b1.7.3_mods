A couple of Mods I'd like to toss in for you guys. - iChun
It is YOUR responsibility to read ALL the info to prevent any issues.
Copy the zip to the mods folder.
Mods that uses sounds need audiomod. All of them need ModLoader.
I forgot to update the version string for the Companion Cube and Sentry Turret but they work for 1.7.3.

Advanced Knee Replacements
- Adds only the AKR from the Portal Gun mod. DO NOT have it together with the Portal Gun Mod.

Companion Cube
- Adds the Companion Cube and its records. DO NOT have it together with the Portal Gun Mod.
- You will have to copy the "mod" folder from "place in resources" into "resources" for the records to work.

Sentry Turret
- Adds the Sentry Turret. DO NOT have it together with the Portal Gun Mod.
- You will have to copy the "mod" folder from "place in resources" into "resources" for the sounds to work.