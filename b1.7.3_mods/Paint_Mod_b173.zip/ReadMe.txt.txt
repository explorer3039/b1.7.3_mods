Builder Blocks For Minecraft Beta 1.7.3

THIS MOD USES ITEM IDS 98-125
YOU HAVE BEEN WARNED

Installation:
1 open Minecraft.jar With WinRar Or 7Zip
2 Delete META-INF!
3 Install Risugami's ModLoader ... Link: http://www.minecraftforum.net/topic/75440-v173-risugamis-mods-recipe-book-updated/
4 Click And Drag All Of The Contents Of The Mod Into Your Minecraft.jar