public class mod_CraftingBook extends BaseMod {
	private static final int itemOff = 256;
	
	public static InventoryRecipesCraft recCraft = new InventoryRecipesCraft();
	
	@MLProp public static int idRecipeBook = 5500;
	
	public static final uu bWORKBENCH = uu.az;
	public static final gm iBOOK = gm.aJ;
	public static gm iRECBOOK;
	
	public mod_CraftingBook() {
		iRECBOOK = new ItemBookCraft(idRecipeBook-itemOff);
		ModLoader.AddShapelessRecipe(new iz(iRECBOOK),iBOOK,bWORKBENCH);
	}
	
	public String Version() {return "r1";}
}