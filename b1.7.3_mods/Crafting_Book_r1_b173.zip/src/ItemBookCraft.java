public class ItemBookCraft extends gm {
	protected ItemBookCraft(int itemID) {
		super(itemID); a(getClass().getName());
		a(11,3);
		bg = 1;
		
		ModLoader.AddName(this,"Crafting Book");
	}
	
	public int f(int damage) {
		return 0xffffff77;
	}
	
	public iz a(iz stack, fd world, gs player) {
		ModLoader.OpenGUI(player,new GuiRecipesCraft(player.c));
		return stack;
	}
}