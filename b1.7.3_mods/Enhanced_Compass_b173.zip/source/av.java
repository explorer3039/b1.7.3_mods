/*
 * @author Yoda12999
 */

import com.pclewis.mcpatcher.mod.TextureUtils;
import com.pclewis.mcpatcher.mod.TileSize;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import net.minecraft.client.Minecraft;

public class av extends aw {

    private Minecraft g;
    private int[] h;
    private double[] r = new double[66];
    private double[] s = new double[66];
    File configFile;
    private int[] spawnNeedleColor = { 230, 20, 20 };
    private int[] northNeedleColor = { 230, 230, 230 };
    private int[] waypointNeedleColor = { 0, 255, 255 };
    private int[][] waypoints = new int[64][];
    private int compassType = 3; // 1 = default (spawn), 2 = north, 4 = waypoint
    private int[] drawOrder = {3,2,1};
    public int numberWaypoints = 0;

    public av(Minecraft var1) {
        super(gm.aO.a(0));
        configFile = new File(Minecraft.b(), "compass_config.txt");
        this.h = new int[TileSize.int_numPixels];
        this.g = var1;
        this.f = 1;
        for(int i = 0; i < 64; i++) {
            waypoints[i] = null;
        }

        try {
            BufferedImage var2 = TextureUtils.getResourceAsBufferedImage("/gui/items.png");
            int var3 = this.b % 16 * TileSize.int_size;
            int var4 = this.b / 16 * TileSize.int_size;
            var2.getRGB(var3, var4, TileSize.int_size, TileSize.int_size, this.h, 0, TileSize.int_size);
        } catch (IOException var5) {
            var5.printStackTrace();
        }

        loadConfig();
    }

    @Override
    public void a() {
        for(int var1 = 0; var1 < TileSize.int_numPixels; ++var1) {
            int var2 = this.h[var1] >> 24 & 255;
            int var3 = this.h[var1] >> 16 & 255;
            int var4 = this.h[var1] >> 8 & 255;
            int var5 = this.h[var1] >> 0 & 255;
            if(this.c) {
                int var6 = (var3 * 30 + var4 * 59 + var5 * 11) / 100;
                int var7 = (var3 * 30 + var4 * 70) / 100;
                int var8 = (var3 * 30 + var5 * 70) / 100;
                var3 = var6;
                var4 = var7;
                var5 = var8;
            }

            this.a[var1 * 4 + 0] = (byte)var3;
            this.a[var1 * 4 + 1] = (byte)var4;
            this.a[var1 * 4 + 2] = (byte)var5;
            this.a[var1 * 4 + 3] = (byte)var2;
        }

        for(int i = 1; i <= 3; i++) {
            if(drawOrder[0] == i) {
                drawSpawn(i);
            } else if(drawOrder[1] == i) {
                drawNorth(i);
            } else if(drawOrder[2] == i) {
                drawWaypoints(i);
            }
        }

    }

    private void drawSpawn(int cType) {
        if (this.g.f != null && this.g.h != null && ((compassType == 1) || (compassType == 3) || (compassType == 5) || (compassType == 7))) {
            br var20 = this.g.f.u();
            drawNeedle(1, (double)var20.a - this.g.h.aM, (double)var20.c - this.g.h.aO, spawnNeedleColor, ((cType == 1) || (compassType == 2)));
        }
    }

    private void drawNorth(int cType) {
        if((compassType == 2) || (compassType == 3) || (compassType == 6) || (compassType == 7))
            drawNeedle(2, (double)-1, (double)0, northNeedleColor, ((cType == 1) || (compassType == 1)));
    }

    private void drawWaypoints(int cType) {
        if (this.g.f != null && this.g.h != null && ((compassType == 4) || (compassType == 5) || (compassType == 6) || (compassType == 7))) {
            for(int i = 0; i < 64; i++) {
                int j = 0;
                if(waypoints[i] != null) {
                    drawNeedle(3 + i, (double)waypoints[i][0] - this.g.h.aM, (double)waypoints[i][2] - this.g.h.aO, waypointNeedleColor, ((cType == 1) || (compassType == 4)));
                    j++;
                }
                if(j == numberWaypoints) return;
            }
        }
    }

    private void drawNeedle(int cType, double x, double z, int[] color, boolean drawCenter) {
        double var22 = 0.0D;
        if(this.g.f != null && this.g.h != null) {
            var22 = (double)(this.g.h.aS - 90.0F) * 3.141592653589793D / 180.0D - Math.atan2(z, x);
            if(this.g.f.t.c) {
                var22 = Math.random() * 3.1415927410125732D * 2.0D;
            }
        }

        double var25;
        for(var25 = var22 - r[cType]; var25 < -3.141592653589793D; var25 += 6.283185307179586D) {}

        while(var25 >= 3.141592653589793D) {
            var25 -= 6.283185307179586D;
        }

        if(var25 < -1.0D) {
            var25 = -1.0D;
        }

        if(var25 > 1.0D) {
            var25 = 1.0D;
        }

        s[cType] += var25 * 0.1D;
        s[cType] *= 0.8D;
        r[cType] += s[cType];
        double var23 = Math.sin(r[cType]);
        double var26 = Math.cos(r[cType]);

        int var9;
        int var10;
        int var11;
        int var12;
        int var13;
        int var14;
        int var15;
        int var17;
        short var16;
        int var19;
        int var18;
        if (drawCenter) {
            for(var9 = TileSize.int_compassCrossMin; var9 <= TileSize.int_compassCrossMax; ++var9) {
                var10 = (int)(TileSize.double_compassCenterMax + var26 * (double)var9 * 0.3D);
                var11 = (int)(TileSize.double_compassCenterMin - var23 * (double)var9 * 0.3D * 0.5D);
                var12 = var11 * TileSize.int_size + var10;
                var13 = 100;
                var14 = 100;
                var15 = 100;
                var16 = 255;
                if(this.c) {
                    var17 = (var13 * 30 + var14 * 59 + var15 * 11) / 100;
                    var18 = (var13 * 30 + var14 * 70) / 100;
                    var19 = (var13 * 30 + var15 * 70) / 100;
                    var13 = var17;
                    var14 = var18;
                    var15 = var19;
                }

                this.a[var12 * 4 + 0] = (byte)var13;
                this.a[var12 * 4 + 1] = (byte)var14;
                this.a[var12 * 4 + 2] = (byte)var15;
                this.a[var12 * 4 + 3] = (byte)var16;
            }
        }

        for(var9 = TileSize.int_compassNeedleMin; var9 <= TileSize.int_compassNeedleMax; ++var9) {
            var10 = (int)(TileSize.double_compassCenterMax + var23 * (double)var9 * 0.3D);
            var11 = (int)(TileSize.double_compassCenterMin + var26 * (double)var9 * 0.3D * 0.5D);
            var12 = var11 * TileSize.int_size + var10;
            var13 = var9 >= 0?color[0]:100;
            var14 = var9 >= 0?color[1]:100;
            var15 = var9 >= 0?color[2]:100;
            var16 = 255;
            if(this.c) {
                var17 = (var13 * 30 + var14 * 59 + var15 * 11) / 100;
                var18 = (var13 * 30 + var14 * 70) / 100;
                var19 = (var13 * 30 + var15 * 70) / 100;
                var13 = var17;
                var14 = var18;
                var15 = var19;
            }

            this.a[var12 * 4 + 0] = (byte)var13;
            this.a[var12 * 4 + 1] = (byte)var14;
            this.a[var12 * 4 + 2] = (byte)var15;
            this.a[var12 * 4 + 3] = (byte)var16;
        }

    }

    private void writeDefaultConfig(File configFile) {
        try {
            PrintWriter pw = new PrintWriter(new FileWriter(configFile));
            pw.println("# Enhanced Compass Config");
            pw.println("# compassType: 1 = Spawn, 2 = North, 4 = Waypoint");
            pw.println("# Add types for combinations, e.g. spawn + north = 3");
            pw.println("compassType = 7");
            pw.println("# drawOrder: Write what order you want the needles to be drawn in");
            pw.println("the order of the numbers is Spawn needle, North needle, Waypoint needles");
            pw.println("Note: 3 is first, 2 is second, and 1 is last");
            pw.println("drawOrder = 3,2,1");
            pw.println("# Colors are in Red,Green,Blue format");
            pw.println("spawnNeedleColor = 230,20,20");
            pw.println("northNeedleColor = 230,230,230");
            pw.println("waypointNeedleColor = 0,255,255");
            pw.println("# Waypoints are set in x,y,z format and must be called waypoint + a number");
            pw.println("# Up to 32 waypoints are allowed");
            pw.println("# At this moment y doesn't really matter");
            pw.println("# Ex: waypoint1 = 175,20,30");
            pw.close();
        } catch (IOException ioexception) {
            ioexception.printStackTrace();
        }
    }

    private void loadConfig() {
        if(!configFile.exists()) {
            writeDefaultConfig(configFile);
        } else {
            try {
                BufferedReader configReader = new BufferedReader(new FileReader(configFile));
                String curLine;
                while( (curLine = configReader.readLine()) != null ) {
                    if (curLine.startsWith("#")) continue;
                    String[] kV = curLine.split("=");
                    int[] curColor = null;
                    if (kV[0].trim().equals("compassType")) {
                    compassType = Integer.parseInt(kV[1].trim());
                    if ( (compassType > 7) || (compassType < 1) )
                        compassType = 1;
                    }
                    else if (kV[0].trim().equals("drawOrder")) {
                    curColor = parseColor(kV[1].trim());
                    if(curColor[0] != curColor[1] && curColor[1] != curColor[2] && curColor[0] != curColor[2])
                        drawOrder = curColor;
                    }
                    else if (kV[0].trim().equals("spawnNeedleColor")) {
                    curColor = parseColor(kV[1]);
                    if (curColor != null)
                        spawnNeedleColor = curColor;
                    }
                    else if (kV[0].trim().equals("northNeedleColor")) {
                    curColor = parseColor(kV[1]);
                    if (curColor != null)
                        northNeedleColor = curColor;
                    }
                    else if (kV[0].trim().equals("waypointNeedleColor")) {
                    curColor = parseColor(kV[1]);
                    if (curColor != null)
                        waypointNeedleColor = curColor;
                    }
                    else {
                        for(int i = 0; i < 64; i++)
                            if (kV[0].trim().equals("waypoint" + i)) {
                                curColor = parseColor(kV[1]);
                                if (curColor != null) {
                                    waypoints[i + 32] = curColor;
                                    numberWaypoints++;
                                }
                        }
                    }
                }
                configReader.close();
            } catch (Exception exc) {exc.printStackTrace();}
        }
    }

    private int[] parseColor(String data) {
        int[] retColor = { 0, 0, 0 };
        String[] values = data.trim().split(",");
        try {
            retColor[0] = Integer.parseInt(values[0].trim());
            retColor[1] = Integer.parseInt(values[1].trim());
            retColor[2] = Integer.parseInt(values[2].trim());
        } catch (Exception exc) {
            exc.printStackTrace();
            retColor = null;
        }
        return retColor;
    }

    public void setWaypoint(int x, int y, int z) {
        int[] waypoint = new int[3];
        
        waypoint[0] = x;
        waypoint[1] = y;
        waypoint[2] = z;
        

        for(int i = 0; i < 64; i++) {
            if(waypoints[i] == null) {
               waypoints[i] = waypoint;
               numberWaypoints++;
               return;
            }
        }
    }

    public void removeWaypoint(int x, int y, int z) {
        for(int i = 0; i < 64; i++) {
            if(waypoints[i] != null) {
                if((waypoints[i][0] == x) && (waypoints[i][1] == y) && (waypoints[i][2] == z)) {
                    waypoints[i] = null;
                    numberWaypoints--;
                    return;
                }
            }
        }
    }

    public boolean findWaypoint(int x, int y, int z) {
        for(int i = 0; i < 64; i++) {
            if(waypoints[i] != null) {
                if((waypoints[i][0] == x) && (waypoints[i][1] == y) && (waypoints[i][2] == z)) {
                    return true;
                }
            }
        }
		return false;
    }
}
