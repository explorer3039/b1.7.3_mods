Some recipes:

With shape:

Wolf Clothing Maker:
XXX
WIW
WWW 

X = Wool
I = Iron Ingot
W = Planks


Shapeless:

Breeding bone:
Two raw porkchops + one bone


Supplies for clothing maker:
Headgear:
2 wool + one dye
(any color)

Bodygear:
3 wool + one dye

Collar:
1 wool + one iron ingot

Backpack:
2 leather + 2 wool

To open wolf GUI, ctrl+click tamed wolf.
TO show parent names and age, shift+click tamed wolf. Only works with born wolves.
Be careful when using the clothing maker, soft clicks.

Give breeding bones to two wolves on the same room to breed.

-- Nandonalt~~