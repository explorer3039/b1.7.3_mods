// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode

package net.minecraft.src;


// Referenced classes of package net.minecraft.src:
//            Item, Block, World, ItemStack,
//            Material, StepSound, EntityPlayer

public class mod_ColoredLights_ItemBlockLite extends ItemBlock
{
    public mod_ColoredLights_ItemBlockLite(int i)
    {
        super(i);
        blockID=i + 256;
        setMaxDamage(0);
        setHasSubtypes(true);
    }

    public int getIconFromDamage(int i)
    {
        return Block.blocksList[blockID].getBlockTextureFromSideAndMetadata(2, i & 0xf);
    }

    public int getPlacedBlockMetadata(int i)
    {
        return i;
    }

    protected int damageDropped(int i)
    {
        return i;
    }

    private int blockID;
}
