package net.minecraft.src;
import java.io.*;
import java.util.*;

public class mod_ColoredLights extends BaseMod

{

public static final mod_ColoredLights_BlockLite coloredLights, coloredLightsLit;


public static final int idColoredLights = 111;
public static final int idColoredLightsLit = 112;

public String Version()
        {
                return "1.7.3";
        }

        static
        {

			System.err.println("Going through this once");


			coloredLights = (mod_ColoredLights_BlockLite)(new mod_ColoredLights_BlockLite(idColoredLights, 49, Material.glass)).setHardness(0.3F).setStepSound(Block.soundGlassFootstep).setBlockName("coloredLights").disableNeighborNotifyOnMetadataChange();
			coloredLightsLit = (mod_ColoredLights_BlockLite)(new mod_ColoredLights_BlockLite(idColoredLightsLit, 49, Material.glass)).setLightValue(1.0F).setHardness(0.3F).setStepSound(Block.soundGlassFootstep).setBlockName("coloredLightsLit").disableNeighborNotifyOnMetadataChange();

		}


		public int getOverride(String file)
		{
			try
			{
				int n=Integer.parseInt( file );
				return n;
			}
			catch (NumberFormatException e )
			{
				return ModLoader.addOverride("/terrain.png", "/colored/"+file);
			}
		}

		public void setCustomIndexSide(BlockCustom bc, int index, String side, int n)
		{
			bc.setCustomIndexSide(index, n, side);
		}

        public mod_ColoredLights()
        {


			ModLoader.RegisterBlock(coloredLights, mod_ColoredLights_ItemBlockLite.class);
			ModLoader.RegisterBlock(coloredLightsLit, mod_ColoredLights_ItemBlockLite.class);


			try
			{
				InputStream in = mod_ColoredLights_BlockLite.class.getResourceAsStream("/colored/config.txt");
				if (in==null) 			System.err.println("Error: java sucks");
				BufferedReader br = new BufferedReader(new InputStreamReader(in));
				String strLine;
				strLine = br.readLine();
				while ((strLine = br.readLine()) != null)
				{
					String[] arrConfig = strLine.split("\t");
					BlockCustom bc;

					int index = Integer.parseInt(arrConfig[1]);
					String side = arrConfig[2];
					int n = getOverride(arrConfig[3]);

					if (arrConfig[0].equals("colored"))
					{
						coloredLights.setCustomIndexSide(index, n, side);
						coloredLightsLit.setCustomIndexSide(index, n, side);
					}

					System.err.println("hok");

				}
				in.close();
			}
			catch (Exception e)
			{
			System.err.println("Error: " + e.getMessage());
			}

			// custom slabs
        	ModLoader.AddShapelessRecipe(new ItemStack(coloredLights, 1, 0), new Object[] {new ItemStack(Block.torchRedstoneActive, 1), new ItemStack(Block.glass, 1), new ItemStack(Item.dyePowder, 1, 15)}); // white
        	ModLoader.AddShapelessRecipe(new ItemStack(coloredLights, 1, 1), new Object[] {new ItemStack(Block.torchRedstoneActive, 1), new ItemStack(Block.glass, 1)}); // red
        	ModLoader.AddShapelessRecipe(new ItemStack(coloredLights, 1, 2), new Object[] {new ItemStack(Block.torchRedstoneActive, 1), new ItemStack(Block.glass, 1), new ItemStack(Item.dyePowder, 1, 2)}); // green
        	ModLoader.AddShapelessRecipe(new ItemStack(coloredLights, 1, 3), new Object[] {new ItemStack(Block.torchRedstoneActive, 1), new ItemStack(Block.glass, 1), new ItemStack(Item.dyePowder, 1, 11)}); // yellow
        	ModLoader.AddShapelessRecipe(new ItemStack(coloredLights, 1, 4), new Object[] {new ItemStack(Block.torchRedstoneActive, 1), new ItemStack(Block.glass, 1), new ItemStack(Item.dyePowder, 1, 4)}); // blue
        	ModLoader.AddShapelessRecipe(new ItemStack(coloredLights, 1, 5), new Object[] {new ItemStack(Block.torchRedstoneActive, 1), new ItemStack(Block.glass, 1), new ItemStack(Item.dyePowder, 1, 5)}); // purple
        	ModLoader.AddShapelessRecipe(new ItemStack(coloredLights, 1, 6), new Object[] {new ItemStack(Block.torchRedstoneActive, 1), new ItemStack(Block.glass, 1), new ItemStack(Item.dyePowder, 1, 14)}); // orange
        	ModLoader.AddShapelessRecipe(new ItemStack(coloredLights, 1, 7), new Object[] {new ItemStack(Block.torchRedstoneActive, 1), new ItemStack(Block.glass, 1), new ItemStack(Item.dyePowder, 1, 6)}); // cyan

        }
}
