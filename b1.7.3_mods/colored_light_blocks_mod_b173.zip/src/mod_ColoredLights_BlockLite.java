// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode

package net.minecraft.src;

import java.util.*;

// Referenced classes of package net.minecraft.src:
//            BlockTorch, Block, RedstoneUpdateInfo, World,
//            IBlockAccess

public class mod_ColoredLights_BlockLite extends Block
{

	int customIndex[][];

    public mod_ColoredLights_BlockLite(int i, int j, Material material)
    {
//        super(i, j, material);
        super(i, j, material);


        setTickOnLoad(true);

        customIndex=new int[16][];
        for (int i1=0; i1<16; i1++)
        {
			customIndex[i1]=new int[6];
    	    for (int i2=0; i2<6; i2++)
				customIndex[i1][i2]=blockIndexInTexture;
		}
    }

    public void setCustomIndexSide(int index, int block, String side)
    {
		System.err.println("setting index "+String.valueOf(index)+", side "+side+" to "+String.valueOf(block));
		if (side.equals("top")   || side.equals("all")) customIndex[index][0]=block;
		if (side.equals("top")   || side.equals("all")) customIndex[index][1]=block;
		if (side.equals("sides") || side.equals("all")) customIndex[index][2]=block;
		if (side.equals("sides") || side.equals("all")) customIndex[index][3]=block;
		if (side.equals("sides") || side.equals("all")) customIndex[index][4]=block;
		if (side.equals("sides") || side.equals("all")) customIndex[index][5]=block;
	}

	// 0 bottom 1 top 2 east 3 west 4 north 5 south
    public int getBlockTextureFromSideAndMetadata(int i, int j)
    {
		return customIndex[j][i];
    }

    public int idDropped(int i, Random random)
    {
        return mod_ColoredLights.idColoredLights;
    }

    protected int damageDropped(int i)
    {
        return i&7;
    }


    public int quantityDropped(Random random)
    {
       	return 1;
    }

    public int tickRate()
    {
        return 2;
    }

    public void updateTick(World world, int i, int j, int k, Random random)
    {
		if(world.isBlockGettingPowered(i, j, k))
		{
			if (blockID == mod_ColoredLights.idColoredLightsLit) return;
			//System.err.println("BZZT");

			world.setBlockAndMetadataWithNotify(i, j, k, mod_ColoredLights.idColoredLightsLit, (world.getBlockMetadata(i, j, k) & 7) + 8);
		}
		else
		{
			if (blockID == mod_ColoredLights.idColoredLights) return;
			//System.err.println("bzzt");
			world.setBlockAndMetadataWithNotify(i, j, k, mod_ColoredLights.idColoredLights, world.getBlockMetadata(i, j, k) & 7);
		}
    }

    public void onNeighborBlockChange(World world, int i, int j, int k, int l)
    {
        updateTick(world, i, j, k, null);
    }

    private static List torchUpdates = new ArrayList();

}
