{\rtf1\ansi\ansicpg1252\cocoartf1038\cocoasubrtf350
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
\paperw11900\paperh16840\margl1440\margr1440\vieww9000\viewh8400\viewkind0
\pard\tx566\tx1133\tx1700\tx2267\tx2834\tx3401\tx3968\tx4535\tx5102\tx5669\tx6236\tx6803\ql\qnatural\pardirnatural

\f0\fs24 \cf0 					
\b Thank you for downloading\

\fs30 ++++++++++++++++++++++++++++++++++++++++++++++++++\
\
What it does?\
\pard\tx560\tx1120\tx1680\tx2240\tx2800\tx3360\tx3920\tx4480\tx5040\tx5600\tx6160\tx6720\ql\qnatural\pardirnatural

\b0 \cf0 This mod adds burgers and some more stuff to the game\
\

\b What it adds?\

\b0 This mod adds two burgers, a hamburger and a Cheeseburger (more to come soon) it also add Cheese, Buns, Burger Block (for Epicness) and a CheesePatty\
\

\b How to Install?\

\b0 Install is even more simple than any other mod\
all you do is install modlaoder then drag every file (even the image files) into minecraft.jar, it may conflict with other mods,\
if it does tell me.\
\

\b Enjoy The Burger Mod :D\

\b0 And remember this is just the first version more updates will come soon.}