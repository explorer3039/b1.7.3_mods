Malachite Ore v1.1_01:


Made by BRH-Productions:


-Benjothebanjo: Head and Coder!
-Haribo_efc: Coder and videos!
_The_Riddler_: Art!



Malachite Ore just adds one new ore to the game which can be mined with a Stone Pickaxe or better! The Ore Generates on layer 64 and
below. When you mine Malachite Ore, you will obtain the Ore Block. When you put the Ore Block in the crafting bench you will 
get a Malachite Nugget which you can use for making Malachite Blocks or Lime Green Dye! If you put the Malachite Ore Block in the furnace, 
it will smelt into a Copper Ingot which you can then make Copper blocks, Copper Tools, Copper Armour, Copper Buckets and Copper Money!


How to install (Windows):

- Download and install the Modloader! (instructions on the ModLoader thread)
- Open up "Malachite Ore" Mod with Winrar or 7-Zip!
- go to start and type "Run" in the search bar, then open it!
- Type in "%appdata%" in the search bar in run, then click ok!
- Open the .minecraft, then open the bin folder!
- Right click on the "minecraft.jar" folder and open it with winrar or 7-Zip!
- Drag all of the files from inside the "Malachite Ore.rar" into the "minecraft.jar"
- Start up Minecraft and enjoy Malachite Ore! :D


If any of your PC, Minecraft or any of your save files break it's not my problem, even though I've tested it on mine, and
I've had no problems!



BRH-Productions



Links: 


Official Website: http://www.brh-productions.webs.com

Official Forums thread: http://www.minecraftforum.net/viewtopic.php?f=1039&t=276074

Fix mod: http://www.minecraftforum.net/viewtopic.php?f=1032&t=284427

