INSTALL MODLOADER

INSTALL GUI API



Take EVERYTHING in the folder called "More Ores v0.6.6" and put EVERYTHING in the minecraft.jar

(DO NOT just move the folder into minecraft.jar, take the class files and two folders and put THOSE in minecraft.jar)

(DO NOT mess with those two folders� just put them AS IS into minecraft.jar)


make sure META-INF is deleted!!!


play!



(after the first time you run Minecraft after installing, you will be able to change the block ids 
using the properties files in the MoreOres folder in the mods folder in your minecraft folder)

NEW you can now change the spawning properties IN-GAME in the global mod options in the options menus




ENJOY!
if you have any problems installing, or bug reports, check if Im on my channel #MoreOres at esper.net; 
if im not there, send me a pm or post on the thread at minecraftforums


please note: the cheat sheet is out of date as i have removed several of the ores