Drag the class files from the Add To Jar into the Minecraft.jar file.
-Toonlego90 AKA CrystalShadow8790
This mod is for 1.7.3 to bring the new 1.8 mob to 1.7.

Version 2 Released:

Added Properties file for changing the blocks the destroy.

Version 2.1_01 Released:

Fixed bugs.

Version 2.1_02 Released:

Fixed 2.1_01 bugs.

Version 2.1_02.3 Released:

Fixed Bugs

SECRETS

Version 2.1_02.4 Released:

Fixed a bug.

Smoother animation.

Final update:

Teleportation

Staring..

Pumpkin..

DISCONTINUED MOD