My First mod!! -xNiggle
v 1.0
How to install:
windows:
1. Hit the start button on your toolbar
2. Type "%appdata%" (without the quotes) and hit enter
3. Go into .minecraft folder
4. Go into the bin and then click minecrft.jar (requires WinRar Archiver to open)
5. Drag the uu.class file into minecraft.jar
6. delete META-INF or else your minecraft could black screen.
7. Play minecraft. have fun:)
(You need a wooden pickaxe or higher to mine bedrock. it has a hardness
of 0.5f and has stone's properties)