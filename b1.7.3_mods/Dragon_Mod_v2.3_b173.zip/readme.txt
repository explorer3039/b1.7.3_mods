~<<Dragons>>~
By TheHippoMaster



~Mods Used~
You MUST download the following if it says so!
 -Modloader: Required
 -AudioMod: Not required; No sound otherwise
 -Turbo Model Thingy: Required


~How To Install~
 -First, install the requirements above. If you have problems, report them in their respective threads
 -For Macs, search other tutorials on the Mapping and Modding forum

TO INSTALL, DRAG THE ZIP INTO THE MODS FOLDER OF .MINECRAFT
Extract the resources folder in the zip and merge it with the resources folder in .minecraft

If you have problems or you would prefer loading the mod through minecraft.jar, follow this tutorial:
 a) Locate minecraft.jar in /.minecraft/bin (search %APPDATA% in the search of the start menu to find the .minecraft folder)
 b) Open minecraft.jar with winRAR or 7zip, or something similar
 c) Extract the contents of Dragon Mod.zip
 d) Drag the class files into minecraft.jar along with the other class files
 e) Open mob in Dragon Mod and put contents into minecraft.jar/mob
 f) Open gui in Dragon Mod and put the contents into minecraft.jar/gui
 g) Open resources in both .minecraft and Dragon Mod
 h) Merge the folder 'resources' from Dragon Mod with your resources in .minecraft
 i) Test it out :)


~Update~
Version: 2.3
-Added eggs and nests
-Added white mystic dragon
-Attempted to fix blue dragon e2 lag
-Attempted to fix scale sword issue
-Changed despawning code
-Made dragons not attack wolves
-Made minor fixes
-Limited dragon's flying
-Added dragon information; right-click them with a compass or clock
-Added code to make tamed dragons stop moving; feed them any cooked meat; to make them move again, ride them
-Made attack power more random
-Somewhat changed blue e2's movement
-Added properties file
-Changed class names (hopefully) for compatibility with Agressive Elemental Dragons
-Added a new sand ability to green dragon; in testing, and may be removed


~Info~
This mod adds different dragons into your minecraft world. Most dragons are neutral, but will attack anything that attacks it, along with animals. Dragons can be tamed be mounting them many times.
To mount a dragon, you must right-click it while holding nothing. Dragons will push you off of them, and if you anger them, they will start attacking you. Once tamed, they will not despawn.
You can ride on them, and hit them with a sword of their type of scale to make them agressive. To turn them peaceful again, right-click them with the sword. Note that dragons may not be hungy all the time, and
may refuse to attack. Tamed dragons will not naturally attack animals.


~Evolution~
Dragons can evolve! After you tame a dragon, it gets a certain amount of 'exp' for each creature it attacks. It gets more exp from hostile mobs than animals. Once a dragon reaches a certain
amount of exp, it'll flash, and evolve into the next evolution! Higher evolutions are stronger, and may have other effects.

Current Evolutions:
 -Blue Dragon to Blue Dragon Evolution2
 -More will be added in the future


~Right-clicking~
When you are holding...
 -Nothing: Mounts the dragon
 -Raw fish or raw pork: Feeds the dragon; and alternative taming method across from mounting; also makes the dragon grow a little bit and gain a bit exp
 -Cooked fish or cooked pork: If the dragon is tamed, it makes the dragon rest; also heals it a bit
 -Milk bucket: Prevents the dragon from evolving, FOREVER
 -Scale sword: Makes the dragon passive
 -Compass or clock: Shows some basic information on a tamed dragon in the chat screen
 
 
~Crafting~
 _ = nothing
 
 Scale Sword:
 _#_
 _#_
 _I_
 
 # = dragon scale
 I = stick
 
 More will be added in the future..


~Credits~
Thanks for..

Textures: SpaceInvaders, QLight, and PillowKitty
Testing: shipmaster4000
Support: You :)

Modders at #risucraft, especially 303: Thanks for constant help
Gary: Thanks for introducing me to your mod, and helping me out with it
OgreSean: You helped me when I first began modding, so thanks, it really helped

If you have any requests or feedback, or you find any bugs that you want me to know of, post it on the forum. If I don't reply after a while (in case I don't see it), then you can send me a PM on minecraftforum.
Please do not email me from now on, unless I ask you to.