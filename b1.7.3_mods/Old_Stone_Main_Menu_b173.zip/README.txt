Old Stone Main Menu for Beta 1.7.3
Made by Johnanater

To install:
1. Add the classes to your minecraft.jar
2. Delete META-INF
3. Enjoy!

Classes Changed:
GuiMainMenu (fu.class, ported old func_1238_a function)
LogoEffectRandomizer (added)

(I don't own any of the code, it was simply ported to Beta 1.7.3)