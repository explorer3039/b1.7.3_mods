package net.minecraft.src;

import net.minecraft.client.Minecraft;

public class mod_PumpkinRebreather extends BaseMod {

	@Override
	public String Version() {
		return "Beta v1.6.6";
	}

	protected mod_PumpkinRebreather() {
		ModLoader.SetInGameHook(this, true, true);
	}

	@Override
	public void OnTickInGame(Minecraft minecraft) {
		if( minecraft.theWorld.multiplayerWorld ) {
			return;
		}
		if(minecraft.thePlayer.isDead) return;

		//only refills air meter at last second (no waste)
		if(minecraft.thePlayer.air > -10) return;
		
		//only works if we're wearing pumpkin helmet
		ItemStack helmet = minecraft.thePlayer.inventory.armorItemInSlot(3);
		if(helmet == null) return;
		if(helmet.itemID != Block.pumpkin.blockID)return;
		
		int newAir = minecraft.thePlayer.maxAir * minecraft.thePlayer.health / 20;
		minecraft.thePlayer.air = newAir;
		minecraft.thePlayer.attackEntityFrom(null, 1);
	}
	
	private int counter;
}
