1.Go To Start Menu
2.type run And open it 
3.Type in %appdata%
4.open .minecraft folder
5.open the bin folder
6.open minecraft.jar With WinRaR
7.Delete META-INF
8.Drag the uu.class into the Minecraft.jar
9.Close And Enjoy :)