import java.io.PrintStream;
import java.util.*;

@SuppressWarnings({"unused","rawtypes","unchecked"})
public class fd implements xp {
	public boolean a;
	private List C;
	public List b;
	private List D;
	private TreeSet E;
	private Set F;
	public List c;
	private List G;
	public List d;
	public List e;
	private long H;
	public int f;
	protected int g;
	protected final int h = 0x3c6ef35f;
	protected float i;
	protected float j;
	protected float k;
	protected float l;
	protected int m;
	public int n;
	public boolean o;
	private long I;
	protected int p;
	public int q;
	public Random r;
	public boolean s;
	public final xa t;
	protected List u;
	protected cl v;
	protected final wt w;
	protected ei x;
	public boolean y;
	private boolean J;
	public hc z;
	private ArrayList K;
	private boolean L;
	private int M;
	private boolean N;
	private boolean O;
	static int A = 0;
	private Set P;
	private int Q;
	private List R;
	public boolean B;

	public xv a() {
		return t.b;
	}

	public fd(wt wt1, String s1, xa xa1, long l1) {
		a = false;
		C = ((List) (new ArrayList()));
		b = ((List) (new ArrayList()));
		D = ((List) (new ArrayList()));
		E = new TreeSet();
		F = ((Set) (new HashSet()));
		c = ((List) (new ArrayList()));
		G = ((List) (new ArrayList()));
		d = ((List) (new ArrayList()));
		e = ((List) (new ArrayList()));
		H = 0xffffffL;
		f = 0;
		g = (new Random()).nextInt();
		m = 0;
		n = 0;
		o = false;
		I = System.currentTimeMillis();
		p = 40;
		r = new Random();
		s = false;
		u = ((List) (new ArrayList()));
		K = new ArrayList();
		M = 0;
		N = true;
		O = true;
		P = ((Set) (new HashSet()));
		Q = r.nextInt(12000);
		R = ((List) (new ArrayList()));
		B = false;
		w = wt1;
		x = new ei(l1, s1);
		t = xa1;
		z = new hc(wt1);
		xa1.a(this);
		v = b();
		k();
		E();
	}

	public fd(fd fd1, xa xa1) {
		a = false;
		C = ((List) (new ArrayList()));
		b = ((List) (new ArrayList()));
		D = ((List) (new ArrayList()));
		E = new TreeSet();
		F = ((Set) (new HashSet()));
		c = ((List) (new ArrayList()));
		G = ((List) (new ArrayList()));
		d = ((List) (new ArrayList()));
		e = ((List) (new ArrayList()));
		H = 0xffffffL;
		f = 0;
		g = (new Random()).nextInt();
		m = 0;
		n = 0;
		o = false;
		I = System.currentTimeMillis();
		p = 40;
		r = new Random();
		s = false;
		u = ((List) (new ArrayList()));
		K = new ArrayList();
		M = 0;
		N = true;
		O = true;
		P = ((Set) (new HashSet()));
		Q = r.nextInt(12000);
		R = ((List) (new ArrayList()));
		B = false;
		I = fd1.I;
		w = fd1.w;
		x = new ei(fd1.x);
		z = new hc(w);
		t = xa1;
		xa1.a(this);
		v = b();
		k();
		E();
	}

	public fd(wt wt1, String s1, long l1) {
		this(wt1, s1, l1, ((xa) (null)));
	}

	public fd(wt wt1, String s1, long l1, xa xa1) {
		a = false;
		C = ((List) (new ArrayList()));
		b = ((List) (new ArrayList()));
		D = ((List) (new ArrayList()));
		E = new TreeSet();
		F = ((Set) (new HashSet()));
		c = ((List) (new ArrayList()));
		G = ((List) (new ArrayList()));
		d = ((List) (new ArrayList()));
		e = ((List) (new ArrayList()));
		H = 0xffffffL;
		f = 0;
		g = (new Random()).nextInt();
		m = 0;
		n = 0;
		o = false;
		I = System.currentTimeMillis();
		p = 40;
		r = new Random();
		s = false;
		u = ((List) (new ArrayList()));
		K = new ArrayList();
		M = 0;
		N = true;
		O = true;
		P = ((Set) (new HashSet()));
		Q = r.nextInt(12000);
		R = ((List) (new ArrayList()));
		B = false;
		w = wt1;
		z = new hc(wt1);
		x = wt1.c();
		s = x == null;

		if (xa1 != null) { this.t = xa1; } else {
			int i1 = 0;
			if (this.x != null) i1 = this.x.i();
			DimensionBase localDimensionBase = DimensionBase.getDimByNumber(i1);
			this.t = localDimensionBase.getWorldProvider();
		}

		boolean flag = false;

		if(x == null) {
			x = new ei(l1, s1);
			flag = true;
		} else {
			x.a(s1);
		}

		t.a(this);
		v = b();

		if(flag)
		c();

		k();
		E();
	}

	protected cl b() {
		bf bf = w.a(t);
		return ((cl) (new ok(this, bf, t.b())));
	}

	protected void c() {
		y = true;
		int i1 = 0;
		byte byte0 = 64;
		int j1;

		for(j1 = 0; !t.a(i1, j1); j1 += r.nextInt(64) - r.nextInt(64))
		i1 += r.nextInt(64) - r.nextInt(64);

		x.a(i1, ((int) (byte0)), j1);
		y = false;
	}

	public void d() {
		if(x.d() <= 0)
		x.b(64);

		int i1 = x.c();
		int j1;

		for(j1 = x.e(); a(i1, j1) == 0; j1 += r.nextInt(8) - r.nextInt(8))
		i1 += r.nextInt(8) - r.nextInt(8);

		x.a(i1);
		x.c(j1);
	}

	public int a(int i1, int j1) {
		int k1;

		for(k1 = 63; !d(i1, k1 + 1, j1); k1++);

		return a(i1, k1, j1);
	}

	public void e() {
	}

	public void a(gs gs1) {
		try {
			nu nu = x.h();

			if(nu != null) {
				gs1.e(nu);
				x.a(((nu) (null)));
			}

			if(v instanceof kx) {
				kx kx1 = (kx)v;
				int i1 = in.d((int)gs1.aM) >> 4;
				int j1 = in.d((int)gs1.aO) >> 4;
				kx1.d(i1, j1);
			}

			b(((sn) (gs1)));
		} catch(Exception exception) {
			exception.printStackTrace();
		}
	}

	public void a(boolean flag, yb yb1) {
		if(!v.b())
		return;

		if(yb1 != null)
		yb1.b("Saving level");

		D();

		if(yb1 != null)
		yb1.d("Saving chunks");

		v.a(flag, yb1);
	}

	private void D() {
		r();
		w.a(x, d);
		z.a();
	}

	public boolean a(int i1) {
		if(!v.b())
		return true;

		if(i1 == 0)
		D();

		return v.a(false, ((yb) (null)));
	}

	public int a(int i1, int j1, int k1) {
		if(i1 < 0xfe17b800 || k1 < 0xfe17b800 || i1 >= 0x1e84800 || k1 > 0x1e84800)
		return 0;

		if(j1 < 0)
		return 0;

		if(j1 >= 128)
		return 0;
		else
		return c(i1 >> 4, k1 >> 4).a(i1 & 0xf, j1, k1 & 0xf);
	}

	public boolean d(int i1, int j1, int k1) {
		return a(i1, j1, k1) == 0;
	}

	public boolean i(int i1, int j1, int k1) {
		if(j1 < 0 || j1 >= 128)
		return false;
		else
		return f(i1 >> 4, k1 >> 4);
	}

	public boolean b(int i1, int j1, int k1, int l1) {
		return a(i1 - l1, j1 - l1, k1 - l1, i1 + l1, j1 + l1, k1 + l1);
	}

	public boolean a(int i1, int j1, int k1, int l1, int i2, int j2) {
		if(i2 < 0 || j1 >= 128)
		return false;

		i1 >>= 4;
		j1 >>= 4;
		k1 >>= 4;
		l1 >>= 4;
		i2 >>= 4;
		j2 >>= 4;

		for(int k2 = i1; k2 <= l1; k2++) {
			for(int l2 = k1; l2 <= j2; l2++)
			if(!f(k2, l2))
			return false;
		}

		return true;
	}

	private boolean f(int i1, int j1) {
		return v.a(i1, j1);
	}

	public lm b(int i1, int j1) {
		return c(i1 >> 4, j1 >> 4);
	}

	public lm c(int i1, int j1) {
		return v.b(i1, j1);
	}

	public boolean a(int i1, int j1, int k1, int l1, int i2) {
		if(i1 < 0xfe17b800 || k1 < 0xfe17b800 || i1 >= 0x1e84800 || k1 > 0x1e84800)
		return false;

		if(j1 < 0)
		return false;

		if(j1 >= 128) {
			return false;
		} else {
			lm lm1 = c(i1 >> 4, k1 >> 4);
			l1 = SAPI.interceptBlockSet(this,new Loc(i1,j1,k1),l1);
			return lm1.a(i1 & 0xf, j1, k1 & 0xf, l1, i2);
		}
	}

	public boolean c(int i1, int j1, int k1, int l1) {
		if(i1 < 0xfe17b800 || k1 < 0xfe17b800 || i1 >= 0x1e84800 || k1 > 0x1e84800)
		return false;

		if(j1 < 0)
		return false;

		if(j1 >= 128) {
			return false;
		} else {
			lm lm1 = c(i1 >> 4, k1 >> 4);
			l1 = SAPI.interceptBlockSet(this,new Loc(i1,j1,k1),l1);
			return lm1.a(i1 & 0xf, j1, k1 & 0xf, l1);
		}
	}

	public ln f(int i1, int j1, int k1) {
		int l1 = a(i1, j1, k1);

		if(l1 == 0)
		return ln.a;
		else
		return uu.m[l1].bA;
	}

	public int e(int i1, int j1, int k1) {
		if(i1 < 0xfe17b800 || k1 < 0xfe17b800 || i1 >= 0x1e84800 || k1 > 0x1e84800)
		return 0;

		if(j1 < 0)
		return 0;

		if(j1 >= 128) {
			return 0;
		} else {
			lm lm1 = c(i1 >> 4, k1 >> 4);
			i1 &= 0xf;
			k1 &= 0xf;
			return lm1.b(i1, j1, k1);
		}
	}

	public void d(int i1, int j1, int k1, int l1) {
		if(e(i1, j1, k1, l1)) {
			int i2 = a(i1, j1, k1);

			if(uu.t[i2 & 0xff])
			g(i1, j1, k1, i2);
			else
			i(i1, j1, k1, i2);
		}
	}

	public boolean e(int i1, int j1, int k1, int l1) {
		if(i1 < 0xfe17b800 || k1 < 0xfe17b800 || i1 >= 0x1e84800 || k1 > 0x1e84800)
		return false;

		if(j1 < 0)
		return false;

		if(j1 >= 128) {
			return false;
		} else {
			lm lm1 = c(i1 >> 4, k1 >> 4);
			i1 &= 0xf;
			k1 &= 0xf;
			lm1.b(i1, j1, k1, l1);
			return true;
		}
	}

	public boolean f(int i1, int j1, int k1, int l1) {
		if(c(i1, j1, k1, l1)) {
			g(i1, j1, k1, l1);
			return true;
		} else {
			return false;
		}
	}

	public boolean b(int i1, int j1, int k1, int l1, int i2) {
		if(a(i1, j1, k1, l1, i2)) {
			g(i1, j1, k1, l1);
			return true;
		} else {
			return false;
		}
	}

	public void j(int i1, int j1, int k1) {
		for(int l1 = 0; l1 < u.size(); l1++)
		((pm)u.get(l1)).a(i1, j1, k1);
	}

	protected void g(int i1, int j1, int k1, int l1) {
		j(i1, j1, k1);
		i(i1, j1, k1, l1);
	}

	public void h(int i1, int j1, int k1, int l1) {
		if(k1 > l1) {
			int i2 = l1;
			l1 = k1;
			k1 = i2;
		}

		b(i1, k1, j1, i1, l1, j1);
	}

	public void k(int i1, int j1, int k1) {
		for(int l1 = 0; l1 < u.size(); l1++)
		((pm)u.get(l1)).b(i1, j1, k1, i1, j1, k1);
	}

	public void b(int i1, int j1, int k1, int l1, int i2, int j2) {
		for(int k2 = 0; k2 < u.size(); k2++)
		((pm)u.get(k2)).b(i1, j1, k1, l1, i2, j2);
	}

	public void i(int i1, int j1, int k1, int l1) {
		l(i1 - 1, j1, k1, l1);
		l(i1 + 1, j1, k1, l1);
		l(i1, j1 - 1, k1, l1);
		l(i1, j1 + 1, k1, l1);
		l(i1, j1, k1 - 1, l1);
		l(i1, j1, k1 + 1, l1);
	}

	private void l(int i1, int j1, int k1, int l1) {
		if(o || B)
		return;

		uu uu1 = uu.m[a(i1, j1, k1)];

		if(uu1 != null)
		uu1.b(this, i1, j1, k1, l1);
	}

	public boolean l(int i1, int j1, int k1) {
		return c(i1 >> 4, k1 >> 4).c(i1 & 0xf, j1, k1 & 0xf);
	}

	public int m(int i1, int j1, int k1) {
		if(j1 < 0)
		return 0;

		if(j1 >= 128)
		j1 = 127;

		return c(i1 >> 4, k1 >> 4).c(i1 & 0xf, j1, k1 & 0xf, 0);
	}

	public int n(int i1, int j1, int k1) {
		return a(i1, j1, k1, true);
	}

	public int a(int i1, int j1, int k1, boolean flag) {
		if(i1 < 0xfe17b800 || k1 < 0xfe17b800 || i1 >= 0x1e84800 || k1 > 0x1e84800)
		return 15;

		if(flag) {
			int l1 = a(i1, j1, k1);

			if(l1 == uu.al.bn || l1 == uu.aB.bn || l1 == uu.aI.bn || l1 == uu.au.bn) {
				int i2 = a(i1, j1 + 1, k1, false);
				int j2 = a(i1 + 1, j1, k1, false);
				int k2 = a(i1 - 1, j1, k1, false);
				int l2 = a(i1, j1, k1 + 1, false);
				int i3 = a(i1, j1, k1 - 1, false);

				if(j2 > i2)
				i2 = j2;

				if(k2 > i2)
				i2 = k2;

				if(l2 > i2)
				i2 = l2;

				if(i3 > i2)
				i2 = i3;

				return i2;
			}
		}

		if(j1 < 0)
		return 0;

		if(j1 >= 128)
		j1 = 127;

		lm lm1 = c(i1 >> 4, k1 >> 4);
		i1 &= 0xf;
		k1 &= 0xf;
		return lm1.c(i1, j1, k1, f);
	}

	public boolean o(int i1, int j1, int k1) {
		if(i1 < 0xfe17b800 || k1 < 0xfe17b800 || i1 >= 0x1e84800 || k1 > 0x1e84800)
		return false;

		if(j1 < 0)
		return false;

		if(j1 >= 128)
		return true;

		if(!f(i1 >> 4, k1 >> 4)) {
			return false;
		} else {
			lm lm1 = c(i1 >> 4, k1 >> 4);
			i1 &= 0xf;
			k1 &= 0xf;
			return lm1.c(i1, j1, k1);
		}
	}

	public int d(int i1, int j1) {
		if(i1 < 0xfe17b800 || j1 < 0xfe17b800 || i1 >= 0x1e84800 || j1 > 0x1e84800)
		return 0;

		if(!f(i1 >> 4, j1 >> 4)) {
			return 0;
		} else {
			lm lm1 = c(i1 >> 4, j1 >> 4);
			return lm1.b(i1 & 0xf, j1 & 0xf);
		}
	}

	public void a(eb eb1, int i1, int j1, int k1, int l1) {
		if(t.e && eb1 == eb.a)
		return;

		if(!i(i1, j1, k1))
		return;

		if(eb1 == eb.a) {
			if(o(i1, j1, k1))
			l1 = 15;
		} else if(eb1 == eb.b) {
			int i2 = a(i1, j1, k1);

			if(uu.s[i2] > l1)
			l1 = uu.s[i2];
		}

		if(a(eb1, i1, j1, k1) != l1)
		a(eb1, i1, j1, k1, i1, j1, k1);
	}

	public int a(eb eb1, int i1, int j1, int k1) {
		if(j1 < 0)
		j1 = 0;

		if(j1 >= 128)
		j1 = 127;

		if(j1 < 0 || j1 >= 128 || i1 < 0xfe17b800 || k1 < 0xfe17b800 || i1 >= 0x1e84800 || k1 > 0x1e84800)
		return eb1.c;

		int l1 = i1 >> 4;
		int i2 = k1 >> 4;

		if(!f(l1, i2)) {
			return 0;
		} else {
			lm lm1 = c(l1, i2);
			return lm1.a(eb1, i1 & 0xf, j1, k1 & 0xf);
		}
	}

	public void b(eb eb1, int i1, int j1, int k1, int l1) {
		if(i1 < 0xfe17b800 || k1 < 0xfe17b800 || i1 >= 0x1e84800 || k1 > 0x1e84800)
		return;

		if(j1 < 0)
		return;

		if(j1 >= 128)
		return;

		if(!f(i1 >> 4, k1 >> 4))
		return;

		lm lm1 = c(i1 >> 4, k1 >> 4);
		lm1.a(eb1, i1 & 0xf, j1, k1 & 0xf, l1);

		for(int i2 = 0; i2 < u.size(); i2++)
		((pm)u.get(i2)).a(i1, j1, k1);
	}

	public float a(int i1, int j1, int k1, int l1) {
		int i2 = n(i1, j1, k1);

		if(i2 < l1)
		i2 = l1;

		return t.f[i2];
	}

	public float c(int i1, int j1, int k1) {
		return t.f[n(i1, j1, k1)];
	}

	public boolean f() {
		return f < 4;
	}

	public vf a(bt bt1, bt bt2) {
		return a(bt1, bt2, false, false);
	}

	public vf a(bt bt1, bt bt2, boolean flag) {
		return a(bt1, bt2, flag, false);
	}

	public vf a(bt bt1, bt bt2, boolean flag, boolean flag1) {
		if(Double.isNaN(bt1.a) || Double.isNaN(bt1.b) || Double.isNaN(bt1.c))
		return null;

		if(Double.isNaN(bt2.a) || Double.isNaN(bt2.b) || Double.isNaN(bt2.c))
		return null;

		int i1 = in.b(bt2.a);
		int j1 = in.b(bt2.b);
		int k1 = in.b(bt2.c);
		int l1 = in.b(bt1.a);
		int i2 = in.b(bt1.b);
		int j2 = in.b(bt1.c);
		int k2 = a(l1, i2, j2);
		int i3 = e(l1, i2, j2);
		uu uu1 = uu.m[k2];

		if((!flag1 || uu1 == null || uu1.e(this, l1, i2, j2) != null) && k2 > 0 && uu1.a(i3, flag)) {
			vf vf = uu1.a(this, l1, i2, j2, bt1, bt2);

			if(vf != null)
			return vf;
		}

		for(int l2 = 200; l2-- >= 0;) {
			if(Double.isNaN(bt1.a) || Double.isNaN(bt1.b) || Double.isNaN(bt1.c))
			return null;

			if(l1 == i1 && i2 == j1 && j2 == k1)
			return null;

			boolean flag2 = true;
			boolean flag3 = true;
			boolean flag4 = true;
			double d1 = 999D;
			double d2 = 999D;
			double d3 = 999D;

			if(i1 > l1)
			d1 = (double)l1 + 1.0D;
			else if(i1 < l1)
			d1 = (double)l1 + 0.0D;
			else
			flag2 = false;

			if(j1 > i2)
			d2 = (double)i2 + 1.0D;
			else if(j1 < i2)
			d2 = (double)i2 + 0.0D;
			else
			flag3 = false;

			if(k1 > j2)
			d3 = (double)j2 + 1.0D;
			else if(k1 < j2)
			d3 = (double)j2 + 0.0D;
			else
			flag4 = false;

			double d4 = 999D;
			double d5 = 999D;
			double d6 = 999D;
			double d7 = bt2.a - bt1.a;
			double d8 = bt2.b - bt1.b;
			double d9 = bt2.c - bt1.c;

			if(flag2)
			d4 = (d1 - bt1.a) / d7;

			if(flag3)
			d5 = (d2 - bt1.b) / d8;

			if(flag4)
			d6 = (d3 - bt1.c) / d9;

			byte byte0 = 0;

			if(d4 < d5 && d4 < d6) {
				if(i1 > l1)
				byte0 = 4;
				else
				byte0 = 5;

				bt1.a = d1;
				bt1.b += d8 * d4;
				bt1.c += d9 * d4;
			} else if(d5 < d6) {
				if(j1 > i2)
				byte0 = 0;
				else
				byte0 = 1;

				bt1.a += d7 * d5;
				bt1.b = d2;
				bt1.c += d9 * d5;
			} else {
				if(k1 > j2)
				byte0 = 2;
				else
				byte0 = 3;

				bt1.a += d7 * d6;
				bt1.b += d8 * d6;
				bt1.c = d3;
			}

			bt bt3 = bt.b(bt1.a, bt1.b, bt1.c);
			l1 = (int)(bt3.a = in.b(bt1.a));

			if(byte0 == 5) {
				l1--;
				bt3.a++;
			}

			i2 = (int)(bt3.b = in.b(bt1.b));

			if(byte0 == 1) {
				i2--;
				bt3.b++;
			}

			j2 = (int)(bt3.c = in.b(bt1.c));

			if(byte0 == 3) {
				j2--;
				bt3.c++;
			}

			int j3 = a(l1, i2, j2);
			int k3 = e(l1, i2, j2);
			uu uu2 = uu.m[j3];

			if((!flag1 || uu2 == null || uu2.e(this, l1, i2, j2) != null) && j3 > 0 && uu2.a(k3, flag)) {
				vf vf1 = uu2.a(this, l1, i2, j2, bt1, bt2);

				if(vf1 != null)
				return vf1;
			}
		}

		return null;
	}

	public void a(sn sn1, String s1, float f1, float f2) {
		for(int i1 = 0; i1 < u.size(); i1++)
		((pm)u.get(i1)).a(s1, sn1.aM, sn1.aN - (double)sn1.bf, sn1.aO, f1, f2);
	}

	public void a(double d1, double d2, double d3, String s1,
	float f1, float f2) {
		for(int i1 = 0; i1 < u.size(); i1++)
		((pm)u.get(i1)).a(s1, d1, d2, d3, f1, f2);
	}

	public void a(String s1, int i1, int j1, int k1) {
		for(int l1 = 0; l1 < u.size(); l1++)
		((pm)u.get(l1)).a(s1, i1, j1, k1);
	}

	public void a(String s1, double d1, double d2, double d3,
	double d4, double d5, double d6) {
		for(int i1 = 0; i1 < u.size(); i1++)
		((pm)u.get(i1)).a(s1, d1, d2, d3, d4, d5, d6);
	}

	public boolean a(sn sn1) {
		e.add(((Object) (sn1)));
		return true;
	}

	public boolean b(sn sn1) {
		int i1 = in.b(sn1.aM / 16D);
		int j1 = in.b(sn1.aO / 16D);
		boolean flag = false;

		if(sn1 instanceof gs)
		flag = true;

		if(flag || f(i1, j1)) {
			if(sn1 instanceof gs) {
				gs gs1 = (gs)sn1;
				d.add(((Object) (gs1)));
				y();
			}

			c(i1, j1).a(sn1);
			b.add(((Object) (sn1)));
			c(sn1);
			return true;
		} else {
			return false;
		}
	}

	protected void c(sn sn1) {
		for(int i1 = 0; i1 < u.size(); i1++)
		((pm)u.get(i1)).a(sn1);
	}

	protected void d(sn sn1) {
		for(int i1 = 0; i1 < u.size(); i1++)
		((pm)u.get(i1)).b(sn1);
	}

	public void e(sn sn1) {
		if(sn1.aG != null)
		sn1.aG.i(((sn) (null)));

		if(sn1.aH != null)
		sn1.i(((sn) (null)));

		sn1.K();

		if(sn1 instanceof gs) {
			d.remove(((Object) ((gs)sn1)));
			y();
		}
	}

	public void a(pm pm1) {
		u.add(((Object) (pm1)));
	}

	public void b(pm pm1) {
		u.remove(((Object) (pm1)));
	}

	public List a(sn sn1, eq eq1) {
		K.clear();
		int i1 = in.b(eq1.a);
		int j1 = in.b(eq1.d + 1.0D);
		int k1 = in.b(eq1.b);
		int l1 = in.b(eq1.e + 1.0D);
		int i2 = in.b(eq1.c);
		int j2 = in.b(eq1.f + 1.0D);

		for(int k2 = i1; k2 < j1; k2++) {
			for(int l2 = i2; l2 < j2; l2++) {
				if(!i(k2, 64, l2))
				continue;

				for(int i3 = k1 - 1; i3 < l1; i3++) {
					uu uu1 = uu.m[a(k2, i3, l2)];

					if(uu1 != null)
					uu1.a(this, k2, i3, l2, eq1, K);
				}
			}
		}

		double d1 = 0.25D;
		List list = b(sn1, eq1.b(d1, d1, d1));

		for(int j3 = 0; j3 < list.size(); j3++) {
			eq eq2 = ((sn)list.get(j3)).f();

			if(eq2 != null && eq2.a(eq1))
			K.add(((Object) (eq2)));

			eq2 = sn1.a((sn)list.get(j3));

			if(eq2 != null && eq2.a(eq1))
			K.add(((Object) (eq2)));
		}

		return ((List) (K));
	}

	public int a(float f1) {
		float f2 = b(f1);
		float f3 = 1.0F - (in.b(f2 * 3.141593F * 2.0F) * 2.0F + 0.5F);

		if(f3 < 0.0F)
		f3 = 0.0F;

		if(f3 > 1.0F)
		f3 = 1.0F;

		f3 = 1.0F - f3;
		f3 = (float)((double)f3 * (1.0D - (double)(g(f1) * 5F) / 16D));
		f3 = (float)((double)f3 * (1.0D - (double)(f(f1) * 5F) / 16D));
		f3 = 1.0F - f3;
		return (int)(f3 * 11F);
	}

	public bt a(sn sn1, float f1) {
		float f2 = b(f1);
		float f3 = in.b(f2 * 3.141593F * 2.0F) * 2.0F + 0.5F;

		if(f3 < 0.0F)
		f3 = 0.0F;

		if(f3 > 1.0F)
		f3 = 1.0F;

		int i1 = in.b(sn1.aM);
		int j1 = in.b(sn1.aO);
		float f4 = (float)a().b(i1, j1);
		int k1 = a().a(i1, j1).a(f4);
		float f5 = (float)(k1 >> 16 & 0xff) / 255F;
		float f6 = (float)(k1 >> 8 & 0xff) / 255F;
		float f7 = (float)(k1 & 0xff) / 255F;
		f5 *= f3;
		f6 *= f3;
		f7 *= f3;
		float f8 = g(f1);

		if(f8 > 0.0F) {
			float f9 = (f5 * 0.3F + f6 * 0.59F + f7 * 0.11F) * 0.6F;
			float f11 = 1.0F - f8 * 0.75F;
			f5 = f5 * f11 + f9 * (1.0F - f11);
			f6 = f6 * f11 + f9 * (1.0F - f11);
			f7 = f7 * f11 + f9 * (1.0F - f11);
		}

		float f10 = f(f1);

		if(f10 > 0.0F) {
			float f12 = (f5 * 0.3F + f6 * 0.59F + f7 * 0.11F) * 0.2F;
			float f14 = 1.0F - f10 * 0.75F;
			f5 = f5 * f14 + f12 * (1.0F - f14);
			f6 = f6 * f14 + f12 * (1.0F - f14);
			f7 = f7 * f14 + f12 * (1.0F - f14);
		}

		if(n > 0) {
			float f13 = (float)n - f1;

			if(f13 > 1.0F)
			f13 = 1.0F;

			f13 *= 0.45F;
			f5 = f5 * (1.0F - f13) + 0.8F * f13;
			f6 = f6 * (1.0F - f13) + 0.8F * f13;
			f7 = f7 * (1.0F - f13) + 1.0F * f13;
		}

		return bt.b(f5, f6, f7);
	}

	public float b(float f1) {
		return t.a(x.f(), f1);
	}

	public bt c(float f1) {
		float f2 = b(f1);
		float f3 = in.b(f2 * 3.141593F * 2.0F) * 2.0F + 0.5F;

		if(f3 < 0.0F)
		f3 = 0.0F;

		if(f3 > 1.0F)
		f3 = 1.0F;

		float f4 = (float)(H >> 16 & 255L) / 255F;
		float f5 = (float)(H >> 8 & 255L) / 255F;
		float f6 = (float)(H & 255L) / 255F;
		float f7 = g(f1);

		if(f7 > 0.0F) {
			float f8 = (f4 * 0.3F + f5 * 0.59F + f6 * 0.11F) * 0.6F;
			float f10 = 1.0F - f7 * 0.95F;
			f4 = f4 * f10 + f8 * (1.0F - f10);
			f5 = f5 * f10 + f8 * (1.0F - f10);
			f6 = f6 * f10 + f8 * (1.0F - f10);
		}

		f4 *= f3 * 0.9F + 0.1F;
		f5 *= f3 * 0.9F + 0.1F;
		f6 *= f3 * 0.85F + 0.15F;
		float f9 = f(f1);

		if(f9 > 0.0F) {
			float f11 = (f4 * 0.3F + f5 * 0.59F + f6 * 0.11F) * 0.2F;
			float f12 = 1.0F - f9 * 0.95F;
			f4 = f4 * f12 + f11 * (1.0F - f12);
			f5 = f5 * f12 + f11 * (1.0F - f12);
			f6 = f6 * f12 + f11 * (1.0F - f12);
		}

		return bt.b(f4, f5, f6);
	}

	public bt d(float f1) {
		float f2 = b(f1);
		return t.b(f2, f1);
	}

	public int e(int i1, int j1) {
		lm lm1 = b(i1, j1);
		int k1 = 127;
		i1 &= 0xf;
		j1 &= 0xf;

		while(k1 > 0)  {
			int l1 = lm1.a(i1, k1, j1);
			ln ln1 = l1 != 0 ? uu.m[l1].bA : ln.a;

			if(!ln1.c() && !ln1.d())
			k1--;
			else
			return k1 + 1;
		}

		return -1;
	}

	public float e(float f1) {
		float f2 = b(f1);
		float f3 = 1.0F - (in.b(f2 * 3.141593F * 2.0F) * 2.0F + 0.75F);

		if(f3 < 0.0F)
		f3 = 0.0F;

		if(f3 > 1.0F)
		f3 = 1.0F;

		return f3 * f3 * 0.5F;
	}

	public void c(int i1, int j1, int k1, int l1, int i2) {
		qy qy1 = new qy(i1, j1, k1, l1);
		byte byte0 = 8;

		if(a) {
			if(a(qy1.a - byte0, qy1.b - byte0, qy1.c - byte0, qy1.a + byte0, qy1.b + byte0, qy1.c + byte0)) {
				int j2 = a(qy1.a, qy1.b, qy1.c);

				if(j2 == qy1.d && j2 > 0)
				uu.m[j2].a(this, qy1.a, qy1.b, qy1.c, r);
			}

			return;
		}

		if(a(i1 - byte0, j1 - byte0, k1 - byte0, i1 + byte0, j1 + byte0, k1 + byte0)) {
			if(l1 > 0)
			qy1.a((long)i2 + x.f());

			if(!F.contains(((Object) (qy1)))) {
				F.add(((Object) (qy1)));
				E.add(((Object) (qy1)));
			}
		}
	}

	public void g() {
		for(int i1 = 0; i1 < e.size(); i1++) {
			sn sn1 = (sn)e.get(i1);
			sn1.w_();

			if(sn1.be)
			e.remove(i1--);
		}

		b.removeAll(((Collection) (D)));

		for(int j1 = 0; j1 < D.size(); j1++) {
			sn sn2 = (sn)D.get(j1);
			int i2 = sn2.bG;
			int k2 = sn2.bI;

			if(sn2.bF && f(i2, k2))
			c(i2, k2).b(sn2);
		}

		for(int k1 = 0; k1 < D.size(); k1++)
		d((sn)D.get(k1));

		D.clear();

		for(int l1 = 0; l1 < b.size(); l1++) {
			sn sn3 = (sn)b.get(l1);

			if(sn3.aH != null) {
				if(!sn3.aH.be && sn3.aH.aG == sn3)
				continue;

				sn3.aH.aG = null;
				sn3.aH = null;
			}

			if(!sn3.be)
			f(sn3);

			if(!sn3.be)
			continue;

			int j2 = sn3.bG;
			int l2 = sn3.bI;

			if(sn3.bF && f(j2, l2))
			c(j2, l2).b(sn3);

			b.remove(l1--);
			d(sn3);
		}

		L = true;
		Iterator iterator = c.iterator();

		do {
			if(!iterator.hasNext())
			break;

			ow ow1 = (ow)iterator.next();

			if(!ow1.g())
			ow1.n_();

			if(ow1.g()) {
				iterator.remove();
				lm lm1 = c(ow1.e >> 4, ow1.g >> 4);

				if(lm1 != null)
				lm1.e(ow1.e & 0xf, ow1.f, ow1.g & 0xf);
			}
		} while(true);

		L = false;

		if(!G.isEmpty()) {
			Iterator iterator1 = G.iterator();

			do {
				if(!iterator1.hasNext())
				break;

				ow ow2 = (ow)iterator1.next();

				if(!ow2.g()) {
					if(!c.contains(((Object) (ow2))))
					c.add(((Object) (ow2)));

					lm lm2 = c(ow2.e >> 4, ow2.g >> 4);

					if(lm2 != null)
					lm2.a(ow2.e & 0xf, ow2.f, ow2.g & 0xf, ow2);

					j(ow2.e, ow2.f, ow2.g);
				}
			} while(true);

			G.clear();
		}
	}

	public void a(Collection collection) {
		if(L)
		G.addAll(collection);
		else
		c.addAll(collection);
	}

	public void f(sn sn1) {
		a(sn1, true);
	}

	public void a(sn sn1, boolean flag) {
		int i1 = in.b(sn1.aM);
		int j1 = in.b(sn1.aO);
		byte byte0 = 32;

		if(flag && !a(i1 - byte0, 0, j1 - byte0, i1 + byte0, 128, j1 + byte0))
		return;

		sn1.bl = sn1.aM;
		sn1.bm = sn1.aN;
		sn1.bn = sn1.aO;
		sn1.aU = sn1.aS;
		sn1.aV = sn1.aT;

		if(flag && sn1.bF)
		if(sn1.aH != null)
		sn1.s_();
		else
		sn1.w_();

		if(Double.isNaN(sn1.aM) || Double.isInfinite(sn1.aM))
		sn1.aM = sn1.bl;

		if(Double.isNaN(sn1.aN) || Double.isInfinite(sn1.aN))
		sn1.aN = sn1.bm;

		if(Double.isNaN(sn1.aO) || Double.isInfinite(sn1.aO))
		sn1.aO = sn1.bn;

		if(Double.isNaN(sn1.aT) || Double.isInfinite(sn1.aT))
		sn1.aT = sn1.aV;

		if(Double.isNaN(sn1.aS) || Double.isInfinite(sn1.aS))
		sn1.aS = sn1.aU;

		int k1 = in.b(sn1.aM / 16D);
		int l1 = in.b(sn1.aN / 16D);
		int i2 = in.b(sn1.aO / 16D);

		if(!sn1.bF || sn1.bG != k1 || sn1.bH != l1 || sn1.bI != i2) {
			if(sn1.bF && f(sn1.bG, sn1.bI))
			c(sn1.bG, sn1.bI).a(sn1, sn1.bH);

			if(f(k1, i2)) {
				sn1.bF = true;
				c(k1, i2).a(sn1);
			} else {
				sn1.bF = false;
			}
		}

		if(flag && sn1.bF && sn1.aG != null)
		if(sn1.aG.be || sn1.aG.aH != sn1) {
			sn1.aG.aH = null;
			sn1.aG = null;
		} else {
			f(sn1.aG);
		}
	}

	public boolean a(eq eq1) {
		List list = b(((sn) (null)), eq1);

		for(int i1 = 0; i1 < list.size(); i1++) {
			sn sn1 = (sn)list.get(i1);

			if(!sn1.be && sn1.aF)
			return false;
		}

		return true;
	}

	public boolean b(eq eq1) {
		int i1 = in.b(eq1.a);
		int j1 = in.b(eq1.d + 1.0D);
		int k1 = in.b(eq1.b);
		int l1 = in.b(eq1.e + 1.0D);
		int i2 = in.b(eq1.c);
		int j2 = in.b(eq1.f + 1.0D);

		if(eq1.a < 0.0D)
		i1--;

		if(eq1.b < 0.0D)
		k1--;

		if(eq1.c < 0.0D)
		i2--;

		for(int k2 = i1; k2 < j1; k2++) {
			for(int l2 = k1; l2 < l1; l2++) {
				for(int i3 = i2; i3 < j2; i3++) {
					uu uu1 = uu.m[a(k2, l2, i3)];

					if(uu1 != null && uu1.bA.d())
					return true;
				}
			}
		}

		return false;
	}

	public boolean c(eq eq1) {
		int i1 = in.b(eq1.a);
		int j1 = in.b(eq1.d + 1.0D);
		int k1 = in.b(eq1.b);
		int l1 = in.b(eq1.e + 1.0D);
		int i2 = in.b(eq1.c);
		int j2 = in.b(eq1.f + 1.0D);

		if(a(i1, k1, i2, j1, l1, j2)) {
			for(int k2 = i1; k2 < j1; k2++) {
				for(int l2 = k1; l2 < l1; l2++) {
					for(int i3 = i2; i3 < j2; i3++) {
						int j3 = a(k2, l2, i3);

						if(j3 == uu.as.bn || j3 == uu.D.bn || j3 == uu.E.bn)
						return true;
					}
				}
			}
		}

		return false;
	}

	public boolean a(eq eq1, ln ln1, sn sn1) {
		int i1 = in.b(eq1.a);
		int j1 = in.b(eq1.d + 1.0D);
		int k1 = in.b(eq1.b);
		int l1 = in.b(eq1.e + 1.0D);
		int i2 = in.b(eq1.c);
		int j2 = in.b(eq1.f + 1.0D);

		if(!a(i1, k1, i2, j1, l1, j2))
		return false;

		boolean flag = false;
		bt bt1 = bt.b(0.0D, 0.0D, 0.0D);

		for(int k2 = i1; k2 < j1; k2++) {
			for(int l2 = k1; l2 < l1; l2++) {
				for(int i3 = i2; i3 < j2; i3++) {
					uu uu1 = uu.m[a(k2, l2, i3)];

					if(uu1 == null || uu1.bA != ln1)
					continue;

					double d2 = (float)(l2 + 1) - rp.d(e(k2, l2, i3));

					if((double)l1 >= d2) {
						flag = true;
						uu1.a(this, k2, l2, i3, sn1, bt1);
					}
				}
			}
		}

		if(bt1.d() > 0.0D) {
			bt1 = bt1.c();
			double d1 = 0.014D;
			sn1.aP += bt1.a * d1;
			sn1.aQ += bt1.b * d1;
			sn1.aR += bt1.c * d1;
		}

		return flag;
	}

	public boolean a(eq eq1, ln ln1) {
		int i1 = in.b(eq1.a);
		int j1 = in.b(eq1.d + 1.0D);
		int k1 = in.b(eq1.b);
		int l1 = in.b(eq1.e + 1.0D);
		int i2 = in.b(eq1.c);
		int j2 = in.b(eq1.f + 1.0D);

		for(int k2 = i1; k2 < j1; k2++) {
			for(int l2 = k1; l2 < l1; l2++) {
				for(int i3 = i2; i3 < j2; i3++) {
					uu uu1 = uu.m[a(k2, l2, i3)];

					if(uu1 != null && uu1.bA == ln1)
					return true;
				}
			}
		}

		return false;
	}

	public boolean b(eq eq1, ln ln1) {
		int i1 = in.b(eq1.a);
		int j1 = in.b(eq1.d + 1.0D);
		int k1 = in.b(eq1.b);
		int l1 = in.b(eq1.e + 1.0D);
		int i2 = in.b(eq1.c);
		int j2 = in.b(eq1.f + 1.0D);

		for(int k2 = i1; k2 < j1; k2++) {
			for(int l2 = k1; l2 < l1; l2++) {
				for(int i3 = i2; i3 < j2; i3++) {
					uu uu1 = uu.m[a(k2, l2, i3)];

					if(uu1 == null || uu1.bA != ln1)
					continue;

					int j3 = e(k2, l2, i3);
					double d1 = l2 + 1;

					if(j3 < 8)
					d1 = (double)(l2 + 1) - (double)j3 / 8D;

					if(d1 >= eq1.b)
					return true;
				}
			}
		}

		return false;
	}

	public qx a(sn sn1, double d1, double d2, double d3,
	float f1) {
		return a(sn1, d1, d2, d3, f1, false);
	}

	public qx a(sn sn1, double d1, double d2, double d3,
	float f1, boolean flag) {
		qx qx1 = new qx(this, sn1, d1, d2, d3, f1);
		qx1.a = flag;
		qx1.a();
		qx1.a(true);
		return qx1;
	}

	public float a(bt bt1, eq eq1) {
		double d1 = 1.0D / ((eq1.d - eq1.a) * 2D + 1.0D);
		double d2 = 1.0D / ((eq1.e - eq1.b) * 2D + 1.0D);
		double d3 = 1.0D / ((eq1.f - eq1.c) * 2D + 1.0D);
		int i1 = 0;
		int j1 = 0;

		for(float f1 = 0.0F; f1 <= 1.0F; f1 = (float)((double)f1 + d1)) {
			for(float f2 = 0.0F; f2 <= 1.0F; f2 = (float)((double)f2 + d2)) {
				for(float f3 = 0.0F; f3 <= 1.0F; f3 = (float)((double)f3 + d3)) {
					double d4 = eq1.a + (eq1.d - eq1.a) * (double)f1;
					double d5 = eq1.b + (eq1.e - eq1.b) * (double)f2;
					double d6 = eq1.c + (eq1.f - eq1.c) * (double)f3;

					if(a(bt.b(d4, d5, d6), bt1) == null)
					i1++;

					j1++;
				}
			}
		}

		return (float)i1 / (float)j1;
	}

	public void a(gs gs1, int i1, int j1, int k1, int l1) {
		if(l1 == 0)
		j1--;

		if(l1 == 1)
		j1++;

		if(l1 == 2)
		k1--;

		if(l1 == 3)
		k1++;

		if(l1 == 4)
		i1--;

		if(l1 == 5)
		i1++;

		if(a(i1, j1, k1) == uu.as.bn) {
			a(gs1, 1004, i1, j1, k1, 0);
			f(i1, j1, k1, 0);
		}
	}

	public sn a(Class class1) {
		return null;
	}

	public String h() {
		return (new StringBuilder()).append("All: ").append(b.size()).toString();
	}

	public String i() {
		return v.c();
	}

	public ow b(int i1, int j1, int k1) {
		lm lm1 = c(i1 >> 4, k1 >> 4);

		if(lm1 != null)
		return lm1.d(i1 & 0xf, j1, k1 & 0xf);
		else
		return null;
	}

	public void a(int i1, int j1, int k1, ow ow1) {
		if(!ow1.g())
		if(L) {
			ow1.e = i1;
			ow1.f = j1;
			ow1.g = k1;
			G.add(((Object) (ow1)));
		} else {
			c.add(((Object) (ow1)));
			lm lm1 = c(i1 >> 4, k1 >> 4);

			if(lm1 != null)
			lm1.a(i1 & 0xf, j1, k1 & 0xf, ow1);
		}
	}

	public void p(int i1, int j1, int k1) {
		ow ow1 = b(i1, j1, k1);

		if(ow1 != null && L) {
			ow1.i();
		} else {
			if(ow1 != null)
			c.remove(((Object) (ow1)));

			lm lm1 = c(i1 >> 4, k1 >> 4);

			if(lm1 != null)
			lm1.e(i1 & 0xf, j1, k1 & 0xf);
		}
	}

	public boolean g(int i1, int j1, int k1) {
		uu uu1 = uu.m[a(i1, j1, k1)];

		if(uu1 == null)
		return false;
		else
		return uu1.c();
	}

	public boolean h(int i1, int j1, int k1) {
		uu uu1 = uu.m[a(i1, j1, k1)];

		if(uu1 == null)
		return false;
		else
		return uu1.bA.h() && uu1.d();
	}

	public void a(yb yb1) {
		a(true, yb1);
	}

	public boolean j() {
		if(M >= 50)
		return false;

		M++;

		try {
			int i1 = 500;

			for(; C.size() > 0; ((st)C.remove(C.size() - 1)).a(this))
			if(--i1 <= 0) {
				boolean flag = true;
				return flag;
			}

			boolean flag1 = false;
			return flag1;
		} finally {
			M--;
		}
	}

	public void a(eb eb1, int i1, int j1, int k1, int l1, int i2, int j2) {
		a(eb1, i1, j1, k1, l1, i2, j2, true);
	}

	public void a(eb eb1, int i1, int j1, int k1, int l1, int i2, int j2,
	boolean flag) {
		if(t.e && eb1 == eb.a)
		return;

		A++;

		try {
			if(A == 50)
			return;

			int k2 = (l1 + i1) / 2;
			int l2 = (j2 + k1) / 2;

			if(!i(k2, 64, l2))
			return;

			if(b(k2, l2).h())
			return;

			int i3 = C.size();

			if(flag) {
				int j3 = 5;

				if(j3 > i3)
				j3 = i3;

				for(int l3 = 0; l3 < j3; l3++) {
					st st1 = (st)C.get(C.size() - l3 - 1);

					if(st1.a == eb1 && st1.a(i1, j1, k1, l1, i2, j2))
					return;
				}
			}

			C.add(((Object) (new st(eb1, i1, j1, k1, l1, i2, j2))));
			int k3 = 0xf4240;

			if(C.size() > 0xf4240) {
				System.out.println((new StringBuilder()).append("More than ").append(k3).append(" updates, aborting lighting updates").toString());
				C.clear();
			}
		} finally {
			A--;
		}
	}

	public void k() {
		int i1 = a(1.0F);

		if(i1 != f)
		f = i1;
	}

	public void a(boolean flag, boolean flag1) {
		N = flag;
		O = flag1;
	}

	public void l() {
		m();

		if(A()) {
			boolean flag = false;

			if(N && q >= 1)
			flag = cq.a(this, d);

			if(!flag) {
				long l1 = x.f() + 24000L;
				x.a(l1 - l1 % 24000L);
				z();
			}
		}

		cq.a(this, N, O);
		v.a();
		int i1 = a(1.0F);

		if(i1 != f) {
			f = i1;

			for(int j1 = 0; j1 < u.size(); j1++)
			((pm)u.get(j1)).e();
		}

		long l2 = x.f() + 1L;

		if(l2 % (long)p == 0L)
		a(false, ((yb) (null)));

		x.a(l2);
		a(false);
		n();
	}

	private void E() {
		if(x.o()) {
			j = 1.0F;

			if(x.m())
			l = 1.0F;
		}
	}

	protected void m() {
		if(t.e)
		return;

		if(m > 0)
		m--;

		int i1 = x.n();

		if(i1 <= 0) {
			if(x.m())
			x.e(r.nextInt(12000) + 3600);
			else
			x.e(r.nextInt(0x29040) + 12000);
		} else {
			i1--;
			x.e(i1);

			if(i1 <= 0)
			x.a(!x.m());
		}

		int j1 = x.p();

		if(j1 <= 0) {
			if(x.o())
			x.f(r.nextInt(12000) + 12000);
			else
			x.f(r.nextInt(0x29040) + 12000);
		} else {
			j1--;
			x.f(j1);

			if(j1 <= 0)
			x.b(!x.o());
		}

		i = j;

		if(x.o())
		j += 0.01D;
		else
		j -= 0.01D;

		if(j < 0.0F)
		j = 0.0F;

		if(j > 1.0F)
		j = 1.0F;

		k = l;

		if(x.m())
		l += 0.01D;
		else
		l -= 0.01D;

		if(l < 0.0F)
		l = 0.0F;

		if(l > 1.0F)
		l = 1.0F;
	}

	private void F() {
		x.f(0);
		x.b(false);
		x.e(0);
		x.a(false);
	}

	protected void n() {
		P.clear();

		for(int i1 = 0; i1 < d.size(); i1++) {
			gs gs1 = (gs)d.get(i1);
			int j1 = in.b(gs1.aM / 16D);
			int l1 = in.b(gs1.aO / 16D);
			byte byte0 = 9;

			for(int j2 = -byte0; j2 <= byte0; j2++) {
				for(int k3 = -byte0; k3 <= byte0; k3++)
				P.add(((Object) (new yy(j2 + j1, k3 + l1))));
			}
		}

		if(Q > 0)
		Q--;

		for(Iterator iterator = P.iterator(); iterator.hasNext();) {
			yy yy1 = (yy)iterator.next();
			int k1 = yy1.a * 16;
			int i2 = yy1.b * 16;
			lm lm1 = c(yy1.a, yy1.b);

			if(Q == 0) {
				g = g * 3 + 0x3c6ef35f;
				int k2 = g >> 2;
				int l3 = k2 & 0xf;
				int l4 = k2 >> 8 & 0xf;
				int l5 = k2 >> 16 & 0x7f;
				int l6 = lm1.a(l3, l5, l4);
				l3 += k1;
				l4 += i2;

				if(l6 == 0 && m(l3, l5, l4) <= r.nextInt(8) && a(eb.a, l3, l5, l4) <= 0) {
					gs gs2 = a((double)l3 + 0.5D, (double)l5 + 0.5D, (double)l4 + 0.5D, 8D);

					if(gs2 != null && gs2.g((double)l3 + 0.5D, (double)l5 + 0.5D, (double)l4 + 0.5D) > 4D) {
						a((double)l3 + 0.5D, (double)l5 + 0.5D, (double)l4 + 0.5D, "ambient.cave.cave", 0.7F, 0.8F + r.nextFloat() * 0.2F);
						Q = r.nextInt(12000) + 6000;
					}
				}
			}

			if(r.nextInt(0x186a0) == 0 && C() && B()) {
				g = g * 3 + 0x3c6ef35f;
				int l2 = g >> 2;
				int i4 = k1 + (l2 & 0xf);
				int i5 = i2 + (l2 >> 8 & 0xf);
				int i6 = e(i4, i5);

				if(t(i4, i6, i5)) {
					a(((sn) (new c(this, i4, i6, i5))));
					m = 2;
				}
			}

			if(r.nextInt(16) == 0) {
				g = g * 3 + 0x3c6ef35f;
				int i3 = g >> 2;
				int j4 = i3 & 0xf;
				int j5 = i3 >> 8 & 0xf;
				int j6 = e(j4 + k1, j5 + i2);

				if(a().a(j4 + k1, j5 + i2).c() && j6 >= 0 && j6 < 128 && lm1.a(eb.b, j4, j6, j5) < 10) {
					int i7 = lm1.a(j4, j6 - 1, j5);
					int k7 = lm1.a(j4, j6, j5);

					if(C() && k7 == 0 && uu.aT.a(this, j4 + k1, j6, j5 + i2) && i7 != 0 && i7 != uu.aU.bn && uu.m[i7].bA.c())
					f(j4 + k1, j6, j5 + i2, uu.aT.bn);

					if(i7 == uu.C.bn && lm1.b(j4, j6 - 1, j5) == 0)
					f(j4 + k1, j6 - 1, j5 + i2, uu.aU.bn);
				}
			}

			int j3 = 0;

			while(j3 < 80)  {
				g = g * 3 + 0x3c6ef35f;
				int k4 = g >> 2;
				int k5 = k4 & 0xf;
				int k6 = k4 >> 8 & 0xf;
				int j7 = k4 >> 16 & 0x7f;
				int l7 = lm1.b[k5 << 11 | k6 << 7 | j7] & 0xff;

				if(uu.n[l7])
				uu.m[l7].a(this, k5 + k1, j7, k6 + i2, r);

				j3++;
			}
		}
	}

	public boolean a(boolean flag) {
		int i1 = E.size();

		if(i1 != F.size())
		throw new IllegalStateException("TickNextTick list out of synch");

		if(i1 > 1000)
		i1 = 1000;

		for(int j1 = 0; j1 < i1; j1++) {
			qy qy1 = (qy)E.first();

			if(!flag && qy1.e > x.f())
			break;

			E.remove(((Object) (qy1)));
			F.remove(((Object) (qy1)));
			byte byte0 = 8;

			if(!a(qy1.a - byte0, qy1.b - byte0, qy1.c - byte0, qy1.a + byte0, qy1.b + byte0, qy1.c + byte0))
			continue;

			int k1 = a(qy1.a, qy1.b, qy1.c);

			if(k1 == qy1.d && k1 > 0)
			uu.m[k1].a(this, qy1.a, qy1.b, qy1.c, r);
		}

		return E.size() != 0;
	}

	public void q(int i1, int j1, int k1) {
		byte byte0 = 16;
		Random random = new Random();

		for(int l1 = 0; l1 < 1000; l1++) {
			int i2 = (i1 + r.nextInt(((int) (byte0)))) - r.nextInt(((int) (byte0)));
			int j2 = (j1 + r.nextInt(((int) (byte0)))) - r.nextInt(((int) (byte0)));
			int k2 = (k1 + r.nextInt(((int) (byte0)))) - r.nextInt(((int) (byte0)));
			int l2 = a(i2, j2, k2);

			if(l2 > 0)
			uu.m[l2].b(this, i2, j2, k2, random);
		}
	}

	public List b(sn sn1, eq eq1) {
		R.clear();
		int i1 = in.b((eq1.a - 2D) / 16D);
		int j1 = in.b((eq1.d + 2D) / 16D);
		int k1 = in.b((eq1.c - 2D) / 16D);
		int l1 = in.b((eq1.f + 2D) / 16D);

		for(int i2 = i1; i2 <= j1; i2++) {
			for(int j2 = k1; j2 <= l1; j2++)
			if(f(i2, j2))
			c(i2, j2).a(sn1, eq1, R);
		}

		return R;
	}

	public List a(Class class1, eq eq1) {
		int i1 = in.b((eq1.a - 2D) / 16D);
		int j1 = in.b((eq1.d + 2D) / 16D);
		int k1 = in.b((eq1.c - 2D) / 16D);
		int l1 = in.b((eq1.f + 2D) / 16D);
		ArrayList arraylist = new ArrayList();

		for(int i2 = i1; i2 <= j1; i2++) {
			for(int j2 = k1; j2 <= l1; j2++)
			if(f(i2, j2))
			c(i2, j2).a(class1, eq1, ((List) (arraylist)));
		}

		return ((List) (arraylist));
	}

	public List o() {
		return b;
	}

	public void b(int i1, int j1, int k1, ow ow1) {
		if(i(i1, j1, k1))
		b(i1, k1).g();

		for(int l1 = 0; l1 < u.size(); l1++)
		((pm)u.get(l1)).a(i1, j1, k1, ow1);
	}

	public int b(Class class1) {
		int i1 = 0;

		for(int j1 = 0; j1 < b.size(); j1++) {
			sn sn1 = (sn)b.get(j1);

			if(class1.isAssignableFrom(((Object) (sn1)).getClass()))
			i1++;
		}

		return i1;
	}

	public void a(List list) {
		b.addAll(((Collection) (list)));

		for(int i1 = 0; i1 < list.size(); i1++)
		c((sn)list.get(i1));
	}

	public void b(List list) {
		D.addAll(((Collection) (list)));
	}

	public void p() {
		while(v.a()) ;
	}

	public boolean a(int i1, int j1, int k1, int l1, boolean flag, int i2) {
		int j2 = a(j1, k1, l1);
		uu uu1 = uu.m[j2];
		uu uu2 = uu.m[i1];
		eq eq1 = uu2.e(this, j1, k1, l1);

		if(flag)
		eq1 = null;

		if(eq1 != null && !a(eq1))
		return false;

		if(uu1 == uu.B || uu1 == uu.C || uu1 == uu.D || uu1 == uu.E || uu1 == uu.as || uu1 == uu.aT)
		uu1 = null;

		return i1 > 0 && uu1 == null && uu2.a(this, j1, k1, l1, i2);
	}

	public dh a(sn sn1, sn sn2, float f1) {
		int i1 = in.b(sn1.aM);
		int j1 = in.b(sn1.aN);
		int k1 = in.b(sn1.aO);
		int l1 = (int)(f1 + 16F);
		int i2 = i1 - l1;
		int j2 = j1 - l1;
		int k2 = k1 - l1;
		int l2 = i1 + l1;
		int i3 = j1 + l1;
		int j3 = k1 + l1;
		ew ew1 = new ew(this, i2, j2, k2, l2, i3, j3);
		return (new fw(((xp) (ew1)))).a(sn1, sn2, f1);
	}

	public dh a(sn sn1, int i1, int j1, int k1, float f1) {
		int l1 = in.b(sn1.aM);
		int i2 = in.b(sn1.aN);
		int j2 = in.b(sn1.aO);
		int k2 = (int)(f1 + 8F);
		int l2 = l1 - k2;
		int i3 = i2 - k2;
		int j3 = j2 - k2;
		int k3 = l1 + k2;
		int l3 = i2 + k2;
		int i4 = j2 + k2;
		ew ew1 = new ew(this, l2, i3, j3, k3, l3, i4);
		return (new fw(((xp) (ew1)))).a(sn1, i1, j1, k1, f1);
	}

	public boolean j(int i1, int j1, int k1, int l1) {
		int i2 = a(i1, j1, k1);

		if(i2 == 0)
		return false;
		else
		return uu.m[i2].d(this, i1, j1, k1, l1);
	}

	public boolean r(int i1, int j1, int k1) {
		if(j(i1, j1 - 1, k1, 0))
		return true;

		if(j(i1, j1 + 1, k1, 1))
		return true;

		if(j(i1, j1, k1 - 1, 2))
		return true;

		if(j(i1, j1, k1 + 1, 3))
		return true;

		if(j(i1 - 1, j1, k1, 4))
		return true;

		return j(i1 + 1, j1, k1, 5);
	}

	public boolean k(int i1, int j1, int k1, int l1) {
		if(h(i1, j1, k1))
		return r(i1, j1, k1);

		int i2 = a(i1, j1, k1);

		if(i2 == 0)
		return false;
		else
		return uu.m[i2].c(((xp) (this)), i1, j1, k1, l1);
	}

	public boolean s(int i1, int j1, int k1) {
		if(k(i1, j1 - 1, k1, 0))
		return true;

		if(k(i1, j1 + 1, k1, 1))
		return true;

		if(k(i1, j1, k1 - 1, 2))
		return true;

		if(k(i1, j1, k1 + 1, 3))
		return true;

		if(k(i1 - 1, j1, k1, 4))
		return true;

		return k(i1 + 1, j1, k1, 5);
	}

	public gs a(sn sn1, double d1) {
		return a(sn1.aM, sn1.aN, sn1.aO, d1);
	}

	public gs a(double d1, double d2, double d3, double d4) {
		double d5 = -1D;
		gs gs1 = null;

		for(int i1 = 0; i1 < d.size(); i1++) {
			gs gs2 = (gs)d.get(i1);
			double d6 = gs2.g(d1, d2, d3);

			if((d4 < 0.0D || d6 < d4 * d4) && (d5 == -1D || d6 < d5)) {
				d5 = d6;
				gs1 = gs2;
			}
		}

		return gs1;
	}

	public gs a(String s1) {
		for(int i1 = 0; i1 < d.size(); i1++)
		if(s1.equals(((Object) (((gs)d.get(i1)).l))))
		return (gs)d.get(i1);

		return null;
	}

	public void a(int i1, int j1, int k1, int l1, int i2, int j2, byte abyte0[]) {
		int k2 = i1 >> 4;
		int l2 = k1 >> 4;
		int i3 = (i1 + l1) - 1 >> 4;
		int j3 = (k1 + j2) - 1 >> 4;
		int k3 = 0;
		int l3 = j1;
		int i4 = j1 + i2;

		if(l3 < 0)
		l3 = 0;

		if(i4 > 128)
		i4 = 128;

		for(int j4 = k2; j4 <= i3; j4++) {
			int k4 = i1 - j4 * 16;
			int l4 = (i1 + l1) - j4 * 16;

			if(k4 < 0)
			k4 = 0;

			if(l4 > 16)
			l4 = 16;

			for(int i5 = l2; i5 <= j3; i5++) {
				int j5 = k1 - i5 * 16;
				int k5 = (k1 + j2) - i5 * 16;

				if(j5 < 0)
				j5 = 0;

				if(k5 > 16)
				k5 = 16;

				k3 = c(j4, i5).a(abyte0, k4, l3, j5, l4, i4, k5, k3);
				b(j4 * 16 + k4, l3, i5 * 16 + j5, j4 * 16 + l4, i4, i5 * 16 + k5);
			}
		}
	}

	public void q() {
	}

	public void r() {
		w.b();
	}

	public void a(long l1) {
		x.a(l1);
	}

	public long s() {
		return x.b();
	}

	public long t() {
		return x.f();
	}

	public br u() {
		return new br(x.c(), x.d(), x.e());
	}

	public void a(br br1) {
		x.a(br1.a, br1.b, br1.c);
	}

	public void g(sn sn1) {
		int i1 = in.b(sn1.aM / 16D);
		int j1 = in.b(sn1.aO / 16D);
		byte byte0 = 2;

		for(int k1 = i1 - byte0; k1 <= i1 + byte0; k1++) {
			for(int l1 = j1 - byte0; l1 <= j1 + byte0; l1++)
			c(k1, l1);
		}

		if(!b.contains(((Object) (sn1))))
		b.add(((Object) (sn1)));
	}

	public boolean a(gs gs1, int i1, int j1, int k1) {
		return true;
	}

	public void a(sn sn1, byte byte0) {
	}

	public void v() {
		b.removeAll(((Collection) (D)));

		for(int i1 = 0; i1 < D.size(); i1++) {
			sn sn1 = (sn)D.get(i1);
			int l1 = sn1.bG;
			int j2 = sn1.bI;

			if(sn1.bF && f(l1, j2))
			c(l1, j2).b(sn1);
		}

		for(int j1 = 0; j1 < D.size(); j1++)
		d((sn)D.get(j1));

		D.clear();

		for(int k1 = 0; k1 < b.size(); k1++) {
			sn sn2 = (sn)b.get(k1);

			if(sn2.aH != null) {
				if(!sn2.aH.be && sn2.aH.aG == sn2)
				continue;

				sn2.aH.aG = null;
				sn2.aH = null;
			}

			if(!sn2.be)
			continue;

			int i2 = sn2.bG;
			int k2 = sn2.bI;

			if(sn2.bF && f(i2, k2))
			c(i2, k2).b(sn2);

			b.remove(k1--);
			d(sn2);
		}
	}

	public cl w() {
		return v;
	}

	public void d(int i1, int j1, int k1, int l1, int i2) {
		int j2 = a(i1, j1, k1);

		if(j2 > 0)
		uu.m[j2].a(this, i1, j1, k1, l1, i2);
	}

	public ei x() {
		return x;
	}

	public void y() {
		J = !d.isEmpty();
		Iterator iterator = d.iterator();

		do {
			if(!iterator.hasNext())
			break;

			gs gs1 = (gs)iterator.next();

			if(gs1.N())
			continue;

			J = false;
			break;
		} while(true);
	}

	protected void z() {
		J = false;
		Iterator iterator = d.iterator();

		do {
			if(!iterator.hasNext())
			break;

			gs gs1 = (gs)iterator.next();

			if(gs1.N())
			gs1.a(false, false, true);
		} while(true);

		F();
	}

	public boolean A() {
		if(J && !B) {
			for(Iterator iterator = d.iterator(); iterator.hasNext();) {
				gs gs1 = (gs)iterator.next();

				if(!gs1.O())
				return false;
			}

			return true;
		} else {
			return false;
		}
	}

	public float f(float f1) {
		return (k + (l - k) * f1) * g(f1);
	}

	public float g(float f1) {
		return i + (j - i) * f1;
	}

	public void h(float f1) {
		i = f1;
		j = f1;
	}

	public boolean B() {
		return (double)f(1.0F) > 0.90000000000000002D;
	}

	public boolean C() {
		return (double)g(1.0F) > 0.20000000000000001D;
	}

	public boolean t(int i1, int j1, int k1) {
		if(!C())
		return false;

		if(!l(i1, j1, k1))
		return false;

		if(e(i1, k1) > j1)
		return false;

		kd kd1 = a().a(i1, k1);

		if(kd1.c())
		return false;
		else
		return kd1.d();
	}

	public void a(String s1, hm hm) {
		z.a(s1, hm);
	}

	public hm a(Class class1, String s1) {
		return z.a(class1, s1);
	}

	public int b(String s1) {
		return z.a(s1);
	}

	public void e(int i1, int j1, int k1, int l1, int i2) {
		a(((gs) (null)), i1, j1, k1, l1, i2);
	}

	public void a(gs gs1, int i1, int j1, int k1, int l1, int i2) {
		for(int j2 = 0; j2 < u.size(); j2++)
		((pm)u.get(j2)).a(gs1, i1, j1, k1, l1, i2);
	}
}