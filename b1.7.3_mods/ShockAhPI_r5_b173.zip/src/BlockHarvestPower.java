public class BlockHarvestPower {
	public final int blockID;
	public final float percentage;
	
	public BlockHarvestPower(int blockID, float percentage) {
		this.blockID = blockID;
		this.percentage = percentage;
	}
	
	public boolean equals(Object other) {
		if (other == null) return false;
		if (other instanceof BlockHarvestPower) return blockID == ((BlockHarvestPower)other).blockID;
		if (other instanceof Integer) return blockID == (Integer)other;
		return false;
	}
}