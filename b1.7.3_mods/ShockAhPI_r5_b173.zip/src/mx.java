import java.io.File;
import java.util.List;

public class mx extends fm {
	public mx(File paramFile, String paramString, boolean paramBoolean)
	{
		super(paramFile, paramString, paramBoolean);
	}

	public bf a(xa paramxa)
	{
		File localFile1 = a();
		DimensionBase localDimensionBase = DimensionBase.getDimByProvider(paramxa.getClass());
		if (localDimensionBase.number != 0) {
			File localFile2 = new File(localFile1, "DIM" + localDimensionBase.number);
			localFile2.mkdirs();
			return new ld(localFile2);
		}

		return new ld(localFile1);
	}

	@SuppressWarnings("rawtypes")
	public void a(ei paramei, List paramList)
	{
		paramei.d(19132);
		super.a(paramei, paramList);
	}
}