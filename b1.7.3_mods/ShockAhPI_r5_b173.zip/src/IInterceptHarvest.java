public interface IInterceptHarvest {
	public boolean canIntercept(fd world, gs player, Loc loc, int blockID, int meta);
	public void intercept(fd world, gs player, Loc loc, int blockID, int meta);
}