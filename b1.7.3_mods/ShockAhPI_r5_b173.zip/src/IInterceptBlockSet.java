public interface IInterceptBlockSet {
	public boolean canIntercept(fd world, Loc loc, int blockID);
	public int intercept(fd world, Loc loc, int blockID);
}