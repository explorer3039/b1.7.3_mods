import java.util.Random;

public class ak extends jp
{
	public ak(int paramInt1, int paramInt2)
	{
		super(paramInt1, paramInt2, ln.y, false);
	}

	public eq e(fd paramfd, int paramInt1, int paramInt2, int paramInt3) {
		return null;
	}

	public void a(xp paramxp, int paramInt1, int paramInt2, int paramInt3)
	{
		float f1;
		float f2;
		if ((paramxp.a(paramInt1 - 1, paramInt2, paramInt3) == this.bn) || (paramxp.a(paramInt1 + 1, paramInt2, paramInt3) == this.bn)) {
			f1 = 0.5F;
			f2 = 0.125F;
			a(0.5F - f1, 0.0F, 0.5F - f2, 0.5F + f1, 1.0F, 0.5F + f2);
		} else {
			f1 = 0.125F;
			f2 = 0.5F;
			a(0.5F - f1, 0.0F, 0.5F - f2, 0.5F + f1, 1.0F, 0.5F + f2);
		}
	}

	public boolean c() {
		return false;
	}

	public boolean d() {
		return false;
	}

	public boolean a_(fd paramfd, int paramInt1, int paramInt2, int paramInt3) {
		int i = 0;
		int j = 0;
		if ((paramfd.a(paramInt1 - 1, paramInt2, paramInt3) == uu.aq.bn) || (paramfd.a(paramInt1 + 1, paramInt2, paramInt3) == uu.aq.bn)) i = 1;
		if ((paramfd.a(paramInt1, paramInt2, paramInt3 - 1) == uu.aq.bn) || (paramfd.a(paramInt1, paramInt2, paramInt3 + 1) == uu.aq.bn)) j = 1;

		if (i == j) return false;

		if (paramfd.a(paramInt1 - i, paramInt2, paramInt3 - j) == 0) {
			paramInt1 -= i;
			paramInt3 -= j;
		}
		int m;
		for (int k = -1; k <= 2; k++) {
			for (m = -1; m <= 3; m++) {
				int n = (k == -1) || (k == 2) || (m == -1) || (m == 3) ? 1 : 0;
				if (((k == -1) || (k == 2)) && ((m == -1) || (m == 3)))
				continue;
				int i1 = paramfd.a(paramInt1 + i * k, paramInt2 + m, paramInt3 + j * k);

				if (n != 0) {
					if (i1 != uu.aq.bn) return false;
				}
				else if ((i1 != 0) && (i1 != uu.as.bn)) return false;
			}

		}

		paramfd.o = true;
		for (int k = 0; k < 2; k++) {
			for (m = 0; m < 3; m++) {
				paramfd.f(paramInt1 + i * k, paramInt2 + m, paramInt3 + j * k, uu.bf.bn);
			}
		}
		paramfd.o = false;

		return true;
	}

	public void b(fd paramfd, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
		int i = 0;
		int j = 1;
		if ((paramfd.a(paramInt1 - 1, paramInt2, paramInt3) == this.bn) || (paramfd.a(paramInt1 + 1, paramInt2, paramInt3) == this.bn)) {
			i = 1;
			j = 0;
		}

		int k = paramInt2;
		while (paramfd.a(paramInt1, k - 1, paramInt3) == this.bn) {
			k--;
		}
		if (paramfd.a(paramInt1, k - 1, paramInt3) != uu.aq.bn) {
			paramfd.f(paramInt1, paramInt2, paramInt3, 0);
			return;
		}

		int m = 1;
		while ((m < 4) && (paramfd.a(paramInt1, k + m, paramInt3) == this.bn)) {
			m++;
		}
		if ((m != 3) || (paramfd.a(paramInt1, k + m, paramInt3) != uu.aq.bn)) {
			paramfd.f(paramInt1, paramInt2, paramInt3, 0);
			return;
		}

		int n = (paramfd.a(paramInt1 - 1, paramInt2, paramInt3) == this.bn) || (paramfd.a(paramInt1 + 1, paramInt2, paramInt3) == this.bn) ? 1 : 0;
		int i1 = (paramfd.a(paramInt1, paramInt2, paramInt3 - 1) == this.bn) || (paramfd.a(paramInt1, paramInt2, paramInt3 + 1) == this.bn) ? 1 : 0;
		if ((n != 0) && (i1 != 0)) {
			paramfd.f(paramInt1, paramInt2, paramInt3, 0);
			return;
		}

		if (((paramfd.a(paramInt1 + i, paramInt2, paramInt3 + j) != uu.aq.bn) || (paramfd.a(paramInt1 - i, paramInt2, paramInt3 - j) != this.bn)) && ((paramfd.a(paramInt1 - i, paramInt2, paramInt3 - j) != uu.aq.bn) || (paramfd.a(paramInt1 + i, paramInt2, paramInt3 + j) != this.bn)))
		{
			paramfd.f(paramInt1, paramInt2, paramInt3, 0);
			return;
		}
	}

	public boolean b(xp paramxp, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
		if (paramxp.a(paramInt1, paramInt2, paramInt3) == this.bn) return false;

		int i = (paramxp.a(paramInt1 - 1, paramInt2, paramInt3) == this.bn) && (paramxp.a(paramInt1 - 2, paramInt2, paramInt3) != this.bn) ? 1 : 0;
		int j = (paramxp.a(paramInt1 + 1, paramInt2, paramInt3) == this.bn) && (paramxp.a(paramInt1 + 2, paramInt2, paramInt3) != this.bn) ? 1 : 0;

		int k = (paramxp.a(paramInt1, paramInt2, paramInt3 - 1) == this.bn) && (paramxp.a(paramInt1, paramInt2, paramInt3 - 2) != this.bn) ? 1 : 0;
		int m = (paramxp.a(paramInt1, paramInt2, paramInt3 + 1) == this.bn) && (paramxp.a(paramInt1, paramInt2, paramInt3 + 2) != this.bn) ? 1 : 0;

		int n = (i != 0) || (j != 0) ? 1 : 0;
		int i1 = (k != 0) || (m != 0) ? 1 : 0;

		if ((n != 0) && (paramInt4 == 4)) return true;
		if ((n != 0) && (paramInt4 == 5)) return true;
		if ((i1 != 0) && (paramInt4 == 2)) return true;
		return (i1 != 0) && (paramInt4 == 3);
	}

	public int a(Random paramRandom)
	{
		return 0;
	}

	public int b_() {
		return 1;
	}

	public void a(fd paramfd, int paramInt1, int paramInt2, int paramInt3, sn paramsn) {
		if ((paramsn.aH == null) && (paramsn.aG == null)) {
			if ((paramsn instanceof dc)) {
				dc localda = (dc)paramsn;
				localda.portal = getDimNumber();
			}
			paramsn.S(); 
		}
	}

	public void b(fd paramfd, int paramInt1, int paramInt2, int paramInt3, Random paramRandom)
	{
		if (paramRandom.nextInt(100) == 0) {
			paramfd.a(paramInt1 + 0.5D, paramInt2 + 0.5D, paramInt3 + 0.5D, "portal.portal", 1.0F, paramRandom.nextFloat() * 0.4F + 0.8F);
		}
		for (int i = 0; i < 4; i++) {
			double d1 = paramInt1 + paramRandom.nextFloat();
			double d2 = paramInt2 + paramRandom.nextFloat();
			double d3 = paramInt3 + paramRandom.nextFloat();
			double d4 = 0.0D;
			double d5 = 0.0D;
			double d6 = 0.0D;
			int j = paramRandom.nextInt(2) * 2 - 1;
			d4 = (paramRandom.nextFloat() - 0.5D) * 0.5D;
			d5 = (paramRandom.nextFloat() - 0.5D) * 0.5D;
			d6 = (paramRandom.nextFloat() - 0.5D) * 0.5D;
			if ((paramfd.a(paramInt1 - 1, paramInt2, paramInt3) == this.bn) || (paramfd.a(paramInt1 + 1, paramInt2, paramInt3) == this.bn)) {
				d3 = paramInt3 + 0.5D + 0.25D * j;
				d6 = paramRandom.nextFloat() * 2.0F * j;
			} else {
				d1 = paramInt1 + 0.5D + 0.25D * j;
				d4 = paramRandom.nextFloat() * 2.0F * j;
			}

			paramfd.a("portal", d1, d2, d3, d4, d5, d6);
		}
	}

	public int getDimNumber() {
		return -1;
	}
}