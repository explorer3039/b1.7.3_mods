public class DimensionOverworld extends DimensionBase {
	public DimensionOverworld() {
		super(0,rh.class,null);
		this.name = "Overworld";
	}
}