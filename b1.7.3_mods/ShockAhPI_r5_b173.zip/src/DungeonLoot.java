import java.util.Random;

public class DungeonLoot {
	public final iz loot;
	public final int min,max;
	
	public DungeonLoot(iz stack) {
		loot = new iz(stack.c,1,stack.i());
		min = max = stack.a;
	}
	public DungeonLoot(iz stack, int min, int max) {
		loot = new iz(stack.c,1,stack.i());
		this.min = min;
		this.max = max;
	}
	
	public iz getStack() {
		int damage = 0;
		if (loot.c <= 255) if (uu.m[loot.c].b(1) != 1) damage = loot.i();
		else if (!loot.a().bi) damage = loot.i();
		
		return new iz(loot.c,min+(new Random().nextInt(max-min+1)),damage);
	}
}