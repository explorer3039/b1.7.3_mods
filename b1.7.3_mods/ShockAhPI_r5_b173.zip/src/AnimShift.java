public class AnimShift extends AnimBase {
	private final int h, v;
	
	public AnimShift(int spriteID, String spritePath, int h, int v) {
		super(spriteID,spritePath);
		this.h = h;
		this.v = v;
		
		getCleanFrame();
	}
	
	public void a() {
		animFrame();
		copyFrameToArray();
	}

	public void animFrame() {
		shiftFrame(h,v,true,true);
	}
}