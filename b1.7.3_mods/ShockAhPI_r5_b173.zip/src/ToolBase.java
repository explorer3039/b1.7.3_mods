import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ToolBase {
	public static final ToolBase Pickaxe,Shovel,Axe;
	
	static {
		SAPI.showText();
		
		List<Integer> list;
		Pickaxe = new ToolBase();
		Shovel = new ToolBase();
		Axe = new ToolBase();
		
		list = Arrays.asList(new Integer[]{1,4,16,21,22,23,24,43,44,45,48,52,61,62,67,77,79,87,89,93,94});
		for (Integer blockID : list) Pickaxe.mineBlocks.add(new BlockHarvestPower(blockID,20));
		list = Arrays.asList(new Integer[]{15,42,71});
		for (Integer blockID : list) Pickaxe.mineBlocks.add(new BlockHarvestPower(blockID,40));
		list = Arrays.asList(new Integer[]{14,41,56,57,73,74});
		for (Integer blockID : list) Pickaxe.mineBlocks.add(new BlockHarvestPower(blockID,60));
		list = Arrays.asList(new Integer[]{49});
		for (Integer blockID : list) Pickaxe.mineBlocks.add(new BlockHarvestPower(blockID,80));
		
		list = Arrays.asList(new Integer[]{2,3,12,13,78,80,82});
		for (Integer blockID : list) Shovel.mineBlocks.add(new BlockHarvestPower(blockID,20));
		
		list = Arrays.asList(new Integer[]{5,17,18,25,47,53,54,58,63,64,65,66,68,69,81,84,85});
		for (Integer blockID : list) Axe.mineBlocks.add(new BlockHarvestPower(blockID,20));
	}
	
	public ArrayList<BlockHarvestPower> mineBlocks = new ArrayList<BlockHarvestPower>();
	public ArrayList<ln> mineMaterials = new ArrayList<ln>();
	
	public boolean canHarvest(uu block, float currentPower) {
		for (ln material : mineMaterials) if (material == block.bA) return true;
		for (BlockHarvestPower power : mineBlocks) if (block.bn == power.blockID || currentPower >= power.percentage) return true;
		return false;
	}
}