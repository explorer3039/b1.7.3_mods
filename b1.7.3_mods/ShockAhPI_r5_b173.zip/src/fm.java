import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.logging.Logger;

@SuppressWarnings({"unused","rawtypes"})
public class fm implements wt {
	private static final Logger a = Logger.getLogger("Minecraft");
	private final File b;
	private final File c;
	private final File d;
	private final long e = System.currentTimeMillis();

	public fm(File paramFile, String paramString, boolean paramBoolean) {
		this.b = new File(paramFile, paramString);
		this.b.mkdirs();
		this.c = new File(this.b, "players");
		this.d = new File(this.b, "data");
		this.d.mkdirs();

		if (paramBoolean) {
			this.c.mkdirs();
		}

		d();
	}

	private void d() {
		try {
			File localFile = new File(this.b, "session.lock");
			DataOutputStream localDataOutputStream = new DataOutputStream(new FileOutputStream(localFile));
			try {
				localDataOutputStream.writeLong(this.e);
			} finally {
				localDataOutputStream.close();
			}
		} catch (IOException localIOException) {
			localIOException.printStackTrace();
			throw new RuntimeException("Failed to check session lock, aborting");
		}
	}

	protected File a() {
		return this.b;
	}

	public void b() {
		try {
			File localFile = new File(this.b, "session.lock");
			DataInputStream localDataInputStream = new DataInputStream(new FileInputStream(localFile));
			try {
				if (localDataInputStream.readLong() != this.e)
				throw new us("The save is being accessed from another location, aborting");
			}
			finally {
				localDataInputStream.close();
			}
		} catch (IOException localIOException) {
			throw new us("Failed to check session lock, aborting");
		}
	}

	public bf a(xa paramxa)
	{
		DimensionBase localDimensionBase = DimensionBase.getDimByProvider(paramxa.getClass());
		if (localDimensionBase.number != 0) {
			File localFile = new File(this.b, "DIM" + localDimensionBase.number);
			localFile.mkdirs();
			return new to(localFile, true);
		}

		return new to(this.b, true);
	}

	public ei c() {
		File localFile = new File(this.b, "level.dat");
		nu localnu3;
		if (localFile.exists()) {
			try {
				nu localnu1 = as.a(new FileInputStream(localFile));
				localnu3 = localnu1.k("Data");

				return new ei(localnu3);
			}
			catch (Exception localException1) {
				localException1.printStackTrace();
			}
		}
		localFile = new File(this.b, "level.dat_old");
		if (localFile.exists()) {
			try {
				nu localnu2 = as.a(new FileInputStream(localFile));
				localnu3 = localnu2.k("Data");

				return new ei(localnu3);
			}
			catch (Exception localException2) {
				localException2.printStackTrace();
			}
		}
		return null;
	}

	public void a(ei paramei, List paramList)
	{
		nu localnu1 = paramei.a(paramList);

		nu localnu2 = new nu();
		localnu2.a("Data", localnu1);
		try
		{
			File localFile1 = new File(this.b, "level.dat_new");
			File localFile2 = new File(this.b, "level.dat_old");
			File localFile3 = new File(this.b, "level.dat");

			as.a(localnu2, new FileOutputStream(localFile1));

			if (localFile2.exists()) localFile2.delete();
			localFile3.renameTo(localFile2);
			if (localFile3.exists()) localFile3.delete();
			localFile1.renameTo(localFile3);
			if (localFile1.exists()) localFile1.delete(); 
		}
		catch (Exception localException) {
			localException.printStackTrace();
		}
	}

	public void a(ei paramei) {
		nu localnu1 = paramei.a();

		nu localnu2 = new nu();
		localnu2.a("Data", localnu1);
		try
		{
			File localFile1 = new File(this.b, "level.dat_new");
			File localFile2 = new File(this.b, "level.dat_old");
			File localFile3 = new File(this.b, "level.dat");

			as.a(localnu2, new FileOutputStream(localFile1));

			if (localFile2.exists()) localFile2.delete();
			localFile3.renameTo(localFile2);
			if (localFile3.exists()) localFile3.delete();
			localFile1.renameTo(localFile3);
			if (localFile1.exists()) localFile1.delete(); 
		}
		catch (Exception localException) {
			localException.printStackTrace();
		}
	}

	public File a(String paramString)
	{
		return new File(this.d, paramString + ".dat");
	}
}