public abstract class xa
{
	public fd a;
	public xv b;
	public boolean c = false;
	public boolean d = false;
	public boolean e = false;
	public float[] f = new float[16];
	public int g = 0;

	private float[] h = new float[4];

	public final void a(fd paramfd)
	{
		this.a = paramfd;
		a();
		e();
	}

	protected void e() {
		float f1 = 0.05F;
		for (int i = 0; i <= 15; i++) {
			float f2 = 1.0F - i / 15.0F;
			this.f[i] = ((1.0F - f2) / (f2 * 3.0F + 1.0F) * (1.0F - f1) + f1);
		}
	}

	protected void a() {
		this.b = new xv(this.a);
	}

	public cl b() {
		return new yf(this.a, this.a.s());
	}

	public boolean a(int paramInt1, int paramInt2)
	{
		int i = this.a.a(paramInt1, paramInt2);

		return i == uu.F.bn;
	}

	public float a(long paramLong, float paramFloat)
	{
		int i = (int)(paramLong % 24000L);
		float f1 = (i + paramFloat) / 24000.0F - 0.25F;
		if (f1 < 0.0F) f1 += 1.0F;
		if (f1 > 1.0F) f1 -= 1.0F;
		float f2 = f1;
		f1 = 1.0F - (float)((Math.cos(f1 * 3.141592653589793D) + 1.0D) / 2.0D);
		f1 = f2 + (f1 - f2) / 3.0F;
		return f1;
	}

	public float[] a(float paramFloat1, float paramFloat2)
	{
		float f1 = 0.4F;
		float f2 = in.b(paramFloat1 * 3.141593F * 2.0F) - 0.0F;
		float f3 = -0.0F;
		if ((f2 >= f3 - f1) && (f2 <= f3 + f1)) {
			float f4 = (f2 - f3) / f1 * 0.5F + 0.5F;
			float f5 = 1.0F - (1.0F - in.a(f4 * 3.141593F)) * 0.99F;
			f5 *= f5;
			this.h[0] = (f4 * 0.3F + 0.7F);
			this.h[1] = (f4 * f4 * 0.7F + 0.2F);
			this.h[2] = (f4 * f4 * 0.0F + 0.2F);
			this.h[3] = f5;
			return this.h;
		}

		return null;
	}

	public bt b(float paramFloat1, float paramFloat2) {
		float f1 = in.b(paramFloat1 * 3.141593F * 2.0F) * 2.0F + 0.5F;
		if (f1 < 0.0F) f1 = 0.0F;
		if (f1 > 1.0F) f1 = 1.0F;

		float f2 = 0.7529412F;
		float f3 = 0.8470588F;
		float f4 = 1.0F;
		f2 *= (f1 * 0.94F + 0.06F);
		f3 *= (f1 * 0.94F + 0.06F);
		f4 *= (f1 * 0.91F + 0.09F);

		return bt.b(f2, f3, f4);
	}

	public boolean f() {
		return true;
	}

	public static xa a(int paramInt) {
		DimensionBase localDimensionBase = DimensionBase.getDimByNumber(paramInt);
		if (localDimensionBase != null) return localDimensionBase.getWorldProvider();
		return null;
	}

	public float d() {
		return 108.0F;
	}

	public boolean c() {
		return true;
	}
}