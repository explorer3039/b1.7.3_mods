import java.util.ArrayList;
import java.util.Random;

public class ACPage {
	private static int nextID = 1;
	
	final int id;
	public final String title;
	ArrayList<Integer> list = new ArrayList<Integer>();
	
	public ACPage() {
		id = 0;
		title = "Minecraft";
		SAPI.acPageAdd(this);
	}
	public ACPage(String title) {
		id = nextID++;
		this.title = title;
		SAPI.acPageAdd(this);
	}
	
	public void addAchievements(ny... achievements) {
		for (ny achievement : achievements) list.add(achievement.e);
	}
	
	public int bgGetSprite(Random random, int x, int y) {
		int sprite = uu.F.bm;
		int rnd = random.nextInt(1+y)+y/2;
		
		if (rnd > 37 || y == 35) sprite = uu.A.bm;
		else if (rnd == 22) sprite = random.nextInt(2) == 0 ? uu.ax.bm : uu.aO.bm;
		else if (rnd == 10) sprite = uu.I.bm;
		else if (rnd == 8) sprite = uu.J.bm;
		else if (rnd > 4) sprite = uu.u.bm;
		else if (rnd > 0) sprite = uu.w.bm;
		
		return sprite;
	}
}