import java.awt.Color;

public class AnimPulse extends AnimBase {
	private int animState = 0, animAdd = 1;
	private final int animMax;
	private final Color c1, c2;
	
	public AnimPulse(int spriteID, String spritePath, int animMax, Color c1, Color c2) {
		super(spriteID,spritePath);
		this.animMax = animMax;
		this.c1 = c1;
		this.c2 = c2;
	}

	public void animFrame() {
		animState += animAdd;
		if (animState == animMax || animState == 0) animAdd *= -1;
		
		drawRect(0,0,size,size,merge(c1,c2,(float)(animState)/(float)(animMax)),mdBlend);
	}
}