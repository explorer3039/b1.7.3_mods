import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class GenDeposit {
	private final int blockID;
	private final List<Integer> set1stOn,setOn;
	private final List<Loc> sides = Arrays.asList(Loc.vecAdjacent());
	private ArrayList<Loc> check = new ArrayList<Loc>(),cantSet = new ArrayList<Loc>(),sidesTmp = new ArrayList<Loc>();
	private final fd world;
	private final Random rand;
	
	public GenDeposit(fd world, int blockID, Integer[] set1stOn, Integer[] setOn) {
		this.world = world;
		this.blockID = blockID;
		this.set1stOn = Arrays.asList(set1stOn);
		this.setOn = Arrays.asList(setOn);
		
		rand = world.r;
	}
	
	public void gen(int pX, int pY, int pZ, int maxAmount, int maxTries) {
		gen(new Loc(pX,pY,pZ),maxAmount,maxTries);
	}
	public void gen(Loc startLoc, int maxAmount, int maxTries) {
		if (!set1stOn.contains(startLoc.getBlock(world))) return;
		
		check.add(startLoc);
		while (maxAmount > 0 && maxTries > 0 && !check.isEmpty()) {
			maxTries--;
			int i;
			
			i = rand.nextInt(check.size());
			Loc side,curLoc = check.get(i); check.remove(i);
			sidesTmp = new ArrayList<Loc>(sides);
			
			if (setOn.contains(curLoc.getBlock(world))) {
				curLoc.setBlock(world,blockID);
				cantSet.add(curLoc);
				check.addAll(Arrays.asList(curLoc.adjacent()));
				maxAmount--;
			}
			
			while (!sidesTmp.isEmpty()) {
				i = rand.nextInt(sidesTmp.size());
				side = sidesTmp.get(i); sidesTmp.remove(i);
				if (cantSet.contains(side)) continue;
			}
		}
	}
	
	public int getGoodY(int pX, int pY, int pZ) {
		int off = 0;
		if (set1stOn.contains(world.a(pX,pY,pZ))) return pY;
		while (true) {
			off++;
			if (pY+off <= 127) {if (set1stOn.contains(world.a(pX,pY+off,pZ))) return pY+off;}
			if (pY-off >= 0) {if (set1stOn.contains(world.a(pX,pY-off,pZ))) return pY-off;}
			if (pY+off > 127 && pY-off < 0) return -1;
		}
	}
}