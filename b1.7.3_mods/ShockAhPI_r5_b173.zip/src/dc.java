import net.minecraft.client.Minecraft;

@SuppressWarnings("unused")
public class dc extends gs
{
	public uo a;
	protected Minecraft b;
	private cu bN = new cu();
	private cu bO = new cu();
	private cu bP = new cu();
	public int portal = -1;

	public dc(Minecraft paramMinecraft, fd paramfd, gr paramgr, int paramInt)
	{
		super(paramfd);
		this.b = paramMinecraft;
		this.m = paramInt;

		if ((paramgr != null) && (paramgr.b != null) && (paramgr.b.length() > 0)) {
			this.bA = ("http://s3.amazonaws.com/MinecraftSkins/" + paramgr.b + ".png");
		}
		this.l = paramgr.b;
	}

	public void b(double paramDouble1, double paramDouble2, double paramDouble3)
	{
		super.b(paramDouble1, paramDouble2, paramDouble3);
	}

	public void f_()
	{
		super.f_();
		this.aw = this.a.a;
		this.ax = this.a.b;
		this.az = this.a.d;
	}

	public void o() {
		if (!this.b.I.a(ep.f)) {
			this.b.u.b(ep.f);
		}
		this.C = this.B;
		
		if (this.portal != 0) {
			DimensionBase localDimensionBase = DimensionBase.getDimByNumber(portal);
			if (this.A) {
				if ((!this.aI.B) && 
						(this.aH != null)) i(null);
	
				if (this.b.r != null) this.b.a((da)null);
	
				if (this.B == 0.0F) {
					this.b.B.a(localDimensionBase.soundTrigger, 1.0F, this.bs.nextFloat() * 0.4F + 0.8F);
				}
				this.B += 0.0125F;
				if (this.B >= 1.0F) {
					this.B = 1.0F;
					if (!this.aI.B) {
						this.z = 10;
						this.b.B.a(localDimensionBase.soundTravel, 1.0F, this.bs.nextFloat() * 0.4F + 0.8F);
						DimensionBase.usePortal(this.portal);
					}
				}
				this.A = false;
			} else {
				if (this.B > 0.0F) this.B -= 0.05F;
				if (this.B < 0.0F) this.B = 0.0F;
			}
		}

		if (this.z > 0) this.z -= 1;
		this.a.a(this);

		if ((this.a.e) && 
				(this.bo < 0.2F)) this.bo = 0.2F;

		c(this.aM - this.bg * 0.35D, this.aW.b + 0.5D, this.aO + this.bg * 0.35D);
		c(this.aM - this.bg * 0.35D, this.aW.b + 0.5D, this.aO - this.bg * 0.35D);
		c(this.aM + this.bg * 0.35D, this.aW.b + 0.5D, this.aO - this.bg * 0.35D);
		c(this.aM + this.bg * 0.35D, this.aW.b + 0.5D, this.aO + this.bg * 0.35D);

		super.o();
	}

	public void o_() {
		this.a.a();
	}

	public void a(int paramInt, boolean paramBoolean) {
		this.a.a(paramInt, paramBoolean);
	}

	public void b(nu paramnu) {
		super.b(paramnu);
		paramnu.a("Score", this.g);
	}

	public void a(nu paramnu) {
		super.a(paramnu);
		this.g = paramnu.e("Score");
	}

	public void r() {
		super.r();
		this.b.a((da)null);
	}

	public void a(yk paramyk) {
		this.b.a(new yc(paramyk));
	}

	public void a(lw paramlw) {
		this.b.a(new hp(this.c, paramlw));
	}

	public void a(int paramInt1, int paramInt2, int paramInt3) {
		this.b.a(new oo(this.c, this.aI, paramInt1, paramInt2, paramInt3));
	}

	public void a(sk paramsk) {
		this.b.a(new ov(this.c, paramsk));
	}

	public void a(az paramaz)
	{
		this.b.a(new gq(this.c, paramaz));
	}

	public void b(sn paramsn, int paramInt) {
		this.b.j.a(new em(this.b.f, paramsn, this, -0.5F));
	}

	public int s() {
		return this.c.f();
	}

	public void a(String paramString) {
	}

	public boolean t() {
		return (this.a.e) && (!this.u);
	}

	public void d_(int paramInt) {
		int i = this.Y - paramInt;
		if (i <= 0) {
			this.Y = paramInt;
			if (i < 0)
			this.by = (this.E / 2);
		}
		else {
			this.au = i;
			this.Z = this.Y;
			this.by = this.E;
			b(i);
			this.aa = (this.ab = 10);
		}
	}

	public void p_() {
		DimensionBase.respawn(false, 0);
	}

	public void v()
	{
	}

	public void b(String paramString)
	{
		this.b.v.c(paramString);
	}

	public void a(vr paramvr, int paramInt) {
		if (paramvr == null) {
			return;
		}
		if (paramvr.d()) {
			ny localny = (ny)paramvr;
			if ((localny.c == null) || (this.b.I.a(localny.c))) {
				if (!this.b.I.a(localny)) {
					this.b.u.a(localny);
				}
				this.b.I.a(paramvr, paramInt);
			}
		} else {
			this.b.I.a(paramvr, paramInt);
		}
	}

	private boolean d(int paramInt1, int paramInt2, int paramInt3) {
		return this.aI.h(paramInt1, paramInt2, paramInt3);
	}

	protected boolean c(double paramDouble1, double paramDouble2, double paramDouble3) {
		int i = in.b(paramDouble1);
		int j = in.b(paramDouble2);
		int k = in.b(paramDouble3);

		double d1 = paramDouble1 - i;
		double d2 = paramDouble3 - k;

		if ((d(i, j, k)) || (d(i, j + 1, k))) {
			int m = (!d(i - 1, j, k)) && (!d(i - 1, j + 1, k)) ? 1 : 0;
			int n = (!d(i + 1, j, k)) && (!d(i + 1, j + 1, k)) ? 1 : 0;
			int i1 = (!d(i, j, k - 1)) && (!d(i, j + 1, k - 1)) ? 1 : 0;
			int i2 = (!d(i, j, k + 1)) && (!d(i, j + 1, k + 1)) ? 1 : 0;

			int i3 = -1;
			double d3 = 9999.0D;
			if ((m != 0) && (d1 < d3)) {
				d3 = d1;
				i3 = 0;
			}
			if ((n != 0) && (1.0D - d1 < d3)) {
				d3 = 1.0D - d1;
				i3 = 1;
			}
			if ((i1 != 0) && (d2 < d3)) {
				d3 = d2;
				i3 = 4;
			}
			if ((i2 != 0) && (1.0D - d2 < d3)) {
				d3 = 1.0D - d2;
				i3 = 5;
			}

			float f = 0.1F;
			if (i3 == 0) this.aP = (-f);
			if (i3 == 1) this.aP = f;
			if (i3 == 4) this.aR = (-f);
			if (i3 == 5) this.aR = f;
		}

		return false;
	}
}