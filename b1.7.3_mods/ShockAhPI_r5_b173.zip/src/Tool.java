import java.util.ArrayList;

public class Tool extends gm {
	static {
		SAPI.showText();
	}
	
	public final boolean usingSAPI;
	public ToolBase toolBase;
	public final float baseDamage, basePower, defaultSpeed, toolSpeed;
	
	public ArrayList<BlockHarvestPower> mineBlocks = new ArrayList<BlockHarvestPower>();
	public ArrayList<ln> mineMaterials = new ArrayList<ln>();
	
	public Tool(boolean usingSAPI, ToolBase toolBase, int itemID, int uses, float baseDamage, float basePower, float toolSpeed) {
		this(usingSAPI,toolBase,itemID,uses,baseDamage,basePower,toolSpeed,1F);
	}
	public Tool(boolean usingSAPI, ToolBase toolBase, int itemID, int uses, float baseDamage, float basePower, float toolSpeed, float defaultSpeed) {
		super(itemID);
		e(uses);
		bg = 1;
		
		this.usingSAPI = usingSAPI;
		this.toolBase = toolBase;
		this.baseDamage = baseDamage;
		this.basePower = basePower;
		this.toolSpeed = toolSpeed;
		this.defaultSpeed = defaultSpeed;
	}
	
	public boolean b() {
		return true;
	}
	
	public boolean a(iz stack, ls living, ls living2) {
		stack.a(2,living2);
		return true;
	}

	public boolean a(iz stack, int blockID, int x, int y, int z, ls living) {
		stack.a(1,living);
		return true;
	}
	
	public int a(sn entity) {
		return (int)Math.floor(baseDamage);
	}
	
	public float getPower() {
		return basePower;
	}
	public float a(iz stack, uu block) {
		return canHarvest(block) ? toolSpeed : defaultSpeed;
	}
	
	public boolean canHarvest(uu block) {
		if (toolBase != null) if (toolBase.canHarvest(block,getPower())) return true;
		for (ln material : mineMaterials) if (material == block.bA) return true;
		for (BlockHarvestPower power : mineBlocks) if (block.bn == power.blockID || getPower() >= power.percentage) return true;
		return false;
	}
}