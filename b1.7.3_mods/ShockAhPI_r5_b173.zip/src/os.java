import net.minecraft.client.Minecraft;

public class os extends ob {
	private int c = -1;
	private int d = -1;
	private int e = -1;
	private float f = 0.0F;
	private float g = 0.0F;
	private float h = 0.0F;
	private int i = 0;

	public os(Minecraft paramMinecraft) {
		super(paramMinecraft);
	}

	public void a(gs paramgs)
	{
		paramgs.aS = -180.0F;
	}

	public boolean b(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
	{
		int j = this.a.f.a(paramInt1, paramInt2, paramInt3);
		int k = this.a.f.e(paramInt1, paramInt2, paramInt3);
		boolean bool1 = super.b(paramInt1, paramInt2, paramInt3, paramInt4);

		iz localiz = this.a.h.G();
		boolean bool2 = this.a.h.b(uu.m[j]);
		if (localiz != null) {
			localiz.a(j, paramInt1, paramInt2, paramInt3, this.a.h);
			if (localiz.a == 0) {
				localiz.a(this.a.h);
				this.a.h.H();
			}
		}
		if ((bool1) && (bool2)) {
			if (SAPI.interceptHarvest(a.f,a.h,new Loc(paramInt1,paramInt2,paramInt3),j,k)) return bool1;
			uu.m[j].a(this.a.f, this.a.h, paramInt1, paramInt2, paramInt3, k);
		}
		return bool1;
	}

	public void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
	{
		this.a.f.a(this.a.h, paramInt1, paramInt2, paramInt3, paramInt4);
		int j = this.a.f.a(paramInt1, paramInt2, paramInt3);
		if ((j > 0) && (this.f == 0.0F)) uu.m[j].b(this.a.f, paramInt1, paramInt2, paramInt3, this.a.h);
		if ((j > 0) && (uu.m[j].a(this.a.h) >= 1.0F))
		b(paramInt1, paramInt2, paramInt3, paramInt4);
	}

	public void a()
	{
		this.f = 0.0F;
		this.i = 0;
	}

	public void c(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
		if (this.i > 0) {
			this.i -= 1;
			return;
		}
		if ((paramInt1 == this.c) && (paramInt2 == this.d) && (paramInt3 == this.e)) {
			int j = this.a.f.a(paramInt1, paramInt2, paramInt3);
			if (j == 0) return;
			uu localuu = uu.m[j];

			this.f += localuu.a(this.a.h);

			if ((this.h % 4.0F == 0.0F) && 
					(localuu != null)) {
				this.a.B.b(localuu.by.d(), paramInt1 + 0.5F, paramInt2 + 0.5F, paramInt3 + 0.5F, (localuu.by.b() + 1.0F) / 8.0F, localuu.by.c() * 0.5F);
			}

			this.h += 1.0F;

			if (this.f >= 1.0F) {
				b(paramInt1, paramInt2, paramInt3, paramInt4);
				this.f = 0.0F;
				this.g = 0.0F;
				this.h = 0.0F;
				this.i = 5;
			}
		} else {
			this.f = 0.0F;
			this.g = 0.0F;
			this.h = 0.0F;
			this.c = paramInt1;
			this.d = paramInt2;
			this.e = paramInt3;
		}
	}

	public void a(float paramFloat) {
		if (this.f <= 0.0F) {
			this.a.v.b = 0.0F;
			this.a.g.i = 0.0F;
		} else {
			float f1 = this.g + (this.f - this.g) * paramFloat;
			this.a.v.b = f1;
			this.a.g.i = f1;
		}
	}

	public float b() {
		return SAPI.reachGet();
	}

	public void a(fd paramfd) {
		super.a(paramfd);
	}

	public void c() {
		this.g = this.f;
		this.a.B.c();
	}
}