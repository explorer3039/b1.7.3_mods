public interface IReach {
	public boolean reachItemMatches(iz stack);
	public float getReach(iz stack);
}