public class dq extends Tool {
	public bu a;
	
	protected dq(int itemID, int damage, bu material, uu[] blocks) {
		super(false,null,itemID,material.a(),damage+material.c(),getToolPower(material),material.b());
		a = material;
		toolBase = getToolBase();
		for (uu block : blocks) mineBlocks.add(new BlockHarvestPower(block.bn,0));
	}
	
	public ToolBase getToolBase() {
		if (this instanceof au) return ToolBase.Pickaxe;
		if (this instanceof ta) return ToolBase.Axe;
		if (this instanceof wc) return ToolBase.Shovel;
		return null;
	}
	
	public static float getToolPower(bu material) {
		if (material == bu.d) return 80;
		if (material == bu.c) return 60;
		if (material == bu.b) return 40;
		return 20;
	}
	
	public boolean canHarvest(uu block) {
		if (!usingSAPI && !isBlockOnList(block.bn)) {
			if (this instanceof au) {
				if (bf <= 369) return false;
				if (block.bA == ln.e || block.bA == ln.s) return true;
				if (block.bA == ln.f && basePower >= 40) return true;
			} else if (this instanceof ta) {
				if (bf <= 369) return false;
				if (block.bA == ln.d || block.bA == ln.i || block.bA == ln.j || block.bA == ln.v || block.bA == ln.x) return true;
			} else if (this instanceof wc) {
				if (bf <= 369) return false;
				if (block.bA == ln.b || block.bA == ln.c || block.bA == ln.n || block.bA == ln.t || block.bA == ln.u || block.bA == ln.w) return true;
			}
		}
		return super.canHarvest(block);
	}
	
	private boolean isBlockOnList(int blockID) {
		for (BlockHarvestPower power : mineBlocks) if (power.blockID == blockID) return true;
		for (BlockHarvestPower power : toolBase.mineBlocks) if (power.blockID == blockID) return true;
		return false;
	}
}