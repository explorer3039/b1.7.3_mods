import java.util.Random;

public class er extends pg
{
	public boolean a(fd paramfd, Random paramRandom, int paramInt1, int paramInt2, int paramInt3)
	{
		int i = 3;
		int j = paramRandom.nextInt(2) + 2;
		int k = paramRandom.nextInt(2) + 2;

		int m = 0;
		int i1;
		int i2;
		for (int n = paramInt1 - j - 1; n <= paramInt1 + j + 1; n++) {
			for (i1 = paramInt2 - 1; i1 <= paramInt2 + i + 1; i1++) {
				for (i2 = paramInt3 - k - 1; i2 <= paramInt3 + k + 1; i2++) {
					ln localln = paramfd.f(n, i1, i2);
					if ((i1 == paramInt2 - 1) && (!localln.a())) return false;
					if ((i1 == paramInt2 + i + 1) && (!localln.a())) return false;

					if (((n != paramInt1 - j - 1) && (n != paramInt1 + j + 1) && (i2 != paramInt3 - k - 1) && (i2 != paramInt3 + k + 1)) || 
							(i1 != paramInt2) || (!paramfd.d(n, i1, i2)) || (!paramfd.d(n, i1 + 1, i2))) continue;
					m++;
				}

			}

		}

		if ((m < 1) || (m > 5)) return false;

		for (int n = paramInt1 - j - 1; n <= paramInt1 + j + 1; n++) {
			for (i1 = paramInt2 + i; i1 >= paramInt2 - 1; i1--) {
				for (i2 = paramInt3 - k - 1; i2 <= paramInt3 + k + 1; i2++)
				{
					if ((n == paramInt1 - j - 1) || (i1 == paramInt2 - 1) || (i2 == paramInt3 - k - 1) || (n == paramInt1 + j + 1) || (i1 == paramInt2 + i + 1) || (i2 == paramInt3 + k + 1)) {
						if ((i1 >= 0) && (!paramfd.f(n, i1 - 1, i2).a()))
						paramfd.f(n, i1, i2, 0);
						else if (paramfd.f(n, i1, i2).a()) {
							if ((i1 == paramInt2 - 1) && (paramRandom.nextInt(4) != 0))
							paramfd.f(n, i1, i2, uu.ap.bn);
							else
							paramfd.f(n, i1, i2, uu.x.bn);
						}
					}
					else {
						paramfd.f(n, i1, i2, 0);
					}
				}
			}
		}

		for (int n = 0; n < 2; n++) {
			for (i1 = 0; i1 < 3; i1++) {
				i2 = paramInt1 + paramRandom.nextInt(j * 2 + 1) - j;
				int i3 = paramInt2;
				int i4 = paramInt3 + paramRandom.nextInt(k * 2 + 1) - k;
				if (!paramfd.d(i2, i3, i4))
				continue;
				int i5 = 0;
				if (paramfd.f(i2 - 1, i3, i4).a()) i5++;
				if (paramfd.f(i2 + 1, i3, i4).a()) i5++;
				if (paramfd.f(i2, i3, i4 - 1).a()) i5++;
				if (paramfd.f(i2, i3, i4 + 1).a()) i5++;

				if (i5 != 1)
				continue;
				paramfd.f(i2, i3, i4, uu.av.bn);
				js localjs = (js)paramfd.b(i2, i3, i4);
				for (int i6 = 0; i6 < 8; i6++) {
					iz localiz = a(paramRandom);
					if (localiz == null) continue; localjs.a(paramRandom.nextInt(localjs.a()), localiz);
				}
				for (int i6 = 0; i6 < Math.min(19,SAPI.dungeonGetAmountOfGuaranteed()); i6++) {
					iz stack = SAPI.dungeonGetGuaranteed(i6).getStack();
					if (stack == null) continue; localjs.a(paramRandom.nextInt(localjs.a()),stack);
				}

				break;
			}

		}

		paramfd.f(paramInt1, paramInt2, paramInt3, uu.at.bn);
		cy localcy = (cy)paramfd.b(paramInt1, paramInt2, paramInt3);
		localcy.a(b(paramRandom));

		return true;
	}

	private iz a(Random paramRandom) {
		return SAPI.dungeonGetRandomItem();
	}

	private String b(Random paramRandom) {
		return SAPI.dungeonGetRandomMob();
	}
}