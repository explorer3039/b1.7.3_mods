Merlwiz79's Unofficial SDK's Mods for Minecraft 1.7.3

Version 1

------------
Installation
------------

1. Open the .zip archive (already done)
2. Open your .minecraft directory Windows:(%appdata%\.minecraft) Linux:(~/.minecraft) Mac:(~/Library/Application Support/minecraft)
3. Go to .minecraft/bin and open your minecraft.jar in winRAR, winZIP, 7zip or any other suitiable program
4. Drag the files from "jar_files"(NOT THE JAR_FILES FOLDER) into the minecraft.jar
5. Drag everything inside the "resources" folder into the folder called "resources".
6. Copy the mod_*.properties files (in the zip file) into the .minecraft folder. Windows:(%appdata%\.minecraft) Mac:(~/Library/Application Support/minecraft/bin) Linux:(~/.minecraft) 
7. Install Risugami's ModLoader Beta 1.7.3 (similar instructions to above)
8. Install Flan's Unofficial ModLoaderMp 1.7.3 v2(similar instructions to above)
9. DELETE THE META-INF FOLDER
10. Play!
