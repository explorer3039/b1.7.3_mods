http://www.minecraftforum.net/forums/mapping-and-modding/minecraft-mods/1273278-1-7-3-ninjacraft-v1
