package net.minecraft.src;

import net.minecraft.client.Minecraft;

public class mod_Nyctophobia extends BaseMod {

	@Override
	public String Version() {
		return "Beta 1.6.6";
	}

	protected mod_Nyctophobia() {
		ModLoader.SetInGameHook(this,true,true);
	}

	@Override
	public void OnTickInGame(Minecraft mc) {

		int timeDawn = 5000;
		int timeDusk = 19000;
		int timeMult = 33;
		
		boolean fearDay = false;
		boolean fearDark = true;
		
		int curTime = (int)((mc.theWorld.getWorldTime() + 6000) % 24000);
		
		if( curTime >= timeDawn && curTime <= timeDusk ){
			if( fearDay )
				mc.theWorld.setWorldTime( mc.theWorld.getWorldTime() + timeMult);
		} else {
			if( fearDark )
				mc.theWorld.setWorldTime( mc.theWorld.getWorldTime() + timeMult);
		}
	}
	
	
}
