package net.minecraft.src;

public class ItemTimer extends Item {

	public ItemTimer(int i) {
		super(i);
		hasSubtypes = false;
		setMaxDamage(0);
	}

    public void onUpdate(ItemStack itemstack, World world, Entity entity, int i, boolean flag)
    {
    	if(active) {
    		if(timer <= 4000)
    			color = 0x00FF00;
    		else if(timer <= 5500) {
    			color = 0xFFFF00;
    			if((timer % 50) == 0)
    	            world.playSoundAtEntity(entity, "note.harp", 1.0F, 1.5F);
//                    ModLoader.getMinecraftInstance().sndManager.playSoundFX("note.harp", 15.0F, 1.5F);
    		} else if(timer <= 6000) {
    			color = 0xFF0000;
    			if((timer % 10) == 0)
    	            world.playSoundAtEntity(entity, "note.harp", 1.0F, 3.0F);
//                    ModLoader.getMinecraftInstance().sndManager.playSoundFX("note.harp", 15.0F, 3F);
    		} else {
    			active = false;
    			timer = 0;
    			color = 0xFFFFFF;
    		}
    		timer++;
    	}
    }

    public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer entityplayer)
    {
    	if(timer == 0)
    		active = true;
    	else {
    		active = false;
    		timer = 0;
    		color = 0xFFFFFF;
    	}

        return itemstack;
    }

    public int getColorFromDamage(int i)
    {
        return color;
    }
    
    private int timer = 0;
    private boolean active = false;
    private int color = 0xFFFFFF;
}
