package net.minecraft.src;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import net.minecraft.client.Minecraft;

public class mod_ItemTimer extends BaseMod {
	
	public mod_ItemTimer() {
		setIDs();
		
		itemtimer = (new ItemTimer(itimer-256)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/ItemTimer/itemtimer.png")).setItemName("itemTimer");
        ModLoader.AddName(itemtimer, "Item Timer");
        ModLoader.AddShapelessRecipe(new ItemStack(itemtimer, 1), new Object[] {
            Item.egg, Item.pocketSundial
        });
	}
	
	public void setIDs() {
		File dir = Minecraft.getAppDir("minecraft/mods/SanAndreasP_mods/ItemTimer");
		File file = new File(dir, "config.txt");
		
		try {
			if (!file.exists()) {
				System.out.println("config.txt not found - Load mod defaults!");
				FileWriter fstream = new FileWriter(file,true);
				BufferedWriter out = new BufferedWriter(fstream);
				out.write("< ITEM ID >\n");
				out.write("itemTimer=" + Integer.toString(itimer));
				out.close();
				System.out.println("config.txt successfully created.");
			} else {
				FileReader fstream = new FileReader(file);
				BufferedReader in = new BufferedReader(fstream);
				
				in.readLine();
				itimer = Integer.valueOf((in.readLine()).replaceAll(".*?=", ""));
				in.close();
				System.out.println("config.txt successfully readed.");
			}
			
			System.out.println("Item ID is now: " + itimer);
		}
		catch (IOException e) {
			System.out.println(e);
		}
	}
	
	@Override
	public String Version() {
		return "1.7.3 v. 1.0";
	}
	
	public static Item itemtimer;
	public static int itimer = 3000;
}
