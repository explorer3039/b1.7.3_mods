Heya I am Chase, the lazy programmer. A person with far too many years of programming experience. :(

But anyway, I have here for you a simple mod to make your life easier.

http://www.minecraftforum.net/viewtopic.php?f=25&t=170764


=== INSTALL INSTRUCTIONS ===

1. Locate your minecraft.jar file. On Windows, it's in %APPDATA%/.minecraft/bin
2. Create a backup of minecraft.jar
3. Open minecraft.jar in an archive editor (WinRar/7-Zip/etc)
4. Delete the META-INF folder.
5. Copy the files from the downloaded archive file into the jar file, replacing previous files.
6. Run Minecraft and test!

Modifies the ItemBlock class only. Not many mods do this (that I know of), so should be fairly compatible.


=== VERSION HISTORY ===

Version 1.3 - 20110725:1149
+Option to try and use it in Multiplayer again (probably will not work)
-Removed original mode (sorry)
=Hacked edition, since MCP toolchain is hard is a pain to get and use.

Version 1.2 - 20110210:0015
+Added configuration file, contiaining key config and block placement number. (req)
+Added the ability to switch which mode is the secondary one (in config).
+Added secondary mode to fast build blocks off from a facing side. (req)
+Improved the placement detection

Version 1.1 - 20110207:2200
+Added Vertical placement
=Streamlined algorithms

Version 1.0 - 20110207:1055
+Initial Release


=== DESCRIPTION ===

Alright, here is the short of it for you.

Hold control or alt and place a block, it will place as many as possible in that direction
till it hits something or you run out of blocks to place. Very useful for bridge building.

It can do both vertical and horizontal placement.


=== CONFIGURATION ===

The configuration file is found in your main minecraft directory, above the bin directory, the file is called fastbuild_config.txt
Run minecraft once with the mod installed to get the configuration file.


build_key
** The key that must be pressed to use fast build.

max_stack_build_num
** Determines the maximum number of items that will be attempted to be placed at one time.


=== Credits ===

Chase @ csdgn.org


