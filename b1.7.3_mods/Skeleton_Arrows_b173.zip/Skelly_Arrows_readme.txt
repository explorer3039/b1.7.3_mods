Digital Cougar : 07/07/2011

This mod makes it so the player can pick up arrows fired by skeletons, just as they can pick up arrows they fired themselves.

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
Use this mod at your own risk! Although I have extensively playtested it, I cannot and will not guarantee that it won't cause your computer to spontaneously erupt into flames, your plants, pets and/or family members to wither and die, your power to go off, sunspots and solar eruptions, plagues, oceans of blood, demonic possessions, or monkeys to fly out of your butt. The author is not responsible for any damages, direct or consequential, that may result from its use.
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=