# Description:
	To get the description go to: 	http://www.minecraftforum.net/topic/286677-165-magic-chest-wood-on-steroids-v07a/
	To get the ToDo List go to:		https://spreadsheets.google.com/ccc?key=0AkDunj0oG2uNdHFadjAtWkQ3amY2RnZXbDFtZU9peUE


# Installation:
	1. Go to your .minecraft folder
	2. Open the minecraft.jar in /bin with WinRar
	3. Drag all .class files and the easyChest folder of this modification into the minecraft.jar
	4. DELETE META-INF FOLDER!
	5. Optional: Copy the MagicChestConfig.txt in your .minecraft folder to configure this modification


# Troubleshooting:
	- Did you delete META-INF?
	- Do you have the right version of your ModLoader and Minecraft?
	- Are all class files at the right place?
	
	If you can answer all of these questions with "HELL YES!", go to #minecraftforumlink and post the issue with
		- a description of what you have done
		- or/and an error log
		(both options are preferable)
		
	Thanks for posting the issue.


# Licensing:
	If you have licensing questions, read the license.txt, which should have been shipped with Magic Chest.