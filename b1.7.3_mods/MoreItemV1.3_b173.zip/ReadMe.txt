    xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
   xx                                                                    xx
  xxx     - MM-MM OOOOO RRRR- EEEEE   IIIII TTTTT EEEEE MM-MM SSSSS -    xxx
 xxxx   --- M-M-M O---O R---R E----   --I-- --T-- E---- M-M-M S---- ---  xxxx
xxxxx  ---- M---M O---O RRRR- EEEEE   --I-- --T-- EEEEE M---M SSSSS ---- xxxxx
 xxxx   --- M---M O---O R--R- E----   --I-- --T-- E---- M---M ----S ---  xxxx
  xxx     - M---M OOOOO R---R EEEEE   IIIII --T-- EEEEE M---M SSSSS -    xxx
   xx                                                                    xx
    xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

Well I won't be doing that again...

Anyways were were we? Excuse my manners, my name is Tidus. Never had that before eh?
A talking ReadMe file? Pah! Well you can brag to your freinds that your computer can
talk to you, as I am doing now. But I digress. You wan't to know why I made the mod
no doubt? Can't say I know myself, but I made it, and it's pretty damn good, if the
computers can say so itself. Which it does. This mod adds (and will be removed after)
a few blocks supposidly coming out in the 1.8 update. I talk of the stone bricks,
if you  have seen the wiki, you know what they are and what they will be used for.
Ruins. Nice touch. I am looking to the creative mode more than anything but that is
me. Unless these bricks are so rare you have more chances of winnig the Euromillion
lottery than finding them I will consider keeping the recipies shown as a way 
of easier crafting. I digress even more... Lol. Yes, I used an acronym. Is that how
it's spelt? Meh, I'll find out soon enough. But until a do, enjoy the mod I made, 
because my Crying Obsidian house sitting on top of a cliff is a damn fine sight.
And I do say so myself.

-- The Mod --

As I said before (and the title should be a great hint), this mod adds a few more items.
This mod, apart from previous tutorials mentioned in my first mod (FFXCraft, or FinalCraftX
, project when tits up when i got 100 errors when i recomped the files kind of destroyed
any hope of making the mod public.) or my first released mod, Duskfang. Google that and you will
find what I replicated. But no more chit-chat, in the mod we have so far :

Blocks :
-Crying Obsiidan
-Stone Brick
-Cracked Stone Brick
-Mossy Stone Brick

Items :
-The Quiver
-Colored Shears, all working.

-- Change Log : --

V1.0: Initial Release. The easiest version...
V1.1: Minor bug fixes, including Quiver not being there and the Crafting recipie for Crying Obsidian
V1.2: Added the Stone Bricks
V1.3: Added 4 Colored Shears (red,white. Fixed the Cobblestone showing as "Stone Block". Turns out the java name for it is stonebrick...
V1.4: More Shears, every dye color, and colored wood?

-- Credits --

Tuts that were used in the making of this mod were the same for my Duskfang one. Ziddia (who I adore) and simo-417's
tutorials were my inspiration. And some MCForums user named Noleon. No help was used, and V1.3 was made on my laptop
during my 2 week holiday at the sea, in a bungalow with zip internet. I hated the bloody place.

-- Recipies --

Crying Obsidian :
XO : X = Obsidian and O = Blue dye.

Stone Brick / Mossy Stone Brick :
XX
XX 
Where X is either Stone or Mossy Cobblestone.

Quiver : 
XO   
X O
XO
X is leather and O is string.

Fill the quiver : 
OOO
OXO
OOO

O are Arrows and X is an empty Quiver. 
The result is 8 arrows in one space. 
To unfill it, put it in a crafting space. It however sacrifices the quiver.
But 8*64 arrows is a lot in one inventory space... And cows are commun...

The Colored Shears : 
Put a dye and shears in a crafting table and you have made your colored shears! They are slightly faster and more resistant.


Have fun!
   

  xXtidusFRXx