package net.minecraft.src;

import java.util.Random;

public class BlockMoreItems extends Block
{

    protected BlockMoreItems(int i, int j)
    {
        super(i, j, Material.rock);
    }

    public int idDropped(int i, Random random)
    {
        if(blockID == mod_MoreItems.cryingobsidian.blockID)
        {
            return mod_MoreItems.cryingobsidian.blockID;
        }
		
		if(blockID== mod_MoreItems.stonebrick2.blockID)
		{
		    return mod_MoreItems.crackedstone.blockID;
		}
		
		if(blockID== mod_MoreItems.mossystone.blockID)
		{
		    return mod_MoreItems.mossystone.blockID;
		}
		
		if(blockID== mod_MoreItems.crackedstone.blockID)
		{
		    return mod_MoreItems.crackedstone.blockID;
		}else
		{
            return blockID;
        }
    }
}