package net.minecraft.src;

import java.io.File;
import java.util.Random;
import net.minecraft.client.Minecraft;

public class mod_MoreItems extends BaseMod
{

    public mod_MoreItems()
	{
	ModLoader.RegisterBlock(cryingobsidian);
	ModLoader.RegisterBlock(stonebrick2);
	ModLoader.RegisterBlock(mossystone);
	ModLoader.RegisterBlock(crackedstone);
	cryingobsidian.blockIndexInTexture = ModLoader.addOverride("/terrain.png", "/MoreItems/cryingobsidian.png");
	stonebrick2.blockIndexInTexture = ModLoader.addOverride("/terrain.png", "/MoreItems/stonebrick.png");
	mossystone.blockIndexInTexture = ModLoader.addOverride("/terrain.png", "/MoreItems/mossystone.png");
	crackedstone.blockIndexInTexture = ModLoader.addOverride("/terrain.png", "/MoreItems/crackedstone.png");
	quiverItem.iconIndex = ModLoader.addOverride("/gui/items.png", "/MoreItems/quiver.png");
	quiverfullItem.iconIndex = ModLoader.addOverride("/gui/items.png", "/MoreItems/fullquiver.png");
	yellowshears.iconIndex = ModLoader.addOverride("/gui/items.png", "/MoreItems/yellowshears.png");
	redshears.iconIndex = ModLoader.addOverride("/gui/items.png", "/MoreItems/redshears.png");
	blueshears.iconIndex = ModLoader.addOverride("/gui/items.png", "/MoreItems/blueshears.png");
	whiteshears.iconIndex = ModLoader.addOverride("/gui/items.png", "/MoreItems/whiteshears.png");
	blackshears.iconIndex = ModLoader.addOverride("/gui/items.png", "/MoreItems/blackshears.png");
	brownshears.iconIndex = ModLoader.addOverride("/gui/items.png", "/MoreItems/brownshears.png");
	greenshears.iconIndex = ModLoader.addOverride("/gui/items.png", "/MoreItems/greenshears.png");
	greyshears.iconIndex = ModLoader.addOverride("/gui/items.png", "/MoreItems/greyshears.png");
	lightblueshears.iconIndex = ModLoader.addOverride("/gui/items.png", "/MoreItems/lightblueshears.png");
	lightgreyshears.iconIndex = ModLoader.addOverride("/gui/items.png", "/MoreItems/lightgreyshears.png");
	limeshears.iconIndex = ModLoader.addOverride("/gui/items.png", "/MoreItems/limeshears.png");
	magentashears.iconIndex = ModLoader.addOverride("/gui/items.png", "/MoreItems/magentashears.png");
	pinkshears.iconIndex = ModLoader.addOverride("/gui/items.png", "/MoreItems/pinkshears.png");
	purpleshears.iconIndex = ModLoader.addOverride("/gui/items.png", "/MoreItems/purpleshears.png");
	cyanshears.iconIndex = ModLoader.addOverride("/gui/items.png", "/MoreItems/cyanshears.png");
	orangeshears.iconIndex = ModLoader.addOverride("/gui/items.png", "/MoreItems/orangeshears.png");
	ModLoader.AddName(cryingobsidian, "Crying Obsidian");
	ModLoader.AddName(stonebrick2, "Stone Brick");
	ModLoader.AddName(mossystone, "Mossy Stone Brick");
	ModLoader.AddName(crackedstone, "Cracked Stone Brick");
	ModLoader.AddName(quiverItem, "Quiver");
	ModLoader.AddName(quiverfullItem, "Full Quiver");
	ModLoader.AddName(yellowshears, "Yellow Shears");
	ModLoader.AddName(redshears, "Red Shears");
	ModLoader.AddName(blueshears, "Blue Shears");
	ModLoader.AddName(whiteshears, "White Shears");
	ModLoader.AddName(blackshears, "Black Shears");
	ModLoader.AddName(brownshears, "Brown Shears");
	ModLoader.AddName(greenshears, "Green Shears");
	ModLoader.AddName(greyshears, "Grey Shears");
	ModLoader.AddName(lightblueshears, "Light Blue Shears");
	ModLoader.AddName(lightgreyshears, "Light Grey Shears");
	ModLoader.AddName(limeshears, "Lime Shears");
	ModLoader.AddName(magentashears, "Magenta Shears");
	ModLoader.AddName(pinkshears, "Pink Shears");
	ModLoader.AddName(purpleshears, "Purple Shears");
	ModLoader.AddName(cyanshears, "Cyan Shears");
	ModLoader.AddName(orangeshears, "Orange Shears");
	ModLoader.AddRecipe(new ItemStack(quiverItem, 1), new Object[] {
        "XO ", "X O", "XO ", Character.valueOf('X'), Item.leather, Character.valueOf('O'), Item.silk
        });
	ModLoader.AddRecipe(new ItemStack(quiverfullItem, 1), new Object[] {
        "XXX", "XOX", "XXX", Character.valueOf('X'), Item.arrow, Character.valueOf('O'), quiverItem
        });
	ModLoader.AddRecipe(new ItemStack(Item.arrow, 8), new Object[] {
        "X", Character.valueOf('X'), quiverfullItem
        });
	ModLoader.AddRecipe(new ItemStack(cryingobsidian, 9), new Object[] {
        "XXX", "XOX", "XXX", Character.valueOf('X'), Block.obsidian, Character.valueOf('O'), Item.diamond
        });
	ModLoader.AddRecipe(new ItemStack(Item.silk, 4), new Object[] {
        "X", Character.valueOf('X'), Block.cloth
        });
	ModLoader.AddRecipe(new ItemStack(Block.web, 1), new Object[] {
        "XXX", "XXX", "XXX", Character.valueOf('X'), Item.silk
        });
	ModLoader.AddRecipe(new ItemStack(Item.silk, 9), new Object[] {
        "X", Character.valueOf('X'), Block.web
        });
	ModLoader.AddRecipe(new ItemStack(stonebrick2, 4), new Object[] {
	    "XX", "XX", Character.valueOf('X'), Block.stone
		});
	ModLoader.AddRecipe(new ItemStack(mossystone, 4), new Object[] {
	    "XX", "XX", Character.valueOf('X'), Block.cobblestoneMossy 
		});
	ModLoader.AddShapelessRecipe(new ItemStack(yellowshears, 1), new Object[] {
	    new ItemStack(Item.shears, 1), new ItemStack(Item.dyePowder, 1, 11) 
		});
	ModLoader.AddShapelessRecipe(new ItemStack(redshears, 1), new Object[] {
	    new ItemStack(Item.shears, 1), new ItemStack(Item.dyePowder, 1, 1) 
		});
	ModLoader.AddShapelessRecipe(new ItemStack(blueshears, 1), new Object[] {
	    new ItemStack(Item.shears, 1), new ItemStack(Item.dyePowder, 1, 4) 
		});
	ModLoader.AddShapelessRecipe(new ItemStack(whiteshears, 1), new Object[] {
	    new ItemStack(Item.shears, 1), new ItemStack(Item.dyePowder, 1, 15) 
		});
	ModLoader.AddShapelessRecipe(new ItemStack(brownshears, 1), new Object[] {
	    new ItemStack(Item.shears, 1), new ItemStack(Item.dyePowder, 1, 3) 
		});
	ModLoader.AddShapelessRecipe(new ItemStack(blackshears, 1), new Object[] {
	    new ItemStack(Item.shears, 1), new ItemStack(Item.dyePowder, 1, 1) 
		});
	ModLoader.AddShapelessRecipe(new ItemStack(greenshears, 1), new Object[] {
	    new ItemStack(Item.shears, 1), new ItemStack(Item.dyePowder, 1, 2) 
		});
	ModLoader.AddShapelessRecipe(new ItemStack(greyshears, 1), new Object[] {
	    new ItemStack(Item.shears, 1), new ItemStack(Item.dyePowder, 1, 8) 
		});
	ModLoader.AddShapelessRecipe(new ItemStack(lightblueshears, 1), new Object[] {
	    new ItemStack(Item.shears, 1), new ItemStack(Item.dyePowder, 1, 12) 
		});
	ModLoader.AddShapelessRecipe(new ItemStack(lightgreyshears, 1), new Object[] {
	    new ItemStack(Item.shears, 1), new ItemStack(Item.dyePowder, 1, 7) 
		});
	ModLoader.AddShapelessRecipe(new ItemStack(limeshears, 1), new Object[] {
	    new ItemStack(Item.shears, 1), new ItemStack(Item.dyePowder, 1, 10) 
		});
	ModLoader.AddShapelessRecipe(new ItemStack(magentashears, 1), new Object[] {
	    new ItemStack(Item.shears, 1), new ItemStack(Item.dyePowder, 1, 13) 
		});
	ModLoader.AddShapelessRecipe(new ItemStack(pinkshears, 1), new Object[] {
	    new ItemStack(Item.shears, 1), new ItemStack(Item.dyePowder, 1, 9) 
		});
	ModLoader.AddShapelessRecipe(new ItemStack(purpleshears, 1), new Object[] {
	    new ItemStack(Item.shears, 1), new ItemStack(Item.dyePowder, 1, 5) 
		});
	ModLoader.AddShapelessRecipe(new ItemStack(cyanshears, 1), new Object[] {
	    new ItemStack(Item.shears, 1), new ItemStack(Item.dyePowder, 1, 6) 
		});
	ModLoader.AddShapelessRecipe(new ItemStack(orangeshears, 1), new Object[] {
	    new ItemStack(Item.shears, 1), new ItemStack(Item.dyePowder, 1, 14) 
		});
	
	}
	
	public String Version()
   {
       return "1.7.3";
   }
   
   public static void prepareProps()
   {
	props.getInt("cryingobsidianID", 105);
	props.getInt("stonebrick2ID", 106);
	props.getInt("mossystoneID", 107);
	props.getInt("crackedstoneID", 108);
	props.getInt("quiverItemID", 1025);
	props.getInt("quiverfullItemID", 1026);
	props.getInt("yellowshearsID", 1027);
	props.getInt("redshearsID", 1028);
	props.getInt("blueshearsID", 1029);
	props.getInt("whiteshearsID", 1030);
	props.getInt("blackshearsID", 1031);
	props.getInt("brownshearsID", 1032);
	props.getInt("greenshearsID", 1033);
	props.getInt("greyshearsID", 1034);
	props.getInt("lightblueshearsID", 1035);
	props.getInt("lightgreyshearsID", 1036);
	props.getInt("limeshearsID", 1037);
	props.getInt("magentashearsID", 1038);
	props.getInt("pinkshearsID", 1039);
	props.getInt("purpleshearsID", 1040);
	props.getInt("cyanshearsID", 1041);
	props.getInt("orangeshearsID", 1042);
   } 
   
    public static final Block cryingobsidian;
	public static final Block stonebrick2;
	public static final Block mossystone;
	public static final Block crackedstone;
    public static final Item quiverItem;
    public static final Item quiverfullItem;
	public static final ItemMoreShears yellowshears;
	public static final ItemMoreShears redshears;
	public static final ItemMoreShears blueshears;
	public static final ItemMoreShears whiteshears;
	public static final ItemMoreShears blackshears;
	public static final ItemMoreShears brownshears;
	public static final ItemMoreShears greenshears;
	public static final ItemMoreShears greyshears;
	public static final ItemMoreShears lightblueshears;
	public static final ItemMoreShears lightgreyshears;
	public static final ItemMoreShears limeshears;
	public static final ItemMoreShears magentashears;
	public static final ItemMoreShears pinkshears;
	public static final ItemMoreShears purpleshears;
	public static final ItemMoreShears cyanshears;
	public static final ItemMoreShears orangeshears;
    private static MoreItemsProps props;
	
    static
	{ 
	    props = new MoreItemsProps((new File((new StringBuilder()).append(Minecraft.getMinecraftDir()).append("/").append("mod_MoreItems.props").toString())).getPath());
        prepareProps();
		cryingobsidian = new BlockMoreItems(props.getInt("cryingobsidianID"), 0).setHardness(5F).setResistance(4000F).setBlockName("cryingobsidian");
		stonebrick2 = new BlockMoreItems(props.getInt("stonebrick2ID"), 0).setHardness(1.5F).setResistance(10F).setBlockName("stonebrick2");
		mossystone = new BlockMoreItems(props.getInt("mossystoneID"), 0).setHardness(1.5F).setResistance(10F).setBlockName("mossystone");
		crackedstone = new BlockMoreItems(props.getInt("crackedstoneID"), 0).setHardness(1.5F).setResistance(10F).setBlockName("crackedstone");
		quiverItem = new Item(props.getInt("quiverItemID")).setItemName("quiverItem");
	    quiverfullItem = new Item(props.getInt("quiverfullItemID")).setItemName("quiverfullItem");
		yellowshears = (ItemMoreShears) ( new ItemMoreShears(props.getInt("yellowshearsID"))).setItemName("yellowshears");
		redshears = (ItemMoreShears) ( new ItemMoreShears(props.getInt("redshearsID"))).setItemName("redshears");
		blueshears = (ItemMoreShears) ( new ItemMoreShears(props.getInt("blueshearsID"))).setItemName("blueshears");
		whiteshears = (ItemMoreShears) (new ItemMoreShears(props.getInt("whiteshearsID"))).setItemName("whiteshears");
		blackshears = (ItemMoreShears) (new ItemMoreShears(props.getInt("blackshearsID"))).setItemName("blackshears");
		brownshears = (ItemMoreShears) (new ItemMoreShears(props.getInt("brownshearsID"))).setItemName("brownshears");
		greenshears = (ItemMoreShears) (new ItemMoreShears(props.getInt("greenshearsID"))).setItemName("greenshears");
		greyshears = (ItemMoreShears) (new ItemMoreShears(props.getInt("greyshearsID"))).setItemName("greyshears");
		lightblueshears = (ItemMoreShears) (new ItemMoreShears(props.getInt("lightblueshearsID"))).setItemName("lightblueshears");
		lightgreyshears = (ItemMoreShears) (new ItemMoreShears(props.getInt("lightgreyshearsID"))).setItemName("lightgreyshears");
		limeshears = (ItemMoreShears) (new ItemMoreShears(props.getInt("limeshearsID"))).setItemName("limeshears");
		magentashears = (ItemMoreShears) (new ItemMoreShears(props.getInt("magentashearsID"))).setItemName("magentashears");
		pinkshears = (ItemMoreShears) (new ItemMoreShears(props.getInt("pinkshearsID"))).setItemName("pinkshears");
		purpleshears = (ItemMoreShears) (new ItemMoreShears(props.getInt("purpleshearsID"))).setItemName("purpleshears");
		cyanshears = (ItemMoreShears) (new ItemMoreShears(props.getInt("cyanshearsID"))).setItemName("cyanshears");
		orangeshears = (ItemMoreShears) (new ItemMoreShears(props.getInt("orangeshearsID"))).setItemName("orangeshears");
	}
}