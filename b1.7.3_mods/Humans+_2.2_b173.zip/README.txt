=============================
#   Minecraft Humans+ Mod   #
=============================

#       Version:  2.2       #
#     MCVersion: 1.7.3      #
#        Release:  r3       #
# Release Date:  09/08/2011 #


Prequisits:
----------

- Valid Minecraft Alpha/Beta Account.
- Minecraft 1.7.3 Client.
- Risugami's ModLoader.
- Risugami's AudioMod.
- An Archiver that can handle a RAR.

Changelog:
---------

- Updated for compatibility with 1.7.3.

- Opted in for Naughty List mod Protection.


- Previous Changelog:-
---------
- Achievement IDs changed to fix clash with Achievements+.

- Wanderer texture paths resolved.

- Crash when obtaining certain swords should be fixed.

- Knights will no longer be insane towards the player.

 
-Brought forward from last update:
---------
- Humans now have inventories that will fill up with items they come across, there's a chance they will drop all
  of it upon death.

- Phase one of the Item overhaul, 17 new swords, names are currently changable because i can't decide what to 
  call them,(information will come soon in the lexicon, long day..),all available as (potentially) rare drops
  from most of the Humans.

- Super secret lightning event, no spoilers though.

- Names for named mobs (Leaders, Assassin Friends) will only be rendered if the player is within 10 blocks.

- A few of what will eventually be a big amount of Achievements have been added, still in beta phase for those 
  though.
  
- Assassins now follow you using Smarter Pathfinding and will never leave you for no reason.

- Alignment shifting has been changed to if you kill a human, not just hit them.

- Messages for alignment changes can now be set in the config.

- Move speeds have all been fixed.

- Faction Flags can be toggled randomly by holding sneak and right clicking them.

- All mobs have a chance of spawning with a Shield and/or Cape, the player unfortunately will not be able to use
  them, it would involve editing Mojang's classes and is therefore illegal.

- Elf and Hunter Leader names have been moved to txt files located in /humansplus/settings.

- If debug in the properties is set to true information and invincibility will occur.

- Lots of new Artwork.

- Cookie renamed to "Super Cookie" because i added it first, so it's super now.

- Fresh Bread added as a joke to Notch for adding in cookies officially.

- A LOT of optimization and bugfixes literally everywhere.

- Added the ability for other modders to make content plugins.

- Alignment Checker Recipe fixed.



Installation Instructions:
-------------------------

(This is written on the premise you know how to get to your .minecraft folder, minecraft.jar and insert classes using an archiver).

1. Back up your minecraft.jar.
2. First make sure you have Risugami's Modloader and AudioMod installed to your minecraft.jar.
3. Copy ALL of the files from "Inject to minecraft.jar" Into your minecraft.jar.
4. Copy the folder "humansplus" from in "Inject to minecraft.jar" STRAIGHT into your minecraft.jar
5. Add the files from resources to the resources in your .minecraft folder (%appdata%\.minecraft).
6. Copy "mods" folder directly to your .minecraft folder.
7. Delete META-INF from your minecraft.jar and close.
8. Start up minecraft and test.


Features:
--------

- Over 15 Unique Human Mobs, Including: Assassin, Bandit, Rogue, Rogue Archer, Hunter, Wanderer, Him, Settler, Lost Miner, Mob Horse, Knight, Elf, Samurai, Pirate and Shadow Walker.

- A fully working Alignment system, in which, you can gain/lost trust from different factions.

- Over 20 new Items, including Swords, flags, food and more.

- Faction Flags, very rare drops that can be placed on walls to act as mob spawners for the faction they represent.

- Friends, some factions will help you if you are good enough, others will work for contracts.

- Fully customizable config file, change all of the values to get a truly unique experience.

- Equestrians! Thanks to the great DrZhark for giving me the horse code, with a little modification i was able to make horses that Humans can mount and ride!

- Fishermen, Pirates are able to fish for any water creature, be it added from another mod or in the original minecraft.

- Zelda style hearts are a 1 in 3 drop from most mobs, they will heal 1 heart on contact.

- Leaders spawn with a group of their faction that follow them around and fight for them, leaders themselves are stronger, faster and have moer health, They also have randomly picked names above their heads and wear special leader capes.

- WIP: Targeting compatibility with other mods.

- Over 70 Textures for the mobs, they are randomly picked at spawn, but each faction has their own texture pool and are easy to tell apart.


Information on the configuration:
--------------------------------

I have added detailed instructions to the settings file itself, if you don't install it in the right place
or delete it, the game will generate a new one, it will not be formatted with all of my detailed help, it will be
all of the settings randomly ordered down the page.


Credits:
-------

Mr_okushama - Mod Creator

Humans+ Support Team:
Tipaa - Code/Content Optimizer.
HunterParasite - Texture Artist.
Gunrise - Critique, Texture Artist.

Other Worthy Individuals:
_303 - Original Pirate Author and all round Go To guy.
DrZhark - Original Horse Author and My original inspiration.
Corosus, Kodaichi, HarryPitFall, _303, Risugami, Seronis,
Club559, ZeuX, and Ayutashi - Supporting Mr_okushama and teaching him java.
MCP Team - Creating modders out of block heads since 2010.
8bitGinno - The creator of the Humans+ banner.
PhoenixBrave - Flag Designer.
Many Unnamed Character Artists - A lot of textures obtained from http://www.minecraftskins.com
Hdxd - Samurai Textures.


==================
=  Terms of Use  =
==================

By Downloading/Installing this Minecraft Modification you are agreeing to the following:
- You will actively seek methods of help other than the forum thread or PMs to members of the Humans+ Team.
- You are responsible for any damaged/corrupted worlds.
- You will NEVER rush the Mr_okushama for updates, we will delay release 1 hour for each request.
- You agree to not compain about the adf.ly links we use to earn a tiny amount of money for all of our hard work.
- You will not re-package and/or re-distrubute this modification or any of the included files.


Breaking any one of the terms listed above will result in your name being added to the NaughtyList database, 
causing my mods to no longer work for you.

Humans+ concept, code and distribution is all to be handled solely by okushama_inc (Mr_okushama & The Humans+ Team).

Minecraft � Mojang Specifications AB 2010-2011, All Rights Reserved.
Humans+ � okushama_inc 2010-2011, All Rights Reserved.
