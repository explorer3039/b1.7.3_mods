[1.7.3] arms' Mods+


READ ME


How to install:


- Backup your minecraft.jar
- Requires Risagumi's ModLoader, so first install that one.
- Then drag and drop all files into the root of minecraft.jar with a file browser like 7-Zip or WinRar.(Archive Utility for Mac OS and Linux (I think))
- Delete META-INF if you did not do that already.
- Enjoy!


---------------------------------------------


Copyrights:


This mod (plugin, a patch to Minecraft source, henceforth "Mod" or "The Mod"), by the terms of http://www.minecraft.net/copyright.jsp is sole property of the Mod author (, henceforth "Owner" or "The Owner"). By default it may only be distributed on minecraftforums.net, mcmodcenter.net. It may only be mirrored or reposted with advance written permission of the Owner. Electronic Mail is fine if you wait for a response. URL shorteners or other attempts to make money off The Owner's Mod are strictly forbidden without advance written permission.


-------------------------------------


The Owner: arms for sale, a.k.a. David Armbruster
Mod Creator: arms for sale, a.k.a. David Armbruster