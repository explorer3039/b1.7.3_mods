Digital Cougar : 07/07/2011

These .class files add a new awesome tool to Minecraft: the Paxel. Three tools in one! The Paxel combines the Pick, Axe, and Shovel into one multi-purpose tool that is effective against all the block types the three componant tools are. Wood, stone, or dirt, this tool goes right through them all. No more switching to your shovel when you find dirt or gravel while mining! Chop down trees, dig a hole, or tunnel through a mountain, all without ever switching tools. Takes up only one inventory slot, rather than three, and lasts longer than the vanilla tools!

It is crafted by placing a new Pick, a new Axe, and a new Shovel, left-to-right in that order, in the top row of the 3x3 crafting grid. Place two sticks, one on top of the other, centered below them to make the new handle and you have a shiny new Paxel! Whatever material the original tools were is the type of Paxel you get. They all must be the same - you cannot mix-and-match materials. And they must be brand new!

The durability of the three original tools is combined into the new Paxel - no wasted durability, and triple the uses from one tool! This makes the iron Paxel last almost as long as diamond tools in an unmodified game.

The code for the original Diamond Paxel has passed through many hands - first created by IWannaWin way back in the day, it was picked up by Zaraza107 who updated it through Minecraft Alpha 1.2.6. I patched it for Beta 1.1_01, then Ayu fixed it when Beta 1.1_02 broke it again.

Now I've taken that old code and fixed it so it works with Minecraft 1.7.2, added four new types of Paxels for the different materials, and the tool is effective on several block types that it wasn't previously - miscellaneous things like stairs, jukeboxes, bookshelves, furnaces, and pistons. I also made it effective against leaves, so you're not taking double durability damage just getting up to the tree trunk to chop it down. :)


The files necessary for the Paxels to work are:

  ModLoader! It won't work without it. http://www.minecraftforum.net/topic/75440-v166-risugamis-mods-updates/

  EnumToolMaterialMod.class
  ItemPaxel.class
  ItemToolMod.class
  mod_Paxel.class


The .png files inside the gui-64x folder are Paxel icons that work with 64x64 texture packs. If you're using one, such as Misa's Realistic or similar, use these files. They go inside the gui folder in the minecraft.jar. If you're not using a texture pack...why not?!?
The .png files inside gui-32x are for use with any pack at that resolution, and gui-16x is for unmodified, vanilla Minecraft. If you install all the .png files all at once, you fail computers (and life) forever, and I don't want to hear about it not working. :) I'm assuming just a little computer and minecraft mod installation compentency, here. There's plenty of walkthroughs on the forums.

If you are using a texture pack higher than 64x64, you can use the lower-resolution Paxel icons with no problems. There's never a problem using icons that are at a lower resolution than you're currently at - they'll just look like crap in-game. :)


Again, you need ModLoader for the Paxels to work! Get it at:

http://www.minecraftforum.net/topic/75440-v166-risugamis-mods-updates/

Install it first, THEN this mod, or I promise you'll be sorry.


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
Use this mod at your own risk! Although I have extensively playtested it, I cannot and will not guarantee that it won't cause your computer to spontaneously erupt into flames, your plants, pets and/or family members to wither and die, your power to go off, sunspots and solar eruptions, plagues, oceans of blood, demonic possessions, or monkeys to fly out of your butt. The author is not responsible for any damages, direct or consequential, that may result from its use.
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=



TL;DR version - Needs ModLoader. Icons for different resolutions, use the correct one for your setup. If you have problems, RTFM. :)