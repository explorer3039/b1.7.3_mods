[1.7.3][v1.2]BoatsDeluxe_Mod

=== Description: ===
The BoatsDeluxe_Mod makes boats in Minecraft un-crashable while you are riding them.
This means that if you crash into land while going fast, your boat will NOT break.
Also if you break the boat with your hands it gives you a boat item in return. If you
Jump out of the boat, the boat stays in the exact place you jumped out at (basically an anchor).
Another awesome feature is the powered boat (activated by holding the �space� bar).

=== Installation ===
1.) Delete META-INF (If not already deleted)
2.) Drag-and-drop fz.class into minecraft.jar

Have fun with your un-crashable boats!

=== Change Log ===
v1.2
* Renamed from "Boats Don't Break Mod" to "Boats Deluxe Mod"
* Breaking the boat with your hands gives you a boat item in return
* Added an anchor feature
* Added a motor feature (activated by holding the "Space" bar)

v1.1
* Not enough (in my mind) to release

v1.0
* First release (As "Boats Don't Break Mod")