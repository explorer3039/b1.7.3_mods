package net.mine_diver.infsprites.proxy;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import net.minecraft.client.Minecraft;
import net.minecraft.src.Block;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.EntitySorter;
import net.minecraft.src.MathHelper;
import net.minecraft.src.ModLoader;
import net.minecraft.src.RenderBlocks;
import net.minecraft.src.RenderEngine;
import net.minecraft.src.RenderGlobal;
import net.minecraft.src.RenderManager;
import net.minecraft.src.World;
import net.minecraft.src.WorldRenderer;
import net.minecraft.src.mod_InfSprites;
import net.minecraft.src.overrideapi.utils.Reflection;

public class RenderGlobalProxy extends RenderGlobal {
	
	public RenderGlobalProxy(Minecraft minecraft, RenderEngine renderengine) {
		super(minecraft, renderengine);
	}

	@Override
	public void changeWorld(World world)
    {
		loadFieldsFromSuper();
        if(worldObj != null)
        {
            worldObj.removeWorldAccess(this);
        }
        mod_InfSprites.PackageAccess.RenderGlobal.setPrevSortX(this, -9999D);
        mod_InfSprites.PackageAccess.RenderGlobal.setPrevSortY(this, -9999D);
        mod_InfSprites.PackageAccess.RenderGlobal.setPrevSortZ(this, -9999D);
        RenderManager.instance.func_852_a(world);
        worldObj = world;
        globalRenderBlocks = new RenderBlocksProxy(world);
        if(world != null)
        {
            world.addWorldAccess(this);
            saveFieldsToSuper();
            loadRenderers();
        }
    }
	
	@SuppressWarnings("unchecked")
	@Override
	public void loadRenderers()
    {
		loadFieldsFromSuper();
        Block.leaves.setGraphicsLevel(mc.gameSettings.fancyGraphics);
        renderDistance = mc.gameSettings.renderDistance;
        if(worldRenderers != null)
        {
            for(int i = 0; i < worldRenderers.length; i++)
            {
                worldRenderers[i].func_1204_c();
            }

        }
        int j = 64 << 3 - renderDistance;
        if(j > 400)
        {
            j = 400;
        }
        renderChunksWide = j / 16 + 1;
        renderChunksTall = 8;
        renderChunksDeep = j / 16 + 1;
        worldRenderers = new WorldRenderer[renderChunksWide * renderChunksTall * renderChunksDeep];
        sortedWorldRenderers = new WorldRenderer[renderChunksWide * renderChunksTall * renderChunksDeep];
        int k = 0;
        int l = 0;
        minBlockX = 0;
        minBlockY = 0;
        minBlockZ = 0;
        maxBlockX = renderChunksWide;
        maxBlockY = renderChunksTall;
        maxBlockZ = renderChunksDeep;
        for(int i1 = 0; i1 < worldRenderersToUpdate.size(); i1++)
        {
            ((WorldRenderer)worldRenderersToUpdate.get(i1)).needsUpdate = false;
        }

        worldRenderersToUpdate.clear();
        tileEntities.clear();
        for(int j1 = 0; j1 < renderChunksWide; j1++)
        {
            for(int k1 = 0; k1 < renderChunksTall; k1++)
            {
                for(int l1 = 0; l1 < renderChunksDeep; l1++)
                {
                    worldRenderers[(l1 * renderChunksTall + k1) * renderChunksWide + j1] = new WorldRendererProxy(worldObj, tileEntities, j1 * 16, k1 * 16, l1 * 16, 16, glRenderListBase + k);
                    if(occlusionEnabled)
                    {
                        worldRenderers[(l1 * renderChunksTall + k1) * renderChunksWide + j1].glOcclusionQuery = glOcclusionQueryBase.get(l);
                    }
                    worldRenderers[(l1 * renderChunksTall + k1) * renderChunksWide + j1].isWaitingOnOcclusionQuery = false;
                    worldRenderers[(l1 * renderChunksTall + k1) * renderChunksWide + j1].isVisible = true;
                    worldRenderers[(l1 * renderChunksTall + k1) * renderChunksWide + j1].isInFrustum = true;
                    worldRenderers[(l1 * renderChunksTall + k1) * renderChunksWide + j1].chunkIndex = l++;
                    worldRenderers[(l1 * renderChunksTall + k1) * renderChunksWide + j1].markDirty();
                    sortedWorldRenderers[(l1 * renderChunksTall + k1) * renderChunksWide + j1] = worldRenderers[(l1 * renderChunksTall + k1) * renderChunksWide + j1];
                    worldRenderersToUpdate.add(worldRenderers[(l1 * renderChunksTall + k1) * renderChunksWide + j1]);
                    k += 3;
                }

            }

        }

        if(worldObj != null)
        {
            EntityLiving entityliving = mc.renderViewEntity;
            if(entityliving != null)
            {
                markRenderersForNewPosition(MathHelper.floor_double(((Entity) (entityliving)).posX), MathHelper.floor_double(((Entity) (entityliving)).posY), MathHelper.floor_double(((Entity) (entityliving)).posZ));
                Arrays.sort(sortedWorldRenderers, new EntitySorter(entityliving));
            }
        }
        renderEntitiesStartupCounter = 2;
        saveFieldsToSuper();
    }

    private World worldObj;
    @SuppressWarnings("rawtypes")
	private List worldRenderersToUpdate;
    private WorldRenderer sortedWorldRenderers[];
    private WorldRenderer worldRenderers[];
    private int renderChunksWide;
    private int renderChunksTall;
    private int renderChunksDeep;
    private int glRenderListBase;
	private Minecraft mc;
	@SuppressWarnings("unused")
	private RenderBlocks globalRenderBlocks;
    private IntBuffer glOcclusionQueryBase;
    private boolean occlusionEnabled;
    @SuppressWarnings("unused")
	private int minBlockX;
    @SuppressWarnings("unused")
	private int minBlockY;
    @SuppressWarnings("unused")
	private int minBlockZ;
    @SuppressWarnings("unused")
	private int maxBlockX;
    @SuppressWarnings("unused")
	private int maxBlockY;
    @SuppressWarnings("unused")
	private int maxBlockZ;
    private int renderDistance;
    @SuppressWarnings("unused")
	private int renderEntitiesStartupCounter;
    
    public void initSuper() {
    	try {
    		for (Field field : RenderGlobal.class.getDeclaredFields())
    			Reflection.publicField(field).set(this, Reflection.publicField(field).get(ModLoader.getMinecraftInstance().renderGlobal));
            Field field = (net.minecraft.src.ModLoader.class).getDeclaredField("texturesAdded");
            field.setAccessible(true);
            field.set(null, Boolean.valueOf(true));
            field = (net.minecraft.src.ModLoader.class).getDeclaredField("texPack");
            field.setAccessible(true);
            field.set(null, ModLoader.getMinecraftInstance().gameSettings.skin);
            ModLoader.RegisterAllTextureOverrides(ModLoader.getMinecraftInstance().renderEngine);
        }
        catch(Exception exception) {
            throw new RuntimeException(exception);
        }
    }
    
    private static List<Field> superFields = new ArrayList<Field>();
    
    static {
    	List<String[]> names = new ArrayList<String[]>();
    	names.add(new String[]{"k", "worldObj"});
    	names.add(new String[]{"m", "worldRenderersToUpdate"});
    	names.add(new String[]{"n", "sortedWorldRenderers"});
    	names.add(new String[]{"o", "worldRenderers"});
    	names.add(new String[]{"p", "renderChunksWide"});
    	names.add(new String[]{"q", "renderChunksTall"});
    	names.add(new String[]{"r", "renderChunksDeep"});
    	names.add(new String[]{"s", "glRenderListBase"});
    	names.add(new String[]{"t", "mc"});
    	names.add(new String[]{"u", "globalRenderBlocks"});
    	names.add(new String[]{"v", "glOcclusionQueryBase"});
    	names.add(new String[]{"w", "occlusionEnabled"});
    	names.add(new String[]{"B", "minBlockX"});
    	names.add(new String[]{"C", "minBlockY"});
    	names.add(new String[]{"D", "minBlockZ"});
    	names.add(new String[]{"E", "maxBlockX"});
    	names.add(new String[]{"F", "maxBlockY"});
    	names.add(new String[]{"G", "maxBlockZ"});
    	names.add(new String[]{"H", "renderDistance"});
    	names.add(new String[]{"I", "renderEntitiesStartupCounter"});
    	for (String[] s : names)
    		superFields.add(Reflection.publicField(Reflection.findField(RenderGlobal.class, s)));
    }
    
    private void loadFieldsFromSuper() {
    	for (int i = 0; i < superFields.size(); i++)
			try {
				getClass().getDeclaredFields()[i].set(this, superFields.get(i).get(this));
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
    }
    
    private void saveFieldsToSuper() {
    	for (int i = 0; i < superFields.size(); i++)
			try {
				superFields.get(i).set(this, getClass().getDeclaredFields()[i].get(this));
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
    }

	private static final Method markRenderersForNewPosition;
	
	static {
		Method markRenderersForNewPositionMethod = null;
		for (Method m : RenderGlobal.class.getDeclaredMethods()) {
			if ((m.getName().equals("b") || m.getName().equals("markRenderersForNewPosition")) && Arrays.equals(m.getParameterTypes(), new Class<?>[]{int.class, int.class, int.class})) {
				m.setAccessible(true);
				markRenderersForNewPositionMethod = m;
			}
		}
		markRenderersForNewPosition = markRenderersForNewPositionMethod;
	}
    
	private void markRenderersForNewPosition(int i, int j, int k) {
		try {
        	saveFieldsToSuper();
			markRenderersForNewPosition.invoke(this, i, j, k);
			loadFieldsFromSuper();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
}
