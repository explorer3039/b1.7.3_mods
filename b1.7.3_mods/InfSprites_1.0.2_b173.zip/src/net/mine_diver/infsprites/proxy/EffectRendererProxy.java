package net.mine_diver.infsprites.proxy;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.lwjgl.opengl.GL11;

import net.mine_diver.infsprites.mcextended.MCExtendedManagers;
import net.minecraft.src.EffectRenderer;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityFX;
import net.minecraft.src.MathHelper;
import net.minecraft.src.ModLoader;
import net.minecraft.src.RenderEngine;
import net.minecraft.src.Tessellator;
import net.minecraft.src.World;
import net.minecraft.src.mod_InfSprites.PackageAccess;
import net.minecraft.src.overrideapi.utils.Reflection;

public class EffectRendererProxy extends EffectRenderer {

	public EffectRendererProxy(World world, RenderEngine renderengine) {
		super(world, renderengine);
	}
	
	@Override
	public void renderParticles(Entity entity, float f)
    {
		loadFieldsFromSuper();
        float f1 = MathHelper.cos((entity.rotationYaw * 3.141593F) / 180F);
        float f2 = MathHelper.sin((entity.rotationYaw * 3.141593F) / 180F);
        float f3 = -f2 * MathHelper.sin((entity.rotationPitch * 3.141593F) / 180F);
        float f4 = f1 * MathHelper.sin((entity.rotationPitch * 3.141593F) / 180F);
        float f5 = MathHelper.cos((entity.rotationPitch * 3.141593F) / 180F);
        EntityFX.interpPosX = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * (double)f;
        EntityFX.interpPosY = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * (double)f;
        EntityFX.interpPosZ = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * (double)f;
        for(int i = 0; i < 3; i++)
        {
            if(fxLayers[i].size() == 0)
            {
                continue;
            }
            int j = 0;
            if(i == 0)
            {
                j = renderer.getTexture("/particles.png");
            }
            if(i == 1)
            {
                j = renderer.getTexture("/terrain.png");
            }
            if(i == 2)
            {
                j = renderer.getTexture("/gui/items.png");
            }
            GL11.glBindTexture(3553 /*GL_TEXTURE_2D*/, j);
            Tessellator tessellator = Tessellator.instance;
            for(int k = 0; k < fxLayers[i].size(); k++)
            {
                tessellator.startDrawingQuads();
                EntityFX entityfx = (EntityFX)fxLayers[i].get(k);
                if (i == 1) {
                	GL11.glBindTexture(3553 /*GL_TEXTURE_2D*/, MCExtendedManagers.TerrainManager.getTerrain(PackageAccess.EntityFX.getParticleTextureIndex(entityfx) / 256));
                }
                entityfx.renderParticle(tessellator, f, f1, f5, f2, f3, f4);
                tessellator.draw();
            }

        }
        saveFieldsToSuper();
    }
	
	private List<EntityFX> fxLayers[];
	private RenderEngine renderer;
	
	public void initSuper() {
		try {
			for (Field field : EffectRenderer.class.getDeclaredFields())
				Reflection.publicField(field).set(this, Reflection.publicField(field).get(ModLoader.getMinecraftInstance().effectRenderer));
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
	
    private static List<Field> superFields = new ArrayList<Field>();
    
    static {
    	List<String[]> names = new ArrayList<String[]>();
    	names.add(new String[]{"b", "fxLayers"});
    	names.add(new String[]{"c", "renderer"});
    	for (String[] s : names)
    		superFields.add(Reflection.publicField(Reflection.findField(EffectRenderer.class, s)));
    }
	
    private void loadFieldsFromSuper() {
    	for (int i = 0; i < superFields.size(); i++)
			try {
				getClass().getDeclaredFields()[i].set(this, superFields.get(i).get(this));
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
    }
    
    private void saveFieldsToSuper() {
    	for (int i = 0; i < superFields.size(); i++)
			try {
				superFields.get(i).set(this, getClass().getDeclaredFields()[i].get(this));
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
    }
}
