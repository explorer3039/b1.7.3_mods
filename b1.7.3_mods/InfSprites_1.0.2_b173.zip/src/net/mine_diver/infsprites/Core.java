package net.mine_diver.infsprites;

import java.lang.reflect.Field;
import java.util.Map;

import net.mine_diver.infsprites.proxy.EffectRendererProxy;
import net.mine_diver.infsprites.proxy.ItemRendererProxy;
import net.mine_diver.infsprites.proxy.RenderGlobalProxy;
import net.mine_diver.infsprites.proxy.RenderItemProxy;
import net.mine_diver.infsprites.util.compatibility.Forge;
import net.mine_diver.infsprites.util.compatibility.HowManyItems;
import net.mine_diver.infsprites.util.compatibility.ICompatibilityPatcher;
import net.mine_diver.infsprites.util.compatibility.IDResolver;
import net.minecraft.client.Minecraft;
import net.minecraft.src.BaseMod;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityItem;
import net.minecraft.src.GuiContainer;
import net.minecraft.src.GuiIngame;
import net.minecraft.src.ModLoader;
import net.minecraft.src.Render;
import net.minecraft.src.RenderItem;
import net.minecraft.src.RenderManager;
import net.minecraft.src.mod_InfSprites;
import net.minecraft.src.overrideapi.utils.Reflection;
import sun.misc.Unsafe;

public class Core {
	
	public void preInit(BaseMod mod) {
		if (MLCore == null)
			MLCore = mod;
		ModLoader.SetInGUIHook(MLCore, true, false);
		ICompatibilityPatcher.compatibilityPatchers.add(new Forge());
		ICompatibilityPatcher.compatibilityPatchers.add(new HowManyItems());
		ICompatibilityPatcher.compatibilityPatchers.add(new IDResolver());
		try {
			Field itemRendererField = Reflection.publicField(Reflection.findField(GuiContainer.class, new String[]{"l", "itemRenderer"}));
			RenderItemProxy RIProxy = (RenderItemProxy) unsafe.allocateInstance(RenderItemProxy.class);
			RIProxy.initSuper((RenderItem) itemRendererField.get(null));
			itemRendererField.set(null, RIProxy);
			itemRendererField = Reflection.publicField(Reflection.findField(GuiIngame.class, new String[]{"d", "itemRenderer"}));
			RIProxy = (RenderItemProxy) unsafe.allocateInstance(RenderItemProxy.class);
			RIProxy.initSuper((RenderItem) itemRendererField.get(null));
			itemRendererField.set(null, RIProxy);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	public void init(Map<Class<? extends Entity>, Render> renders) {
		try {
			RenderItemProxy RIProxy = (RenderItemProxy) unsafe.allocateInstance(RenderItemProxy.class);
			RIProxy.initSuper((RenderItem) renders.get(EntityItem.class));
			renders.replace(EntityItem.class, RIProxy);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	public void postInit(Minecraft minecraft) {
		try {
			RenderGlobalProxy RGProxy = (RenderGlobalProxy) unsafe.allocateInstance(RenderGlobalProxy.class);
			RGProxy.initSuper();
			minecraft.renderGlobal = RGProxy;
			EffectRendererProxy ERProxy = (EffectRendererProxy) unsafe.allocateInstance(EffectRendererProxy.class);
			ERProxy.initSuper();
			minecraft.effectRenderer = ERProxy;
			
			ItemRendererProxy IRProxy = (ItemRendererProxy) unsafe.allocateInstance(ItemRendererProxy.class);
			IRProxy.initSuper(RenderManager.instance.itemRenderer);
			RenderManager.instance.itemRenderer = IRProxy;
			
			IRProxy = (ItemRendererProxy) unsafe.allocateInstance(ItemRendererProxy.class);
			IRProxy.initSuper(ModLoader.getMinecraftInstance().entityRenderer.itemRenderer);
			ModLoader.getMinecraftInstance().entityRenderer.itemRenderer = IRProxy;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		
		for (ICompatibilityPatcher patcher : ICompatibilityPatcher.compatibilityPatchers) {
			try {
				if ((patcher.requiredClass() == null && ModLoader.isModLoaded((mod_InfSprites.workspace ? "net.minecraft.src." : "") + "mod_" + patcher.getClass().getSimpleName())) || (patcher.requiredClass() != null && Class.forName(patcher.requiredClass()) != null))
					patcher.patch();
			} catch (ClassNotFoundException e) {}
		}
	}
	
	private BaseMod MLCore;
	
	private static final Unsafe unsafe;
	static {
		Unsafe inst = null;
		try {
			inst = (Unsafe) ModLoader.getPrivateValue(Unsafe.class, null, "theUnsafe");
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		unsafe = inst;
	}
}
