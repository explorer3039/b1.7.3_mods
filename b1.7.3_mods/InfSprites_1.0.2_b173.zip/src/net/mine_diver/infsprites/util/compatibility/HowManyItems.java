package net.mine_diver.infsprites.util.compatibility;

import hmi.Utils;
import net.mine_diver.infsprites.proxy.RenderItemProxy;

public class HowManyItems implements ICompatibilityPatcher {
	
	@Override
	public String requiredClass() {
		return null;
	}
	
	@Override
	public void patch() {
		Utils.itemRenderer = new RenderItemProxy();
	}
}
