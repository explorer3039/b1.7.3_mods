Drag all the files into the minecraft jar.
modloader not required!
deleat meta_inf
close minecraft jar.
Play mah mod

Floating Sky Expanse v 1.0
Created By Thehugh100
If you find bugs email me gxdp@hotmail.co.uk