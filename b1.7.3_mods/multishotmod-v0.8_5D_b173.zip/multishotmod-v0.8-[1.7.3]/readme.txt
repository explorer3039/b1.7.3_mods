{\rtf1\ansi\ansicpg1252\cocoartf1038\cocoasubrtf360
{\fonttbl\f0\fnil\fcharset0 Menlo-Bold;\f1\fnil\fcharset0 Menlo-Regular;}
{\colortbl;\red255\green255\blue255;}
{\*\listtable{\list\listtemplateid1\listhybrid{\listlevel\levelnfc23\levelnfcn23\leveljc0\leveljcn0\levelfollow0\levelstartat1\levelspace360\levelindent0{\*\levelmarker \{disc\}}{\leveltext\leveltemplateid1\'01\uc0\u8226 ;}{\levelnumbers;}\fi-360\li720\lin720 }{\listname ;}\listid1}}
{\*\listoverridetable{\listoverride\listid1\listoverridecount0\ls1}}
\paperw11900\paperh16840\margl1440\margr1440\vieww10900\viewh9240\viewkind0
\pard\tx220\tx720\tx1133\tx1700\tx2267\tx2834\tx3401\tx3968\tx4535\tx5102\tx5669\tx6236\tx6803\li720\fi-720\ql\qnatural\pardirnatural

\f0\b\fs22 \cf0 \'95Read the whole thread if you haven't already!\
\pard\tx220\tx720\tx1133\tx1700\tx2267\tx2834\tx3401\tx3968\tx4535\tx5102\tx5669\tx6236\tx6803\li720\fi-720\ql\qnatural\pardirnatural
\ls1\ilvl0\cf0 \'95Before installing SHUT DOWN MINECRAFT!\
\'95When multishot is turned on don't move or the resulting video will move!\
\'95Make sure you aren't using M or N for any other game controls!
\f1\b0 \
\pard\tx220\tx720\tx1133\tx1700\tx2267\tx2834\tx3401\tx3968\tx4535\tx5102\tx5669\tx6236\tx6803\li720\fi-720\ql\qnatural\pardirnatural
\cf0 \
\pard\tx560\tx1120\tx1680\tx2240\tx2800\tx3360\tx3920\tx4480\tx5040\tx5600\tx6160\tx6720\ql\qnatural\pardirnatural

\f0\b \cf0 Installation:\
Windows:\

\f1\b0 1)Open up %appdata%, if you don't know how to do this, go to start>run, then type in %appdata%\
2)Browse to .minecraft/bin\
3)Open minecraft.jar with WinRAR or 7zip\
4)Drag and drop .class file into "bin/minecraft.jar/net/minecraft/client"\
5)Delete the META-INF folder in minecraft.jar\
6)Add config.txt to ".minecraft/mods/multishot." If the folders do not exist create them (config.txt does not go in minecraft.jar)\
7)Run Minecraft\
\

\f0\b Mac:\

\f1\b0 1)Open Terminal from Applications>Utilities\
2)Type in the following code, line by line:\
-------------------------------------------------------------------\

\f0\b cd ~
\f1\b0 \

\f0\b mkdir mctmp
\f1\b0 \

\f0\b cd mctmp
\f1\b0 \

\f0\b jar xf ~/Library/Application\\ Support/minecraft/bin/minecraft.jar\

\f1\b0 -------------------------------------------------------------------\
3)Outside of terminal, drop the .class file into "mctmp/net/minecraft/client"\
4)Back inside terminal, type in the following, line by line again:\
-------------------------------------------------------------------\

\f0\b rm META-INF/MOJANG_C.*
\f1\b0 \

\f0\b jar uf ~/Library/Application\\ Support/minecraft/bin/minecraft.jar ./\
cd ..
\f1\b0 \

\f0\b rm -rf mctmp\

\f1\b0 -------------------------------------------------------------------
\f0\b \

\f1\b0 5)Add config.txt to ".minecraft/mods/multishot." If the folders do not exist create them (config.txt does not go in minecraft.jar)\
6)Run Minecraft\
\

\f0\b Default keys:\

\f1\b0 On - M\
Off - N\
Exposure - 3.0 (seconds)}