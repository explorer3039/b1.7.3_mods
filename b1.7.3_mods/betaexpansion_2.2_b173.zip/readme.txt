===INSTALLATION===

Step 1: Copy Beta 1.7.3 jar into your (minecraftdir)/versions/betaexpansion folder and rename it betaexpansion.jar
Step 2: Copy files in "files" into betaexpansion.jar using 7-Zip, WinRar or your preferred program and delete META-INF
Step 3: Copy betaexpansion.json into the (minecraftdir)/versions/betaexpansion folder
Step 4: Start betaexpansion in launcher
