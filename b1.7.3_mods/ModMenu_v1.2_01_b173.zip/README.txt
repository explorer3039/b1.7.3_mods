ModMenu v1.2_01 for beta 1.7.3

Requires:

- ModLoader

- OverrideAPI v0.1_02 or higher

Compatibility:

- Should be compatible with anything

Installation:

- Use this .zip as mod for minecraft.jar

�hangeLog:

- Fixed bug when custom mod entries wouldn't work

- Removed defaultMLName, as it's useless

- Added defaultModInfoPath config property

TODO list:

1) Add more info (like authors, multiplayer support, bigger description, etc)

1.1) Add a screen with full info and configurable entries (for example, worldMenu for Aether)

Credit:

- mine_diver

Feel free to use it :D