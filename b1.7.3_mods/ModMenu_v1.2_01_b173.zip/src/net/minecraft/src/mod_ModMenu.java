package net.minecraft.src;

import java.util.Map;

import net.mine_diver.modmenu.Core;
import net.mine_diver.modmenu.info;

public class mod_ModMenu extends BaseMod {
	public mod_ModMenu() {
		Core.INSTANCE.init();
	}
	
	@Override
	public void AddRenderer(@SuppressWarnings("rawtypes") Map map) {
		Core.INSTANCE.postInit();
	}
	
	public String Name() {
		return info.NAME;
	}
	
	public String Description() {
		return info.DESCRIPTION;
	}
	
	@Override
	public String Version() {
		return info.VERSION;
	}
	
	@MLProp(info = "Folder with all .modinfos")
	public static String defaultModInfoPath = "/config/Mod Menu/";
	
	@MLProp(info = "Default name of a mod")
	public static String defaultName = "Mod";
	
	@MLProp(info = "Default description of a mod")
	public static String defaultDescription = "A Minecraft modification";
	
	@MLProp(info = "Default version of a mod")
	public static String defaultVersion = "Unknown version";
	
	@MLProp(info = "Default icon folder inside minecraft.jar for mods")
	public static String defaultIconPath = "/gui/mods/";
	
	@MLProp(info = "Default icon of a mod")
	public static String defaultIcon = "/gui/background.png";
	
	@MLProp(info = "Default description of a ModLoader mod")
	public static String defaultMLDescription = "A ModLoader mod";
	
	@MLProp(info = "Default icon folder inside minecraft.jar for ModLoader mods")
	public static String defaultMLIconPath = "/gui/mods/";
	
	@MLProp(info = "Default icon of a ModLoader mod")
	public static String defaultMLIcon = "/gui/background.png";
}
