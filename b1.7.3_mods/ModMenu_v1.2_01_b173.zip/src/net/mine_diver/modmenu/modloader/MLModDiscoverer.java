package net.mine_diver.modmenu.modloader;

import java.util.ArrayList;
import java.util.List;

import net.mine_diver.modmenu.util.IModDiscoverer;
import net.mine_diver.modmenu.util.Mod;
import net.minecraft.src.BaseMod;
import net.minecraft.src.ModLoader;

public class MLModDiscoverer implements IModDiscoverer {

	@SuppressWarnings("unchecked")
	@Override
	public List<Mod> discover() {
		List<Mod> mods = new ArrayList<Mod>();
		for (BaseMod mod : (List<BaseMod>)ModLoader.getLoadedMods())
			mods.add(new MLMod(mod));
		return mods;
	}
	
}
