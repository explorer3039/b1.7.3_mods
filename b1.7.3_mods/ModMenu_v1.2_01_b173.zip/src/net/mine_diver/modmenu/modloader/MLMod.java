package net.mine_diver.modmenu.modloader;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

import net.mine_diver.modmenu.Core;
import net.mine_diver.modmenu.util.Mod;
import net.minecraft.src.BaseMod;
import net.minecraft.src.mod_ModMenu;

public class MLMod extends Mod {
	
	public MLMod(BaseMod mod) {
		super(Core.INSTANCE.config.load(mod.getClass().getSimpleName().startsWith("mod_")
				? mod.getClass().getSimpleName().substring(4)
						: mod.getClass().getSimpleName()), mod);
	}
	
	@Override
	protected void init(Object... additionalArgs) {
		if (name == null && description == null && version == null)
			try {
				Field baseModField = getClass().getDeclaredField("baseMod");
				baseModField.setAccessible(true);
				modifiers.set(baseModField, baseModField.getModifiers() & ~Modifier.FINAL);
				baseModField.set(this, additionalArgs[0]);
				modifiers.set(baseModField, baseModField.getModifiers() | Modifier.FINAL);
				baseModField.setAccessible(false);
			} catch (Exception e) {e.printStackTrace();}
	}
	
	@Override
	protected String getName() {
		String name = baseMod.getClass().getSimpleName().startsWith("mod_") ? baseMod.getClass().getSimpleName().substring(4) : baseMod.getClass().getSimpleName();
		try {
			name = (String)baseMod.getClass().getDeclaredMethod("Name", new Class<?>[]{}).invoke(baseMod, new Object[]{});
		} catch (Exception e) {}
		return name;
	}
	
	@Override
	protected String getDescription() {
		String description = defaultDescription;
		try {
			description = (String)baseMod.getClass().getDeclaredMethod("Description", new Class<?>[]{}).invoke(baseMod, new Object[]{});
		} catch (Exception e) {}
		return description;
	}
	
	@Override
	protected String getVersion() {
		return baseMod.Version();
	}
	
	@Override
	protected String getThumbnailPath() {
		String thumbnailPath = defaultIconPath + (baseMod.getClass().getSimpleName().startsWith("mod_") ? baseMod.getClass().getSimpleName().substring(4) : baseMod.getClass().getSimpleName()) + ".png";
		try {
			thumbnailPath = (String)baseMod.getClass().getDeclaredMethod("Icon", new Class<?>[]{}).invoke(baseMod, new Object[]{});
		} catch (Exception e) {}
		return thumbnailPath;
	}

	public final BaseMod baseMod = null;
	
	public static String defaultDescription = mod_ModMenu.defaultMLDescription;
	public static String defaultIconPath = mod_ModMenu.defaultMLIconPath;
	public static String defaultIcon = mod_ModMenu.defaultMLIcon;

	private static final Field getModifiersField() {
		try {
			return Field.class.getDeclaredField("modifiers");
		} catch (Exception e) {e.printStackTrace();return null;}
	}
	private static final Field modifiers = getModifiersField();
	static {
		modifiers.setAccessible(true);
	}
}
