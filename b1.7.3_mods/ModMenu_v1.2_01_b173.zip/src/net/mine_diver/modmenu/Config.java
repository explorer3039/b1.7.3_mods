package net.mine_diver.modmenu;

import java.io.File;

import net.mine_diver.modmenu.util.FileProperties;
import net.mine_diver.modmenu.util.Mod;
import net.minecraft.client.Minecraft;
import net.minecraft.src.mod_ModMenu;

public class Config {
	public void init() {
		if (!configDir.exists()) {
			configDir.mkdirs();
		}
	}
	
	public FileProperties load(String name) {
		return new FileProperties(new File(configDir + "/" + name + ".modinfo"));
	}
	
	public void save(Mod mod, FileProperties config) {
		try {
			config.store("Mod info for " + mod.name);
		} catch (Exception e) {e.printStackTrace();}
	}
	public final File configDir = new File(Minecraft.getMinecraftDir() + mod_ModMenu.defaultModInfoPath);
}
