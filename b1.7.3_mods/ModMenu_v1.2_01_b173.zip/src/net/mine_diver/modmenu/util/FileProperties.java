package net.mine_diver.modmenu.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

@SuppressWarnings("serial")
public class FileProperties extends Properties {
	
	public FileProperties(File file) {
		this.file = file;
		try {
			load();
		} catch (FileNotFoundException e) {
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void load() throws FileNotFoundException, IOException {
		FileInputStream stream = new FileInputStream(file);
		super.load(stream);
		stream.close();
	}
	
	public void store(String comments) throws FileNotFoundException, IOException {
		FileOutputStream stream = new FileOutputStream(file);
		super.store(stream, comments);
		stream.close();
	}
	
	private final File file;
}