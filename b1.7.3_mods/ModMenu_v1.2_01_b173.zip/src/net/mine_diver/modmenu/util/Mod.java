package net.mine_diver.modmenu.util;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.lwjgl.opengl.GL11;

import net.mine_diver.modmenu.Core;
import net.minecraft.client.Minecraft;
import net.minecraft.src.mod_ModMenu;

public class Mod {
	
	public Mod(FileProperties config, Object... additionalArgs) {
		init(additionalArgs);
		name = config.getProperty("name", getName());
		description = config.getProperty("description", getDescription());
		version = config.getProperty("version", getVersion());
		manual = config.getProperty("manual", "false").equals("true");
		config.setProperty("name", name);
		config.setProperty("description", description);
		config.setProperty("version", version);
		config.setProperty("manual", manual ? "true" : "false");
		Core.INSTANCE.config.save(this, config);
		modTextureId = -1;
		try
        {
            modThumbnail = ImageIO.read(getClass().getResource(getThumbnailPath()));
        }
        catch(IOException ioexception)
        {
            ioexception.printStackTrace();
        }
		catch(IllegalArgumentException e) {};
	}
	
	protected void init(Object... additionalArgs) {}
	
	protected String getName() {
		return defaultName;
	}
	
	protected String getDescription() {
		return defaultDescription;
	}
	
	protected String getVersion() {
		return defaultVersion;
	}
	
	protected String getThumbnailPath() {
		return defaultIconPath + name + ".png";
	}
	
	public final void bindThumbnailTexture(Minecraft minecraft) {
		if(modThumbnail != null && modTextureId < 0)
        {
            modTextureId = minecraft.renderEngine.allocateAndSetupTexture(modThumbnail);
        }
        if(modThumbnail != null)
        {
            minecraft.renderEngine.bindTexture(modTextureId);
        } else
        {
            GL11.glBindTexture(3553, minecraft.renderEngine.getTexture(defaultIcon));
        }
	}
	
	@Override
	public String toString() {
		return name + ":" + description + ":" + version;
	}
	
	public final String name;
	public final String description;
	public final String version;
	public final boolean manual;
	private BufferedImage modThumbnail;
	private int modTextureId;
	
	public static String defaultName = mod_ModMenu.defaultName;
	public static String defaultDescription = mod_ModMenu.defaultDescription;
	public static String defaultVersion = mod_ModMenu.defaultVersion;
	public static String defaultIconPath = mod_ModMenu.defaultIconPath;
	public static String defaultIcon = mod_ModMenu.defaultIcon;
}
