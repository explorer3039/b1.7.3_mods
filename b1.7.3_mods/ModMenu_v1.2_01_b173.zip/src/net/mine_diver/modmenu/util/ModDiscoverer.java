package net.mine_diver.modmenu.util;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import net.mine_diver.modmenu.Core;

public class ModDiscoverer implements IModDiscoverer {
	public List<Mod> discover() {
		List<Mod> mods = new ArrayList<Mod>();
		for (File file : Core.INSTANCE.config.configDir.listFiles())
			if (file.getName().endsWith(".modinfo")) {
				FileProperties config = new FileProperties(file);
				if (config.getProperty("manual") != null && config.getProperty("manual").equals("true")) {
					Mod mod = new Mod(config);
					mods.add(mod);
				}
			}
		return mods;
	}
}
