package net.mine_diver.modmenu.util;

import java.util.List;

public interface IModDiscoverer {
	List<Mod> discover();
}
