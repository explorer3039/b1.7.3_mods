package net.mine_diver.modmenu.util;

import java.util.*;

public class ModList
{

    public ModList()
    {
        loadedMods = new ArrayList<Mod>();
        field_6538_d = new HashMap<String, Mod>();
        updateLoadedMods();
    }

	public void updateLoadedMods()
    {
    	loadedMods.clear();
    	for (IModDiscoverer discoverer : discoverers)
    		for (Mod mod : discoverer.discover()) {
    			if (!field_6538_d.containsKey(mod.toString())) {
            		field_6538_d.put(mod.toString(), mod);
            	}
            	loadedMods.add(field_6538_d.get(mod.toString()));
    		}
    }

    public List<Mod> loadedMods()
    {
        return new ArrayList<Mod>(loadedMods);
    }
    
    public void registerModDiscoverer(IModDiscoverer discoverer) {
    	discoverers.add(discoverer);
    	updateLoadedMods();
    }
    
    private final List<IModDiscoverer> discoverers = new ArrayList<IModDiscoverer>();
    private final List<Mod> loadedMods;
    private final Map<String, Mod> field_6538_d;
}
