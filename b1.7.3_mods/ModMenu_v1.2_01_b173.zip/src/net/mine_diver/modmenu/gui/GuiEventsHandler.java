package net.mine_diver.modmenu.gui;

import java.lang.reflect.Field;
import java.util.List;

import net.mine_diver.modmenu.gui.screens.GuiMods;
import net.minecraft.src.GuiButton;
import net.minecraft.src.GuiScreen;
import net.minecraft.src.GuiSmallButton;
import net.minecraft.src.GuiTexturePacks;
import net.minecraft.src.ModLoader;
import net.minecraft.src.overrideapi.OverrideAPI;
import net.minecraft.src.overrideapi.utils.Reflection;
import net.minecraft.src.overrideapi.utils.gui.ButtonHandler;

public class GuiEventsHandler implements ButtonHandler {

	@Override
	public void initGui(GuiScreen guiscreen, List<GuiButton> customButtons) {
		if (guiscreen instanceof GuiTexturePacks) {
			for (GuiButton button : customButtons)
				if (button.id == 6)
					try {
						widthField.set(button, (Integer)widthField.get(button) / 3);
						button.xPosition += (Integer)widthField.get(button) * 2;
					} catch (IllegalArgumentException e) {
						e.printStackTrace();
					} catch (IllegalAccessException e) {
						e.printStackTrace();
					}
			modsButton = OverrideAPI.getUniqueButtonID();
			customButtons.add(new GuiSmallButton(modsButton, guiscreen.width / 2 + 4, guiscreen.height - 48, 92, 20, "Mods"));
		}
	}

	@Override
	public void actionPerformed(GuiScreen guiscreen, GuiButton guibutton) {
		if (guiscreen instanceof GuiTexturePacks)
			if (guibutton.id == modsButton)
				try {
					ModLoader.getMinecraftInstance().displayGuiScreen(new GuiMods((GuiScreen)guiScreenField.get(guiscreen)));
				} catch (IllegalArgumentException e) {
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					e.printStackTrace();
				}
	}
	
	private int modsButton;
	
	private final Field widthField = Reflection.findField(GuiButton.class, new String[] {"a", "width"});
	private final Field guiScreenField = Reflection.findField(GuiTexturePacks.class, new String[] {"a", "guiScreen"});
	public GuiEventsHandler() {
		widthField.setAccessible(true);
		guiScreenField.setAccessible(true);
	}
}
