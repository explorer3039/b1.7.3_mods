package net.mine_diver.modmenu.gui.screens;

import java.util.List;

import org.lwjgl.opengl.GL11;

import net.mine_diver.modmenu.Core;
import net.mine_diver.modmenu.util.Mod;
import net.minecraft.src.GuiSlot;
import net.minecraft.src.Tessellator;

public class GuiModSlot extends GuiSlot {
	public GuiModSlot(GuiMods guimods)
    {
        super(GuiMods.func_22124_a(guimods), guimods.width, guimods.height, 32, (guimods.height - 55) + 4, 36);
        parentModGui = guimods;
    }
	
	@Override
    protected int getSize()
    {
        List<Mod> list = Core.INSTANCE.modList.loadedMods();
        return list.size();
    }
    
	@Override
	protected void elementClicked(int i, boolean flag) {}
	
	@Override
    protected boolean isSelected(int i)
    {
        return false;
    }
	
	@Override
    protected int getContentHeight()
    {
        return getSize() * 36;
    }
	
	@Override
    protected void drawBackground()
    {
        parentModGui.drawDefaultBackground();
    }
	
	@Override
    protected void drawSlot(int i, int j, int k, int l, Tessellator tessellator)
    {
        Mod mod = Core.INSTANCE.modList.loadedMods().get(i);
        mod.bindThumbnailTexture(GuiMods.func_22123_i(parentModGui));
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        tessellator.startDrawingQuads();
        tessellator.setColorOpaque_I(0xffffff);
        tessellator.addVertexWithUV(j, k + l, 0.0D, 0.0D, 1.0D);
        tessellator.addVertexWithUV(j + 32, k + l, 0.0D, 1.0D, 1.0D);
        tessellator.addVertexWithUV(j + 32, k, 0.0D, 1.0D, 0.0D);
        tessellator.addVertexWithUV(j, k, 0.0D, 0.0D, 0.0D);
        tessellator.draw();
        parentModGui.drawString(GuiMods.func_22127_j(parentModGui), mod.name, j + 32 + 2, k + 1, 0xffffff);
        parentModGui.drawString(GuiMods.func_22120_k(parentModGui), mod.description, j + 32 + 2, k + 12, 0x808080);
        parentModGui.drawString(GuiMods.func_22125_l(parentModGui), mod.version, j + 32 + 2, k + 12 + 10, 0x808080);
    }

    final GuiMods parentModGui; /* synthetic field */

}
