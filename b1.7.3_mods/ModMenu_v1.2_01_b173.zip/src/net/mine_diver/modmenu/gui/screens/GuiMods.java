package net.mine_diver.modmenu.gui.screens;

import java.io.File;

import org.lwjgl.Sys;

import net.mine_diver.modmenu.Core;
import net.minecraft.client.Minecraft;
import net.minecraft.src.FontRenderer;
import net.minecraft.src.GuiButton;
import net.minecraft.src.GuiScreen;
import net.minecraft.src.GuiSmallButton;
import net.minecraft.src.GuiTexturePacks;
import net.minecraft.src.StringTranslate;

public class GuiMods extends GuiScreen {
	public GuiMods(GuiScreen guiscreen)
    {
        field_6454_o = -1;
        fileLocation = "";
        guiScreen = guiscreen;
    }

    @SuppressWarnings("unchecked")
	public void initGui()
    {
        StringTranslate stringtranslate = StringTranslate.getInstance();
        controlList.add(new GuiSmallButton(5, width / 2 - 154, height - 48, "Open mod folder"));
        controlList.add(new GuiSmallButton(6, width / 2 + 4, height - 48, 92, 20, "Texture Packs"));
        controlList.add(new GuiSmallButton(7, width / 2 + 104, height - 48, 50, 20, stringtranslate.translateKey("gui.done")));
        Core.INSTANCE.modList.updateLoadedMods();
        fileLocation = (new File(Minecraft.getMinecraftDir(), "mods")).getAbsolutePath();
        guiModSlot = new GuiModSlot(this);
        guiModSlot.registerScrollButtons(controlList, 8, 9);
    }

    protected void actionPerformed(GuiButton guibutton)
    {
        if(!guibutton.enabled)
        {
            return;
        }
        if(guibutton.id == 5)
        {
            Sys.openURL((new StringBuilder()).append("file://").append(fileLocation).toString());
        } else
        if(guibutton.id == 6)
        {
        	mc.displayGuiScreen(new GuiTexturePacks(guiScreen));
        } else
        if(guibutton.id == 7)
        {
            mc.displayGuiScreen(guiScreen);
        } else
        {
            guiModSlot.actionPerformed(guibutton);
        }
    }

    protected void mouseClicked(int i, int j, int k)
    {
        super.mouseClicked(i, j, k);
    }

    protected void mouseMovedOrUp(int i, int j, int k)
    {
        super.mouseMovedOrUp(i, j, k);
    }

    public void drawScreen(int i, int j, float f)
    {
        guiModSlot.drawScreen(i, j, f);
        if(field_6454_o <= 0)
        {
        	Core.INSTANCE.modList.updateLoadedMods();
            field_6454_o += 20;
        }
        drawCenteredString(fontRenderer, "Select Mod", width / 2, 16, 0xffffff);
        drawCenteredString(fontRenderer, "(Place mod files here)", width / 2 - 77, height - 26, 0x808080);
        super.drawScreen(i, j, f);
    }

    public void updateScreen()
    {
        super.updateScreen();
        field_6454_o--;
    }

    static Minecraft func_22124_a(GuiMods guimods)
    {
        return guimods.mc;
    }

    static Minecraft func_22126_b(GuiMods guimods)
    {
        return guimods.mc;
    }

    static Minecraft func_22119_c(GuiMods guimods)
    {
        return guimods.mc;
    }

    static Minecraft func_22122_d(GuiMods guimods)
    {
        return guimods.mc;
    }

    static Minecraft func_22117_e(GuiMods guimods)
    {
        return guimods.mc;
    }

    static Minecraft func_22118_f(GuiMods guimods)
    {
        return guimods.mc;
    }

    static Minecraft func_22116_g(GuiMods guimods)
    {
        return guimods.mc;
    }

    static Minecraft func_22121_h(GuiMods guimods)
    {
        return guimods.mc;
    }

    static Minecraft func_22123_i(GuiMods guimods)
    {
        return guimods.mc;
    }

    static FontRenderer func_22127_j(GuiMods guimods)
    {
        return guimods.fontRenderer;
    }

    static FontRenderer func_22120_k(GuiMods guimods)
    {
        return guimods.fontRenderer;
    }

    static FontRenderer func_22125_l(GuiMods guimods)
    {
        return guimods.fontRenderer;
    }

    protected GuiScreen guiScreen;
    private int field_6454_o;
    private String fileLocation;
    private GuiModSlot guiModSlot;
}
