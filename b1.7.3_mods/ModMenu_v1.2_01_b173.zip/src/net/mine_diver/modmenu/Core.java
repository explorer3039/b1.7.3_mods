package net.mine_diver.modmenu;

import net.mine_diver.modmenu.gui.GuiEventsHandler;
import net.mine_diver.modmenu.modloader.MLModDiscoverer;
import net.mine_diver.modmenu.util.ModDiscoverer;
import net.mine_diver.modmenu.util.ModList;
import net.minecraft.src.overrideapi.OverrideAPI;

public class Core {
	
	private Core() {}
	
	public static final Core INSTANCE = new Core();
	
	public void init() {
		OverrideAPI.registerButtonHandler(new GuiEventsHandler());
		config.init();
		modList = new ModList();
	}
	
	public void postInit() {
		modList.registerModDiscoverer(new ModDiscoverer());
		modList.registerModDiscoverer(new MLModDiscoverer());
	}
	
	public final Config config = new Config();
	public ModList modList;
}
