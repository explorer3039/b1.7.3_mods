package net.minecraft.src;

public class mod_ToolRepair extends BaseMod {

	ItemStack __shears = new ItemStack(Item.field_31001_bc, 1, -1);

	ItemStack __shovelStone    = new ItemStack(Item.shovelStone,  1,-1);
	ItemStack __shovelSteel    = new ItemStack(Item.shovelSteel,  1,-1);
	ItemStack __shovelGold     = new ItemStack(Item.shovelGold ,  1,-1);
	ItemStack __shovelDiamond  = new ItemStack(Item.shovelDiamond,1,-1);

	ItemStack __hoeStone    = new ItemStack(Item.hoeStone,  1,-1);
	ItemStack __hoeSteel    = new ItemStack(Item.hoeSteel,  1,-1);
	ItemStack __hoeGold     = new ItemStack(Item.hoeGold ,  1,-1);
	ItemStack __hoeDiamond  = new ItemStack(Item.hoeDiamond,1,-1);

	ItemStack __axeStone    = new ItemStack(Item.axeStone,  1,-1);
	ItemStack __axeSteel    = new ItemStack(Item.axeSteel,  1,-1);
	ItemStack __axeGold     = new ItemStack(Item.axeGold ,  1,-1);
	ItemStack __axeDiamond  = new ItemStack(Item.axeDiamond,1,-1);

	ItemStack __pickaxeStone    = new ItemStack(Item.pickaxeStone,  1,-1);
	ItemStack __pickaxeSteel    = new ItemStack(Item.pickaxeSteel,  1,-1);
	ItemStack __pickaxeGold     = new ItemStack(Item.pickaxeGold ,  1,-1);
	ItemStack __pickaxeDiamond  = new ItemStack(Item.pickaxeDiamond,1,-1);

	ItemStack __swordStone    = new ItemStack(Item.swordStone,  1,-1);
	ItemStack __swordSteel    = new ItemStack(Item.swordSteel,  1,-1);
	ItemStack __swordGold     = new ItemStack(Item.swordGold ,  1,-1);
	ItemStack __swordDiamond  = new ItemStack(Item.swordDiamond,1,-1);

	@Override
	public String Version() {
		return "Beta 1.7.2";
	}

	protected mod_ToolRepair() {
		//shears
		ModLoader.AddRecipe(new ItemStack(Item.field_31001_bc,   1), new Object[] {	"O O", " S ", "S S"
			, Character.valueOf('S'), Item.stick, Character.valueOf('O'), Item.ingotIron
		});
		ModLoader.AddRecipe(new ItemStack(Item.field_31001_bc,   1), new Object[] {	"S  ", "ST "
			, Character.valueOf('S'), Item.stick, Character.valueOf('T'), __shears
		});

		//shovels
		ModLoader.AddRecipe(new ItemStack(Item.shovelStone,   1), new Object[] {	"S  ", "ST "
			, Character.valueOf('S'), Item.stick, Character.valueOf('T'), __shovelStone
		});
		ModLoader.AddRecipe(new ItemStack(Item.shovelSteel,   1), new Object[] {	"S  ", "ST "
			, Character.valueOf('S'), Item.stick, Character.valueOf('T'), __shovelSteel
		});
		ModLoader.AddRecipe(new ItemStack(Item.shovelGold,    1), new Object[] {	"S  ", "ST "
			, Character.valueOf('S'), Item.stick, Character.valueOf('T'), __shovelGold
		});
		ModLoader.AddRecipe(new ItemStack(Item.shovelDiamond, 1), new Object[] {	"S  ", "ST "
			, Character.valueOf('S'), Item.stick, Character.valueOf('T'), __shovelDiamond
		});

		//hoes
		ModLoader.AddRecipe(new ItemStack(Item.hoeStone,   1), new Object[] {	"S  ", "ST "
			, Character.valueOf('S'), Item.stick, Character.valueOf('T'), __hoeStone
		});
		ModLoader.AddRecipe(new ItemStack(Item.hoeSteel,   1), new Object[] {	"S  ", "ST "
			, Character.valueOf('S'), Item.stick, Character.valueOf('T'), __hoeSteel
		});
		ModLoader.AddRecipe(new ItemStack(Item.hoeGold,    1), new Object[] {	"S  ", "ST "
			, Character.valueOf('S'), Item.stick, Character.valueOf('T'), __hoeGold
		});
		ModLoader.AddRecipe(new ItemStack(Item.hoeDiamond, 1), new Object[] {	"S  ", "ST "
			, Character.valueOf('S'), Item.stick, Character.valueOf('T'), __hoeDiamond
		});

		//axes
		ModLoader.AddRecipe(new ItemStack(Item.axeStone,   1), new Object[] {	"S  ", "STO"
			, Character.valueOf('S'), Item.stick, Character.valueOf('T'), __axeStone
			, Character.valueOf('O'), Block.cobblestone
		});
		ModLoader.AddRecipe(new ItemStack(Item.axeSteel,   1), new Object[] {	"S  ", "STO"
			, Character.valueOf('S'), Item.stick, Character.valueOf('T'), __axeSteel
			, Character.valueOf('O'), Item.ingotIron
		});
		ModLoader.AddRecipe(new ItemStack(Item.axeGold,    1), new Object[] {	"S  ", "STO"
			, Character.valueOf('S'), Item.stick, Character.valueOf('T'), __axeGold
			, Character.valueOf('O'), Item.ingotGold
		});
		ModLoader.AddRecipe(new ItemStack(Item.axeDiamond, 1), new Object[] {	"S  ", "STO"
			, Character.valueOf('S'), Item.stick, Character.valueOf('T'), __axeDiamond
			, Character.valueOf('O'), Item.diamond
		});

		//pickaxes
		ModLoader.AddRecipe(new ItemStack(Item.pickaxeStone,   1), new Object[] {	"S  ", "STO"
			, Character.valueOf('S'), Item.stick, Character.valueOf('T'), __pickaxeStone
			, Character.valueOf('O'), Block.cobblestone
		});
		ModLoader.AddRecipe(new ItemStack(Item.pickaxeSteel,   1), new Object[] {	"S  ", "STO"
			, Character.valueOf('S'), Item.stick, Character.valueOf('T'), __pickaxeSteel
			, Character.valueOf('O'), Item.ingotIron
		});
		ModLoader.AddRecipe(new ItemStack(Item.pickaxeGold,    1), new Object[] {	"S  ", "STO"
			, Character.valueOf('S'), Item.stick, Character.valueOf('T'), __pickaxeGold
			, Character.valueOf('O'), Item.ingotGold
		});
		ModLoader.AddRecipe(new ItemStack(Item.pickaxeDiamond, 1), new Object[] {	"S  ", "STO"
			, Character.valueOf('S'), Item.stick, Character.valueOf('T'), __pickaxeDiamond
			, Character.valueOf('O'), Item.diamond
		});

		//swords
		ModLoader.AddRecipe(new ItemStack(Item.swordStone,   1), new Object[] {	" TO"
			, Character.valueOf('T'), __swordStone
			, Character.valueOf('O'), Block.cobblestone
		});
		ModLoader.AddRecipe(new ItemStack(Item.swordSteel,   1), new Object[] {	" TO"
			, Character.valueOf('T'), __swordSteel
			, Character.valueOf('O'), Item.ingotIron
		});
		ModLoader.AddRecipe(new ItemStack(Item.swordGold,    1), new Object[] {	" TO"
			, Character.valueOf('T'), __swordGold
			, Character.valueOf('O'), Item.ingotGold
		});
		ModLoader.AddRecipe(new ItemStack(Item.swordDiamond, 1), new Object[] {	" TO"
			, Character.valueOf('T'), __swordDiamond
			, Character.valueOf('O'), Item.diamond
		});
	}
}
