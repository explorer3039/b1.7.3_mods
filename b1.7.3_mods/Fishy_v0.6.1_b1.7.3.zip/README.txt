                                           FISHY
                                      Minecraft 1.7.2
                                          ver 0.6.1

       
Installation:
Requires Modloader and AudioMod 
PropertyReader included

These instructions assume you already know where your .minecraft directory is.
And that Modloader and AudioMod are already installed.

1. Using your favorite archiving tool(ex. 7zip), extract LoafCat to a temporary folder.
2. Then just copy the folders (mods, resorces) to your .minecraft folder.
3. Make sure Meta-INF folder is deleted. (.minecraft/bin/minecraft.jar)
4. Run game and enjoy!

Properties file - 
Fishy creates its own props file at location: .minecraft/mods/Fishy/fishy.properties. The only thing that is configurable during this release version is the 'Fishy SpawnRate'. Acceptable number range: 0-99. Only accepts whole numbers, no decimals. Slower machines should be cautious of setting the rate too high. Default is 20.


Version Log:
0.1 - 0.3 - Ground work. Learning experience.
0.35 -      Test Release. bioluminous,bone drop, swims.
0.5 -        Added sounds, drops rawfish/bone, props file, spawn rate, 3 diff colors.
0.6 -       MC ver1.6.5 update, individual glow .png (3 diff entities).
0.6.1 -   MC version update (1.7.2)

-LK

 - Acknowledgements -

BIG PHAT thank you to Zekeyspaceylizard for all the gorgeous texture work. Salut!!
Amalah - testing and textures
All of the great tutorials and info on the Minecraft Community forums. 
Randomobs src - apply function for random textures.
Roundaround and the author of PropertyReader.
And the authors of Techne and MCP - this mod would not be possible w/o those tools.
And I sincerely thank YOU for using one of my projects.