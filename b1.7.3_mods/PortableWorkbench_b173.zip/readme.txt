Installation:
(This is written on the premise you know how to get to your minecraft.jar)

1. Backup your minecraft.jar.
2. Delete META-INF.
3. Install ModLoader.
4. Drag the files in the "minecraft" folder into your minecraft.jar
5. Start up minecraft and play.