/**
 * @author Yoda12999
 */

public class mod_Waypoint extends BaseMod {

    private uu blockWaypoint;
    @MLProp private static int blockIdWaypoint = 201;

    public mod_Waypoint() {
        blockWaypoint = (new BlockWaypoint(blockIdWaypoint, ModLoader.addOverride("/terrain.png", "/yoda12999/blockWaypoint.png"))).b(true).c(1.0F).a(uu.i).a("blockWaypoint");
        ModLoader.RegisterBlock(blockWaypoint);
        ModLoader.AddName(blockWaypoint, "Waypoint");
        ModLoader.AddShapelessRecipe(new iz(blockWaypoint, 1), new Object[] {gm.aO, uu.aj});
    }

    public String Version(){
        return "1.7.3";
    }
}
