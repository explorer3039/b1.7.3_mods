/**
 * @author Yoda12999
 */

import net.minecraft.client.Minecraft;
import java.util.List;
import java.util.Random;

public class BlockWaypoint extends uu {

    private av compassFX;
    
    protected BlockWaypoint(int i, int j) {
        super(i, j, ln.c);
        getCompassFX(ModLoader.getMinecraftInstance());
        //b(true); //setTickOnLoad
    }

    @Override
    public void a(fd world, int x, int y, int z, Random random) { //updateTick
        if(!compassFX.findWaypoint(x, y, z)) compassFX.setWaypoint(x, y, z);
    }

    @Override
    public boolean a(fd world, int x, int y, int z) { //canPlaceBlockAt
        super.a(world, x, y, z);
        return compassFX.numberWaypoints < 32;
    }

    @Override
    public void c(fd world, int x, int y, int z) { //onBlockAdded
        compassFX.setWaypoint(x, y, z);
    }
    
    @Override
    public void b(fd world, int x, int y, int z) { //onBlockRemoval
        compassFX.removeWaypoint(x, y, z);
    }

    public final void getCompassFX(Minecraft mc) {
        List textureList = null;
        try {
            textureList = (List)ModLoader.getPrivateValue( ji.class, mc.p, 6);
        } catch(Exception exc) {ModLoader.ThrowException("TextureList not set correctly", exc);}
        compassFX = (av)textureList.get(0);
    }
}
