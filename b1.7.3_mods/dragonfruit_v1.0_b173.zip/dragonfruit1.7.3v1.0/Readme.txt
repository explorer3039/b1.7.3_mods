Dragon Fruit v1.0 [for 1.7.3]
by mattop101


Thank-you for downloading my Dragon Fruit Mod.

Have you ever been low and health and desperatly trying to find food but seeing nothing but cactus?
Well now you can eat Dragon Fruit! Cactus have a small chance of dropping Dragon Fruit when destroyed. You can eat it straight away once you collect it! Dragon Fruit will heal 2 hearts of health but are not stackable.


How to install:
If you haven't already, install ModLoader. It can be found here:
http://www.minecraftforum.net/viewtopic.php?t=80246
Delete the 'META-INF' folder in 'minecraft.jar' if you haven't done so already.
Copy everything from the 'class' folder to your 'minecraft.jar'. This includes the 'mattop101' folder.


How to locate 'minecraft.jar':

1. Open the start menu
2. Type in "show hidden files" into the search box
3. Click on the "show hidden files and folders" option, should show up under control panel
4. Under "Hidden files and folders", select the option that says; "show hidden files, folders, and drives"
5. Close the folder options window
6. Open the start menu
7. Open "Computer" or "My Computer"
8. Double-click on the hard drive
9. Double-click on the "Users" folder
10. Double-click on the folder with your username
11. Double-click on the "AppData" folder
12. Double-click on the "Roaming" folder
13. Double-click on the ".minecraft" folder
14. Double-click on the "bin" folder

Enjoy!
-mattop101