package net.minecraft.src;

public class mod_PhobiaRelief extends BaseMod {
	@MLProp public static boolean noFiends = false;
	@MLProp public static boolean noMonsters = false;
	@MLProp public static boolean noLivestock = false;
	
	@MLProp public static boolean noSpiders = false;
	@MLProp public static boolean noZombies = false;
	@MLProp public static boolean noSkelies = false;
	@MLProp public static boolean noCreeper = false;
	
	@MLProp public static boolean noPigZom = false;
	@MLProp public static boolean noGhasts = false;
	
	@MLProp public static boolean noPigs = false;
	@MLProp public static boolean noCows = false;
	@MLProp public static boolean noSheep = false;
	@MLProp public static boolean noChick = false;
	
	@MLProp public static boolean noSquid = false;

	@Override
	public String Version() {
		return "Beta 1.7.3";
	}

	public mod_PhobiaRelief() {
		
		//Monsters
		if( noMonsters || noSpiders ) {
			ModLoader.RemoveSpawn(EntitySpider.class, EnumCreatureType.monster);
		}
		if( noMonsters || noZombies ) {
			ModLoader.RemoveSpawn(EntityZombie.class, EnumCreatureType.monster);
		}
		if( noMonsters || noSkelies ) {
			ModLoader.RemoveSpawn(EntitySkeleton.class, EnumCreatureType.monster);
		}
		if( noMonsters || noCreeper ) {
			ModLoader.RemoveSpawn(EntityCreeper.class, EnumCreatureType.monster);
		}
		
		//Fiends
		if( noFiends || noGhasts ) {
			ModLoader.RemoveSpawn(EntityGhast.class, EnumCreatureType.monster, new BiomeGenBase[] {BiomeGenBase.hell} );
		}
		if( noFiends || noPigZom ) {
			ModLoader.RemoveSpawn(EntityPigZombie.class, EnumCreatureType.monster, new BiomeGenBase[] {BiomeGenBase.hell} );
		}

		//Livestock
		if( noLivestock || noCows )
			ModLoader.RemoveSpawn(EntityCow.class, EnumCreatureType.creature);

		if( noLivestock || noPigs )
			ModLoader.RemoveSpawn(EntityPig.class, EnumCreatureType.creature);

		if( noLivestock || noSheep )
			ModLoader.RemoveSpawn(EntitySheep.class, EnumCreatureType.creature);

		if( noLivestock || noChick )
			ModLoader.RemoveSpawn(EntityChicken.class, EnumCreatureType.creature);
		
		//Fish
		if( noSquid )
			ModLoader.RemoveSpawn(EntitySquid.class, EnumCreatureType.waterCreature);
	}
}
