Put everything inside "Put in minecraft.jar" into .minecraft/bin/minecraft.jar

Put everything inside "Put in resources folder" into .minecraft/resources

Put Titans.properties file into .minecraft folder or let it generate but there won't be #comments

On instruction how to locate the minecraft.jar, go to
http://www.minecraftforum.net/topic/515037-/

Titans mod made by Will.eze (aka Willez)

Enjoy!

