Backup your minecraft.jar and saves best to be safe then sorry :)

Instructions:

Instal Single player version:

1. Open the "Single player" folder

2. Instal "ModLoader" and "ModLoaderMp client"

3. DELETE "Meta-INF" inside minecraft.jar 

4. Put all the files inside the "Goes into minecraft.jar" folder into your "/.minecraft/bin/minecraft.jar".

5. Put all the files inside the "Goes into mods folder" folder into you "/.minecraft/mods/CampCraft".

6. Open Tent.properties inside the "/.minecraft/mods/CampCraft folder" and change the block id if you got block id clash.

Instal Server version:

1: Open the "Server" Folder

2: Instal "ModLoaderMp server"

3: DO NOT DELTE "Meta-INF"

4: Put all the files inside the "Goes into minecraft_server.jar" folder into your minecraft_server.jar

5: Drag the "Tent.properties" file into the same folder as minecraft_server.jar

The recipes are in the "recipes" folder, their only temp recipes and if you have better ideas please send pm :)


Changing block ids

Make sure both client and server tent.properties block ids match or minecraft will crash


Links for ModLoader, ModLoaderMp Server and Client are on main post


Please post bugs or ideas you may have on this mod :)


Happy camping


