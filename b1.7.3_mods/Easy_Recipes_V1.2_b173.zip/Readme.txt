~~~~~How To install~~~~~
	
	Windows:
		1: Goto %appdata%/.minecraft/bin
		2: Open minecraft.jar with winrar or 7-zip
		3: move mod_easyRecipes.class into minecraft.jar
		4: delete META-INF
		5: close all windows
		6: start minecraft and enjoy!!

	Mac:
		Unknown

	Linux:
		Unknown


~~~~~Copyright~~~~~
This document is Copyright �(Goguy77) and is the intellectual
property of the author. Only Minecraftforum.net and mcmodcenter.net is able to host any of my material without my(Goguy77) consent. It may not be placed on any web site or otherwise distributed
publicly without advance written permission. If you mirror this mod page or anything I've(Goguy77) made on any other site, I(Goguy77) may express my angst at you in the form of a lawsuit.


~~~~~Currently Adds~~~~~~
grass
gravel 
sand
glowstone
cobblestone
netherrack
soulsand	