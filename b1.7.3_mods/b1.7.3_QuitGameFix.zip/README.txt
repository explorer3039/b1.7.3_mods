This is QuitGameFix for Minecraft Beta 1.7.3 Client

DESCRIPTION
This mod enables the Quit Game button on the main menu screen that is normally disabled for some reason

INSTALL
1. Install Modloader
2. Delete META-INF from the minecraft.jar
3. Insert this zip into the .minecraft/mods folder
4. ???
5. Success!