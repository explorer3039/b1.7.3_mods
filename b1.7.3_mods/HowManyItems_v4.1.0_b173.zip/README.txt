This is HowManyItems v4.1.0 for Minecraft Beta 1.7.3 Client

DESCRIPTION
TMI brought to 2019 standards:
- Left click on items for recipes.
- Right click on items for uses.
- Go to the previous recipe you searched with 'BACKSPACE'
- If your inventory contains all the items in a recipe you can click the '+' button to automatically fill the recipe in
- Feel free to configure the mod to your liking in the options: turn cheat mode on to spawn stuff in.
Modmakers can add their own tabs with addModTab(new Tab()) in mod_HowManyItems

INSTALL
1. Install Modloader
2. Delete META-INF from the minecraft.jar
3. Insert this zip into the .minecraft/mods folder
4. ???
5. Success!

SUPPORTED MODS
- IndustrialCraft2 v1.00 - Macerator, Extractor, Compressor, Canning Machine
- Aether Mod v1.02 - Enchanter, Freezer (Compatible with older/mp versions)
- Uranium Mod - Reactor
- Flan's Planes - Plane Workbench
- Buildcraft - Auto fill recipe support for Automatic Crafting Table

If you would like a mod to be supported or further support for an existing mod, feel free to ask me on the mod station discord @rek

TODO
- Code cleanup
- BTW recipe tabs
- EE recipe tabs
- More recipe tabs
- TMI style inventory loadouts
- MP commands for utility buttons
- Better icons

CREDIT
Original recipe book mods this was built upon - Risugami & Shockah
Creators of TMI, TMIRecipe, NEI & JEI for code, assets and layouts that were stolen for this mod.
References to relevant source code for Aether - mine_diver
Coding mastermind - me, rek

CHANGELOG
v4.1.0
- More items are now shown in the overlay (particularly from RedPower)
- Low quality icons added for tab order screen
- 'Auto' recipe viewer size changed to have equal width to parent screen
- Tooltips now show properly ontop of overlay
- Items not in overlay can now show item IDs
- Fixed compatibility issue with Tmim's Better Stained Glass mod
- Minor bugfixes

v4.0.0
- Mod is now a complete inventory editor instead of an 'addon' for TMI
- Colours fixed, gui no longer opens in sign editing (Thanks mine_diver, Meefy)

v3.0.1
- Gui no longer opens when user is in chat. (Thanks Meefy)
- Mod makers can now add their own tabs with addModTab(new Tab()) in mod_RecipeViewer
- Tabs can now be reordered or disabled in the config file.
- Icon and description added for mine_divers' Mod Menu.
- Code has been compiled in Java 6 =)

v3.0.0
- Items removed and mod now a client only JEI style recipe guide

v2.0
- Sloppy code -> legit code
- UI overhaul: instead of there being a seperate gui for each book, there is 1 combining the best of both
- Flan's plane crash when scrolling back is fixed
- ModLoaderMp is no longer required for those playing on single player
- Item & Gui IDs are now configurable

v1.1
- Huge code improvements despite a low difference for user
- Packets sent to server reduced
- Classes formalised and refined
- Indicator slot on book to show it cannot be moved
- Book textures swapped to match Risugami's book
- Book now retains item in filter slot until gui is closed
- Gui png no longer required, uses crafting table gui
- Item ID changed to not conflict with Risugami's book