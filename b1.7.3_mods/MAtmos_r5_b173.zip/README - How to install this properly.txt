   MAtmos
    More information on:
      Minecraftforum http://goo.gl/wLTaJ

ModLoader is required. ( http://www.minecraftforum.net/topic/75440-v166-risugamis-mods-updates/ )
ModLoader seems to break BetterGrass by the way.


You have to do two things:

Extract the >contents< of the folder "CLASSFILES" into (Roaming)/.minecraft/bin/Minecraft.jar
Do not forget to remove the META_INF folder.


Extract the >contents< of the folder "minecraft" into (Roaming)/.minecraft/


If you don't know what (Roaming) is nor what is the ".minecraft" folder, please look at the Official Thread on Minecraft forums (http://goo.gl/wLTaJ).*
There are descriptions for each operating system (Windows, Linux/UNIX/whatever-based incl. Mac)


Thank you for reading this file. If it doesn't work, please read the FAQ on the OP thread, or read the last pages of the thread.