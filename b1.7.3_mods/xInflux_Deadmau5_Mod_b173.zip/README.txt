this give you the same ears that deadmau5 has. but your skin needs
to have the ears on it so please download one of the base skins