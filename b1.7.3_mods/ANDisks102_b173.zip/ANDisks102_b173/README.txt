README!
This will tell you how to install my mod!

---Requirements---
You MUST have AudioMod and ModLoader installed.

---Steps---
1. Backup your bin
2. Open up your minecraft.jar with WinRAR archiver
3. Take everything from the "Add to minecraft jar" folder and put them inside the minecraft.jar
*You may now close minecraft.jar
4. Navigate to your .minecraft folder again
5. Take everything from the "Add to resources" and put them in the corresponding folder.
6. Delete the META-INF folder
7. Enjoy!