This is OldCustomLogo v1 for Minecraft Beta 1.7.3 Client

INTRO
This mod changes the logo to the old animated one from Beta 1.3
You can customise it in .minecraft/config/oldCustomLogo.cfg
You can disable it in .minecraft/config/ModLoader.cfg

INSTALL
1. Install Modloader
2. Insert the files from this .zip into the minecraft.jar
3. Delete META-INF from the minecraft.jar
4. ???
5. Sucess!

CREDIT
Mod creator - me, rek
Original port from 1.3 - Johnanater 
Fix for transparency issue - Dereku

COMPATIBILITY
This mod is incompatible with any mod that changes fu.class
It also seems to have an issue where the vanilla logo goes dark if the mod is disabled and Optifine is installed
If you find any issues please contact me (rek#5168) via the Modification Station discord (https://discord.gg/8Qky5XY)