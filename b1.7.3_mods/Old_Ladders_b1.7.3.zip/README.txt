Old Ladders for Beta 1.7.3 by Johnanater

This mod restores the old ladder physics where you could have a space inbetween them!

Just plop it in your minecraft.jar and delete META-INF!

All of the original code belongs to Mojang.