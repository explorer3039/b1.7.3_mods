package net.minecraft.src;

public class mod_Chainmail extends BaseMod {

	protected mod_Chainmail() {

        ModLoader.AddRecipe(new ItemStack(Item.helmetChain,1), new Object[] {	"IXI", "X X"
        	, Character.valueOf('X'), Item.leather, Character.valueOf('I'), Item.ingotIron
        });
        ModLoader.AddRecipe(new ItemStack(Item.plateChain, 1), new Object[] {	"I I", "IXI", "XXX"
        	, Character.valueOf('X'), Item.leather, Character.valueOf('I'), Item.ingotIron
        });
        ModLoader.AddRecipe(new ItemStack(Item.bootsChain, 1), new Object[] {	"X X", "I I"
        	, Character.valueOf('X'), Item.leather, Character.valueOf('I'), Item.ingotIron
        });
        ModLoader.AddRecipe(new ItemStack(Item.legsChain,  1), new Object[] {	"XXX", "I I", "X X"
        	, Character.valueOf('X'), Item.leather, Character.valueOf('I'), Item.ingotIron
        });

        ModLoader.AddRecipe(new ItemStack(Item.helmetChain,1), new Object[] {	"IXI"
        	, Character.valueOf('X'), Item.helmetLeather, Character.valueOf('I'), Item.ingotIron
        });
        ModLoader.AddRecipe(new ItemStack(Item.plateChain, 1), new Object[] {	"IXI"
        	, Character.valueOf('X'), Item.plateLeather,  Character.valueOf('I'), Item.ingotIron
        });
        ModLoader.AddRecipe(new ItemStack(Item.bootsChain, 1), new Object[] {	"IXI"
        	, Character.valueOf('X'), Item.bootsLeather,  Character.valueOf('I'), Item.ingotIron
        });
        ModLoader.AddRecipe(new ItemStack(Item.legsChain,  1), new Object[] {	"IXI"
        	, Character.valueOf('X'), Item.legsLeather,   Character.valueOf('I'), Item.ingotIron
        });
	}

	@Override
	public String Version() {
        return "Beta 1.6.6";
	}

}
