public class WorldProviderBiosphere extends xa {
	protected void a() {
		this.b = new BiosphereWeather(this.a);
	}

	public cl b() {
		return new BiosphereGen(this.a, this.a.s());
	}

	public boolean a(int paramInt1, int paramInt2) {
		int i = this.a.a(paramInt1, paramInt2);
		return i == uu.v.bn;
	}

	public float d() {
		return 0.0F;
	}
	
	public boolean f() {
		return false;
	}
}