import java.util.Random;

public class BiosphereWeather extends xv {
	private fd world;
	private Random rnd;

	public BiosphereWeather()
	{
		this.rnd = new Random();
	}

	public BiosphereWeather(fd paramWorld) {
		this.world = paramWorld;
		this.rnd = new Random(paramWorld.s());
	}

	private double getTemp(int paramInt1, int paramInt2) {
		int chunkX = paramInt1 >> 4;
		int chunkZ = paramInt2 >> 4;
		int midX = (chunkX - (int)Math.floor(Math.IEEEremainder(chunkX, mod_Biosphere.grid)) << 4) + 8;
		int midZ = (chunkZ - (int)Math.floor(Math.IEEEremainder(chunkZ, mod_Biosphere.grid)) << 4) + 8;

		if (this.world != null)
		{
			this.rnd.setSeed(this.world.s());
			long seedX = this.rnd.nextLong() / 2L * 2L + 1L;
			long seedZ = this.rnd.nextLong() / 2L * 2L + 1L;
			this.rnd.setSeed((midX * seedX + midZ * seedZ) * 7215145L ^ this.world.s());
		}

		return (this.rnd.nextDouble() + this.rnd.nextDouble()) / 2.0D;
	}

	private double getHumidity(int paramInt1, int paramInt2) {
		int chunkX = paramInt1 >> 4;
		int chunkZ = paramInt2 >> 4;
		int midX = (chunkX - (int)Math.floor(Math.IEEEremainder(chunkX, mod_Biosphere.grid)) << 4) + 8;
		int midZ = (chunkZ - (int)Math.floor(Math.IEEEremainder(chunkZ, mod_Biosphere.grid)) << 4) + 8;

		if (this.world != null)
		{
			this.rnd.setSeed(this.world.s());
			long seedX = this.rnd.nextLong() / 2L * 2L + 1L;
			long seedZ = this.rnd.nextLong() / 2L * 2L + 1L;
			this.rnd.setSeed((midX * seedX + midZ * seedZ) * 1551617761L ^ this.world.s());
		}

		return (this.rnd.nextDouble() + this.rnd.nextDouble()) / 2.0D;
	}

	public double b(int paramInt1, int paramInt2)
	{
		return getTemp(paramInt1, paramInt2);
	}

	public double[] a(double[] paramArrayOfDouble, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
	{
		if ((paramArrayOfDouble == null) || (paramArrayOfDouble.length < paramInt3 * paramInt4)) {
			paramArrayOfDouble = new double[paramInt3 * paramInt4];
		}

		double temp = getTemp(paramInt1, paramInt2);

		int i = 0;
		for (int j = 0; j < paramInt3; j++) {
			for (int k = 0; k < paramInt4; k++)
			{
				paramArrayOfDouble[i] = temp;
				i++;
			}

		}

		return paramArrayOfDouble;
	}

	public kd[] a(kd[] biomeArray, int x, int z, int width, int height)
	{
		if ((biomeArray == null) || (biomeArray.length < width * height)) {
			biomeArray = new kd[width * height];
		}

		this.a = new double[width * width];
		this.b = new double[width * width];

		double temp = getTemp(x, z);
		double humid = getHumidity(x, z);

		boolean isHell = this.rnd.nextInt(50) == 0;
		kd biome;
		if (isHell) biome = kd.l; else {
			biome = kd.a(temp, humid);
		}
		int i = 0;
		for (int j = 0; j < width; j++) {
			for (int k = 0; k < height; k++) {
				this.a[i] = temp;
				this.b[i] = humid;
				biomeArray[(i++)] = biome;
			}

		}

		return biomeArray;
	}
}