public class ItemBiospherePortal extends gm {
	protected ItemBiospherePortal(int itemID) {
		super(itemID); a(getClass().getName());
		bh = 79;
		bg = 1;
		
		ModLoader.AddName(this,"Biosphere Teleporter");
	}
	
	public int f(int damage) {
		return 0xff7777ff;
	}
	
	public iz a(iz stack, fd world, gs player) {
		DimensionBase.usePortal(getDimNumber());
		return stack;
	}

	public int getDimNumber() {
		return 2;
	}
}