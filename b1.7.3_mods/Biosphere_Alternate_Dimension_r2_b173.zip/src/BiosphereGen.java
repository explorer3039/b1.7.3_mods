import java.util.Random;

public class BiosphereGen implements cl {
	public final Random rndSphere;
	public final Random rndNoise;
	private fd world;
	private fv caveGen = new BiosphereCaveGen();
	private uf noiseGen;
	public int midX;
	public int midY;
	public int midZ;
	public int oreMidX;
	public int oreMidY;
	public int oreMidZ;
	public int lakeMidY;
	public double sphereRadius;
	public double lakeRadius;
	public double lakeEdgeRadius;
	public double noiseMin = 1.7976931348623157E+308D; public double noiseMax = 4.9E-324D;
	public kd biome;
	public boolean hasLake;
	public boolean lavaLake;
	public double[] noise = new double[256];

	static {
		kd.l.p = (kd.l.q = (byte)uu.bc.bn);

		if (mod_Biosphere.water_world) {
			uu.q[8] = 0;
			uu.q[9] = 0;
		}
	}

	public BiosphereGen(fd world, long seed) {
		this.rndSphere = new Random(seed);
		this.world = world;

		if (mod_Biosphere.noise) {
			this.rndNoise = new Random(seed);
			this.noiseGen = new uf(this.rndNoise, 4);
		} else {
			this.rndNoise = null;
		}
	}

	public void setRand(int chunkX, int chunkZ) {
		this.midX = ((chunkX - (int)Math.floor(Math.IEEEremainder(chunkX, mod_Biosphere.grid)) << 4) + 8);
		this.midZ = ((chunkZ - (int)Math.floor(Math.IEEEremainder(chunkZ, mod_Biosphere.grid)) << 4) + 8);

		this.oreMidX = (this.midX + mod_Biosphere.grid / 2 * 16 - mod_Biosphere.special);
		this.oreMidZ = (this.midZ + mod_Biosphere.grid / 2 * 16 - mod_Biosphere.special);

		this.rndSphere.setSeed(this.world.s());
		long seedX = this.rndSphere.nextLong() / 2L * 2L + 1L;
		long seedZ = this.rndSphere.nextLong() / 2L * 2L + 1L;
		long seed = (this.midX * seedX + this.midZ * seedZ) * 2512576L ^ this.world.s();
		this.rndSphere.setSeed(seed);

		this.sphereRadius = Math.round(16.0D + this.rndSphere.nextDouble() * 32.0D + this.rndSphere.nextDouble() * 16.0D);
		this.lakeRadius = Math.round(this.sphereRadius / 4.0D);
		this.lakeEdgeRadius = (this.lakeRadius + 2.0D);

		this.biome = this.world.a().a(chunkX << 4, chunkZ << 4);
		this.lavaLake = ((this.biome == kd.l) || ((this.biome != kd.k) && (this.rndSphere.nextInt(10) == 0)));
		this.hasLake = (this.rndSphere.nextInt(2) == 0);

		this.oreMidY = (mod_Biosphere.special + 1 + this.rndSphere.nextInt(127 - (mod_Biosphere.special + 1)));

		if (mod_Biosphere.noise) {
			setNoise(this.midX >> 4, this.midZ >> 4);
			this.noiseMin = 1.7976931348623157E+308D;
			for (int i = 0; i < this.noise.length; i++) {
				if (this.noise[i] < this.noiseMin)
				this.noiseMin = this.noise[i];
			}
			this.lakeMidY = (int)Math.round(64.0D + this.noiseMin * 8.0D);

			setNoise(chunkX, chunkZ);
		} else {
			this.lakeMidY = this.midY;
		}
	}

	public void setNoise(int chunkX, int chunkZ) {
		if (mod_Biosphere.noise) {
			double d1 = 0.0078125D;
			this.noise = this.noiseGen.a(this.noise, chunkX * 16, 109.0134D, chunkZ * 16, 16, 1, 16, d1, 1.0D, d1);
		}
	}

	public double getMainDistance(int x, int y, int z) {
		return Math.round(getDistance(x, y, z, this.midX, this.midY, this.midZ));
	}

	public double getOreDistance(int x, int y, int z) {
		return Math.round(getDistance(x, y, z, this.oreMidX, this.oreMidY, this.oreMidZ));
	}

	public int getSurfaceLevel(int x, int z) {
		if (mod_Biosphere.noise) return (int)Math.round(64.0D + this.noise[(z + x * 16)] * 8.0D);
		return 64;
	}

	public void preGenerateChunk(int chunkX, int chunkZ, byte[] blockArray) {
		int localChunkX = chunkX << 4;
		int localChunkZ = chunkZ << 4;

		for (int z = 0; z < 16; z++)
		for (int x = 0; x < 16; x++) {
			this.midY = getSurfaceLevel(x, z);
			for (int y = 127; y >= 0; y--)
			{
				double mainDistance = getMainDistance(localChunkX + x, y, localChunkZ + z);
				double oreDistance = getOreDistance(localChunkX + x, y, localChunkZ + z);

				int index = (x * 16 + z) * 128 + y;
				byte blockID = 0;

				if (y > this.midY) {
					if (mainDistance == this.sphereRadius) {
						if ((y >= this.midY + 4) || ((Math.abs(localChunkX + x - this.midX) > mod_Biosphere.bridge_size) && (Math.abs(localChunkZ + z - this.midZ) > mod_Biosphere.bridge_size)))
						blockID = mod_Biosphere.dome;
					} else if ((this.hasLake) && (mod_Biosphere.noise) && (this.biome != kd.h) && ((mainDistance == this.lakeRadius + 1.0D) || (mainDistance == this.lakeRadius + 2.0D))) {
						if (y == this.lakeMidY) blockID = this.biome.p;
						else if (y < this.lakeMidY)
						blockID = this.biome.q;
					} else if ((this.hasLake) && (mod_Biosphere.noise) && (this.biome != kd.h) && (mainDistance <= this.lakeRadius)) {
						if ((y == this.lakeMidY) && (this.biome == kd.k)) blockID = (byte)uu.aU.bn;
						else if (y <= this.lakeMidY)
						blockID = (byte)(this.lavaLake ? uu.D.bn : uu.B.bn);
					} else if ((mod_Biosphere.water_world) && (y <= this.midY + 4) && (mainDistance > this.sphereRadius) && (
								(Math.abs(localChunkX + x - this.midX) == mod_Biosphere.bridge_size) || (Math.abs(localChunkZ + z - this.midZ) == mod_Biosphere.bridge_size))) blockID = mod_Biosphere.dome;
					else if ((mod_Biosphere.water_world) && (y == this.midY + 4) && (mainDistance > this.sphereRadius) && (
								(Math.abs(localChunkX + x - this.midX) < mod_Biosphere.bridge_size) || (Math.abs(localChunkZ + z - this.midZ) < mod_Biosphere.bridge_size))) blockID = mod_Biosphere.dome;
					else if ((mod_Biosphere.water_world) && (y < this.midY + 4) && (mainDistance > this.sphereRadius) && (
								(Math.abs(localChunkX + x - this.midX) < mod_Biosphere.bridge_size) || (Math.abs(localChunkZ + z - this.midZ) < mod_Biosphere.bridge_size))) blockID = 0;
					else if ((mod_Biosphere.water_world) && (mainDistance > this.sphereRadius)) blockID = (byte)uu.C.bn;
					else if ((y == this.midY + 1) && (mainDistance > this.sphereRadius) && (
								(Math.abs(localChunkX + x - this.midX) == mod_Biosphere.bridge_size) || (Math.abs(localChunkZ + z - this.midZ) == mod_Biosphere.bridge_size)))
					blockID = mod_Biosphere.bridge_rail;
				}
				else if (mainDistance == this.sphereRadius)
				{
					blockID = (byte)uu.u.bn;
				} else if ((this.hasLake) && (this.biome != kd.h) && (mainDistance <= this.lakeRadius)) {
					if ((y == this.lakeMidY) && (this.biome == kd.k)) blockID = (byte)uu.aU.bn;
					else if (y <= this.lakeMidY)
					blockID = (byte)(this.lavaLake ? uu.D.bn : uu.B.bn);
				} else if ((this.hasLake) && (y < this.lakeMidY - 1) && (this.biome != kd.h) && (mainDistance <= this.lakeEdgeRadius)) blockID = (byte)(this.lavaLake ? uu.G.bn : uu.F.bn);
				else if (mainDistance < this.sphereRadius) {
					if (y == this.midY) blockID = this.biome.p;
					else if (y == this.midY - 1) blockID = this.biome.q; else
					blockID = (byte)uu.u.bn;
				} else if ((y == this.midY) && (mainDistance > this.sphereRadius) && (
							(Math.abs(localChunkX + x - this.midX) < mod_Biosphere.bridge_size + 1) || (Math.abs(localChunkZ + z - this.midZ) < mod_Biosphere.bridge_size + 1))) blockID = mod_Biosphere.bridge_support;
				else if ((mod_Biosphere.water_world) && (mainDistance > this.sphereRadius)) {
					blockID = (byte)uu.C.bn;
				}

				if (oreDistance <= mod_Biosphere.special) {
					int weight = this.rndSphere.nextInt(200);
					int id = uu.u.bn;
					if (weight < 1) id = uu.ax.bn;
					else if (weight < 2) {
						id = uu.O.bn;
					}
					blockID = (byte)id;
				}

				blockArray[index] = blockID;
			}
		}
	}

	public static final double getInverseDistance(double x1, double y1, double z1, double x2, double y2, double z2)
	{
		return Math.sqrt(-Math.pow(y2 - y1, 2.0D) + Math.pow(x2 - x1, 2.0D) + Math.pow(z2 - z1, 2.0D));
	}

	public static final double getDistance(double x1, double y1, double z1, double x2, double y2, double z2) {
		return Math.sqrt(Math.pow(y2 - y1, 2.0D) + Math.pow(x2 - x1, 2.0D) + Math.pow(z2 - z1, 2.0D));
	}

	public lm c(int chunkX, int chunkZ) {
		return b(chunkX, chunkZ);
	}

	public lm b(int chunkX, int chunkZ) {
		setRand(chunkX, chunkZ);

		byte[] blockArray = new byte[32768];

		lm chunk = new lm(this.world, blockArray, chunkX, chunkZ);
		preGenerateChunk(chunkX, chunkZ, blockArray);
		this.caveGen.a(this, this.world, chunkX, chunkZ, blockArray);

		chunk.c();

		return chunk;
	}

	public boolean a(int chunkX, int chunkZ) {
		return true;
	}

	public void a(cl paramcf, int chunkX, int chunkZ) {
		gk.a = true;

		int localChunkX = chunkX << 4;
		int localChunkZ = chunkZ << 4;

		this.biome = this.world.a().a(localChunkX, localChunkZ);

		this.rndSphere.setSeed(this.world.s());
		long seedX = this.rndSphere.nextLong() / 2L * 2L + 1L;
		long seedZ = this.rndSphere.nextLong() / 2L * 2L + 1L;
		this.rndSphere.setSeed(chunkX * seedX + chunkZ * seedZ ^ this.world.s());

		for (int i = 0; i < 8; i++) {
			int x = localChunkX + this.rndSphere.nextInt(16) + 8;
			int y = this.rndSphere.nextInt(64);
			int z = localChunkZ + this.rndSphere.nextInt(16) + 8;
			new er().a(this.world, this.rndSphere, x, y, z);
		}

		for (int i = 0; i < 10; i++) {
			int x = localChunkX + this.rndSphere.nextInt(16);
			int y = this.rndSphere.nextInt(64);
			int z = localChunkZ + this.rndSphere.nextInt(16);
			new ms(32).a(this.world, this.rndSphere, x, y, z);
		}

		for (int i = 0; i < 20; i++) {
			int x = localChunkX + this.rndSphere.nextInt(16);
			int y = this.rndSphere.nextInt(64);
			int z = localChunkZ + this.rndSphere.nextInt(16);
			new fl(uu.J.bn, 16).a(this.world, this.rndSphere, x, y, z);
		}

		for (int i = 0; i < 20; i++) {
			int x = localChunkX + this.rndSphere.nextInt(16);
			int y = this.rndSphere.nextInt(64);
			int z = localChunkZ + this.rndSphere.nextInt(16);
			new fl(uu.I.bn, 8).a(this.world, this.rndSphere, x, y, z);
		}

		for (int i = 0; i < 2; i++) {
			int x = localChunkX + this.rndSphere.nextInt(16);
			int y = this.rndSphere.nextInt(64);
			int z = localChunkZ + this.rndSphere.nextInt(16);
			new fl(uu.H.bn, 8).a(this.world, this.rndSphere, x, y, z);
		}

		for (int i = 0; i < 8; i++) {
			int x = localChunkX + this.rndSphere.nextInt(16);
			int y = this.rndSphere.nextInt(64);
			int z = localChunkZ + this.rndSphere.nextInt(16);
			new fl(uu.aO.bn, 7).a(this.world, this.rndSphere, x, y, z);
		}

		int j = 0;
		if (this.rndSphere.nextInt(10) == 0) {
			j++;
		}
		if (this.biome == kd.d) j += 5;
		else if (this.biome == kd.a) j += 5;
		else if (this.biome == kd.c) j += 2;
		else if (this.biome == kd.g) j += 5;
		else if (this.biome == kd.h) j -= 20;
		else if (this.biome == kd.k) j -= 20;
		else if (this.biome == kd.i)
		j -= 20;
		for (int i = 0; i < j; i++) {
			int x = localChunkX + this.rndSphere.nextInt(16) + 8;
			int z = localChunkZ + this.rndSphere.nextInt(16) + 8;
			pg treeGen = this.biome.a(this.rndSphere);
			treeGen.a(1.0D, 1.0D, 1.0D);
			treeGen.a(this.world, this.rndSphere, x, this.world.d(x, z), z);
		}
		for (int i = 0; i < 2; i++) {
			int x = localChunkX + this.rndSphere.nextInt(16) + 8;
			int y = this.rndSphere.nextInt(128);
			int z = localChunkZ + this.rndSphere.nextInt(16) + 8;
			new be(uu.ae.bn).a(this.world, this.rndSphere, x, y, z);
		}

		if (this.rndSphere.nextInt(2) == 0) {
			int x = localChunkX + this.rndSphere.nextInt(16) + 8;
			int y = this.rndSphere.nextInt(128);
			int z = localChunkZ + this.rndSphere.nextInt(16) + 8;
			new be(uu.af.bn).a(this.world, this.rndSphere, x, y, z);
		}

		if (this.rndSphere.nextInt(4) == 0) {
			int x = localChunkX + this.rndSphere.nextInt(16) + 8;
			int y = this.rndSphere.nextInt(128);
			int z = localChunkZ + this.rndSphere.nextInt(16) + 8;
			new be(uu.ag.bn).a(this.world, this.rndSphere, x, y, z);
		}

		if (this.rndSphere.nextInt(8) == 0) {
			int x = localChunkX + this.rndSphere.nextInt(16) + 8;
			int y = this.rndSphere.nextInt(128);
			int z = localChunkZ + this.rndSphere.nextInt(16) + 8;
			new be(uu.ah.bn).a(this.world, this.rndSphere, x, y, z);
		}

		if (mod_Biosphere.tall_grass) {
			j = 0;
			if (this.biome == kd.d)
			j = 2;
			if (this.biome == kd.a)
			j = 10;
			if (this.biome == kd.c)
			j = 2;
			if (this.biome == kd.g)
			j = 1;
			if (this.biome == kd.i)
			j = 10;
			for (int i = 0; i < j; i++) {
				int height = 1;

				if ((this.biome == kd.a) && (this.rndSphere.nextInt(3) != 0)) {
					height = 2;
				}
				int x = localChunkX + this.rndSphere.nextInt(16) + 8;
				int y = this.rndSphere.nextInt(128);
				int z = localChunkZ + this.rndSphere.nextInt(16) + 8;
				new ap(uu.Y.bn, height).a(this.world, this.rndSphere, x, y, z);
			}
		}

		for (int i = 0; i < 10; i++) {
			int x = localChunkX + this.rndSphere.nextInt(16) + 8;
			int y = this.rndSphere.nextInt(128);
			int z = localChunkZ + this.rndSphere.nextInt(16) + 8;
			new ir().a(this.world, this.rndSphere, x, y, z);
		}

		if (this.rndSphere.nextInt(32) == 0) {
			int x = localChunkX + this.rndSphere.nextInt(16) + 8;
			int y = this.rndSphere.nextInt(128);
			int z = localChunkZ + this.rndSphere.nextInt(16) + 8;
			new wx().a(this.world, this.rndSphere, x, y, z);
		}

		if (this.biome == kd.h) {
			for (int i = 0; i < this.rndSphere.nextInt(5); i++) {
				int x = localChunkX + this.rndSphere.nextInt(16) + 8;
				int y = this.midY;
				int z = localChunkZ + this.rndSphere.nextInt(16) + 8;
				new fx().a(this.world, this.rndSphere, x, y, z);
			}
		} else if (this.biome == kd.l) {
			if (this.rndSphere.nextBoolean()) {
				int x = localChunkX + this.rndSphere.nextInt(16) + 8;
				int y = this.midY;
				int z = localChunkZ + this.rndSphere.nextInt(16) + 8;
				new xs().a(this.world, this.rndSphere, x, y, z);
			}
		} else if ((this.biome == kd.k) || (this.biome == kd.g)) {
			setNoise(chunkX, chunkZ);
			for (int z = 0; z < 16; z++) {
				for (int x = 0; x < 16; x++) {
					this.midY = getSurfaceLevel(x, z);
					int adjustedX = x + localChunkX;
					int adjustedZ = z + localChunkZ;
					int y = this.midY + 1;

					double distance = getMainDistance(adjustedX, this.midY, adjustedZ);
					if ((distance > this.sphereRadius) || (!this.world.d(adjustedX, y, adjustedZ)) || (!this.world.f(adjustedX, y - 1, adjustedZ).c()) || 
							(this.world.f(adjustedX, y - 1, adjustedZ) == ln.s))
					{
						continue;
					}
					this.world.b(adjustedX, y, adjustedZ, uu.aT.bn, 0);
				}

			}

		}

		gk.a = false;
	}

	public boolean a(boolean paramBoolean, yb paramwr) {
		return true;
	}

	public boolean a() {
		return false;
	}

	public boolean b() {
		return true;
	}

	public String c() {
		return "RandomLevelSource";
	}
}