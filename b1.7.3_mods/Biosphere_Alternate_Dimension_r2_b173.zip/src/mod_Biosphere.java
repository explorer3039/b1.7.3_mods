public class mod_Biosphere extends BaseMod {
	public static final int itemOff = 256;
	
	@MLProp public static byte dome = 20, bridge_support = 5, bridge_rail = 85;
	@MLProp public static boolean noise = true, tall_grass = true, water_world = false;
	@MLProp public static int grid = 9, special = 7, lavaLevel = 24, bridge_size = 2;
	@MLProp public static int idItemBiosphereTeleporter = 4000;
	
	public static final uu bGLASS = uu.N;
	public static final gm iDIAMOND = gm.l;
	public static gm iPORTAL;
	
	public mod_Biosphere() {
		new DimensionBiosphere().name = "Biosphere";
		iPORTAL = new ItemBiospherePortal(idItemBiosphereTeleporter-itemOff);
		ModLoader.AddRecipe(new iz(iPORTAL),"GGG","GDG","GGG",'G',bGLASS,'D',iDIAMOND);
		
		try {
			Class.forName("EnumRarity");
			EnumRarity.setRarity(EnumRarity.Rare,iPORTAL);
		} catch (Exception e) {}
	}
	
	public String Version() {return "r2";}
}