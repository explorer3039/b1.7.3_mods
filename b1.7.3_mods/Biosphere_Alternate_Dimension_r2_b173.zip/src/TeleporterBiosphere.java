import java.util.ArrayList;
import java.util.Random;

public class TeleporterBiosphere extends ur {
	public void a(fd paramfd, sn entity) {
		if (b(paramfd, entity)) {
			return;
		}

		c(paramfd, entity);
		b(paramfd, entity);
	}

	public boolean b(fd world, sn entity) {
		int y, x = (int)Math.round(entity.aM-0.5D), z = (int)Math.round(entity.aO-0.5D);
		for (y = 125; y >= 0; y--) {
			uu block = uu.m[new Loc(x,y,z).getBlock(world)];
			if (block != null) if (block.bA.a() && block.bA != ln.p) {
				uu b1 = uu.m[new Loc(x,y+1,z).getBlock(world)], b2 = uu.m[new Loc(x,y+2,z).getBlock(world)];
				
				boolean isGood1 = b1 == null, isGood2 = b2 == null;
				if (!isGood1) isGood1 = !b1.bA.a();
				if (!isGood2) isGood2 = !b2.bA.a();
				
				if (isGood1 && isGood2) break;
			}
		}
		
		if (y <= 2) {
			y = 31+new Random().nextInt(64);
			if (mod_Biosphere.water_world) y = 64+(y/2);
			
			ArrayList<Loc> locs = new Loc(x,y,z).inRadius2D(3,true);
			for (Loc loc : locs) loc.setBlock(world,2);
			locs = new Loc(x,y-1,z).inRadius2D(2,true);
			for (Loc loc : locs) loc.setBlock(world,3);
			new Loc(x,y-2,z).setBlock(world,1);
		}
		
		entity.c(x+0.5D,y+1,z+0.5D,entity.aS,0F);
		entity.aP = entity.aQ = entity.aR = 0D;
		return true;
	}

	public boolean c(fd paramfd, sn entity) {
		return true;
	}
}