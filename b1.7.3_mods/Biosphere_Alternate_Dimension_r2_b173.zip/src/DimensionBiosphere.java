public class DimensionBiosphere extends DimensionBase {
	public DimensionBiosphere() {
		super(2,WorldProviderBiosphere.class,TeleporterBiosphere.class);
	}	
}