-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
	MultiplayerList
	version 1.7.3
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

Paste all .class files into your minecraft.jar

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Contact:
	Web:               	www.turael.claus-digital.de
	E-Mail:            	flap@hotmail.de
	Minecraftforum.net:     Turael

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
VersionLog:
	1.2 Adding some features + removed some crap
	1.1 Graphic Glitch fix
	1.0 Release
	
	