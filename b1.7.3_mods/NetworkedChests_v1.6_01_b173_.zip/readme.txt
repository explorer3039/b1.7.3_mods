Created by Watkins577, follow me on twitter for the latest updates here: www.twitter.com/#!/watkins577

Feel free to email me directly at watkins577@hotmail.com. Try to use an informative subject or I will most likely ignore it.

Put all the files/folders in the classes folder into minecraft.jar.

Put the properties folder in the .minecraft directory.

You can change the id of the block in the properties file.

Make sure you have modloader installed or this mod will not work.

If you get a black screen make sure you have deleted META-INF.

This document is Copyright �2012 Andrew Watkins (watkins577) and is the intellectual property of the author. It may be not be reproduced under any circumstances except for personal, private use as long as it remains in its unaltered, unedited form. It may not be placed on any web site or otherwise distributed publicly without advance written permission.