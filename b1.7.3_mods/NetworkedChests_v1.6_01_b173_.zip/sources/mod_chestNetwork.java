package net.minecraft.src;

import java.util.*;
import java.io.*;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;

import net.minecraft.client.Minecraft;
 
	public class mod_chestNetwork extends BaseMod {
	
		public static Block chestN;
		public int chestNid = 127;
		public static int chestNindex;
		public int updateTicks = 0;
		private static StepSound soundWoodFootstep;
		private static String curWorld = "";
		public static int chestNRenderID;
		
		static {
			soundWoodFootstep = new StepSound("wood", 1.0F, 1.0F);
			chestNindex = ModLoader.addOverride("/terrain.png", "/chestNetworkImages/chestTop.png");
		}
		
		public mod_chestNetwork() {
		}
		
		public String getVersion()
		{
			return "2.0";
		}
		
		public boolean onTickInGame(float tick, net.minecraft.client.Minecraft game) {
			if (curWorld != game.theWorld.worldInfo.getWorldName()) {
				System.out.println("Test");
				updateTicks = 0;
				curWorld = game.theWorld.worldInfo.getWorldName();
				BlockChestNetwork.amount = new HashMap<String, Integer>();
				BlockChestNetwork.chestContents = new HashMap<String, ItemStack[]>();
				BlockChestNetwork.networks = new ArrayList<String>();
				if (!game.theWorld.isNewWorld) {
					File file = new File(Minecraft.getMinecraftDir().getAbsolutePath(), "ntwch_" + curWorld + ".dat");
					if (file.exists()) {
						try {
							FileInputStream fileinp = new FileInputStream(file);
							NBTTagCompound comp = CompressedStreamTools.readCompressed(fileinp);
							BlockChestNetwork.readContents(comp.getTagList("Ntwch"));
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				}
				//load
			}
			updateTicks++;
			if (updateTicks%100 == 0) {
				saveChests();
			}
			return true;
		}
		
		public static void saveChests()
		{
			File file = new File(Minecraft.getMinecraftDir().getAbsolutePath(), "ntwch_" + curWorld + ".dat");
			File file1 = new File(Minecraft.getMinecraftDir().getAbsolutePath(), "tmp_ntwch_" + curWorld + ".dat");
			try {
				FileOutputStream fileout = new FileOutputStream(file1);
				NBTTagList tag = new NBTTagList();
				BlockChestNetwork.saveContents(tag);
				NBTTagCompound comp = new NBTTagCompound();
				comp.setTag("Ntwch", tag);
				CompressedStreamTools.writeCompressed(comp, fileout);
				if (file.exists()) {
					file.delete();
				}
				file1.renameTo(file);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		public void load()
		{
			System.out.println("Tracing");
			ModLoader.setInGameHook(this, true, true);
			String mcPath = (new File(Minecraft.getMinecraftDir(), "properties")).getAbsolutePath();
			Properties applicationProps = new Properties();
			FileInputStream in;
			/*FileOutputStream out;
			try {
				out = new FileOutputStream(mcPath+"\\Net-chest.properties");
				try {
					applicationProps.setProperty("Chest-ID", chestNid+"");
					applicationProps.store(out, "Networked Chest Properties");
					out.close();
				} catch (IOException e) {
					System.out.println(e.toString());
				}
			} catch (FileNotFoundException e) {
				System.out.println(e.toString());
			}*/
			try {
				in = new FileInputStream(mcPath+"\\Net-chest.properties");
				try {
					applicationProps.load(in);
					in.close();
					try {
						chestNid = Integer.parseInt(applicationProps.getProperty("Chest-ID"));
					} catch (Exception e) {
						chestNid = 127;
						System.out.println(e.toString());
					}
				} catch (IOException e) {
					chestNid = 127;
					System.out.println(e.toString());
				}
			} catch (FileNotFoundException e) {
				chestNid = 127;
				System.out.println(e.toString());
			}
			
			chestN = (new BlockChestNetwork(this, chestNid).setHardness(2.5F).setStepSound(soundWoodFootstep).setBlockName("networked chest"));
			chestNRenderID = ModLoader.getUniqueBlockModelID(this, true);

			ModLoader.registerBlock(chestN);
			ModLoader.addName(chestN, "Networked Chest");
			
			ModLoader.addRecipe(new ItemStack(chestN), new Object[] {
				"#", "x", Character.valueOf('#'), Block.chest, Character.valueOf('x'), Item.redstone
			});
			
			ModLoader.registerTileEntity(TileEntityNetworkedChest.class, "Networked Chest", new TileEntityNetworkedChestRenderer());
		}
	
		public void renderInvBlock(RenderBlocks renderblocks, Block block, int i, int j)
		{
			if (j == chestNRenderID)
			{
				TileEntityRenderer.instance.renderTileEntityAt(new TileEntityNetworkedChest(), 0.0D, 0.0D, 0.0D, 0.0F);
				//GL11.glEnable(GL12.GL_RESCALE_NORMAL);
			}
		}
    }
