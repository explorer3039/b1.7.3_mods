package net.minecraft.src;

import java.util.List;
import java.util.Map;

import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

public class GuiNetworkedChest extends GuiScreen {
	
	private GuiTextField textBoxName;
	private TileEntityNetworkedChest nchest;
	private String screenTitle = "Enter Network Name";
	private static final String allowedCharacters;
	
	public GuiNetworkedChest(TileEntityNetworkedChest tileEntity)
	{
		nchest = tileEntity;
	}
	
	public void initGui()
	{
		controlList.clear();
		Keyboard.enableRepeatEvents(true);
		controlList.add(new GuiButton(0, width / 2 - 100, height / 4 + 120, "Done"));
		textBoxName = new GuiTextField(fontRenderer, width / 2 - 100, 60, 200, 20);
		textBoxName.func_50033_b(true);
		textBoxName.setMaxStringLength(15);
	}
	
	public void onGuiClosed()
	{
		Keyboard.enableRepeatEvents(false);
		nchest.network = textBoxName.getText();
		if (BlockChestNetwork.networks.indexOf(nchest.network) == -1) {
			BlockChestNetwork.networks.add(nchest.network);
			BlockChestNetwork.amount.put(nchest.network, 1);
			BlockChestNetwork.chestContents.put(nchest.network, new ItemStack[27]);
		} else if (BlockChestNetwork.amount.get(nchest.network) == 0) {
			BlockChestNetwork.amount.put(nchest.network, 1);
			BlockChestNetwork.chestContents.put(nchest.network, new ItemStack[27]);
		} else {
			BlockChestNetwork.amount.put(nchest.network, BlockChestNetwork.amount.get(nchest.network)+1);
		}
		System.out.println(nchest.network + "\r" + textBoxName.getText());
	}
	
	public void updateScreen()
	{
		textBoxName.updateCursorCounter();
	}
	
	protected void actionPerformed(GuiButton guibutton)
    {
        if(!guibutton.enabled)
        {
            return;
        }
        if(guibutton.id == 0)
        {
            mc.displayGuiScreen(null);
        }
    }
	
	public void drawScreen(int i, int j, float f)
	{
		drawDefaultBackground();
		drawCenteredString(fontRenderer, screenTitle, width/2, 40, 0xffffff);
		textBoxName.drawTextBox();
		super.drawScreen(i, j, f);
	}
	
	protected void keyTyped(char c, int i)
	{
		if (c == '\r') {
			actionPerformed((GuiButton)controlList.get(0));
		}
		if (allowedCharacters.indexOf(c) >= 0 || i == 14) {
			textBoxName.func_50037_a(c, i);
		}
	}
	
	static 
    {
        allowedCharacters = ChatAllowedCharacters.allowedCharacters;
    }

}
