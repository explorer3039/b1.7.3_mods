package net.minecraft.src;
// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

import java.util.*;

public class TileEntityNetworkedChest extends TileEntity
    implements IInventory
{
	

    public TileEntityNetworkedChest()
    {
		network = "";
		/*BlockChestNetwork.amount = new HashMap<String, Integer>();
		BlockChestNetwork.amount.put("simple", 0);
		BlockChestNetwork.chestContents = new HashMap<String, ItemStack[]>();
		BlockChestNetwork.chestContents.put("simple", new ItemStack[27]);
		BlockChestNetwork.networks = new ArrayList<String>();
		BlockChestNetwork.networks.add("simple");*/
    }

    public int getSizeInventory()
    {
        return 27;
    }

    public ItemStack getStackInSlot(int i)
    {
    	ItemStack slotItem = BlockChestNetwork.chestContents.get(network)[i];
        return slotItem;
    }

    public ItemStack decrStackSize(int i, int j)
    {
        if(BlockChestNetwork.chestContents.get(network)[i] != null)
        {
            if(BlockChestNetwork.chestContents.get(network)[i].stackSize <= j)
            {
                ItemStack itemstack = BlockChestNetwork.chestContents.get(network)[i];
                BlockChestNetwork.chestContents.get(network)[i] = null;
                onInventoryChanged();
                return itemstack;
            }
            ItemStack itemstack1 = BlockChestNetwork.chestContents.get(network)[i].splitStack(j);
            if(BlockChestNetwork.chestContents.get(network)[i].stackSize == 0)
            {
                BlockChestNetwork.chestContents.get(network)[i] = null;
            }
            onInventoryChanged();
            return itemstack1;
        } else
        {
            return null;
        }
    }

    public void setInventorySlotContents(int i, ItemStack itemstack)
    {
        BlockChestNetwork.chestContents.get(network)[i] = itemstack;
        if(itemstack != null && itemstack.stackSize > getInventoryStackLimit())
        {
            itemstack.stackSize = getInventoryStackLimit();
        }
        onInventoryChanged();
    }
    
    public void onInventoryChanged() {
    	super.onInventoryChanged();
    	mod_chestNetwork.saveChests();
    }

    public String getInvName()
    {
        return "Networked Chest: " + network;
    }

    public void readFromNBT(NBTTagCompound nbttagcompound)
    {
		super.readFromNBT(nbttagcompound);
        network = nbttagcompound.getString("Network");
		//NBTTagList nbttaglist1 = nbttagcompound.getTagList("ChestN");
		//BlockChestNetwork.readContents(nbttaglist1);

    }

    public void writeToNBT(NBTTagCompound nbttagcompound)
    {
        super.writeToNBT(nbttagcompound);
        nbttagcompound.setString("Network", network);
        //NBTTagList nbttags= new NBTTagList();
		//nbttagcompound.setTag("ChestN", BlockChestNetwork.saveContents(nbttags));
    }

    public int getInventoryStackLimit()
    {
        return 64;
    }

    public boolean isUseableByPlayer(EntityPlayer entityplayer)
    {
        if(worldObj.getBlockTileEntity(xCoord, yCoord, zCoord) != this)
        {
            return false;
        }
        return entityplayer.getDistanceSq((double)xCoord + 0.5D, (double)yCoord + 0.5D, (double)zCoord + 0.5D) <= 64D;
    }
	
	public void closeChest()
	{
	}
	
	public void openChest()
	{
	}
	
	public String network;
	
	public ItemStack getStackInSlotOnClosing(int i) {
		ItemStack selected = BlockChestNetwork.chestContents.get(network)[i];
		if (selected != null)
        {
            selected = null;
            return selected;
        }
        return null;
	}

}
