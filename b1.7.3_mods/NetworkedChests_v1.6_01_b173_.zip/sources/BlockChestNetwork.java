package net.minecraft.src;

import java.util.*;

public class BlockChestNetwork extends BlockContainer {
	
	static Map<String, Integer> amount;
	private Random random;
	static Map<String, ItemStack[]> chestContents;
	static List<String> networks;
	static String worldname;
	static boolean loaded;
	private BaseMod base;
	
	static {
		loaded = false;
	}
	
	protected BlockChestNetwork (BaseMod _base, int i) {
		super (i, Material.wood);
		base = _base;
		random = new Random();
		blockIndexInTexture = 26;
		/*System.out.println("Loaded: "+loaded);
		if (!loaded) {
			//amount = new HashMap<String, Integer>();
			//chestContents = new HashMap<String, ItemStack[]>();
			//networks = new ArrayList<String>();
			loaded = true;
		}
		System.out.println("Loaded: "+loaded);*/
	}
	
	public boolean renderAsNormalBlock()
    {
        return false;
    }
	
	public boolean isOpaqueCube()
    {
        return false;
    }
	
	public int getRenderType()
    {
        return mod_chestNetwork.chestNRenderID;
    }
	
	public int getBlockTexture(IBlockAccess iblockaccess, int i, int j, int k, int l)
    {
        if(l == 1)
        {
            return mod_chestNetwork.chestNindex;
        }
        if(l == 0)
        {
            return blockIndexInTexture - 1;
        }
        int i1 = iblockaccess.getBlockId(i, j, k - 1);
        int j1 = iblockaccess.getBlockId(i, j, k + 1);
        int k1 = iblockaccess.getBlockId(i - 1, j, k);
        int l1 = iblockaccess.getBlockId(i + 1, j, k);
        byte byte0 = 3;
        if(Block.opaqueCubeLookup[i1] && !Block.opaqueCubeLookup[j1])
        {
            byte0 = 3;
        }
        if(Block.opaqueCubeLookup[j1] && !Block.opaqueCubeLookup[i1])
        {
            byte0 = 2;
        }
        if(Block.opaqueCubeLookup[k1] && !Block.opaqueCubeLookup[l1])
        {
            byte0 = 5;
        }
        if(Block.opaqueCubeLookup[l1] && !Block.opaqueCubeLookup[k1])
        {
            byte0 = 4;
        }
        return l != byte0 ? blockIndexInTexture : blockIndexInTexture + 1;
	}
	
	public int getBlockTextureFromSide(int i)
    {
        if(i == 1)
        {
            return mod_chestNetwork.chestNindex;
        }
        if(i == 0)
        {
            return blockIndexInTexture - 1;
        }
        if(i == 3)
        {
            return blockIndexInTexture + 1;
        } else
        {
            return blockIndexInTexture;
        }
    }
	
	static public NBTTagList saveContents(NBTTagList nbttaglist) {
		System.out.println("NBT Loaded save: " + loaded);
		NBTTagCompound nbtcomp = new NBTTagCompound();
		NBTTagList nbtnets = new NBTTagList();
		for (int i = 0; i < networks.size(); i++) {
			nbtnets.appendTag(new NBTTagString(networks.get(i), networks.get(i)));
			System.out.println(new NBTTagString(networks.get(i)));
		}
		nbtcomp.setTag("Networks", nbtnets);
		for (String n : networks) {
			System.out.println(amount.get(n));
			
			NBTTagList nbtlist = new NBTTagList();
			for (int i = 0; i < chestContents.get(n).length; i++) {
				if (chestContents.get(n)[i] != null) {
					NBTTagCompound nbttagcompound = new NBTTagCompound();
					nbttagcompound.setByte("Slot", (byte)i);
					chestContents.get(n)[i].writeToNBT(nbttagcompound);
					nbtlist.appendTag(nbttagcompound);
					System.out.println(chestContents.get(n)[i]);
				}
			}
			nbtcomp.setTag(n+"Contents", nbtlist);	
			nbtcomp.setInteger(n+"Amount", amount.get(n));
			
			
		}
		nbttaglist.appendTag(nbtcomp);
		System.out.println(nbtcomp);
		return nbttaglist;
	}
	
	static public void readContents(NBTTagList nbttaglist) {
		System.out.println(loaded);
		chestContents = new HashMap<String, ItemStack[]>();
		amount = new HashMap<String, Integer>();
		networks = new ArrayList<String>();
		NBTTagCompound nbtcomp = (NBTTagCompound)nbttaglist.tagAt(0);
		NBTTagList nbtnets = nbtcomp.getTagList("Networks");
		for (int i = 0; i < nbtnets.tagCount(); i++) {
			networks.add(((NBTTagString)nbtnets.tagAt(i)).toString());
		}
		for (int j = 0; j < networks.size(); j++) {
			NBTTagList nbttag = nbtcomp.getTagList(networks.get(j)+"Contents");
			ItemStack chest[] = new ItemStack[27];
			for (int i = 0; i < nbttag.tagCount(); i++) {
				NBTTagCompound nbttagcompound = (NBTTagCompound)nbttag.tagAt(i);
				int k = nbttagcompound.getByte("Slot") & 0xff;
				ItemStack itemstack = ItemStack.loadItemStackFromNBT(nbttagcompound);
				if (itemstack.getItem() == null) {
					continue;
				}
				if (k >= 0 && k < chest.length) {
					chest[k] = itemstack;
				}
			}
			chestContents.put(networks.get(j), chest);
			amount.put(networks.get(j), nbtcomp.getInteger(networks.get(j)+"Amount"));
		}
	}
	
	public TileEntity getBlockEntity()
	{
		return new TileEntityNetworkedChest();
	}
	
	public void onBlockPlacedBy(World world, int i, int j, int k, EntityLiving entityliving)
    {
		TileEntityNetworkedChest nchest = (TileEntityNetworkedChest)world.getBlockTileEntity(i, j, k);
		
		byte byte0 = 0;
        int i1 = MathHelper.floor_double((double)((entityliving.rotationYaw * 4F) / 360F) + 0.5D) & 3;

        if (i1 == 0)
        {
            byte0 = 2;
        }

        if (i1 == 1)
        {
            byte0 = 5;
        }

        if (i1 == 2)
        {
            byte0 = 3;
        }

        if (i1 == 3)
        {
            byte0 = 4;
        }
        
        world.setBlockMetadataWithNotify(i, j, k, byte0);
        
		if (entityliving.entityType.equals("humanoid")) {
			ModLoader.openGUI((EntityPlayer)entityliving, new GuiNetworkedChest(nchest));
			System.out.println(nchest.network);
		}
    }
	
	public boolean blockActivated(World world, int i, int j, int k, EntityPlayer entityplayer)
	{
		Object obj = (TileEntityNetworkedChest)world.getBlockTileEntity(i, j, k);
		
		entityplayer.displayGUIChest(((IInventory) (obj)));
		return true;
	}
	
	/*public void onNeighborBlockChange(World world, int i, int j, int k, int l)
    {
		TileEntityNetworkedChest nchest = (TileEntityNetworkedChest)world.getBlockTileEntity(i, j, k);
		if (l == Block.signWall.blockID) {
			TileEntitySign sign = (TileEntitySign)world.getBlockTileEntity(i, j+1, k);
			amount.put(nchest.network, amount.get(nchest.network)-1);
			if (amount.get(nchest.network) == 0) {
label0:
				for(int m = 0; m < nchest.getSizeInventory(); m++)
				{
					ItemStack itemstack = nchest.getStackInSlot(m);
					if(itemstack == null)
					{
						continue;
					}
					float f = random.nextFloat() * 0.8F + 0.1F;
					float f1 = random.nextFloat() * 0.8F + 0.1F;
					float f2 = random.nextFloat() * 0.8F + 0.1F;
					do
					{
						if(itemstack.stackSize <= 0)
						{
							continue label0;
						}
						int i1 = random.nextInt(21) + 10;
						if(i1 > itemstack.stackSize)
						{
							i1 = itemstack.stackSize;
						}
						itemstack.stackSize -= i1;
						EntityItem entityitem = new EntityItem(world, (float)i + f, (float)j + f1, (float)k + f2, new ItemStack(itemstack.itemID, i1, itemstack.getItemDamage()));
						float f3 = 0.05F;
						entityitem.motionX = (float)random.nextGaussian() * f3;
						entityitem.motionY = (float)random.nextGaussian() * f3 + 0.2F;
						entityitem.motionZ = (float)random.nextGaussian() * f3;
						world.entityJoinedWorld(entityitem);
					} while(true);
				}
			}				
			nchest.network = sign.signText[0];
			if (networks.indexOf(nchest.network) == -1) {
				networks.add(nchest.network);
				amount.put(nchest.network, 1);
				chestContents.put(nchest.network, new ItemStack[27]);
			} else if (amount.get(nchest.network) == 0) {
				amount.put(nchest.network, 1);
				chestContents.put(nchest.network, new ItemStack[27]);
			} else {
				amount.put(nchest.network, amount.get(nchest.network)+1);
			}
			System.out.println("Network '"+nchest.network+"'");
		} else if (nchest.network != "simple") {
			amount.put(nchest.network, amount.get(nchest.network)-1);
			if (amount.get(nchest.network) == 0) {
label1:
				for(int m = 0; m < nchest.getSizeInventory(); m++)
				{
					ItemStack itemstack = nchest.getStackInSlot(m);
					if(itemstack == null)
					{
						continue;
					}
					float f = random.nextFloat() * 0.8F + 0.1F;
					float f1 = random.nextFloat() * 0.8F + 0.1F;
					float f2 = random.nextFloat() * 0.8F + 0.1F;
					do
					{
						if(itemstack.stackSize <= 0)
						{
							continue label1;
						}
						int i1 = random.nextInt(21) + 10;
						if(i1 > itemstack.stackSize)
						{
							i1 = itemstack.stackSize;
						}
						itemstack.stackSize -= i1;
						EntityItem entityitem = new EntityItem(world, (float)i + f, (float)j + f1, (float)k + f2, new ItemStack(itemstack.itemID, i1, itemstack.getItemDamage()));
						float f3 = 0.05F;
						entityitem.motionX = (float)random.nextGaussian() * f3;
						entityitem.motionY = (float)random.nextGaussian() * f3 + 0.2F;
						entityitem.motionZ = (float)random.nextGaussian() * f3;
						world.entityJoinedWorld(entityitem);
					} while(true);
				}
			}				
			nchest.network = "simple";
			if (networks.indexOf(nchest.network) == -1) {
				networks.add(nchest.network);
				amount.put(nchest.network, 1);
				chestContents.put(nchest.network, new ItemStack[27]);
			} else if (amount.get(nchest.network) == 0) {
				amount.put(nchest.network, 1);
				chestContents.put(nchest.network, new ItemStack[27]);
			} else {
				amount.put(nchest.network, amount.get(nchest.network)+1);
			}
			System.out.println("Network '"+nchest.network+"'");
		}
			
    }*/
		
	public void onBlockRemoval(World world, int i, int j, int k)
    {
        TileEntityNetworkedChest tileentitychest = (TileEntityNetworkedChest)world.getBlockTileEntity(i, j, k);

		if (amount.get(tileentitychest.network) == 1) {
label0:
			for(int l = 0; l < tileentitychest.getSizeInventory(); l++)
			{
				ItemStack itemstack = tileentitychest.getStackInSlot(l);
				if(itemstack == null)
				{
					continue;
				}
				float f = random.nextFloat() * 0.8F + 0.1F;
				float f1 = random.nextFloat() * 0.8F + 0.1F;
				float f2 = random.nextFloat() * 0.8F + 0.1F;
				do
				{
					if(itemstack.stackSize <= 0)
					{
						continue label0;
					}
					int i1 = random.nextInt(21) + 10;
					if(i1 > itemstack.stackSize)
					{
						i1 = itemstack.stackSize;
					}
					itemstack.stackSize -= i1;
					EntityItem entityitem = new EntityItem(world, (float)i + f, (float)j + f1, (float)k + f2, new ItemStack(itemstack.itemID, i1, itemstack.getItemDamage()));
					float f3 = 0.05F;
					entityitem.motionX = (float)random.nextGaussian() * f3;
					entityitem.motionY = (float)random.nextGaussian() * f3 + 0.2F;
					entityitem.motionZ = (float)random.nextGaussian() * f3;
					if(itemstack.hasTagCompound())
                    {
                        entityitem.item.setTagCompound((NBTTagCompound)itemstack.getTagCompound().copy());
                    }
					world.spawnEntityInWorld(entityitem);
				} while(true);
			}
		}
		
		amount.put(tileentitychest.network, amount.get(tileentitychest.network)-1);
		
        super.onBlockRemoval(world, i, j, k);
    }
}
